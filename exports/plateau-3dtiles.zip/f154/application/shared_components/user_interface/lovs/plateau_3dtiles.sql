prompt --application/shared_components/user_interface/lovs/plateau_3dtiles
begin
--   Manifest
--     PLATEAU_3DTILES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>154
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(61405210813144895)
,p_lov_name=>'PLATEAU_3DTILES'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'PLATEAU_3DTILES'
,p_query_where=>'has_coordinate = ''Y'''
,p_return_column_name=>'URL'
,p_display_column_name=>'URL'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'URL'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(61406225664243522)
,p_query_column_name=>'URL'
,p_heading=>'URL'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(61406696124243522)
,p_query_column_name=>'LAT'
,p_heading=>'Lat'
,p_display_sequence=>20
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(61407074147243522)
,p_query_column_name=>'LON'
,p_heading=>'Lon'
,p_display_sequence=>30
,p_data_type=>'NUMBER'
);
wwv_flow_imp.component_end;
end;
/
