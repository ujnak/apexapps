prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>154
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'PLATEAU 3DTiles'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cesium.com/downloads/cesiumjs/releases/1.90/Build/Cesium/Cesium.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// Cesium Ion\306E\8AAD\307F\8FBC\307F\6307\5B9A'),
'Cesium.Ion.defaultAccessToken = "&G_TOKEN.";',
unistr('// Terrain\306E\6307\5B9A\FF08EGM96\3001\56FD\571F\6570\5024\60C5\58315m\6A19\9AD8\304B\3089\751F\6210\3057\305F\5168\56FD\306E\5730\5F62\30E2\30C7\30EB\30015m\6A19\9AD8\30C7\30FC\30BF\304C\7121\3044\5834\6240\306F10m\6A19\9AD8\3067\88DC\5B8C\3057\3066\3044\308B\FF09'),
'var viewer = new Cesium.Viewer("cesiumContainer", {',
'    terrainProvider: new Cesium.CesiumTerrainProvider({',
'        url: Cesium.IonResource.fromAssetId(&G_ASSET_ID.)',
'    })',
'});',
'',
'/*',
unistr(' * \30C7\30D5\30A9\30EB\30C8\3068\3057\3066\5343\4EE3\7530\533A\3092\9078\629E\3059\308B\3002'),
' */',
'if (!apex.items.P1_3DTILES.getValue()) {',
'    const defaultUrl = "https://plateau.geospatial.jp/main/data/3d-tiles/bldg/13100_tokyo/13101_chiyoda-ku/notexture/tileset.json";',
'    apex.items.P1_3DTILES.setValue(defaultUrl, defaultUrl, false);',
'    apex.items.P1_LAT.setValue(35.6872261, null, true);',
'    apex.items.P1_LON.setValue(139.75657399, null, true);',
'}',
'',
unistr('// \5EFA\7269\30C7\30FC\30BF\FF083D Tiles\FF09'),
'var your_3d_tiles = viewer.scene.primitives.add(new Cesium.Cesium3DTileset({',
'    url : apex.items.P1_3DTILES.getValue()',
'}));',
'',
unistr('// \30AB\30E1\30E9\306E\521D\671F\4F4D\7F6E\306E\6307\5B9A'),
'viewer.camera.setView({',
'    destination : Cesium.Cartesian3.fromDegrees(',
'        apex.items.P1_LON.getValue(),',
'        apex.items.P1_LAT.getValue(),',
'        5000.0)',
'});'))
,p_css_file_urls=>'https://cesium.com/downloads/cesiumjs/releases/1.90/Build/Cesium/Widgets/widgets.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#cesiumContainer {',
'    position: absolute;',
'    top: 0;',
'    left: 0;',
'    height: 100%;',
'    width: 100%;',
'    margin: 0;',
'    overflow: hidden;',
'    padding: 0;',
'    font-family: sans-serif;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230308050419'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60892210908522148)
,p_plug_name=>'3D Tiles'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h640:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(61254302298774530)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<div id="cesiumContainer"></div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60892369998522149)
,p_name=>'P1_3DTILES'
,p_is_required=>true
,p_item_sequence=>10
,p_prompt=>'3D Tiles'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'PLATEAU_3DTILES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(61358478810774606)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_10=>'LAT:P1_LAT,LON:P1_LON'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60892455089522150)
,p_name=>'P1_LAT'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61407890362313101)
,p_name=>'P1_LON'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61407928912313102)
,p_name=>unistr('\5EFA\7269\30C7\30FC\30BF\306E\5909\66F4')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_3DTILES'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61408097791313103)
,p_event_id=>wwv_flow_imp.id(61407928912313102)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
