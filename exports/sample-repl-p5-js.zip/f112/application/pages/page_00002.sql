prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>112
,p_default_id_offset=>17196233140886825
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Sketch'
,p_alias=>'SKETCH'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Sketch'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/p5@2.0.5/lib/p5.min.js'
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'800'
,p_dialog_chained=>'N'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17180631155694748)
,p_plug_name=>'Sketch'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script nonce="#APEX_CSP_NONCE_VALUE#">',
'// Change default parent element implicitly.',
'const createCanvas = function(w, h) {',
'    const cnv = window.createCanvas(w, h);',
'    cnv.parent("canvas-container"); ',
'    return cnv;',
'};',
'&P2_CODE!RAW.',
'</script>',
'<div id="canvas-container"></div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17180431287694746)
,p_name=>'P2_CODE'
,p_data_type=>'CLOB'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32960604751764144)
,p_name=>'P2_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17180525003694747)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Read Code'
,p_process_sql_clob=>'select script into :P2_CODE from p5_scripts where id = :P2_ID;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>17180525003694747
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17179711418694739)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CODE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_script clob;',
'    l_response_json json_object_t;',
'    l_response_clob clob;',
'    l_response_blob blob;',
'begin',
'    select script into l_script from p5_scripts where id = :P1_ID;',
'    l_response_json := json_object_t();',
'    l_response_json.put(''code'', l_script);',
'    l_response_clob := l_response_json.to_clob();',
'    l_response_blob := apex_util.clob_to_blob(',
'        p_clob => l_response_clob,',
'        p_charset => ''AL32UTF8''',
'    );',
'    sys.htp.init;',
'    sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_response_blob));',
'    sys.htp.p(''Content-Type: application/json'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_response_blob);',
'exception',
'    when others then',
'        htp.p(''{ "code": "" }'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>17179711418694739
);
wwv_flow_imp.component_end;
end;
/
