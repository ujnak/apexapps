prompt --application/shared_components/logic/application_computations/g_matrix
begin
--   Manifest
--     APPLICATION COMPUTATION: G_MATRIX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>338
,p_default_id_offset=>69252465979827233
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(69254420170840267)
,p_computation_sequence=>10
,p_computation_item=>'G_MATRIX'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::'
,p_version_scn=>41005836705316
);
wwv_flow_imp.component_end;
end;
/
