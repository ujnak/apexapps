prompt --application/shared_components/navigation/listentry
begin
--   Manifest
--     LIST ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2138965587838225
,p_default_application_id=>100
,p_default_id_offset=>2140280846855539
,p_default_owner=>'APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
