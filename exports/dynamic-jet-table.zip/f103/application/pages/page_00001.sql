prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>103
,p_default_id_offset=>16518495489096815
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Dynamic JET Table'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'require([''ojs/ojtable''], function() {});',
''))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(63726418028501236)
,p_plug_name=>'Table'
,p_region_template_options=>'#DEFAULT#:i-h640:t-Region--scrollBody:margin-top-md'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>'<div id="table"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(63862130545675864)
,p_plug_name=>'Dynamic JET Table'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63726327649501235)
,p_button_sequence=>30
,p_button_name=>'GENERATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Generate'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(63726281869501234)
,p_name=>'P1_SQL'
,p_item_sequence=>20
,p_prompt=>'Source SQL Statement'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(63726680026501238)
,p_name=>'onClick GENERATE'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(63726327649501235)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(63726699832501239)
,p_event_id=>wwv_flow_imp.id(63726680026501238)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'require([''ojs/ojarraydataprovider''], function(ArrayDataProvider) {',
'    apex.server.process( "GET_TABLE", {',
'        pageItems: "#P1_SQL"',
'    }, {',
'        success: function( response )  {',
'            apex.debug.info(response);',
'            // this.tableDataProvider = new ArrayDataProvider( data.data, { keyAttributes: "EMPNO" } );',
'            this.tableDataProvider = new ArrayDataProvider( response.data );',
'            const jetTable = document.createElement("oj-table");',
'            jetTable.columns = response.columns;',
'            jetTable.data = this.tableDataProvider;',
'            const elem = document.getElementById("table");',
'            elem.prepend(jetTable);',
'        }',
'    });',
'});'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16119039676860908)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_TABLE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
unistr('    /* SQL\306E\5B9F\884C */'),
'    l_sql varchar2(32767);',
'    l_cursor    integer;',
'    l_col_cnt   integer;',
'    l_desc_tab  dbms_sql.desc_tab;',
'    l_label_name  varchar2(128);',
'    l_value       varchar2(32767);',
'    l_rows        number;',
'    e_invalid_sql exception;',
unistr('    /* oj-table\306Ecolumns\306B\6E21\3059 */'),
'    l_columns_arr json_array_t;',
'    l_column_obj  json_object_t;',
unistr('    /* oj-table\306Edata\306B\6E21\3059 */'),
'    l_data_arr    json_array_t;',
'    l_data_obj    json_object_t;',
unistr('    /* GET_TABLE\306E\51FA\529B */'),
'    l_response      json_object_t;',
'    l_response_blob blob;',
'begin',
unistr('    /* \4E0E\3048\3089\308C\305FSQL\306E\691C\8A3C */'),
'    l_sql := :P1_SQL;',
'    if l_sql is null or l_sql = '''' then',
'        raise e_invalid_sql;',
'    end if;',
unistr('    /* \30AB\30FC\30BD\30EB\306E\30AA\30FC\30D7\30F3 */'),
'    l_cursor := dbms_sql.open_cursor;',
unistr('    /* SQL\306E\30D1\30FC\30B9 */'),
'    dbms_sql.parse(l_cursor, l_sql, dbms_sql.native);',
'    /*',
unistr('    * \5217\5B9A\7FA9\3092oj-table\306Ecolumns\306B\6E21\305B\308BJSON\914D\5217\306B\5909\63DB\3059\308B\3002'),
'    */',
'    l_columns_arr := json_array_t();',
'    dbms_sql.describe_columns(l_cursor, l_col_cnt, l_desc_tab);',
'    for i in 1..l_col_cnt',
'    loop',
'        l_column_obj := json_object_t();',
'        l_label_name := l_desc_tab(i).col_name;',
'        l_column_obj.put(''headerText'', l_label_name);',
'        l_column_obj.put(''field'', l_label_name);',
'        l_columns_arr.append(l_column_obj);',
'        dbms_sql.define_column(l_cursor, i, l_value, 32767);',
'    end loop;',
'    /*',
unistr('    * SELECT\6587\306E\5B9F\884C\3057\3066\53D6\308A\51FA\3057\305F\884C\3092oj-table\306Edata\306B\6E21\305B\308B'),
unistr('    * JSON\914D\5217\306B\5909\63DB\3059\308B\3002'),
'    */',
'    l_rows := dbms_sql.execute(l_cursor);',
'    l_data_arr := json_array_t();',
'    loop',
'        exit when dbms_sql.fetch_rows(l_cursor) = 0;',
'        l_data_obj := json_object_t();',
'        for i in 1..l_col_cnt',
'        loop',
'            dbms_sql.column_value(l_cursor, i, l_value);',
'            l_data_obj.put(l_desc_tab(i).col_name, l_value);',
'        end loop;',
'        l_data_arr.append(l_data_obj);',
'    end loop;',
unistr('    /* \30AB\30FC\30BD\30EB\306E\30AF\30ED\30FC\30BA */'),
'    dbms_sql.close_cursor(l_cursor);',
'    /*',
unistr('    * \547C\3073\51FA\3057\5143\306BSQL\306E\5B9F\884C\7D50\679C\3092\8FD4\3059\3002'),
'    */',
'    l_response := json_object_t();',
'    l_response.put(''data'', l_data_arr);',
'    l_response.put(''columns'', l_columns_arr);',
'    l_response_blob := l_response.to_blob();',
'    /*',
unistr('    * GET_TABLE\306E\547C\3073\51FA\3057\5143\306BJSON\3092\8FD4\3059\3002'),
'    */',
'    sys.htp.init;',
'    sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_response_blob));',
'    sys.htp.p(''Content-Type: application/json'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_response_blob);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16119039676860908
);
wwv_flow_imp.component_end;
end;
/
