prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>334
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Applications'
,p_alias=>'APPLICATIONS'
,p_step_title=>'Applications'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add([',
'    {',
'        name: "delete-application",',
'        action: function( event, element, args ) {',
'            apex.message.confirm(',
'                "Are you sure?",',
'                (okPressed) => {',
'                    if (okPressed) {',
'                        let result = apex.server.process(',
'                            "DELETE",',
'                            {',
'                                x01: args.id',
'                            }',
'                        );',
'',
'                        result.done(',
'                            (data) => {',
'                                apex.message.showPageSuccess(',
'                                    ''application deleted successfully.'',',
'                                );',
'                                apex.event.trigger(',
'                                    "#APPLICATIONS",',
'                                    "apexrefresh"',
'                                );',
'                            }',
'                        ).fail(',
'                            (jqXHR, textStatus, errorThrown) => {',
'                                apex.message.alert(''Failed to delete application.'');',
'                            }',
'                        );',
'                    }',
'                }',
'            )',
'        }',
'    }',
']);'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240306085806'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(71172174337060177)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(70958479567218925)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(70842897430218827)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(71020802578218967)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(71177872240257515)
,p_plug_name=>'Applications'
,p_region_name=>'APPLICATIONS'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(70936274081218913)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    n001 as application_id',
'    ,c001 as application_name',
'    ,c002 as application_alias',
'    ,c003 as application_group',
'    ,c004 as application_owner',
'    ,n002 as page_count',
'    ,c005 as workspace',
'    ,c006 as availability_status',
'    ,c007 as last_updated_by',
'    ,d001 as last_updated_on',
'    ,''EXPORT'' as EXP',
'    ,''DELETE'' as DEL',
'from apex_collections',
'where collection_name = :G_WORKSPACE_APPLICATIONS'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Applications'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(71177935198257516)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>71177935198257516
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71178004034257517)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71178188442257518)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71178296870257519)
,p_db_column_name=>'APPLICATION_ALIAS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Application Alias'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71178341072257520)
,p_db_column_name=>'APPLICATION_GROUP'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Application Group'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71178481482257521)
,p_db_column_name=>'APPLICATION_OWNER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Application Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71178587380257522)
,p_db_column_name=>'PAGE_COUNT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Page Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71178627123257523)
,p_db_column_name=>'WORKSPACE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Workspace'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71178724509257524)
,p_db_column_name=>'AVAILABILITY_STATUS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Availability Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71178870969257525)
,p_db_column_name=>'LAST_UPDATED_BY'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Last Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71178985908257526)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Last Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71179004394257527)
,p_db_column_name=>'EXP'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Exp'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.:APPLICATION_PROCESS=EXPORT:&DEBUG.::P3_APPLICATION_ID:#APPLICATION_ID#'
,p_column_linktext=>'<button type="button" class="t-Button">Export</button>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71179109409257528)
,p_db_column_name=>'DEL'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Del'
,p_column_html_expression=>'<button type="button" class="t-Button t-Button--danger" data-action="#action$delete-application?id=#APPLICATION_ID#">Delete</button>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(71816202274100250)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'718163'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'APPLICATION_ID:APPLICATION_NAME:APPLICATION_ALIAS:APPLICATION_GROUP:APPLICATION_OWNER:PAGE_COUNT:WORKSPACE:AVAILABILITY_STATUS:LAST_UPDATED_BY:LAST_UPDATED_ON:EXP:DEL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(71179408150257531)
,p_button_sequence=>30
,p_button_name=>'IMPORT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(71019292878218966)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Import'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70130258127549131)
,p_name=>'P3_WORKSPACE_NAME'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70130318883549132)
,p_name=>'P3_INSTANCE_URL'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70130471674549133)
,p_name=>'P3_CREDENTIAL_STATIC_ID'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71179264140257529)
,p_name=>'P3_APPLICATION_ID'
,p_is_required=>true
,p_item_sequence=>10
,p_prompt=>'Application ID'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(71016733842218962)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71179373230257530)
,p_name=>'P3_FILE'
,p_is_required=>true
,p_item_sequence=>20
,p_prompt=>'File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(71016733842218962)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(71179524687257532)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\30A4\30F3\30DD\30FC\30C8')
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'UTL_APEX_REMOTE'
,p_attribute_04=>'IMPORT_APPLICATION'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(71179408150257531)
,p_process_success_message=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\304C\30A4\30F3\30DD\30FC\30C8\3055\308C\307E\3057\305F\3002')
,p_internal_uid=>71179524687257532
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(71179647549257533)
,p_page_process_id=>wwv_flow_imp.id(71179524687257532)
,p_page_id=>3
,p_name=>'p_application_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P3_APPLICATION_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(71179703650257534)
,p_page_process_id=>wwv_flow_imp.id(71179524687257532)
,p_page_id=>3
,p_name=>'p_file'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P3_FILE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(71179830276257535)
,p_page_process_id=>wwv_flow_imp.id(71179524687257532)
,p_page_id=>3
,p_name=>'p_instance_url'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P3_INSTANCE_URL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(71179912581257536)
,p_page_process_id=>wwv_flow_imp.id(71179524687257532)
,p_page_id=>3
,p_name=>'p_workspace_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P3_WORKSPACE_NAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(71180097378257537)
,p_page_process_id=>wwv_flow_imp.id(71179524687257532)
,p_page_id=>3
,p_name=>'p_credential_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P3_CREDENTIAL_STATIC_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(71180162971257538)
,p_page_process_id=>wwv_flow_imp.id(71179524687257532)
,p_page_id=>3
,p_name=>'p_dbapi_version'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(71180239347257539)
,p_page_process_id=>wwv_flow_imp.id(71179524687257532)
,p_page_id=>3
,p_name=>'p_refresh_collection'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(71180373383257540)
,p_page_process_id=>wwv_flow_imp.id(71179524687257532)
,p_page_id=>3
,p_name=>'p_collection_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>80
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(71180453794257541)
,p_page_process_id=>wwv_flow_imp.id(71179524687257532)
,p_page_id=>3
,p_name=>'p_limit'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>90
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(70130519000549134)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>unistr('APEX\30B3\30EC\30AF\30B7\30E7\30F3\306E\521D\671F\5316')
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'UTL_APEX_REMOTE'
,p_attribute_04=>'LOAD_APPS_INTO_APEX_COLLECTION'
,p_internal_uid=>70130519000549134
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(70130662953549135)
,p_page_process_id=>wwv_flow_imp.id(70130519000549134)
,p_page_id=>3
,p_name=>'p_collection_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'STATIC'
,p_value=>'&G_WORKSPACE_APPLICATIONS.'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(70130722461549136)
,p_page_process_id=>wwv_flow_imp.id(70130519000549134)
,p_page_id=>3
,p_name=>'p_instance_url'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P3_INSTANCE_URL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(70130827831549137)
,p_page_process_id=>wwv_flow_imp.id(70130519000549134)
,p_page_id=>3
,p_name=>'p_workspace_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P3_WORKSPACE_NAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(70130997393549138)
,p_page_process_id=>wwv_flow_imp.id(70130519000549134)
,p_page_id=>3
,p_name=>'p_credential_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P3_CREDENTIAL_STATIC_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(70131037954549139)
,p_page_process_id=>wwv_flow_imp.id(70130519000549134)
,p_page_id=>3
,p_name=>'p_dbapi_version'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(70131105486549140)
,p_page_process_id=>wwv_flow_imp.id(70130519000549134)
,p_page_id=>3
,p_name=>'p_limit'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(71180691094257543)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EXPORT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'utl_apex_remote.export_application(',
'    p_application_id        => :P3_APPLICATION_ID',
'    ,p_instance_url         => :P3_INSTANCE_URL',
'    ,p_workspace_name       => :P3_WORKSPACE_NAME',
'    ,p_credential_static_id => :P3_CREDENTIAL_STATIC_ID',
');'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>71180691094257543
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(71180719590257544)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'utl_apex_remote.delete_application(',
'    p_application_id        => apex_application.g_x01',
'    ,p_instance_url         => :P3_INSTANCE_URL',
'    ,p_workspace_name       => :P3_WORKSPACE_NAME',
'    ,p_credential_static_id => :P3_CREDENTIAL_STATIC_ID',
'    ,p_refresh_collection   => true',
'    ,p_collection_name      => :G_WORKSPACE_APPLICATIONS',
');'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>71180719590257544
);
wwv_flow_imp.component_end;
end;
/
