prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 253
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>253
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(137347317264366497)
,p_group_name=>unistr('\7BA1\7406')
);
wwv_flow_imp.component_end;
end;
/
