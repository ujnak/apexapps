prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>158
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Chat Client'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230309044439'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(62410402905412832)
,p_plug_name=>'Chat Client'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(62268474170412724)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61409446101313117)
,p_button_sequence=>20
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(62374318514412783)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61409359008313116)
,p_name=>'P1_QUERY'
,p_item_sequence=>10
,p_prompt=>'Query'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(62371830197412782)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61409509082313118)
,p_name=>'P1_ANSWER'
,p_item_sequence=>30
,p_prompt=>'Answer'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(62371830197412782)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61409651440313119)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Query on Chat Server'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_query json_object_t;',
'    l_query_clob clob;',
'    l_answer_clob clob;',
'    l_answer json_object_t;',
'begin',
'    l_query := json_object_t();',
'    l_query.put(''query'', :P1_QUERY);',
'    l_query_clob := l_query.to_clob();',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', p_reset => false);',
'    l_answer_clob := apex_web_service.make_rest_request(',
'        p_url => :G_ENDPOINT',
'        ,p_http_method => ''POST''',
'        ,p_body => l_query_clob',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        apex_debug.info(''Chat Server Error %s, %s'',',
'            apex_web_service.g_status_code',
'            ,l_answer_clob);',
'        raise_application_error(-20001, ''Chat Server Error = '' ',
'            || apex_web_service.g_status_code);',
'    end if;',
'    l_answer := json_object_t(l_answer_clob);',
'    :P1_ANSWER := l_answer.get_string(''answer'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(61409446101313117)
);
wwv_flow_imp.component_end;
end;
/
