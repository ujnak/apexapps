prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>9114072847088395
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sea Surface Temperature'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9426211510767016)
,p_plug_name=>unistr('\5730\56F3')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(9426388425767017)
,p_region_id=>wwv_flow_imp.id(9426211510767016)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(9426499902767018)
,p_map_region_id=>wwv_flow_imp.id(9426388425767017)
,p_name=>unistr('\30D2\30FC\30C8\30DE\30C3\30D7')
,p_layer_type=>'POLYGON'
,p_display_sequence=>20
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'SST_DATA'
,p_where_clause=>'observation_date = :P1_OBSERVATION_DATE and value < 100'
,p_include_rowid_column=>false
,p_items_to_submit=>'P1_OBSERVATION_DATE'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'SQUARE'
,p_stroke_color=>'#101010'
,p_fill_color_is_spectrum=>true
,p_fill_color_spectr_name=>'Temps'
,p_fill_color_spectr_type=>'DIVERGING'
,p_fill_value_column=>'VALUE'
,p_fill_opacity=>.5
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\7D4C\5EA6: &LONGITUDE.<br>'),
unistr('\7DEF\5EA6: &LATITUDE.<br>'),
unistr('\6E29\5EA6: &VALUE.')))
,p_info_window_adv_formatting=>false
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(9426921902767023)
,p_map_region_id=>wwv_flow_imp.id(9426388425767017)
,p_name=>unistr('\9078\629E\3057\305F\5730\70B9')
,p_layer_type=>'POLYGON'
,p_display_sequence=>30
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_table_name=>'SST_DATA'
,p_where_clause=>'id = :P1_ID'
,p_include_rowid_column=>false
,p_items_to_submit=>'P1_ID'
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'SQUARE'
,p_stroke_color=>'#101010'
,p_fill_color=>'#101010'
,p_fill_color_is_spectrum=>false
,p_fill_opacity=>1
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\7D4C\5EA6: &LONGITUDE.<br>'),
unistr('\7DEF\5EA6: &LATITUDE.<br>'),
unistr('\6E29\5EA6: &VALUE.')))
,p_info_window_adv_formatting=>false
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9427546182767029)
,p_plug_name=>unistr('\6D77\9762\6C34\6E29')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    observation_date,',
'    value,',
'    avg(value) over (',
'        order by observation_date asc',
'        range between interval ''1'' year preceding and current row',
'    ) as moving_avg_1y,',
'    avg(value) over (',
'        order by observation_date asc',
'        range between interval ''10'' year preceding and current row',
'    ) as moving_avg_10y,',
'    avg(value) over (',
'        order by observation_date asc',
'        range between interval ''30'' year preceding and current row',
'    ) as moving_avg_30y',
'from sst_data',
'where ',
'  (longitude,latitude) = (select longitude,latitude from sst_data where id = :P1_ID)',
'  and value < 100',
'order by observation_date asc'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P1_ID'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(9427655937767030)
,p_region_id=>wwv_flow_imp.id(9427546182767029)
,p_chart_type=>'line'
,p_height=>'640'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'live'
,p_initial_zooming=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'on'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(9427796388767031)
,p_chart_id=>wwv_flow_imp.id(9427655937767030)
,p_seq=>10
,p_name=>unistr('\8A08\6E2C\6C34\6E29')
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'OBSERVATION_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(9428034753767034)
,p_chart_id=>wwv_flow_imp.id(9427655937767030)
,p_seq=>20
,p_name=>unistr('\79FB\52D5\5E73\5747 - 1\5E74')
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'MOVING_AVG_1Y'
,p_items_label_column_name=>'OBSERVATION_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(9428173829767035)
,p_chart_id=>wwv_flow_imp.id(9427655937767030)
,p_seq=>30
,p_name=>unistr('\79FB\52D5\5E73\5747 - 10\5E74')
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'MOVING_AVG_10Y'
,p_items_label_column_name=>'OBSERVATION_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(9428240995767036)
,p_chart_id=>wwv_flow_imp.id(9427655937767030)
,p_seq=>40
,p_name=>unistr('\79FB\52D5\5E73\5747 - 30\5E74')
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'MOVING_AVG_30Y'
,p_items_label_column_name=>'OBSERVATION_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(9427880560767032)
,p_chart_id=>wwv_flow_imp.id(9427655937767030)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(9427931742767033)
,p_chart_id=>wwv_flow_imp.id(9427655937767030)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9633051532452166)
,p_plug_name=>'Sea Surface Temperature'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_source=>'COBE-SST 2 and Sea Ice data provided by the NOAA PSL, Boulder, Colorado, USA, from their website at https://psl.noaa.gov'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9426116257767015)
,p_name=>'P1_OBSERVATION_DATE'
,p_item_sequence=>10
,p_prompt=>unistr('\8A08\6E2C\65E5')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select observation_date d, observation_date r from sst_data ',
'group by observation_date order by observation_date desc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- \8A08\6E2C\65E5\3092\9078\3076 -')
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9426733252767021)
,p_name=>'P1_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9426522609767019)
,p_name=>'onChange P1_OBSERVATION_DATE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_OBSERVATION_DATE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9426673794767020)
,p_event_id=>wwv_flow_imp.id(9426522609767019)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9426211510767016)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9427076501767024)
,p_name=>'onClick Map Object'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9426211510767016)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapobjectclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9427179725767025)
,p_event_id=>wwv_flow_imp.id(9427076501767024)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9427313715767027)
,p_name=>'onChange P1_ID'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9427434438767028)
,p_event_id=>wwv_flow_imp.id(9427313715767027)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9426211510767016)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9428300887767037)
,p_event_id=>wwv_flow_imp.id(9427313715767027)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9427546182767029)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
