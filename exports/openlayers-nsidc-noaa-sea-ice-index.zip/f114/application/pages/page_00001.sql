prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'NSIDC Sea Ice Index'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/proj4@2.19.10/dist/proj4.min.js',
'https://cdn.jsdelivr.net/npm/ol-proj@1.1.0/dist/js/proj4.min.js',
'https://cdn.jsdelivr.net/npm/geotiff@2.1.3/dist-browser/geotiff.js',
'https://cdn.jsdelivr.net/npm/ol@10.6.1/dist/ol.js',
'#APP_FILES#openlayers_geotiff_polar#MIN#.js'))
,p_css_file_urls=>'https://cdn.jsdelivr.net/npm/ol@10.6.1/ol.min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'html,body,#map{margin:0;height:100%}',
'#map {',
unistr('  background-color: #1e3a5f; /* \6DF1\3044\6D77\306E\9752 */'),
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17536728235617323)
,p_plug_name=>'Sea Ice Index'
,p_region_template_options=>'#DEFAULT#:i-h640:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>80
,p_location=>null
,p_plug_source=>'<div id="map"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17536939512617325)
,p_plug_name=>'Controls'
,p_region_name=>'CONTROLS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1569994581593435632
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17941524185949217)
,p_plug_name=>'NSIDC Sea Ice Index'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17536445330617320)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(17536939512617325)
,p_button_name=>'ICE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\6D77\6C37\8868\793A')
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="ICE"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17536550689617321)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(17536939512617325)
,p_button_name=>'CLEAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\3059\3079\3066\30AF\30EA\30A2')
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="CLEAR"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17536611879617322)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(17536939512617325)
,p_button_name=>'GRID'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\30B0\30EA\30C3\30C9\5207\66FF')
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="GRID"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17536173658617317)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17536939512617325)
,p_button_name=>'NORTH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\5317\6975\6295\5F71(EPSG:6931)')
,p_button_position=>'BUTTON_START'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="NORTH"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17536243195617318)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17536939512617325)
,p_button_name=>'SOUTH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\5357\6975\6295\5F71(EPSG:6932)')
,p_button_position=>'BUTTON_START'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="SOUTH"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17536317038617319)
,p_name=>'P1_OBSERVATION_DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(17536939512617325)
,p_prompt=>unistr('\89B3\6E2C\65E5')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18137891151671703)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_BLOB'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_hemisphere varchar2(1);',
'  l_blob blob;',
'  l_base64clob clob;',
'  l_response_json json_object_t;',
'  l_response_clob clob;',
'  l_response_blob blob;',
'  e_bad_projection exception;',
'begin',
'  case apex_application.g_x01',
'  when ''EPSG:6931'' then',
'      l_hemisphere := ''N'';',
'  when ''EPSG:6932'' then',
'      l_hemisphere := ''S''; ',
'  else',
unistr('      /* \767A\751F\3057\306A\3044\306F\305A\3002 */'),
'      raise e_bad_projection;',
'  end case;',
unistr('  -- \6307\5B9A\3057\305F\534A\7403\306E\89B3\6E2C\65E5\306E\6D77\6C37\306E\30C7\30FC\30BF\3092GeoTIFF\3067\53D6\5F97\3059\308B\3002'),
'  l_blob := noaa_g02135_pkg.get_blob(',
'    l_hemisphere,',
'    to_date(:P1_OBSERVATION_DATE, ''YYYY/MM/DD'')',
'  );',
unistr('  -- GeoTIFF\306E\30D0\30A4\30CA\30EA\30FB\30C7\30FC\30BF\3092Base64\3067\30A8\30F3\30B3\30FC\30C9\3059\308B\3002'),
'  l_base64clob := apex_web_service.blob2clobbase64(l_blob, ''N'');',
unistr('  -- JSON\306E\30EC\30B9\30DD\30F3\30B9\3092\4F5C\6210\3059\308B\3002GeoTIFF\306E\30C7\30FC\30BF\306Fdata\3068\3057\3066\8FD4\3059\3002'),
'  l_response_json := json_object_t();',
'  l_response_json.put(''data'', l_base64clob);',
'  l_response_clob := l_response_json.to_clob();',
unistr('  -- wpg_docload\3067\547C\3073\51FA\3057\5143\306B\623B\3059\305F\3081\306B\3001BLOB\306B\5909\63DB\3059\308B\3002'),
'  l_response_blob := apex_util.clob_to_blob(l_response_clob);',
unistr('  -- GeoTIFF\30C7\30FC\30BF\3092\547C\3073\51FA\3057\5143\306B\8FD4\3059\3002'),
'  sys.htp.init;',
'  sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_response_blob));',
'  sys.htp.p(''Content-Type: application/json'');',
'  sys.owa_util.http_header_close;',
'  sys.wpg_docload.download_file(l_response_blob);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>18137891151671703
);
wwv_flow_imp.component_end;
end;
/
