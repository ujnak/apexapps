prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>224
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'dotlottie-web'
,p_alias=>'DOTLOTTIE-WEB'
,p_step_title=>'dotlottie-web'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "@lottiefiles/dotlottie-web": "https://esm.sh/@lottiefiles/dotlottie-web"',
'        }',
'    }',
'</script>'))
,p_javascript_file_urls=>'[module,defer]#APP_FILES#js/app-dotlottie#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(248957838633750235)
,p_plug_name=>'Lottie Animation'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(125291798579549331)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<canvas id="lottie-canvas" style="width: 600px; height: 600px;"></canvas>'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(248958003880750237)
,p_plug_name=>'Buttons Container'
,p_region_name=>'lottie-controls'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(125313299490549449)
,p_plug_display_sequence=>10
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125578764422865007)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(248958003880750237)
,p_button_name=>'PLAY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(125430524070550264)
,p_button_image_alt=>'Play'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="PLAY"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125578376645865006)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(248958003880750237)
,p_button_name=>'PAUSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(125430524070550264)
,p_button_image_alt=>'Pause'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="PAUSE"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125579120171865009)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(248958003880750237)
,p_button_name=>'STOP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(125430524070550264)
,p_button_image_alt=>'Stop'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="STOP"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(248962266577750259)
,p_name=>'P3_EVENT'
,p_item_sequence=>20
,p_prompt=>'Event'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(125428008128550242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
