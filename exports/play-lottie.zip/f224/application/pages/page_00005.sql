prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>224
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'lottie-interactivity'
,p_alias=>'LOTTIE-INTERACTIVITY'
,p_step_title=>'lottie-interactivity'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js',
'https://unpkg.com/@lottiefiles/lottie-interactivity@latest/dist/lottie-interactivity.min.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'LottieInteractivity.create({',
'    mode: ''scroll'',',
'    player: ''#firstLottie'',',
'    actions: [',
'        {',
'            visibility: [0, 1],',
'            type: ''seek'',',
'            frames: [0, 100],',
'        },',
'    ],',
'});',
'LottieInteractivity.create({',
'    player: "#secondLottie",',
'    mode: "scroll",',
'    container: "#MyContainerId",',
'    actions: [',
'        {',
'            visibility: [0, 1.0],',
'            type: ''seek'',',
'            frames: [90, 123],',
'        },',
'    ]',
'});',
'LottieInteractivity.create({',
'    player: ''#thirdLottie'',',
'    mode: ''scroll'',',
'    actions: [',
'        {',
'            visibility: [0, 0.3],',
'            type: "stop",',
'            frames: [50]',
'        },',
'        {',
'            visibility: [0.3, 1.0],',
'            type: "seek",',
'            frames: [50, 240]',
'        }',
'    ]',
'});',
'LottieInteractivity.create({',
'    player: "#fourthLottie",',
'    mode: "scroll",',
'    actions: [',
'        {',
'            visibility: [0, 0.2],',
'            type: "stop",',
'            frames: [0]',
'        },',
'        {',
'            visibility: [0.2, 0.45],',
'            type: "seek",',
'            frames: [0, 45]',
'        },',
'        {',
'            visibility: [0.45, 1.0],',
'            type: "loop",',
'            frames: [45, 60]',
'        }',
'    ]',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(500168408573284286)
,p_plug_name=>'Lottie Animation'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(125291798579549331)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<lottie-player',
'    id="firstLottie"',
'    src="&APEX_PATH.#APP_FILES#MyFirstLottie.json"',
'    style="width:400px; height: 400px;"',
'></lottie-player>',
'<div id="MyContainerId">',
'<lottie-player',
'    id="secondLottie"',
'    src="&APEX_PATH.#APP_FILES#MyFirstLottie.json"',
'    style="width:400px; height: 400px;"',
'></lottie-player>',
'</div>',
'<lottie-player',
'    id="thirdLottie"',
'    src="&APEX_PATH.#APP_FILES#MyFirstLottie.json"',
'    style="width:400px; height: 400px;"',
'></lottie-player>',
'<lottie-player',
'    id="fourthLottie"',
'    src="&APEX_PATH.#APP_FILES#MyFirstLottie.json"',
'    style="width:400px; height: 400px;"',
'></lottie-player>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
