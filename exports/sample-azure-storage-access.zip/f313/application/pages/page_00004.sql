prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>313
,p_default_id_offset=>28771582993444361
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Download'
,p_alias=>'DOWNLOAD'
,p_page_mode=>'MODAL'
,p_step_title=>'Download'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(54834086790426503)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240117033807'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27312478899638511)
,p_name=>'P4_FILE_NAME'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(27312529334638512)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Download'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_object_uri varchar2(400);',
'    l_blob blob;',
'    l_download apex_data_export.t_export;',
'begin',
'    l_object_uri := ''https://'' || :G_STORAGE_ACCOUNT_NAME || ''.blob.core.windows.net/'' || :G_CONTAINER_NAME ',
'        || ''/'' || utl_url.escape(:P4_FILE_NAME, false, ''AL32UTF8'');',
'    l_blob := dbms_cloud.get_object(',
'        credential_name => ''AZURE$PA''',
'        ,object_uri => l_object_uri',
'    );',
'    l_download.file_name := :P4_FILE_NAME;',
'    l_download.mime_type := ''application/octet-stream'';',
'    l_download.as_clob := FALSE;',
'    l_download.content_blob := l_blob;',
'    apex_data_export.download( p_export => l_download );',
'    apex_application.stop_apex_engine;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>27312529334638512
);
wwv_flow_imp.component_end;
end;
/
