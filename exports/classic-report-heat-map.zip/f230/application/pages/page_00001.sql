prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>230
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Classic Report Heat Map'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' * make cell square-shape.',
' */',
'.ht-cell {',
'  display: flex;',
'  justify-content: center;',
'  align-items: center;',
'  width:  60px;',
'  height: 60px;',
'}',
'',
'/*',
' * text inside the cell',
' */',
'.ht-text {',
'  color: white;',
'}',
'',
'/*',
' * remove padding from td (cell) except row headers',
' */',
'#HEATMAP td:not([headers="REGION"]) {',
'    --ut-report-cell-padding-x: 0rem;',
'    --ut-report-cell-padding-y: 0rem;',
'}',
'',
'/*',
unistr(' * \5E74\6708\3092\7E26\66F8\304D\306B\3059\308B\3002'),
' */',
'#HEATMAP th:not([id="REGION"]) {',
'    writing-mode: vertical-lr;',
'    transform: rotate(180deg);',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(122416237262659107)
,p_plug_name=>'Classic Report Heat Map'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(122185194428658368)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(122418410248663101)
,p_name=>'Heat Map'
,p_region_name=>'HEATMAP'
,p_template=>wwv_flow_imp.id(122153272879658297)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_periods apex_t_varchar2;',
'    l_idx integer;',
'    l_pivod_columns varchar2(32767);',
'    l_sql clob;',
'    e_too_many_pivod_columns exception;',
'begin',
unistr('    /* \5217\540D\306E\8A2D\5B9A */'),
'    apex_session_state.set_value(''P1_COL01'', ''Region'');',
unistr('    l_idx := 1; /* P1_COL01\306FRegion\306A\306E\3067\3001\5E74\6708\306E\5217\306FP1_COL02\304B\3089\59CB\307E\308B\3002 */'),
'    for p in (',
'        select period from ebaj_demo_house_price',
'        group by period order by to_date(period, ''MonthYYYY'', ''NLS_DATE_LANGUAGE=English'') asc',
'    )',
'    loop',
'        l_idx := l_idx + 1;',
unistr('        /* l_idx\304C20\3092\8D85\3048\308B\3068\4F8B\5916\3092\4E0A\3052\308B - Region\5217\304C\3042\308B\306E\3067\5E74\6708\5217\306F19\304C\4E0A\9650 */'),
'        if l_idx > 20 then',
'            raise e_too_many_pivod_columns;',
'        end if;',
'        apex_session_state.set_value(''P1_COL'' || to_char(l_idx, ''FM00''), p.period );',
'    end loop;',
unistr('    /* \30D4\30DC\30C3\30C8\5217\306E\53D6\308A\51FA\3057 */'),
'    select listagg(chr(39) || prd || chr(39) || '' as '' || prd,'','')',
'    within group (order by to_date(prd, ''MonthYYYY'', ''NLS_DATE_LANGUAGE=English'') asc) ',
'    into l_pivod_columns',
'    from (',
'        select distinct period prd from ebaj_demo_house_price',
'    );',
unistr('    /* Pivot\3092\4F7F\3063\305FSELECT\6587\3092\8FD4\3059 */'),
'    l_sql := ''select * from (select region, period, price from ebaj_demo_house_price) '';',
'    l_sql := l_sql || ''pivot ( sum(price) for period in ('' || l_pivod_columns || ''))'';',
'    return l_sql;',
'end;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>true
,p_query_row_template=>wwv_flow_imp.id(122256895721658526)
,p_plug_query_max_columns=>20
,p_query_num_rows=>15
,p_query_options=>'GENERIC_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122418515884663102)
,p_query_column_id=>1
,p_column_alias=>'COL01'
,p_column_display_sequence=>10
,p_column_heading=>'&P1_COL01.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122418686211663103)
,p_query_column_id=>2
,p_column_alias=>'COL02'
,p_column_display_sequence=>20
,p_column_heading=>'&P1_COL02.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL02#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122418740388663104)
,p_query_column_id=>3
,p_column_alias=>'COL03'
,p_column_display_sequence=>30
,p_column_heading=>'&P1_COL03.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL03#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122418869978663105)
,p_query_column_id=>4
,p_column_alias=>'COL04'
,p_column_display_sequence=>40
,p_column_heading=>'&P1_COL04.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL04#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122418988127663106)
,p_query_column_id=>5
,p_column_alias=>'COL05'
,p_column_display_sequence=>50
,p_column_heading=>'&P1_COL05.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL05#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122419093185663107)
,p_query_column_id=>6
,p_column_alias=>'COL06'
,p_column_display_sequence=>60
,p_column_heading=>'&P1_COL06.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL06#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122419165717663108)
,p_query_column_id=>7
,p_column_alias=>'COL07'
,p_column_display_sequence=>70
,p_column_heading=>'&P1_COL07.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL07#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122419263638663109)
,p_query_column_id=>8
,p_column_alias=>'COL08'
,p_column_display_sequence=>80
,p_column_heading=>'&P1_COL08.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL08#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122419316016663110)
,p_query_column_id=>9
,p_column_alias=>'COL09'
,p_column_display_sequence=>90
,p_column_heading=>'&P1_COL09.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL09#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122419484424663111)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>100
,p_column_heading=>'&P1_COL10.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL10#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122419596075663112)
,p_query_column_id=>11
,p_column_alias=>'COL11'
,p_column_display_sequence=>110
,p_column_heading=>'&P1_COL11.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL11#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122419610269663113)
,p_query_column_id=>12
,p_column_alias=>'COL12'
,p_column_display_sequence=>120
,p_column_heading=>'&P1_COL12.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL12#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122419701047663114)
,p_query_column_id=>13
,p_column_alias=>'COL13'
,p_column_display_sequence=>130
,p_column_heading=>'&P1_COL13.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL13#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122419898015663115)
,p_query_column_id=>14
,p_column_alias=>'COL14'
,p_column_display_sequence=>140
,p_column_heading=>'&P1_COL14.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL14#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122419974012663116)
,p_query_column_id=>15
,p_column_alias=>'COL15'
,p_column_display_sequence=>150
,p_column_heading=>'&P1_COL15.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL15#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122420080094663117)
,p_query_column_id=>16
,p_column_alias=>'COL16'
,p_column_display_sequence=>160
,p_column_heading=>'&P1_COL16.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL16#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122420124758663118)
,p_query_column_id=>17
,p_column_alias=>'COL17'
,p_column_display_sequence=>170
,p_column_heading=>'&P1_COL17.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL17#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122420213119663119)
,p_query_column_id=>18
,p_column_alias=>'COL18'
,p_column_display_sequence=>180
,p_column_heading=>'&P1_COL18.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL18#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122420314286663120)
,p_query_column_id=>19
,p_column_alias=>'COL19'
,p_column_display_sequence=>190
,p_column_heading=>'&P1_COL19.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL19#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(122420458915663121)
,p_query_column_id=>20
,p_column_alias=>'COL20'
,p_column_display_sequence=>200
,p_column_heading=>'&P1_COL20.'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ht-cell">',
' <div class="ht-text">',
'   #COL20#',
'  </div>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122420557943663122)
,p_name=>'P1_COL01'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122420609179663123)
,p_name=>'P1_COL09'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122420765133663124)
,p_name=>'P1_COL05'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122420859343663125)
,p_name=>'P1_COL13'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122420910023663126)
,p_name=>'P1_COL03'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122421027840663127)
,p_name=>'P1_COL07'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122421104171663128)
,p_name=>'P1_COL11'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122421212698663129)
,p_name=>'P1_COL17'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122421322658663130)
,p_name=>'P1_COL15'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122421462333663131)
,p_name=>'P1_COL19'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122421502398663132)
,p_name=>'P1_COL02'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122421650007663133)
,p_name=>'P1_COL04'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122421715947663134)
,p_name=>'P1_COL06'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122421856979663135)
,p_name=>'P1_COL08'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122421994562663136)
,p_name=>'P1_COL10'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122422063865663137)
,p_name=>'P1_COL12'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122422142826663138)
,p_name=>'P1_COL14'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122422222572663139)
,p_name=>'P1_COL16'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122422351654663140)
,p_name=>'P1_COL18'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122422412759663141)
,p_name=>'P1_COL20'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(122422555169663142)
,p_name=>'onRefresh HEATMAP'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(122418410248663101)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(122422636820663143)
,p_event_id=>wwv_flow_imp.id(122422555169663142)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const report = document.getElementById("HEATMAP");',
'const cells = report.querySelectorAll(''.ht-cell'');',
'cells.forEach( (cell) => {',
'    let data = Number(cell.textContent);',
'    let color;',
'    if (data < -1.25) {',
'        color = ''oj-bg-success-30'';',
'    }',
'    // -1% > data >= -1.25%',
'    else if (data < -1) {',
'        color = ''oj-bg-brand-30'';',
'    }',
'    // -0.75% > data >= -1%',
'    else if (data < -0.75) {',
'        color = ''oj-bg-warning-30'';',
'    }',
'    // -0.5% > data >= -0.75%',
'    else if (data < -0.5) {',
'        color = ''oj-bg-warning-20'';',
'    }',
'    // -0.25% > data >= -0.5%',
'    else if (data < -0.25) {',
'        color = ''oj-bg-warning-10'';',
'    }',
'    // data > 2.25%',
'    else if (data > 2.25) {',
'        color = ''oj-bg-neutral-200'';',
'    }',
'    // 2% < data <= 2.25%',
'    else if (data > 2) {',
'        color = ''oj-bg-neutral-170'';',
'    }',
'    // 1.75% < data <= 2%',
'    else if (data > 1.75) {',
'        color = ''oj-bg-success-20'';',
'    }',
'    // 1.5% < data <= 1.75%',
'    else if (data > 1.5) {',
'        color = ''oj-bg-brand-20'';',
'    }',
'    // 1.25% < data <= 1.5%',
'    else if (data > 1.25) {',
'        color = ''oj-bg-info-30'';',
'    }',
'    // 1% < data <= 1.25%',
'    else if (data > 1) {',
'        color = ''oj-bg-info-20'';',
'    }',
'    // 0.75% < data <= 1%',
'    else if (data > 0.75) {',
'        color = ''oj-bg-info-10'';',
'    }',
'    // 0.5% < data <= 0.75%',
'    else if (data > 0.5) {',
'        color = ''oj-bg-neutral-20'';',
'    }',
'    // 0.25% < data <= 0.5%',
'    else if (data > 0.25) {',
'        color = ''oj-bg-neutral-10'';',
'    }',
'    // between -0.25 and 0.25',
'    else {',
'        color = ''oj-bg-neutral-0'';',
'    };',
'    cell.classList.add(color);',
'});'))
);
wwv_flow_imp.component_end;
end;
/
