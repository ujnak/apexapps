prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7335198607042437
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(9949538568033362)
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\30A6\30A7\30D6\30D7\30C3\30B7\30E5\9001\4FE1')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20220908095041'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9958187549033417)
,p_plug_name=>unistr('\30A6\30A7\30D6\30D7\30C3\30B7\30E5\9001\4FE1')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(9823931815033268)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9960395368052801)
,p_plug_name=>unistr('\30A6\30A7\30D6\30D7\30C3\30B7\30E5\9001\4FE1')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(9851775072033284)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9960619733052804)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9960395368052801)
,p_button_name=>'B_SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(9924621469033330)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9960486819052802)
,p_name=>'P1_TITLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9960395368052801)
,p_prompt=>'Title'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(9922187920033326)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9960573862052803)
,p_name=>'P1_BODY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9960395368052801)
,p_prompt=>'Body'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(9922187920033326)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9960730849052805)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\901A\77E5\306E\9001\4FE1')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_rest_return clob;',
'    l_name  apex_application_global.VC_ARR2;',
'    l_value apex_application_global.VC_ARR2;',
'begin',
'    l_name(1)  := ''title'';',
'    l_name(2)  := ''body'';',
'    l_value(1) := utl_url.escape(:P1_TITLE, false, ''AL32UTF8'');',
'    l_value(2) := utl_url.escape(:P1_BODY, false, ''AL32UTF8'');',
'    l_rest_return := apex_web_service.make_rest_request(',
'        p_url => :G_WEBPUSH_URL -- My custom REST endpoint (1)',
'        , p_http_method => ''GET''',
'        , p_parm_name  => l_name  -- Notification structure (2)',
'        , p_parm_value => l_value -- Notification Content (3)',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
