prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Vector Tiles'
,p_alias=>'VECTOR-TILES'
,p_step_title=>'Vector Tiles'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/maplibre-gl@5.7.3/dist/maplibre-gl.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * MapLibre\3092OSM Bright - Vector Tile\3067\521D\671F\5316\3059\308B\3002'),
' * Ref: https://maps.oracle.com/elocation/mapstyles.html',
' */',
unistr('/* Vector Tile\3092\8FD4\3059ORDS REST\30B5\30FC\30D3\30B9\306B\5408\308F\305B\3066\5909\66F4\3059\308B\3002 */'),
'const PREFIX_URL = ''http://localhost:8181/ords/apexdev/'';',
'',
'const map = new maplibregl.Map({',
'    container: ''map'',',
'    style: ''https://elocation.oracle.com/mapviewer/pvt/res/style/osm-bright/style.json'',',
unistr('    center: [139.6917, 35.6895], // \4E2D\5FC3\306F\6771\4EAC\3002'),
'    zoom: 4,',
'    transformRequest: (url, resourceType) => {',
'        if (resourceType === ''Tile'' && url.startsWith(PREFIX_URL)) {',
unistr('            // APEX\30BB\30C3\30B7\30E7\30F3\3067\8A8D\8A3C\3059\308B\3002'),
'            const auth = `${apex.env.APP_ID},${apex.env.APP_SESSION}`;',
'            return {',
'                url: url,',
'                headers: {',
'                    ''Apex-Session'': auth',
'                }',
'            };',
'        };',
'        return { url: url };',
'    }',
'});',
'',
'/*',
unistr(' * Map\30ED\30FC\30C9\6642\306BORDS REST\30B5\30FC\30D3\30B9\3092\547C\3073\51FA\3057\3066\9707\6E90\5730\306EVector Tile\3092\53D6\5F97\3059\308B\3002'),
' */',
'map.on(''load'', function () {',
'    // USGS Earthquakes',
'    map.addSource(''earthquakes'', {',
'      type: ''vector'',',
'      tiles: [',
'        `${PREFIX_URL}usgs/vt/${apex.items.P4_MAG.value}/{z}/{x}/{y}.pbf`',
'      ]',
'});',
'map.addLayer({',
'    ''id'': ''earthquakes-layer'',',
'    ''type'': ''circle'',',
'    ''source'': ''earthquakes'',',
'    ''source-layer'': ''LAYER'',',
'    ''layout'': {},',
'    ''paint'': {',
'        ''circle-radius'': 6,',
'        ''circle-color'': ''#8B3626'',',
'        ''circle-stroke-color'': ''white'',',
'        ''circle-stroke-width'': 1,',
'        ''circle-opacity'': 0.5}',
'    });',
'});',
'',
'/*',
unistr(' * \9707\6E90\5730\3092\30AF\30EA\30C3\30AF\3057\305F\3068\304D\306B\3001\5730\9707\306E\8A73\7D30\3092\8868\793A\3059\308B\3002'),
' */',
'map.on(''click'', ''earthquakes-layer'', function(event) {',
'    apex.debug.info(event.features);',
'    const popup = new maplibregl.Popup();',
'    const longitude = event.lngLat.lng;',
'    const latitude  = event.lngLat.lat;',
'    popup.setLngLat({lng: (longitude), lat: latitude}).setHTML(`<span>Date: ${event.features[0].properties.TIME_UTC}<br>Magnitude: ${event.features[0].properties.MAG}<br>Location: ${event.features[0].properties.PLACE}</span>`).addTo(map);',
'});',
'',
'// Add zoom and rotation controls to the map',
'map.addControl(new maplibregl.NavigationControl());',
'// Add full screen map',
'map.addControl(new maplibregl.FullscreenControl());'))
,p_css_file_urls=>'https://cdn.jsdelivr.net/npm/maplibre-gl@5.7.3/dist/maplibre-gl.min.css'
,p_inline_css=>'#map { position: absolute; top: 0; bottom: 0; width: 100%; }'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20213697116081343)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h640:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>'<div id="map"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20257684750766228)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(20161042439528596)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20213532855081342)
,p_name=>'P4_MAG'
,p_is_required=>true
,p_item_sequence=>10
,p_item_default=>'7'
,p_prompt=>'Matunitude'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp.component_end;
end;
/
