prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Earthquakes'
,p_alias=>'EARTHQUAKES'
,p_step_title=>'Earthquakes'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2526643373347724467
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20205461915071415)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(20161042439528596)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20206118221071418)
,p_plug_name=>unistr('\30DE\30C3\30D7')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'USGS_EARTHQUAKES'
,p_include_rowid_column=>false
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(20208150980071421)
,p_region_id=>wwv_flow_imp.id(20206118221071418)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'139.6917'
,p_init_position_lat_static=>'35.6895'
,p_init_zoomlevel_static=>'4'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(20208658094071421)
,p_map_region_id=>wwv_flow_imp.id(20208150980071421)
,p_name=>'Earthquakes'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_pk_column=>'EVENT_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'EPICENTER'
,p_fill_color=>'#8b3626'
,p_fill_opacity=>.5
,p_point_display_type=>'ICON'
,p_point_icon_source_type=>'STATIC_CLASS'
,p_point_icon_css_classes=>'fa-dot-circle-o'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Date: &TIME_UTC.<br>',
'Mag: &MAG.<br>',
'Place: &PLACE.'))
,p_info_window_adv_formatting=>false
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20206205492071418)
,p_plug_name=>unistr('\691C\7D22')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(20206118221071418)
,p_landmark_label=>unistr('\30D5\30A3\30EB\30BF')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20207034254071420)
,p_plug_name=>unistr('\30DC\30BF\30F3\30FB\30D0\30FC')
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20207574870071421)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(20207034254071420)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>unistr('\30EA\30BB\30C3\30C8')
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:RR,3::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20206718016071419)
,p_name=>'P3_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>unistr('\691C\7D22')
,p_source=>'EVENT_ID,MAG_TYPE,NET,PLACE,TYPE,STATUS,LOCATION_SOURCE,MAG_SOURCE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'collapsed_search_field', 'N',
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_collapsible=>false
,p_fc_initial_collapsed=>false
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20211223307081319)
,p_name=>'P3_EVENT_ID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'EVENT_ID'
,p_source=>'EVENT_ID'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20211382112081320)
,p_name=>'P3_TIME_UTC'
,p_source_data_type=>'TIMESTAMP_TZ'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'Time'
,p_source=>'TIME_UTC'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'N',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20211461109081321)
,p_name=>'P3_LATITUDE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'LATITUDE'
,p_source=>'LATITUDE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20211507574081322)
,p_name=>'P3_LONGITUDE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'LONGITUDE'
,p_source=>'LONGITUDE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20211633720081323)
,p_name=>'P3_EPICENTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'EPICENTER'
,p_source=>'EPICENTER'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20211786675081324)
,p_name=>'P3_DEPTH_KM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'DEPTH_KM'
,p_source=>'DEPTH_KM'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20211861852081325)
,p_name=>'P3_MAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'Magnitude'
,p_source=>'MAG'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'N',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20211999799081326)
,p_name=>'P3_MAG_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'MAG_TYPE'
,p_source=>'MAG_TYPE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20212075438081327)
,p_name=>'P3_NST'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'NST'
,p_source=>'NST'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20212194301081328)
,p_name=>'P3_GAP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'GAP'
,p_source=>'GAP'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20212289219081329)
,p_name=>'P3_DMIN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'DMIN'
,p_source=>'DMIN'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20212350966081330)
,p_name=>'P3_RMS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'RMS'
,p_source=>'RMS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20212447638081331)
,p_name=>'P3_NET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'NET'
,p_source=>'NET'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20212515453081332)
,p_name=>'P3_UPDATED_UTC'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'UPDATED_UTC'
,p_source=>'UPDATED_UTC'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20212608554081333)
,p_name=>'P3_PLACE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'PLACE'
,p_source=>'PLACE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20212703307081334)
,p_name=>'P3_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'TYPE'
,p_source=>'TYPE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20212845816081335)
,p_name=>'P3_HORIZONTAL_ERROR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'HORIZONTAL_ERROR'
,p_source=>'HORIZONTAL_ERROR'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20212926419081336)
,p_name=>'P3_DEPTH_ERROR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'DEPTH_ERROR'
,p_source=>'DEPTH_ERROR'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20213021457081337)
,p_name=>'P3_MAG_ERROR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'MAG_ERROR'
,p_source=>'MAG_ERROR'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20213124809081338)
,p_name=>'P3_MAG_NST'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'MAG_NST'
,p_source=>'MAG_NST'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20213221605081339)
,p_name=>'P3_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'STATUS'
,p_source=>'STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20213399532081340)
,p_name=>'P3_LOCATION_SOURCE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'LOCATION_SOURCE'
,p_source=>'LOCATION_SOURCE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20213406389081341)
,p_name=>'P3_MAG_SOURCE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(20206205492071418)
,p_prompt=>'MAG_SOURCE'
,p_source=>'MAG_SOURCE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(20160477127528596)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp.component_end;
end;
/
