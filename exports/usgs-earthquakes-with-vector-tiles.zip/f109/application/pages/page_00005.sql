prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'OpenLayers'
,p_alias=>'OPENLAYERS'
,p_step_title=>'OpenLayers'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/ol@10.6.1/dist/ol.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \9707\6E90\5730\306E\30B9\30BF\30A4\30EB\3002 '),
' */',
'function getEarthquakeStyle(feature) {',
'    const magnitude = feature.get(''MAG'') || 0;',
'    let color, radius;',
'      ',
'    if (magnitude >= 8.0) {',
unistr('        color = ''rgba(255, 0, 0, 0.8)'';  // \8D64'),
'        radius = 10;',
'    } else if (magnitude >= 7.0) {',
unistr('        color = ''rgba(255, 165, 0, 0.8)''; // \30AA\30EC\30F3\30B8'),
'        radius = 8;',
'    } else if (magnitude >= 6.0) {',
unistr('        color = ''rgba(255, 255, 0, 0.8)''; // \9EC4'),
'        radius = 6;',
'    } else {',
unistr('        color = ''rgba(0, 0, 255, 0.6)'';   // \9752'),
'        radius = 4;',
'    }',
'',
'    return new ol.style.Style({',
'        image: new ol.style.Circle({',
'            radius: radius,',
'            fill: new ol.style.Fill({',
'                color: color',
'            }),',
'            stroke: new ol.style.Stroke({',
'                color: ''rgba(0, 0, 0, 0.5)'',',
'                width: 1',
'            })',
'        })',
'    });',
'}',
'',
'/*',
unistr(' * Oracle Database\304B\3089\30D9\30AF\30BF\30FC\30BF\30A4\30EB\3092\53D6\5F97\3059\308B\3002'),
' */',
'const PREFIX_URL = ''http://localhost:8181/ords/apexdev/'';',
'',
'const oracleEarthquakeLayer = new ol.layer.VectorTile({',
'    title: ''Oracle USGS Earthquakes'',',
'    source: new ol.source.VectorTile({',
'        format: new ol.format.MVT(),',
'        url: `${PREFIX_URL}usgs/vt/${apex.items.P5_MAG.value}/{z}/{x}/{y}.pbf`,',
'        tileLoadFunction: function(tile, url) {',
'            tile.setLoader((extent, resolution, projection) => {',
'                fetch(url, {',
'                    method: ''GET'',',
'                    headers: {',
'                        ''Apex-Session'': `${apex.env.APP_ID},${apex.env.APP_SESSION}`',
'                    }',
'                })',
'                .then(response => {',
'                    if (!response.ok) {',
'                        throw new Error(''Network response was not ok'');',
'                    }',
'                    return response.arrayBuffer();',
'                })',
'                .then(data => {',
'                    const format = new ol.format.MVT();',
'                    const features = format.readFeatures(data, {',
'                        extent: extent,',
'                        featureProjection: projection',
'                    });',
'                    tile.setFeatures(features);',
'                })',
'                .catch(error => {',
'                    console.error(''Tile loading error:'', error);',
'                    tile.setFeatures([]);',
'                })            ',
'            })',
'        }',
'    }),',
'    style: getEarthquakeStyle',
'});',
'',
'/*',
unistr(' * OpenLayers \306E\5730\56F3\3092\521D\671F\5316\3002'),
' */',
'let map;',
'    ',
unistr('// \30C7\30D5\30A9\30EB\30C8\30B3\30F3\30C8\30ED\30FC\30EB\306E\8A2D\5B9A'),
'const defaultControls = [',
unistr('    new ol.control.Zoom(), // \57FA\672C\7684\306A\30BA\30FC\30E0\30DC\30BF\30F3\306E\307F'),
unistr('    new ol.control.Attribution(), // \5E30\5C5E\8868\793A'),
'    new ol.control.ScaleLine({',
'        units: ''metric''',
'    })',
'];',
'',
unistr('// \6771\4EAC\306E\5EA7\6A19\3092Web Mercator\306B\5909\63DB'),
unistr('const tokyoCoords = ol.proj.fromLonLat([139.6917, 35.6895]); // [\7D4C\5EA6, \7DEF\5EA6] \2192 Web Mercator'),
'',
'map = new ol.Map({',
'    target: "map",',
'    layers: [',
'        new ol.layer.Tile({',
'            source: new ol.source.OSM()',
'        }),',
'        oracleEarthquakeLayer',
'    ],',
'    view: new ol.View({',
unistr('        // EPSG:3857\6295\5F71\6CD5\3092\4F7F\7528\FF08Web Mercator - \6A19\6E96\7684\FF09'),
'        projection: ''EPSG:3857'',',
'        center: tokyoCoords,',
'        zoom: 4,',
'        minZoom: 1,',
'        maxZoom: 18',
'    }),',
'    controls: defaultControls',
'});',
'',
'/* ',
unistr(' * VectorTile\7528\306Efeature\691C\51FA\95A2\6570'),
' */',
'function getFeatureAtPixel(pixel) {',
'    let foundFeature = null;',
'      ',
'    map.forEachFeatureAtPixel(pixel, function(feature, layer) {',
'        apex.debug.info(''Found feature on layer:'', layer.get(''title''));',
'        apex.debug.info(''Feature properties:'', feature.getProperties());',
'        if (layer === oracleEarthquakeLayer) {',
'            foundFeature = feature;',
unistr('            return true; // \505C\6B62'),
'        }',
'    }, {',
unistr('        hitTolerance: 15, // \30AF\30EA\30C3\30AF\5224\5B9A\7BC4\56F2\3092\5E83\3052\308B'),
'        layerFilter: function(checkLayer) {',
'            return checkLayer === oracleEarthquakeLayer;',
'        }',
'    });  ',
'    return foundFeature;',
'}',
'',
'/* ',
unistr(' * \30AF\30EA\30C3\30AF\30A4\30D9\30F3\30C8\3002'),
' */',
'map.on(''singleclick'', function(event) {',
'    apex.debug.info(''Map clicked at: '', event.coordinate);',
'    apex.debug.info(''Click pixel: '', event.pixel);',
'      ',
'    const feature = getFeatureAtPixel(event.pixel);',
'      ',
'    if (feature) {',
'        apex.debug.info(''Clicked feature found:'', feature.getProperties());',
'        const props = feature.getProperties();',
'        const coords = ol.proj.toLonLat(event.coordinate);',
'        ',
unistr('        // \30D7\30ED\30D1\30C6\30A3\540D\306E\53D6\5F97\FF08Oracle DB\304B\3089\FF09'),
'        const magnitude = props.MAG || 0;',
'        const place     = props.PLACE || ''N/A'';',
'        const depth     = props.DEPTH_KM || ''N/A'';',
'        const time      = props.TIME_UTC;',
'                ',
'        const timeStr = time ? new Date(time).toLocaleString(''ja-JP'') : ''N/A'';',
'        ',
'        const detailPopup = `',
'          <div style="',
'            position: fixed;',
'            top: 50%;',
'            left: 50%;',
'            transform: translate(-50%, -50%);',
'            background: white;',
'            border-radius: 8px;',
'            padding: 20px;',
'            box-shadow: 0 4px 20px rgba(0,0,0,0.3);',
'            z-index: 2000;',
'            min-width: 300px;',
'            max-width: 400px;',
'          ">',
'            <div style="text-align: center; margin-bottom: 15px;">',
unistr('              <h3 style="margin: 0; color: #d32f2f;">\D83C\DF0B \5730\9707\8A73\7D30\60C5\5831</h3>'),
'            </div>',
'            <div style="line-height: 1.6;">',
unistr('              <p><strong>\30DE\30B0\30CB\30C1\30E5\30FC\30C9:</strong> M ${magnitude.toFixed(2)}</p>'),
unistr('              <p><strong>\5834\6240:</strong> ${place}</p>'),
unistr('              <p><strong>\6DF1\3055:</strong> ${typeof depth === ''number'' ? depth.toFixed(1) + '' km'' : depth}</p>'),
unistr('              <p><strong>\767A\751F\6642\523B:</strong> ${timeStr}</p>'),
unistr('              <p><strong>\5EA7\6A19:</strong> ${coords[1].toFixed(6)}\00B0N, ${coords[0].toFixed(6)}\00B0E</p>'),
'            </div>',
'            <div style="text-align: center; margin-top: 15px;">',
'              <button onclick="this.parentElement.parentElement.remove()" ',
'                style="',
'                  background: #d32f2f;',
'                  color: white;',
'                  border: none;',
'                  padding: 8px 16px;',
'                  border-radius: 4px;',
'                  cursor: pointer;',
unistr('                ">\9589\3058\308B</button>'),
'            </div>',
'          </div>',
'          <div style="',
'            position: fixed;',
'            top: 0;',
'            left: 0;',
'            width: 100%;',
'            height: 100%;',
'            background: rgba(0,0,0,0.5);',
'            z-index: 1999;',
'          " onclick="this.parentElement.remove()"></div>',
'        `;',
'        ',
'        const modalDiv = document.createElement(''div'');',
'        modalDiv.innerHTML = detailPopup;',
'        document.body.appendChild(modalDiv);',
'    } else {',
'        apex.debug.info(''No features found at click location'');',
'    }',
'});'))
,p_css_file_urls=>'https://cdn.jsdelivr.net/npm/ol@10.6.1/ol.min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#map { position: absolute; top: 0; bottom: 0; width: 100%; }',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20213837351081345)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h640:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="map"></div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20345011346958416)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(20161042439528596)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20213702404081344)
,p_name=>'P5_MAG'
,p_is_required=>true
,p_item_sequence=>10
,p_item_default=>'7'
,p_prompt=>'Magnitude'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp.component_end;
end;
/
