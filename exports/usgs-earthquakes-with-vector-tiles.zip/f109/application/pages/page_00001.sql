prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'USGS Earthquakes'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20174202194528621)
,p_plug_name=>'USGS Earthquakes'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20347802177173402)
,p_plug_name=>'Earthquakes'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc:margin-top-sm'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>70
,p_query_type=>'TABLE'
,p_query_table=>'USGS_EARTHQUAKES'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(20347920698173403)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>20347920698173403
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20348022393173404)
,p_db_column_name=>'EVENT_ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Event Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20348153175173405)
,p_db_column_name=>'TIME_UTC'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Time Utc'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20348209831173406)
,p_db_column_name=>'LATITUDE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Latitude'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20348315060173407)
,p_db_column_name=>'LONGITUDE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Longitude'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20348452263173408)
,p_db_column_name=>'EPICENTER'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Epicenter'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20348520938173409)
,p_db_column_name=>'DEPTH_KM'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Depth Km'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20348648669173410)
,p_db_column_name=>'MAG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Mag'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20348794384173411)
,p_db_column_name=>'MAG_TYPE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Mag Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20348834916173412)
,p_db_column_name=>'NST'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Nst'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20348917005173413)
,p_db_column_name=>'GAP'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Gap'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20349021426173414)
,p_db_column_name=>'DMIN'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Dmin'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20349118998173415)
,p_db_column_name=>'RMS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Rms'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20349243365173416)
,p_db_column_name=>'NET'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Net'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20349342049173417)
,p_db_column_name=>'UPDATED_UTC'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Updated Utc'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20349428721173418)
,p_db_column_name=>'PLACE'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Place'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20349594845173419)
,p_db_column_name=>'TYPE'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20349673382173420)
,p_db_column_name=>'HORIZONTAL_ERROR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Horizontal Error'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20349729632173421)
,p_db_column_name=>'DEPTH_ERROR'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Depth Error'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20349831884173422)
,p_db_column_name=>'MAG_ERROR'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Mag Error'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20349974943173423)
,p_db_column_name=>'MAG_NST'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Mag Nst'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20350030705173424)
,p_db_column_name=>'STATUS'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20350117841173425)
,p_db_column_name=>'LOCATION_SOURCE'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Location Source'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20350200793173426)
,p_db_column_name=>'MAG_SOURCE'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Mag Source'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(20360951773177702)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'203610'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EVENT_ID:TIME_UTC:LATITUDE:LONGITUDE:EPICENTER:DEPTH_KM:MAG:MAG_TYPE:NST:GAP:DMIN:RMS:NET:UPDATED_UTC:PLACE:TYPE:HORIZONTAL_ERROR:DEPTH_ERROR:MAG_ERROR:MAG_NST:STATUS:LOCATION_SOURCE:MAG_SOURCE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20214327443081350)
,p_button_sequence=>50
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Load'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20347737127173401)
,p_button_sequence=>60
,p_button_name=>'CLEAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Clear'
,p_confirm_message=>unistr('\672C\5F53\306B\524A\9664\3057\307E\3059\304B\FF1F')
,p_confirm_style=>'danger'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20213918624081346)
,p_name=>'P1_START_TIME'
,p_item_sequence=>10
,p_prompt=>'Start Time'
,p_format_mask=>'YYYY-MM-DD HH24:MI:SS'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'Y',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20214032495081347)
,p_name=>'P1_END_TIME'
,p_item_sequence=>20
,p_prompt=>'End Time'
,p_format_mask=>'YYYY-MM-DD HH24:MI:SS'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'Y',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20214192601081348)
,p_name=>'P1_MAG'
,p_item_sequence=>30
,p_prompt=>'Magnitude'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20214240129081349)
,p_name=>'P1_PROCESSED_ROWS'
,p_item_sequence=>40
,p_prompt=>'Processed Rows'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(20350346969173427)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update Earthquakes events from USGS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_USGS_EARTHQUAKES_QUERY constant varchar2(100) := ''https://earthquake.usgs.gov/fdsnws/event/1/query.csv?starttime=%s&endtime=%s&minmagnitude=%s'';',
'    l_csv clob;',
'    l_url varchar2(140);',
'    e_get_csv_failed exception;',
'    l_load_result apex_data_loading.t_data_load_result;',
'begin',
unistr('    /* \30C7\30FC\30BF\53D6\5F97URL\3092\4F5C\6210 */'),
'    l_url := apex_string.format(C_USGS_EARTHQUAKES_QUERY,',
'        replace(:P1_START_TIME,'' '',''%20''), replace(:P1_END_TIME,'' '',''%20''), to_char(:P1_MAG)',
'    );',
'    apex_debug.info(''Query URL: %s'', l_url);',
unistr('    /* CSV\5F62\5F0F\3067\30C7\30FC\30BF\3092\53D6\5F97\3059\308B\3002 */'),
'    apex_web_service.set_request_headers(''Content-Type'', ''text/csv'');',
'    l_csv := apex_web_service.make_rest_request(',
'        p_url => l_url,',
'        p_http_method => ''GET''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_get_csv_failed;',
'    end if;',
unistr('    /* \30C7\30FC\30BF\3092\30ED\30FC\30C9\3059\308B\3002 */'),
'    l_load_result := apex_data_loading.load_data (',
'        p_static_id    => ''usgs_earthquakes'',',
'        p_data_to_load => l_csv',
'    );',
'    :P1_PROCESSED_ROWS := l_load_result.processed_rows;',
unistr('    /* \7D22\5F15\306E\30EA\30D3\30EB\30C9 */'),
'    /*',
'     * CREATE INDEX usgs_earthquakes_sidx',
'     * ON usgs_earthquakes (epicenter)',
'     * INDEXTYPE IS MDSYS.SPATIAL_INDEX_V2 PARAMETERS (''LAYER_GTYPE=POINT'');',
'     */',
'    execute immediate ''alter index usgs_earthquakes_sidx rebuild'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(20214327443081350)
,p_internal_uid=>20350346969173427
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(20350409928173428)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete all rows in USGS_EARTHQUAKES'
,p_process_sql_clob=>'delete from usgs_earthquakes;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(20347737127173401)
,p_internal_uid=>20350409928173428
);
wwv_flow_imp.component_end;
end;
/
