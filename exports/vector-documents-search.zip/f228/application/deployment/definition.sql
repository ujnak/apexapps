prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 228
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>228
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(43983270866542678)
,p_prompt_sub_string_02=>'Y'
,p_install_prompt_02=>unistr('Pinecone\306E\30A4\30F3\30C7\30C3\30AF\30B9 - 768\6B21\5143')
);
wwv_flow_imp.component_end;
end;
/
