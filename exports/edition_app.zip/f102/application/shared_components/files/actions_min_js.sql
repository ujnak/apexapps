prompt --application/shared_components/files/actions_min_js
begin
--   Manifest
--     APP STATIC FILES: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8511951130686308
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '636F6E7374205345545F4D595F544558543D7B6E616D653A227365742D6D792D74657874222C616374696F6E3A28652C742C61293D3E7B617065782E6974656D28612E746172676574292E73657456616C7565282254686973206973204D41494E22297D';
wwv_flow_imp.g_varchar2_table(2) := '7D3B617065782E6A51756572792877696E646F77292E6F6E28227468656D6534327265616479222C2828293D3E7B617065782E616374696F6E732E616464285B5345545F4D595F544558545D297D29293B';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(9489274914213429)
,p_file_name=>'actions.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
