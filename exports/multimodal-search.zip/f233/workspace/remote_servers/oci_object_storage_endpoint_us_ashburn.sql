prompt --workspace/remote_servers/oci_object_storage_endpoint_us_ashburn
begin
--   Manifest
--     REMOTE SERVER: OCI Object Storage Endpoint - US Ashburn
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>233
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(40968547496358049)
,p_name=>'OCI Object Storage Endpoint - US Ashburn'
,p_static_id=>'OCI_Object_Storage_Endpoint_US_Ashburn'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('OCI_Object_Storage_Endpoint_US_Ashburn'),'https://objectstorage.us-ashburn-1.oraclecloud.com/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('OCI_Object_Storage_Endpoint_US_Ashburn'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('OCI_Object_Storage_Endpoint_US_Ashburn'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('OCI_Object_Storage_Endpoint_US_Ashburn'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('OCI_Object_Storage_Endpoint_US_Ashburn'),'')
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
