prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 233
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>233
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(41025548503076169)
,p_prompt_sub_string_02=>'Y'
,p_install_prompt_02=>unistr('Pincone\306EIndex URL')
,p_prompt_sub_string_03=>'Y'
,p_install_prompt_03=>unistr('embedding\3092\751F\6210\3059\308BREST\30B5\30FC\30D3\30B9')
,p_prompt_sub_string_04=>'Y'
,p_install_prompt_04=>'Object Storage Namespace'
,p_prompt_sub_string_05=>'Y'
,p_install_prompt_05=>'Object Storage Bucket'
);
wwv_flow_imp.component_end;
end;
/
