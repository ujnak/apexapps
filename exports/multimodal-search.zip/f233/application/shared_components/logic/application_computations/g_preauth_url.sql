prompt --application/shared_components/logic/application_computations/g_preauth_url
begin
--   Manifest
--     APPLICATION COMPUTATION: G_PREAUTH_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>233
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(40986418340526595)
,p_computation_sequence=>10
,p_computation_item=>'G_PREAUTH_URL'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_BASE_URL constant varchar2(200) := ''https://objectstorage.us-ashburn-1.oraclecloud.com/n/'' || :G_NAMESPACE || ''/b/'' || :G_BUCKET || ''/p/'';',
'    l_request clob;',
'    l_response clob;',
'    l_response_json json_object_t;',
'    l_access_uri varchar2(400);',
'begin',
'    select json_object(',
'        key ''accessType'' value ''AnyObjectRead'',',
'        key ''name'' value  ''standard-'' || sys_guid(),',
'        key ''timeExpires'' value systimestamp + interval ''1'' hour',
'    ) into l_request from dual;',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'', ''application/json'', p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_BASE_URL',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''OCI_API_ACCESS''',
'    );',
'    l_response_json := json_object_t(l_response);',
'    l_access_uri := l_response_json.get_string(''accessUri'');',
'    return ''https://objectstorage.us-ashburn-1.oraclecloud.com'' || l_access_uri;',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
