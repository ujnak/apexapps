prompt --application/shared_components/data_profiles/list_bucket
begin
--   Manifest
--     DATA PROFILE: list_bucket
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>233
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(40948657196803240)
,p_name=>'list_bucket'
,p_format=>'JSON'
,p_row_selector=>'objects'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(40948801550803243)
,p_data_profile_id=>wwv_flow_imp.id(40948657196803240)
,p_name=>'NAME'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'name'
);
wwv_flow_imp.component_end;
end;
/
