prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>233
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Image Search'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230711021324'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39501492368658311)
,p_plug_name=>'Image Indexes'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(40725136207768646)
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''image'' as image, i.name, x.is_indexed ',
'from vec_images i left outer join vec_image_indexes x on i.name = x.file_name'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Image Indexes'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(39501554475658312)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>39501554475658312
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39503550407658332)
,p_db_column_name=>'IMAGE'
,p_display_order=>10
,p_column_identifier=>'E'
,p_column_label=>'Image'
,p_column_html_expression=>'<img src="&G_PREAUTH_URL.#NAME#" width="30"></img>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39501645473658313)
,p_db_column_name=>'NAME'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39501951467658316)
,p_db_column_name=>'IS_INDEXED'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Is Indexed'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(40953405630874601)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'409535'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IMAGE:NAME:IS_INDEXED:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39502867780658325)
,p_plug_name=>'Results'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(40725136207768646)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>'select c001, n001 from apex_collections where collection_name = ''IMAGES'''
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Results'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(39502976027658326)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>39502976027658326
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39503069972658327)
,p_db_column_name=>'C001'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'C001'
,p_column_html_expression=>'<img src="&G_PREAUTH_URL.#C001#" width="200"></img>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39503173568658328)
,p_db_column_name=>'N001'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'N001'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(40960369830111826)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'409604'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'C001:N001'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39503446745658331)
,p_plug_name=>'Initialize Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(40716427116768642)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40945375844768832)
,p_plug_name=>'Image Search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(40737053310768652)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39502567071658322)
,p_button_sequence=>70
,p_button_name=>'FIND_IMAGES'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(40826092424768712)
,p_button_image_alt=>'Find Images'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39502014708658317)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(39503446745658331)
,p_button_name=>'UPSERT_VECTORS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(40826092424768712)
,p_button_image_alt=>'Upsert Vectors'
,p_button_position=>'CHANGE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39501257672658309)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(39503446745658331)
,p_button_name=>'LOAD_FROM_BUCKET'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(40826092424768712)
,p_button_image_alt=>'Load From Bucket'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39503343255658330)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(39503446745658331)
,p_button_name=>'DELETE_ALL_VECTORS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(40826092424768712)
,p_button_image_alt=>'Delete All Vectors'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39502405541658321)
,p_name=>'P1_QUESTION'
,p_item_sequence=>50
,p_prompt=>'Question'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(40823515133768709)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39502763623658324)
,p_name=>'P1_TOP_K'
,p_item_sequence=>60
,p_item_default=>'1'
,p_prompt=>'Top K'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(40823515133768709)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39501379644658310)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load from Bucket'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    apex_rest_source_sync.synchronize_data(',
'        p_module_static_id      => ''list_images'',',
'        p_run_in_background     => false );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39501257672658309)
,p_internal_uid=>39501379644658310
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39502125877658318)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Upsert Vectors'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request clob;',
'    l_request_json json_object_t;',
'    l_vectors json_array_t;',
'    l_vector  json_object_t;',
'    l_embedding json_array_t;',
'    l_response clob;',
'    l_response_json json_object_t;',
'    C_UPSERT constant varchar2(100) := :G_INDEX || ''/vectors/upsert'';',
'    e_upsert_exception exception;',
'begin',
'    /*',
unistr('     * Pincone\306Eindex\306B\672A\767B\9332\306E\753B\50CF\3092\767B\9332\3059\308B\3002'),
'     */',
'    l_vectors := json_array_t();',
'    for r in (',
'        select i.name',
'        from vec_images i left outer join vec_image_indexes x on i.name = x.file_name',
'        where x.is_indexed is null',
'    )',
'    loop',
unistr('        /* \30A4\30E1\30FC\30B8\306Eembedding\3092\751F\6210\3059\308B. */'),
'        select json_object(',
'            key ''url'' value :G_PREAUTH_URL || r.name',
'        ) into l_request',
'        from dual;',
'        apex_web_service.clear_request_headers;',
'        apex_web_service.set_request_headers(''Accept'',''application/json'',p_reset => false);',
'        apex_web_service.set_request_headers(''Content-Type'',''application/json'',p_reset => false);',
'        l_response := apex_web_service.make_rest_request(',
'            p_url => :G_EMBED || ''/embed-image''',
'            ,p_http_method => ''POST''',
'            ,p_body => l_request',
'        );',
'        l_response_json := json_object_t(l_response);',
'        l_embedding     := l_response_json.get_array(''embedding'');',
'        l_vector := json_object_t();',
'        l_vector.put(''id'', r.name);',
'        l_vector.put(''values'', l_embedding);',
unistr('        /* \3053\306E\30D9\30AF\30C8\30EB\304Cimage\304B\3089\751F\6210\3055\308C\305F\3053\3068\3092\3001metadata\3068\3057\3066\8FFD\52A0\3059\308B\3002 */'),
'        l_vector.put(''metadata'', json_object_t(''{ "type":"image" }''));',
'        l_vectors.append(l_vector);',
'        insert into vec_image_indexes(file_name, is_indexed) values(r.name, ''Y'');',
'    end loop;',
'    if l_vectors.get_size = 0 then',
unistr('        /* \8FFD\52A0\3059\308B\6587\66F8\304C\306A\3044\306E\3067\7D42\4E86 */'),
'        return;',
'    end if;',
'    l_request_json := json_object_t();',
'    l_request_json.put(''vectors'', l_vectors);',
'    l_request := l_request_json.to_clob;',
'    /*',
unistr('     * Pinecone\306EUpsert\3092\547C\3073\51FA\3059\3002'),
'     */',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'',p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'',p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_UPSERT',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''PINECONE_API''',
'    );',
unistr('    /* \30EC\30B9\30DD\30F3\30B9\672C\6587\306F\89E3\6790\4E0D\8981\3002 */'),
'    apex_debug.info(l_response);',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_upsert_exception;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39502014708658317)
,p_internal_uid=>39502125877658318
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39502668616658323)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Find Images'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request clob;',
'    l_response clob;',
'    l_response_json json_object_t;',
'    l_embedding  json_array_t;',
'    /* Pinecone */',
'    l_query_json json_object_t;',
'    l_matches json_array_t;',
'    l_vector  json_object_t;',
'    l_file_name vec_image_indexes.file_name%type;',
'    l_score   number;',
'    C_QUERY constant varchar2(80) := :G_INDEX || ''/query'';',
'    e_query_exception exception;',
'begin',
'    /*',
unistr('     * \6700\521D\306B/embed-text\3092\547C\3073\51FA\3057\3066\3001\8CEA\554F\306Eembedding\3092\751F\6210\3059\308B\3002'),
'     */',
'    select json_object(',
'        key ''text'' value :P1_QUESTION',
'    ) into l_request',
'    from dual;',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'', p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => :G_EMBED || ''/embed-text''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'    );',
'    -- apex_debug.info(l_response);',
'    l_response_json := json_object_t.parse(l_response);',
'    l_embedding     := l_response_json.get_array(''embedding'');',
'    /*',
unistr('     * Pinecone\306B\554F\3044\5408\308F\305B\308B\3002'),
'     */',
'    l_query_json := json_object_t();',
unistr('    /* \691C\7D22\5BFE\8C61\3092\753B\50CF\306B\9650\5B9A\3059\308B\3002 */'),
'    l_query_json.put(''filter'', json_object_t(''{ "type" : "image" }''));',
'    l_query_json.put(''includeValues'', false);',
'    l_query_json.put(''includeMetadata'', false);',
'    l_query_json.put(''vector'', l_embedding);',
'    l_query_json.put(''topK'', :P1_TOP_K);',
'    l_request := l_query_json.to_clob;',
unistr('    /* query\3092\547C\3073\51FA\3059\3002 */'),
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'',p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'',p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_QUERY',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''PINECONE_API''',
'    );',
'    -- apex_debug.info(l_response);',
'    if apex_web_service.g_status_code <> 200 then',
'        apex_debug.info(l_response);',
'        raise e_query_exception;',
'    end if;',
'    /*',
unistr('     * \30EC\30B9\30DD\30F3\30B9\3092APEX\30B3\30EC\30AF\30B7\30E7\30F3\306B\4FDD\5B58\3059\308B\3002'),
'     */',
'    apex_collection.create_or_truncate_collection(''IMAGES'');   ',
'    l_response_json := json_object_t.parse(l_response);',
'    l_matches := l_response_json.get_array(''matches'');',
'    for i in 1..l_matches.get_size',
'    loop',
'        l_vector := json_object_t(l_matches.get(i-1));',
'        l_file_name := l_vector.get_string(''id'');',
'        l_score     := l_vector.get_number(''score'');',
'        apex_collection.add_member(',
'            p_collection_name => ''IMAGES''',
'            ,p_c001 => l_file_name',
'            ,p_n001 => l_score',
'        );',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39502567071658322)
,p_internal_uid=>39502668616658323
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39503257263658329)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete All Vectors'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'    C_DELETE constant varchar2(100) := :G_INDEX || ''/vectors/delete'';',
'    e_delete_exception exception;',
'begin',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'',p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'',p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_DELETE',
'        ,p_http_method => ''POST''',
'        ,p_body => ''{"deleteAll":true}''',
'        ,p_credential_static_id => ''PINECONE_API''',
'    );',
unistr('    /* \30EC\30B9\30DD\30F3\30B9\672C\6587\306F\89E3\6790\4E0D\8981\3002 */'),
'    apex_debug.info(l_response);',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_delete_exception;',
'    end if;',
unistr('    /* \30A4\30F3\30C7\30C3\30AF\30B9\6E08\307F\306E\30D5\30E9\30B0\3092\521D\671F\5316\3002 */'),
'    delete from vec_image_indexes;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39503343255658330)
,p_internal_uid=>39503257263658329
);
wwv_flow_imp.component_end;
end;
/
