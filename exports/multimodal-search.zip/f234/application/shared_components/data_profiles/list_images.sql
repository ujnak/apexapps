prompt --application/shared_components/data_profiles/list_images
begin
--   Manifest
--     DATA PROFILE: List Images
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>234
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(41331371228985745)
,p_name=>'List Images'
,p_format=>'JSON'
,p_row_selector=>'objects'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(41331551402985749)
,p_data_profile_id=>wwv_flow_imp.id(41331371228985745)
,p_name=>'NAME'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'name'
);
wwv_flow_imp.component_end;
end;
/
