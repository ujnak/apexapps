prompt --application/shared_components/web_sources/list_images
begin
--   Manifest
--     WEB SOURCE: List Images
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>234
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(41331812474985752)
,p_name=>'List Images'
,p_static_id=>'list_images'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(41331371228985745)
,p_remote_server_id=>wwv_flow_imp.id(40968547496358049)
,p_url_path_prefix=>'n/:namespace/b/:bucket/o/'
,p_credential_id=>wwv_flow_imp.id(8715697685729597)
,p_sync_table_name=>'VEC_IMAGES'
,p_sync_type=>'REPLACE'
,p_sync_max_http_requests=>1000
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(41346753923653255)
,p_web_src_module_id=>wwv_flow_imp.id(41331812474985752)
,p_name=>'namespace'
,p_param_type=>'URL_PATTERN'
,p_value=>'&G_NAMESPACE.'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(41347093023654448)
,p_web_src_module_id=>wwv_flow_imp.id(41331812474985752)
,p_name=>'bucket'
,p_param_type=>'URL_PATTERN'
,p_value=>'&G_BUCKET.'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(41332028316985754)
,p_web_src_module_id=>wwv_flow_imp.id(41331812474985752)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
