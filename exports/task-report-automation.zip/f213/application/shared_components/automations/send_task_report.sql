prompt --application/shared_components/automations/send_task_report
begin
--   Manifest
--     AUTOMATION: Send Task Report
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>213
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_automation(
 p_id=>wwv_flow_imp.id(17761111650430025)
,p_name=>'Send Task Report'
,p_static_id=>'send-task-report'
,p_trigger_type=>'API'
,p_polling_status=>'DISABLED'
,p_result_type=>'ROWS'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_type=>'TABLE'
,p_query_table=>'TSK_RECIPIENTS'
,p_include_rowid_column=>false
,p_commit_each_row=>false
,p_error_handling_type=>'IGNORE'
,p_code_snippet=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure prepare_report',
'as',
'begin',
'    tsk_prepare_report(',
'        p_application_id => :APP_ID',
'        ,p_page_id       => 2',
'        ,p_static_id     => ''task''',
'        ,p_report_alias  => ''ForEmailReport''',
'        ,p_collection_name => ''ATTACHMENT''',
'    );',
'end;',
''))
,p_init_proc_name=>'prepare_report'
);
wwv_flow_imp_shared.create_automation_action(
 p_id=>wwv_flow_imp.id(17761450057430026)
,p_automation_id=>wwv_flow_imp.id(17761111650430025)
,p_name=>unistr('\30EC\30DD\30FC\30C8\3092\30E1\30FC\30EB\3067\9001\4FE1')
,p_execution_sequence=>10
,p_action_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'replace_your_from_address@domain'
,p_attribute_02=>'&EMAIL_ADDRESS.'
,p_attribute_09=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select blob001, c001, c002, c003',
'from apex_collections where collection_name = ''ATTACHMENT'''))
,p_attribute_10=>'N'
,p_attribute_11=>wwv_flow_imp.id(17760416090263600)
,p_attribute_12=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "SEND_DATE":"&SYSDATE_YYYYMMDD.",',
'    "NAME":"&NAME.",',
'    "MY_APPLICATION_LINK":"https:\/\/this.app\/"',
'}'))
,p_attribute_14=>'HTML'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp.component_end;
end;
/
