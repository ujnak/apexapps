prompt --application/shared_components/email/templates/task_report
begin
--   Manifest
--     REPORT LAYOUT: Task Report
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>213
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(17760416090263600)
,p_name=>'Task Report'
,p_static_id=>'TASK_REPORT'
,p_version_number=>2
,p_subject=>unistr('\30BF\30B9\30AF\30FB\30EC\30DD\30FC\30C8 #SEND_DATE#')
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<strong>#NAME#\3055\3093</strong>'),
'<br>',
'<br>',
unistr('\672C\65E5\306E\30BF\30B9\30AF\4E00\89A7\3092\6DFB\4ED8\3057\307E\3059\3002<br>'),
'<br>'))
,p_html_header=>unistr('<b style="font-size: 24px;">\30BF\30B9\30AF\30FB\30EC\30DD\30FC\30C8 #SEND_DATE#</b>')
,p_html_footer=>unistr('<a href="#MY_APPLICATION_LINK#">\30BF\30B9\30AF\4E00\89A7\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306B\30A2\30AF\30BB\30B9\3059\308B\3002</a>')
,p_text_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('#NAME#\3055\3093'),
'',
unistr('\672C\65E5\306E\30BF\30B9\30AF\4E00\89A7\3092\6DFB\4ED8\3057\307E\3059\3002'),
'',
unistr('\30BF\30B9\30AF\4E00\89A7\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306B\30A2\30AF\30BB\30B9\3059\308B: #MY_APPLICATION_LINK#')))
);
wwv_flow_imp.component_end;
end;
/
