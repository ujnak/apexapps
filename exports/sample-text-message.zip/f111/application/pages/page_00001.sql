prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>111
,p_default_id_offset=>27704457332727184
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Text Message'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const COMPANY = ''&G_COMPANY.'';',
'const SENDER  = ''&G_SENDER.'';'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49071010956311415)
,p_plug_name=>unistr('\52D5\7684\30B3\30F3\30C6\30F3\30C4 - Pre 24.2')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob clob;',
'begin',
'    l_clob := apex_lang.message(''T_GREETING0'', :G_COMPANY, :G_SENDER);',
'    return l_clob;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49071081191311416)
,p_plug_name=>unistr('\9759\7684\30B3\30F3\30C6\30F3\30C4 - 24.2')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>'&{T_GREETING1 sender=&G_SENDER. company=&G_COMPANY. }!RAW.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49071352690311418)
,p_plug_name=>unistr('\52D5\7684\30B3\30F3\30C6\30F3\30C4 - 24.2')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob clob;',
'begin',
'    l_clob := apex_lang.get_message(''T_GREETING1'',',
'        apex_t_varchar2(',
'            ''sender'', :G_SENDER,',
'            ''company'', :G_COMPANY',
'        )',
'    );',
'    return l_clob;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49071387204311419)
,p_plug_name=>'JavaScript - 24.2'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source=>'<div id="greeting-242"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49071975485311425)
,p_plug_name=>'JavaScript - Pre 24.2'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<div id="greeting-pre242"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49072082390311426)
,p_plug_name=>unistr('\9759\7684\30B3\30F3\30C6\30F3\30C4 - Pre 24.2')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>'<div>&APP_TEXT$T_GREETING0!RAW.</div>'
,p_required_patch=>wwv_flow_imp.id(82506727615997708)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82520559031997735)
,p_plug_name=>'Text Message'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76566581326160812)
,p_name=>'Append Text Message - Pre 24.2'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76566664211160813)
,p_event_id=>wwv_flow_imp.id(76566581326160812)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Used in JavaScript is ON'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.getElementById("greeting-pre242").innerHTML = apex.lang.formatMessage( "T_GREETING0", COMPANY, SENDER );',
''))
,p_build_option_id=>wwv_flow_imp.id(82506727615997708)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76566764783160814)
,p_event_id=>wwv_flow_imp.id(76566581326160812)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'apex.lang.loadMessages'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const promise = apex.lang.loadMessages( ["T_GREETING0"] );',
'promise.done( () => {',
'    document.getElementById("greeting-pre242").innerHTML = apex.lang.formatMessage( "T_GREETING0", COMPANY, SENDER );',
'}).fail( () => {',
'    apex.debug.error("Could not get messages.");',
'});'))
,p_build_option_id=>wwv_flow_imp.id(82506727615997708)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76566880150160815)
,p_event_id=>wwv_flow_imp.id(76566581326160812)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'apex.lang.loadMessagesIfNeeded'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.lang.loadMessagesIfNeeded( ["T_GREETING0"], () => {',
'    document.getElementById("greeting-pre242").innerHTML = apex.lang.formatMessageNoEscape( "T_GREETING0", COMPANY, SENDER );',
'});',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76567470166160821)
,p_name=>'Append Text Message - 24.2'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76567553685160822)
,p_event_id=>wwv_flow_imp.id(76567470166160821)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Used in JavaScript is ON'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'document.getElementById("greeting-242").innerHTML = apex.lang.formatMessage( "T_GREETING1", { sender: SENDER, company: COMPANY } );'
,p_build_option_id=>wwv_flow_imp.id(82506727615997708)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76567664159160823)
,p_event_id=>wwv_flow_imp.id(76567470166160821)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'apex.lang.loadMessages'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const promise242 = apex.lang.loadMessages( ["T_GREETING1"] );',
'promise242.done( () => {',
'    document.getElementById("greeting-242").innerHTML = apex.lang.formatMessage( "T_GREETING1", { sender: SENDER, company: COMPANY } );',
'}).fail( () => {',
'    apex.debug.error("Could not get messages.");',
'});'))
,p_build_option_id=>wwv_flow_imp.id(82506727615997708)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76567780661160824)
,p_event_id=>wwv_flow_imp.id(76567470166160821)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'apex.lang.loadMessagesIfNeeded'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.lang.loadMessagesIfNeeded( ["T_GREETING1"], () => {',
'    document.getElementById("greeting-242").innerHTML = apex.lang.formatMessageNoEscape("T_GREETING1",  { sender: SENDER, company: COMPANY });',
'});',
''))
);
wwv_flow_imp.component_end;
end;
/
