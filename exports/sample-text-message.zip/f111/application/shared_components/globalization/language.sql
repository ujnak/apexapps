prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 111
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>111
,p_default_id_offset=>27497641421849418
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_language_map(
 p_id=>wwv_flow_imp.id(54818541013273442)
,p_translation_flow_id=>113
,p_translation_flow_language_cd=>'zh-cn'
);
wwv_flow_imp_shared.create_language_map(
 p_id=>wwv_flow_imp.id(54818608019274846)
,p_translation_flow_id=>115
,p_translation_flow_language_cd=>'ko'
);
wwv_flow_imp_shared.create_language_map(
 p_id=>wwv_flow_imp.id(54818686556277038)
,p_translation_flow_id=>116
,p_translation_flow_language_cd=>'en'
);
wwv_flow_imp.component_end;
end;
/
