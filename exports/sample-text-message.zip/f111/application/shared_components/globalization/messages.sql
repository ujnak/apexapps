prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 111
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>111
,p_default_id_offset=>27704457332727184
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(82523523714008817)
,p_name=>'T_GREETING0'
,p_message_text=>'I hope this message finds you well. <b>This is %1 from %0 Corporation.</b>'
,p_version_scn=>10326861
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(82523718057010773)
,p_name=>'T_GREETING0'
,p_message_language=>'ja'
,p_message_text=>unistr('\3044\3064\3082\5927\5909\304A\4E16\8A71\306B\306A\3063\3066\304A\308A\307E\3059\3002<b>%0\682A\5F0F\4F1A\793E\306E %1 \3067\3059\3002</b>')
,p_version_scn=>10326893
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(82523941387013608)
,p_name=>'T_GREETING0'
,p_message_language=>'ko'
,p_message_text=>unistr('\D3C9\C18C \BCA0\D480\C5B4 \C8FC\C2E0 \C131\C6D0\C5D0 \AE4A\C774 \AC10\C0AC\B4DC\B9BD\B2C8\B2E4. <b>%0\D68C\C0AC %1 \C785\B2C8\B2E4.</b>')
,p_version_scn=>10326940
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(82524185051017399)
,p_name=>'T_GREETING0'
,p_message_language=>'zh-cn'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\975E\5E38\611F\8C22\60A8\957F\671F\4EE5\6765\7684\652F\6301\4E0E\4FE1\4EFB\3002<b>\6211\662F %0\516C\53F8\7684 %1\3002</b>'),
''))
,p_version_scn=>10326974
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(82534110498177123)
,p_name=>'T_GREETING1'
,p_message_text=>'I hope this message finds you well. <b>This is %sender from %company Corporation.</b>'
,p_version_scn=>10327018
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(82534461501180336)
,p_name=>'T_GREETING1'
,p_message_language=>'ja'
,p_message_text=>unistr('\3044\3064\3082\5927\5909\304A\4E16\8A71\306B\306A\3063\3066\304A\308A\307E\3059\3002<b>%company\682A\5F0F\4F1A\793E\306E %sender \3067\3059\3002</b>')
,p_version_scn=>10327061
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(82534792413183220)
,p_name=>'T_GREETING1'
,p_message_language=>'ko'
,p_message_text=>unistr('\D3C9\C18C \BCA0\D480\C5B4 \C8FC\C2E0 \C131\C6D0\C5D0 \AE4A\C774 \AC10\C0AC\B4DC\B9BD\B2C8\B2E4. <b>%company\D68C\C0AC %sender \C785\B2C8\B2E4.</b>')
,p_version_scn=>10327103
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(82535081350186734)
,p_name=>'T_GREETING1'
,p_message_language=>'zh-cn'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\975E\5E38\611F\8C22\60A8\957F\671F\4EE5\6765\7684\652F\6301\4E0E\4FE1\4EFB\3002<b>\6211\662F %company\516C\53F8\7684 %sender\3002</b>'),
''))
,p_version_scn=>10327129
);
wwv_flow_imp.component_end;
end;
/
