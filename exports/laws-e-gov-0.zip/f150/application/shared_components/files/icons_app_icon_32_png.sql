prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>150
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000B54944415458476334987FFB3FC30002C651078C86C068088C86C0A00F817F3FBE32A8F33130B0FCF9C160202F8A51665E78F8';
wwv_flow_imp.g_varchar2_table(2) := '9AE10F0B07D6B2F4DD1F1686B7FFD8F196B3044B42BE2F4F19C48504C872C0CB771F183EF14853E60055B6AF0CBAF2E20CEC7FBE31C41B496118B6F0DC33869F2C5C582DB9FCF025C3ED5FDC43DC01A351301A02039E0B46A3E0F787570C5A62DC649584';
wwv_flow_imp.g_varchar2_table(3) := 'D75E7D65601510A3AC20A2758399605D30EA80D110180D81D110A0750800001405E64115DBF6A80000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(46473844357150098)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
