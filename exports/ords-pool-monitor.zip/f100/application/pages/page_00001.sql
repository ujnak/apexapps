prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5936992655518976
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Pool Monitor'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var refreshInteval;',
'function poolListing(){',
'    // populate the list of pools',
'',
'      fetch(''https://&G_HOST./ords/_/instance-api/stable/database-pools-cache/'',',
'            { headers: {''Authorization'': ''Basic '' + btoa(''&G_USERNAME.:&G_PASSWORD.'')} }',
'           )',
'           .then(response => response.text())',
'           .then((response) => {',
'              items = JSON.parse(response).items;',
'              var pools = document.getElementById("pools");',
'              for( item in  items) {',
'                  pool = document.createElement("option")',
'                  pool.text =items[item].id ',
'                  pool.value =items[item].links[0].href;',
'                  pools.add(pool);',
'              }',
'            });        ',
'            //',
'            // if change in pool cancel interval',
'            if ( refreshInteval ) {clearInterval(refreshInteval); }',
'            // update stats every 250ms',
'',
'          refreshInteval = setInterval(reloadData, 250);',
'      //',
'    }',
'function reloadData(){',
'',
'    // Get the pool data based on the select list of pools',
'',
'      fetch(   document.getElementById(''pools'').selectedOptions[0].value,',
'              { headers: {''Authorization'': ''Basic '' + btoa(''&G_USERNAME.:&G_PASSWORD.'')} })',
'        .then(response => response.text())',
'        .then((response) => {plot(JSON.parse(response))});          ',
'}',
'',
'',
'function updateTable(data){',
'  Object.keys(data.statistics).forEach(function(key) {',
'      var value = data.statistics[key];',
'      var old = document.getElementById(key + "_value").innerHTML;    ',
'      ',
'      // Mark up changes to be obvious',
'      if ( value != old ) {',
'        document.getElementById(key + "_value").innerHTML =  value;    ',
'        document.getElementById(key + "_value").style.color ="red";',
'        document.getElementById(key + "_value").style.fontSize ="xx-large";',
'      } else {',
'        document.getElementById(key + "_value").innerHTML =   value ;    ',
'        document.getElementById(key + "_value").style.color ="black";',
'        document.getElementById(key + "_value").style.fontSize ="initial";',
'      }',
'      ',
'    });',
'}',
'',
'function plot(data){',
'    if ( ! document.getElementById(''stats'') ) {',
'      // Make the new Table',
'            txt = "<table id=''stats'' border=''0''>";',
'            Object.keys(data.statistics).forEach(function(key) {',
'              var value = data.statistics[key];',
'              txt += "<tr><td style=''font-size:xx-large;'' id=''" + key + "''>" + key + "</td><td id=''"+key+"_value'' style=''font-family:Hack;''>" + value+ "</td></tr>";',
'            });',
'            txt += "</table>";',
'            document.getElementById("poolinfo").innerHTML = txt;      ',
'      } else {',
'      // Update the values',
'        updateTable(data);',
'    }',
'  }'))
,p_javascript_code_onload=>'poolListing();'
,p_css_file_urls=>'https://cdn.jsdelivr.net/npm/hack-font@3/build/web/hack-subset.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230520181034'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6237792734552625)
,p_plug_name=>'Pool Monitor'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(6029502043552455)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6240522441612601)
,p_plug_name=>'Pool Monitor'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5980142756552432)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    <div  style=''font-family:Hack;font-size:xx-large;''>Choose a Pool to monitor:<select style=''font-family:Hack;font-size:xx-large;'' name="pools" id="pools" onchange="pickAPool()"></select></div>',
'    <div id="poolinfo"></div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
