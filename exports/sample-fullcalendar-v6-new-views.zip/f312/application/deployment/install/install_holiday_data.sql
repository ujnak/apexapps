prompt --application/deployment/install/install_holiday_data
begin
--   Manifest
--     INSTALL: INSTALL-holiday-data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>312
,p_default_id_offset=>28727668271408008
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(28730803558427633)
,p_install_id=>wwv_flow_imp.id(86170778707073400)
,p_name=>'holiday-data'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
unistr('    --CAL_NATIONAL_HOLIDAYS: 1013/10000 \884C\304C\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\307E\3057\305F, APEX$DATA$PKG/CAL_NATIONAL_HOLIDAYS$384262'),
'    apex_data_install.load_supporting_object_data(p_table_name => ''CAL_NATIONAL_HOLIDAYS'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
