prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>312
,p_default_id_offset=>28727668271408008
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Custom Views'
,p_alias=>'CUSTOM-VIEWS'
,p_step_title=>'Custom Views'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'08'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240116071326'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114864378009558181)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(85960347621281905)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(85844665337281826)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(86022742402281951)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114865069462558182)
,p_plug_name=>'Custom Views'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(85948002427281897)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'CAL_NATIONAL_HOLIDAYS'
,p_include_rowid_column=>false
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'    config.endDateExclusive = false;',
'    config.headerToolbar.end = "";',
'    config.initialView = ''multiMonthFourMonth'';',
'    config.multiMonthMaxColumns = 2;',
'    config.height = ''auto'';',
'    config.views = {',
'        multiMonthFourMonth: {',
'            type: ''multiMonthYear'',',
'            duration: { months: 4 }',
'        }',
'    }',
'}'))
,p_attribute_01=>'HOLIDAY_DATE'
,p_attribute_03=>'HOLIDAY_NAME'
,p_attribute_09=>'list:navigation'
,p_attribute_13=>'N'
,p_attribute_17=>'Y'
,p_attribute_19=>'Y'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_imp.component_end;
end;
/
