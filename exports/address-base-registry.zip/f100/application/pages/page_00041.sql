prompt --application/pages/page_00041
begin
--   Manifest
--     PAGE: 00041
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7768636459008081
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>41
,p_name=>'Upload Address All'
,p_alias=>'UPLOAD-ADDRESS-ALL'
,p_step_title=>'Upload Address All'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240606052729'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9405357836602268)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8043196583506207)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(7927448140506290)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(8105555635506165)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9125703409565905)
,p_button_sequence=>20
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(8103935111506166)
,p_button_image_alt=>'Load'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9125617905565904)
,p_name=>'P41_FILES'
,p_item_sequence=>10
,p_prompt=>'Files'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(8101440398506170)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9126349405565911)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>unistr('\30D0\30C3\30AF\30B0\30E9\30A6\30F3\30C9\51E6\7406')
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_04=>'MOVE'
,p_attribute_05=>'P41_FILES'
,p_attribute_06=>'1'
,p_attribute_08=>'ERROR'
,p_attribute_09=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9125703409565905)
,p_internal_uid=>9126349405565911
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9125887086565906)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(9126349405565911)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load ZIP'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'/**',
unistr(' * CSV\30D5\30A1\30A4\30EB\540D\304B\3089\3001\30C7\30FC\30BF\30FB\30ED\30FC\30C9\306B\4F7F\3046\30C7\30FC\30BF\30FB\30ED\30FC\30C9\5B9A\7FA9\3092\898B\3064\3051\308B\3002'),
' */',
'function get_load_def_from_file_name(',
'    p_file_name in varchar2',
') return varchar2',
'as',
'begin',
'    if    p_file_name like ''mt_pref_pos_%.csv'' then',
'        return ''pref_pos'';',
'    elsif p_file_name like ''mt_pref_%.csv'' then',
'        return ''pref'';',
'    elsif p_file_name like ''mt_city_pos_%.csv'' then',
'        return ''city_pos'';',
'    elsif p_file_name like ''mt_city_%.csv'' then',
'        return ''city'';',
'    elsif p_file_name like ''mt_town_pos_%.csv'' then',
'        return ''town_pos'';',
'    elsif p_file_name like ''mt_town_fullset_%.csv'' then',
'        return ''town_fullset'';',
'    elsif p_file_name like ''mt_town_%.csv'' then',
'        return ''town'';',
'    elsif p_file_name like ''mt_parcel_pos_%.csv'' then',
'        return ''parcel_pos'';',
'    elsif p_file_name like ''mt_parcel_%.csv'' then',
'        return ''parcel'';',
'    elsif p_file_name like ''mt_rsdtdsp_blk_pos_%.csv'' then',
'        return ''rsdtdsp_blk_pos'';',
'    elsif p_file_name like ''mt_rsdtdsp_blk_%.csv'' then',
'        return ''rsdtdsp_blk'';',
'    elsif p_file_name like ''mt_rsdtdsp_rsdt_pos_%.csv'' then',
'        return ''rsdtdsp_rsdt_pos'';',
'    elsif p_file_name like ''mt_rsdtdsp_rsdt_%.csv'' then',
'        return ''rsdtdsp_rsdt'';',
'    end if;',
'    return null;',
'end get_load_def_from_file_name;',
'',
'/**',
unistr(' * \6307\5B9A\3055\308C\305F\30D5\30A1\30A4\30EB\304CCSV\3067\3042\308C\3070\3001\30C7\30FC\30BF\30FB\30ED\30FC\30C9\3092\5B9F\884C\3059\308B\3002'),
unistr(' * ZIP\30D5\30A1\30A4\30EB\306E\5834\5408\306F\5185\5BB9\3092\89E3\51CD\3057\3001\542B\307E\308C\3066\3044\308B\30D5\30A1\30A4\30EB\305D\308C\305E\308C\306B\5BFE\3057\3066'),
unistr(' * \81EA\5206\81EA\8EAB\3092\518D\5E30\7684\306B\547C\3073\51FA\3059\3002'),
' */',
'procedure extract_zip_or_append(',
'    p_file_name      in varchar2',
'    ,p_file_content   in blob',
')',
'is',
'    l_files        apex_zip.t_files;',
'    l_file_name    apex_application_temp_files.filename%type;',
'    l_file_content blob;',
'    l_static_id    varchar2(40);',
'    l_load_result apex_data_loading.t_data_load_result;',
'begin',
'    if apex_string_util.get_file_extension(p_file_name) = ''zip'' then',
'        /* extract zip recursively */',
'        apex_debug.info(''extract %s'', p_file_name);',
'        l_files := apex_zip.get_files(',
'            p_zipped_blob => p_file_content',
'        );',
'        for i in 1 .. l_files.count',
'        loop',
'            l_file_name    := l_files(i);',
'            l_file_content := apex_zip.get_file_content(',
'                p_zipped_blob => p_file_content',
'                ,p_file_name  => l_file_name',
'            );',
'            extract_zip_or_append(',
'                p_file_name      => l_file_name',
'                ,p_file_content   => l_file_content',
'            );',
'        end loop;',
'    else',
'        /* load CSV into database.  */',
'        l_static_id := get_load_def_from_file_name(',
'            p_file_name => p_file_name',
'        );',
'        if l_static_id is null then',
'            apex_debug.info(''Skip loading %s'', p_file_name);',
'            return;',
'        end if;',
'        apex_debug.info(''Start loading %s by %s, length %s'', p_file_name, l_static_id,',
'            dbms_lob.getlength(p_file_content));',
'        l_load_result := apex_data_loading.load_data(',
'            p_static_id     => l_static_id',
'            ,p_data_to_load => p_file_content',
'        );',
'        apex_debug.info(''End loading %s, rows %s'', p_file_name, l_load_result.processed_rows);',
'    end if;',
'end extract_zip_or_append;',
'',
'/**',
unistr(' * \30A2\30C3\30D7\30ED\30FC\30C9\3055\308C\305F\30D5\30A1\30A4\30EB\3092\30C7\30FC\30BF\30D9\30FC\30B9\306B\30ED\30FC\30C9\3059\308B\3002'),
' */',
'begin',
'    apex_debug.info(''Selected files: %s'', :P41_FILES);',
'    for r in (',
'        select filename, mime_type, blob_content',
'        from apex_application_temp_files where name in ',
'        (select column_value from apex_string.split(:P41_FILES, '':''))',
'    )',
'    loop',
'        apex_debug.info(''Process file %s'', r.filename);',
'        extract_zip_or_append(',
'            p_file_name      => r.filename',
'            ,p_file_content  => r.blob_content',
'        );',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>9125887086565906
);
wwv_flow_imp.component_end;
end;
/
