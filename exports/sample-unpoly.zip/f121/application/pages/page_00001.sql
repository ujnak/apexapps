prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7216617235130697
,p_default_application_id=>121
,p_default_id_offset=>11144016972389181
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Unpoly'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/unpoly@3.8.0/unpoly#MIN#.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.addEventListener("up:request:load", (event) => {',
'    event.request.headers["Apex-Session"] = apex.env.APP_ID + "," + apex.env.APP_SESSION;',
'    // console.log(event);',
'});'))
,p_css_file_urls=>'https://cdn.jsdelivr.net/npm/unpoly@3.8.0/unpoly#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'img {',
'  max-width:100%;',
'  max-height: 100%;',
'  width: auto;',
'  height: auto;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8291482283090144)
,p_plug_name=>'Buttons - Link'
,p_region_template_options=>'#DEFAULT#:margin-bottom-lg'
,p_plug_template=>wwv_flow_imp.id(39818247611601090)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="action_1">',
unistr('<a class="t-Button" href="apexdev/unpoly/image/\305F\306C\304D/image_1" up-target="#image_1">\305F\306C\304D</a>'),
unistr('<a class="t-Button" href="apexdev/unpoly/image/\30B7\30DE\30A6\30DE/image_1" up-target="#image_1">\30B7\30DE\30A6\30DE</a>'),
unistr('<a class="t-Button" href="apexdev/unpoly/image/\30EC\30C3\30B5\30FC\30D1\30F3\30C0/image_1" up-target="#image_1">\30EC\30C3\30B5\30FC\30D1\30F3\30C0</a>'),
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29589818326914169)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39821041852601100)
,p_plug_display_sequence=>30
,p_location=>null
,p_required_patch=>wwv_flow_imp.id(39780975161600976)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39725020674723221)
,p_plug_name=>'Image'
,p_region_css_classes=>'w800 h800 margin-auto'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39819626341601096)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>'<div id="image_1"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40083630875602022)
,p_plug_name=>'Sample Unpoly'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39851563654601164)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19432573549479296)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(29589818326914169)
,p_button_name=>'BUTTON1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39958415418601414)
,p_button_image_alt=>unistr('\305F\306C\304D')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19432640028479297)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(29589818326914169)
,p_button_name=>'BUTTON2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39958415418601414)
,p_button_image_alt=>unistr('\30B7\30DE\30A6\30DE')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19432724934479298)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(29589818326914169)
,p_button_name=>'BUTTON3'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39958415418601414)
,p_button_image_alt=>unistr('\30EC\30C3\30B5\30FC\30D1\30F3\30C0')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19432905235479299)
,p_name=>'onClick BUTTON1'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19432573549479296)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19433012961479300)
,p_event_id=>wwv_flow_imp.id(19432905235479299)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'up.render(',
'    {',
unistr('        url: "apexdev/unpoly/image/\305F\306C\304D/image_1",'),
'        target: "#image_1",',
'        headers: {',
'            "Apex-Session" : apex.env.APP_ID + "," + apex.env.APP_SESSION',
'        }',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19433044633479301)
,p_name=>'onClick BUTTON2'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19432640028479297)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19433138811479302)
,p_event_id=>wwv_flow_imp.id(19433044633479301)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'up.render(',
'    {',
unistr('        url: "apexdev/unpoly/image/\30B7\30DE\30A6\30DE/image_1",'),
'        target: "#image_1",',
'        headers: {',
'            "Apex-Session" : apex.env.APP_ID + "," + apex.env.APP_SESSION',
'        }',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19433271532479303)
,p_name=>'onClick  BUTTON3'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19432724934479298)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19433372617479304)
,p_event_id=>wwv_flow_imp.id(19433271532479303)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'up.render(',
'    {',
unistr('        url: "apexdev/unpoly/image/\30EC\30C3\30B5\30FC\30D1\30F3\30C0/image_1",'),
'        target: "#image_1",',
'        headers: {',
'            "Apex-Session" : apex.env.APP_ID + "," + apex.env.APP_SESSION',
'        }',
'    }',
');'))
);
wwv_flow_imp.component_end;
end;
/
