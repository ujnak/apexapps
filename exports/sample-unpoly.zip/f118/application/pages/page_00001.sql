prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7216617235130697
,p_default_application_id=>118
,p_default_id_offset=>10157363975434874
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Unpoly'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/unpoly@3.8.0/unpoly#MIN#.js'
,p_css_file_urls=>'https://cdn.jsdelivr.net/npm/unpoly@3.8.0/unpoly#MIN#.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'img {',
'  max-width:100%;',
'  max-height: 100%;',
'  width: auto;',
'  height: auto;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18445801354524988)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(28677024880211919)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28581003702334040)
,p_plug_name=>'Image'
,p_region_css_classes=>'w800 h800 margin-auto'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(28675609369211915)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<div id="image_1"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28939613903212841)
,p_plug_name=>'Sample Unpoly'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(28707546682211983)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8288556577090115)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18445801354524988)
,p_button_name=>'BUTTON1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(28814398446212233)
,p_button_image_alt=>unistr('\305F\306C\304D')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'up-target="#image_1"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8288623056090116)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(18445801354524988)
,p_button_name=>'BUTTON2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(28814398446212233)
,p_button_image_alt=>unistr('\30B7\30DE\30A6\30DE')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'up-target="#image_1"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8288707962090117)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(18445801354524988)
,p_button_name=>'BUTTON3'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(28814398446212233)
,p_button_image_alt=>unistr('\30EC\30C3\30B5\30FC\30D1\30F3\30C0')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'up-target="#image_1"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8288888263090118)
,p_name=>'onClick BUTTON1'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8288556577090115)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8288995989090119)
,p_event_id=>wwv_flow_imp.id(8288888263090118)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'up.render(',
'    {',
unistr('        url: "apexdev/unpoly/image/\305F\306C\304D/image_1",'),
'        target: "#image_1",',
'        headers: {',
'            "Apex-Session" : apex.env.APP_ID + "," + apex.env.APP_SESSION',
'        }',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8289027661090120)
,p_name=>'onClick BUTTON2'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8288623056090116)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8289121839090121)
,p_event_id=>wwv_flow_imp.id(8289027661090120)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'up.render(',
'    {',
unistr('        url: "apexdev/unpoly/image/\30B7\30DE\30A6\30DE/image_1",'),
'        target: "#image_1",',
'        headers: {',
'            "Apex-Session" : apex.env.APP_ID + "," + apex.env.APP_SESSION',
'        }',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8289254560090122)
,p_name=>'onClick  BUTTON3'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8288707962090117)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8289355645090123)
,p_event_id=>wwv_flow_imp.id(8289254560090122)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'up.render(',
'    {',
unistr('        url: "apexdev/unpoly/image/\30EC\30C3\30B5\30FC\30D1\30F3\30C0/image_1",'),
'        target: "#image_1",',
'        headers: {',
'            "Apex-Session" : apex.env.APP_ID + "," + apex.env.APP_SESSION',
'        }',
'    }',
');'))
);
wwv_flow_imp.component_end;
end;
/
