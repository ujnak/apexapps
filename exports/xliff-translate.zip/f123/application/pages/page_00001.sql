prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>123
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'XLIFF Files'
,p_alias=>'HOME'
,p_step_title=>'XLIFF Translate'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>To find data enter a search term into the search dialog, or click on the column headings to limit the records returned.</p>',
'',
'<p>You can perform numerous functions by clicking the <strong>Actions</strong> button. This includes selecting the columns that are displayed / hidden and their display sequence, plus numerous data and format functions.  You can also define additiona'
||'l views of the data using the chart, group by, and pivot options.</p>',
'',
'<p>If you want to save your customizations select report, or click download to unload the data. Enter you email address and time frame under subscription to be sent the data on a regular basis.<p>',
'',
'<p>For additional information click Help at the bottom of the Actions menu.</p> ',
'',
'<p>Click the <strong>Reset</strong> button to reset the interactive report back to the default settings.</p>'))
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230112042915'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31142181089093951)
,p_plug_name=>'Cwr Xliff Files'
,p_region_template_options=>'#DEFAULT#'
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'select "ID","NAME","SOURCE_LANG","TARGET_LANG",sys.dbms_lob.getlength("XLIFF_RESULT")"XLIFF_RESULT","XLIFF_RESULT_FILENAME","XLIFF_RESULT_MIMETYPE","XLIFF_RESULT_CHARSET","XLIFF_RESULT_LASTUPD",sys.dbms_lob.getlength("XLIFF_SOURCE")"XLIFF_SOURCE","XL'
||'IFF_SOURCE_FILENAME","XLIFF_SOURCE_MIMETYPE","XLIFF_SOURCE_CHARSET","XLIFF_SOURCE_LASTUPD"from "CWR_XLIFF_FILES"'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'XLIFF Files'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(31142294620093951)
,p_name=>'XLIFF Files'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_base_pk1=>'ID'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:RP:P2_ID:\#ID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'APEXDEV'
,p_internal_uid=>31142294620093951
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31142650362093953)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31143036612093954)
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_ID:#ID#'
,p_column_linktext=>'#NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31143430732093954)
,p_db_column_name=>'SOURCE_LANG'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Source Lang'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31143886727093955)
,p_db_column_name=>'TARGET_LANG'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Target Lang'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31144242965093955)
,p_db_column_name=>'XLIFF_RESULT'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Xliff Result'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:CWR_XLIFF_FILES:XLIFF_RESULT:ID::XLIFF_RESULT_MIMETYPE:XLIFF_RESULT_FILENAME:XLIFF_RESULT_LASTUPD:XLIFF_RESULT_CHARSET:attachment::'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31144600522093955)
,p_db_column_name=>'XLIFF_RESULT_FILENAME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Xliff Result Filename'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31145057216093956)
,p_db_column_name=>'XLIFF_RESULT_MIMETYPE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Xliff Result Mimetype'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31145479418093956)
,p_db_column_name=>'XLIFF_RESULT_CHARSET'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Xliff Result Charset'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31145821253093956)
,p_db_column_name=>'XLIFF_RESULT_LASTUPD'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Xliff Result Lastupd'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31146258141093957)
,p_db_column_name=>'XLIFF_SOURCE'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Xliff Source'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:CWR_XLIFF_FILES:XLIFF_SOURCE:ID::XLIFF_SOURCE_MIMETYPE:XLIFF_SOURCE_FILENAME:XLIFF_SOURCE_LASTUPD:XLIFF_SOURCE_CHARSET:attachment::'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31146675883093957)
,p_db_column_name=>'XLIFF_SOURCE_FILENAME'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Xliff Source Filename'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31147086196093957)
,p_db_column_name=>'XLIFF_SOURCE_MIMETYPE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Xliff Source Mimetype'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31147433637093958)
,p_db_column_name=>'XLIFF_SOURCE_CHARSET'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Xliff Source Charset'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31147801539093958)
,p_db_column_name=>'XLIFF_SOURCE_LASTUPD'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Xliff Source Lastupd'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(31168374842093983)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'311684'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NAME:SOURCE_LANG:TARGET_LANG:XLIFF_RESULT:XLIFF_SOURCE'
,p_sort_column_1=>'NAME'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31149778931093961)
,p_plug_name=>'XLIFF Translate'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(30965699327093668)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31148303956093959)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(31142181089093951)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(31089706378093731)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:2::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31148654265093959)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(31142181089093951)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31149145418093960)
,p_event_id=>wwv_flow_imp.id(31148654265093959)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31142181089093951)
);
wwv_flow_imp.component_end;
end;
/
