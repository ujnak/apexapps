prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>122
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Translate'
,p_alias=>'TRANSLATE'
,p_step_title=>'Translate'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#translate-actions#MIN#.js'
,p_javascript_code_onload=>'apex.actions.add(TRANSLATE_ACTIONS);'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>You can insert, update, and delete data directly within this interactive grid.<br>',
'  Insert a new row by clicking the Add Row button.<br>',
'  Double click into a cell, or click the <strong>Edit</strong> button to update data values, similar to editing data in a spreadsheet.</p>',
'',
'<p>Use the Row Actions menu ( <span class="fa fa-bars" aria-hidden="true"></span> ) at the top of the report to duplicate, delete, refresh or revert selected rows.<br> ',
'  Use the Row Actions menu on individual rows to also access the single row view or add a new row.</p>',
'',
'<p>To find data enter a search term into the search dialog, or click on the column headings to limit the records returned.</p>',
'',
'<p>You can perform numerous functions by clicking the <strong>Actions</strong> button. This includes selecting the columns that are displayed / hidden and their display sequence, plus numerous data and format functions.  You can also define an additi'
||'onal view of the data using the chart option.</p>',
'',
'<p>If you want to save your customizations select report, or click download to unload the data.<p>',
'',
'<p>For additional information click Help at the bottom of the Actions menu.</p> ',
'',
'<p>Click the <strong>Reset</strong> button to reset the interactive grid back to the default settings.</p>'))
,p_page_component_map=>'21'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230111050712'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30430915599253743)
,p_plug_name=>'Translate'
,p_region_name=>'IGTRANS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(30289109666253510)
,p_plug_display_sequence=>90
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    seq_id',
'    , c001 as "ID"',
'    , c002 as "SOURCE_TEXT"',
'    , c003 as "TARGET_TEXT"',
'from apex_collections',
'where collection_name = :G_TRANSLATE_COLLECTION'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Translate'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(30432212205253745)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_required_patch=>wwv_flow_imp.id(30195697173253460)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(30432754857253745)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_required_patch=>wwv_flow_imp.id(30195697173253460)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(30433782447253746)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Seq Id'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_link_target=>'#action$open-translate-dialog?id=&SEQ_ID.'
,p_link_text=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(30434775532253747)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(30435713658253748)
,p_name=>'SOURCE_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_TEXT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Source Text'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(30436780114253748)
,p_name=>'TARGET_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TARGET_TEXT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Target Text'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(30431428716253744)
,p_internal_uid=>30431428716253744
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(30431824939253744)
,p_interactive_grid_id=>wwv_flow_imp.id(30431428716253744)
,p_static_id=>'304319'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(30432074245253744)
,p_report_id=>wwv_flow_imp.id(30431824939253744)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(30433187975253745)
,p_view_id=>wwv_flow_imp.id(30432074245253744)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(30432754857253745)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(30434172555253746)
,p_view_id=>wwv_flow_imp.id(30432074245253744)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(30433782447253746)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(30435123145253747)
,p_view_id=>wwv_flow_imp.id(30432074245253744)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(30434775532253747)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(30436195162253748)
,p_view_id=>wwv_flow_imp.id(30432074245253744)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(30435713658253748)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(30437185524253749)
,p_view_id=>wwv_flow_imp.id(30432074245253744)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(30436780114253748)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30438128656253750)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(30311303983253521)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(30196296723253461)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(30373486667253553)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30506066395471803)
,p_plug_name=>'DeepL Translate'
,p_region_name=>'TRANSLATE'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(30274554296253503)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29865055139514217)
,p_button_sequence=>10
,p_button_name=>'LOAD_FROM_SOURCE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(30371850763253552)
,p_button_image_alt=>'Load From Source'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29865268567514219)
,p_button_sequence=>20
,p_button_name=>'STORE_AS_RESULT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(30371850763253552)
,p_button_image_alt=>'Store As Result'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29865101178514218)
,p_button_sequence=>30
,p_button_name=>'LOAD_FROM_RESULT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(30371850763253552)
,p_button_image_alt=>'Load From Result'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29868156589514248)
,p_button_sequence=>40
,p_button_name=>'BATCH_TRANSLATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(30371850763253552)
,p_button_image_alt=>'Batch Translate'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30506423607471807)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(30506066395471803)
,p_button_name=>'TRANSLATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(30371850763253552)
,p_button_image_alt=>'Translate'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30506598718471808)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(30506066395471803)
,p_button_name=>'APPLY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(30371850763253552)
,p_button_image_alt=>'Apply'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$close-translate-dialog"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30506639591471809)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(30506066395471803)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(30371850763253552)
,p_button_image_alt=>'Cancel'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29865311341514220)
,p_name=>'P3_TARGET_LANG'
,p_item_sequence=>70
,p_prompt=>'Target Lang'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(30369386435253551)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29865414684514221)
,p_name=>'P3_SOURCE_LANG'
,p_item_sequence=>60
,p_prompt=>'Source Lang'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(30369386435253551)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29866152457514228)
,p_name=>'P3_ID'
,p_item_sequence=>50
,p_prompt=>'XLIFF Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select name, id from cwr_xliff_files where id = :P3_ID'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(30369386435253551)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30506146739471804)
,p_name=>'P3_GID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30506066395471803)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30506204154471805)
,p_name=>'P3_SOURCE_TEXT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(30506066395471803)
,p_prompt=>'Source Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(30369386435253551)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30506335161471806)
,p_name=>'P3_TARGET_TEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(30506066395471803)
,p_prompt=>'Target Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(30369386435253551)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30506748762471810)
,p_name=>'Close Dialog as Cancel'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(30506639591471809)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30506893693471811)
,p_event_id=>wwv_flow_imp.id(30506748762471810)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Close Dialog'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(30506066395471803)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30506941695471812)
,p_name=>'DeepL Translate'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(30506423607471807)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30507050807471813)
,p_event_id=>wwv_flow_imp.id(30506941695471812)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Call DeepL API'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request clob;',
'    l_result  clob;',
'    l_json   json_object_t;',
'    l_array  json_array_t;',
'    l_trans  json_object_t;',
'begin',
unistr('    /* DeepL\306B\9001\4FE1\3059\308B\7FFB\8A33\30EA\30AF\30A8\30B9\30C8\3002'),
unistr('     * XLIFF\306B\542B\307E\308C\308B\3059\3079\3066\306Esource-lang\304A\3088\3073target-lang\306E\6307\5B9A\304C'),
unistr('     * DeepL\306Esource_lang\3068target_lang\3068\3057\3066\6709\52B9\304B\3069\3046\304B\306F\672A\78BA\8A8D\3002'),
'     */',
'    l_request := ''text=''   || :P3_SOURCE_TEXT ',
'        || ''&target_lang='' || :P3_TARGET_LANG ',
'        || ''&source_lang='' || :P3_SOURCE_LANG; ',
unistr('    /* DeepL\306EAPI\3092\547C\3073\51FA\3059\3002Web\8CC7\683C\8A3C\660E\306F\3042\3089\304B\3058\3081DEEPL_API_KEY\3068\3057\3066\4F5C\6210\3057\3066\304A\304F\3002 */'),
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Content-Type'',''application/x-www-form-urlencoded'');',
'    l_result :=  apex_web_service.make_rest_request(',
'            p_url => ''https://api-free.deepl.com/v2/translate''',
'            ,p_http_method => ''POST''',
'            ,p_credential_static_id => ''DEEPL_API_KEY''',
'            ,p_body => l_request',
'    );',
'    -- apex_debug.info(''DeepL response = '' || l_result);',
unistr('    /* \623B\308A\5024\306EJSON\6587\66F8\3088\308A\3001\7FFB\8A33\6E08\307F\306Etext\3092\53D6\308A\51FA\3057\3001\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306B\8A2D\5B9A\3059\308B\3002 */'),
'    l_json := new json_object_t(l_result);',
'    l_array := l_json.get_array(''translations'');',
'    l_trans := treat(l_array.get(0) as json_object_t);',
'    :P3_TARGET_TEXT := l_trans.get_string(''text'');',
'end;'))
,p_attribute_02=>'P3_SOURCE_TEXT,P3_SOURCE_LANG,P3_TARGET_LANG'
,p_attribute_03=>'P3_TARGET_TEXT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(30437716903253749)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(30430915599253743)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Translate - Save Interactive Grid Data'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if :APEX$ROW_STATUS = ''U'' then',
'        apex_collection.update_member_attribute(',
'            p_collection_name => :G_TRANSLATE_COLLECTION',
'            , p_seq => :SEQ_ID',
'            , p_attr_number => 3',
'            , p_attr_value => :TARGET_TEXT   ',
'        );',
'    end if;',
'end;'))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(29865268567514219)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29866217030514229)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Load From Source'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'CWR_UTIL'
,p_attribute_04=>'LOAD_FROM_SOURCE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(29865055139514217)
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29866326833514230)
,p_page_process_id=>wwv_flow_imp.id(29866217030514229)
,p_page_id=>3
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P3_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29866494109514231)
,p_page_process_id=>wwv_flow_imp.id(29866217030514229)
,p_page_id=>3
,p_name=>'p_source_lang'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P3_SOURCE_LANG'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29866559798514232)
,p_page_process_id=>wwv_flow_imp.id(29866217030514229)
,p_page_id=>3
,p_name=>'p_target_lang'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P3_TARGET_LANG'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29866633272514233)
,p_page_process_id=>wwv_flow_imp.id(29866217030514229)
,p_page_id=>3
,p_name=>'p_collection_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'G_TRANSLATE_COLLECTION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29867201418514239)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Load From Result'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'CWR_UTIL'
,p_attribute_04=>'LOAD_FROM_RESULT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(29865101178514218)
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29867313294514240)
,p_page_process_id=>wwv_flow_imp.id(29867201418514239)
,p_page_id=>3
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P3_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29867432559514241)
,p_page_process_id=>wwv_flow_imp.id(29867201418514239)
,p_page_id=>3
,p_name=>'p_source_lang'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P3_SOURCE_LANG'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29867545032514242)
,p_page_process_id=>wwv_flow_imp.id(29867201418514239)
,p_page_id=>3
,p_name=>'p_target_lang'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P3_TARGET_LANG'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29867600631514243)
,p_page_process_id=>wwv_flow_imp.id(29867201418514239)
,p_page_id=>3
,p_name=>'p_collection_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'G_TRANSLATE_COLLECTION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29867734144514244)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Store As Result'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'CWR_UTIL'
,p_attribute_04=>'STORE_AS_RESULT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(29865268567514219)
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29867819235514245)
,p_page_process_id=>wwv_flow_imp.id(29867734144514244)
,p_page_id=>3
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P3_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29867939011514246)
,p_page_process_id=>wwv_flow_imp.id(29867734144514244)
,p_page_id=>3
,p_name=>'p_collection_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'G_TRANSLATE_COLLECTION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29868277961514249)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Batch Translate'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'CWR_UTIL'
,p_attribute_04=>'BATCH_TRANSLATE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(29868156589514248)
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(29868350093514250)
,p_page_process_id=>wwv_flow_imp.id(29868277961514249)
,p_page_id=>3
,p_name=>'p_source_lang'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P3_SOURCE_LANG'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(30505879153471801)
,p_page_process_id=>wwv_flow_imp.id(29868277961514249)
,p_page_id=>3
,p_name=>'p_target_lang'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P3_TARGET_LANG'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(30505934287471802)
,p_page_process_id=>wwv_flow_imp.id(29868277961514249)
,p_page_id=>3
,p_name=>'p_collection_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'G_TRANSLATE_COLLECTION'
);
wwv_flow_imp.component_end;
end;
/
