prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>267
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Temperatures'
,p_alias=>'HOME'
,p_step_title=>'JET Picto Chart'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'#JET_BASE_DIRECTORY#js/libs/require/require.js?v=#APP_VERSION#',
'#APEX_FILES#libraries/apex/minified/requirejs.jetConfig.min.js?v=#APP_VERSION#',
'*/'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var pictoChart;',
'const C_MONTHS = ''&G_MONTH.'';'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'require(["require", "exports", "knockout", "ojs/ojbootstrap", "ojs/ojarraydataprovider", "ojs/ojpalette", "ojs/ojpaletteutils", "ojs/ojknockout", "ojs/ojpictochart", "ojs/ojlegend"], function (require, exports, ko, ojbootstrap_1, ArrayDataProvider, o'
||'jpalette_1, ojpaletteutils_1) {',
'"use strict";',
'      ',
'    class PictoChartModel {',
'        /*',
unistr('         * Pict Chart\3067\8868\793A\3059\308B\30C7\30FC\30BF\3092\66F4\65B0\3059\308B\3002'),
'         */',
'        update(data) {',
unistr('            /* \30CE\30FC\30C9\3068\30EA\30F3\30AF\306E\30C7\30FC\30BF\3092\66F4\65B0\3059\308B\3002 */'),
'            this.data = data;',
'',
'            let monthKeys = Object.keys(this.data);',
'',
'            for(let i = 1; i <= C_MONTHS; i++) {',
'                let pname = "m" + i + "DataProvider";',
'                this[pname](new ArrayDataProvider(this.data[monthKeys[(i-1)]], {',
'                    keyAttributes: "date"',
'                }));',
'            }',
'            this.legendDataProvider(new ArrayDataProvider(this.legendItems, {',
'                  keyAttributes: "text",',
'            }));',
'        }',
'',
'        constructor() {',
unistr('            /* \30EC\30B8\30A7\30F3\30C9\306E\521D\671F\5316 - \6442\6C0F\306B\5909\66F4 */'),
'            this.legendItems = [];',
'            this.temp = [',
unistr('                  "-30\301C-20\005CxB0C",'),
unistr('                  "-20\301C-10\005CxB0C",'),
unistr('                  "-10\301C0\005CxB0C",'),
unistr('                  "0\301C10\005CxB0C",'),
unistr('                  "10\301C20\005CxB0C",'),
unistr('                  "20\301C30\005CxB0C",'),
unistr('                  "30\301C40\005CxB0C",'),
'            ];',
'            this.colors = (0, ojpalette_1.getColorValuesFromPalette)("viridis", 7);',
'',
unistr('            /* \30C7\30FC\30BF\30FB\30D7\30ED\30D0\30A4\30C0\3092observableArray\3067\521D\671F\5316 */'),
'            for (let i = 1; i <= C_MONTHS; i++) {',
'                let pname = "m" + i + "DataProvider";',
'                this[pname] = ko.observableArray();',
'            }',
'            this.legendDataProvider = ko.observableArray();',
'',
unistr('            /* \30C4\30FC\30EB\30C1\30C3\30D7\306E\8868\793A\5F62\5F0F\3092\6C7A\3081\308B */'),
'            this.getTooltip = (month, date, value) => {',
'                return date === 0',
'                    ? ""',
unistr('                    : `${month}-${date.toString()} (${value.toString()})\00B0C`;'),
'            };',
'',
unistr('            /* \6C17\6E29\306B\3088\308B\8868\793A\8272\3092\6C7A\3081\308B */'),
'            this.getColor = (value) => {',
'                return value === null',
'                    ? "rgba(0,0,0,0)"',
'                    : (0, ojpaletteutils_1.getColorValue)(this.colors, (value + 30) / 70);',
'            };',
'',
unistr('            /* \30EC\30B8\30A7\30F3\30C9\3068\3057\3066\8868\793A\3059\308B\9805\76EE\306E\751F\6210 */'),
'            for (let i = 0; i < this.temp.length; i++) {',
'                this.legendItems.push({ text: this.temp[i], color: this.colors[i] });',
'            }',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        pictoChart = new PictoChartModel();',
'        ko.applyBindings(pictoChart, document.getElementById("chart-container"));',
unistr('        /* \30DA\30FC\30B8\30FB\30ED\30FC\30C9\6642\306E\8868\793A */'),
'        apex.actions.invoke("update-pictoChart");',
'    });',
'});',
'',
'/*',
unistr(' * Picto Chart\3092\66F4\65B0\3059\308B\3002'),
' */',
'apex.actions.add([',
'    {',
'        name: "update-pictoChart",',
'        action: () => {',
'            apex.server.process ( "GET_DATA", {',
'                    pageItems: ["P1_TAG","P1_YEAR","P1_MONTH"]',
'                },',
'                {',
'                    success: (data) =>  {',
'                        // console.log(data);',
'                        pictoChart.update(data);',
'                    }',
'                }',
'            );',
'        }',
'    }',
']);'))
,p_css_file_urls=>'#JET_CSS_DIRECTORY#alta/oj-alta-notag-min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.demo-datavisualizations-blockcalendar-wordspacing {',
'    word-spacing: 0.375rem;',
'}',
'',
'.demo-datavisualizations-blockcalendar-style {',
'    height: 3.125rem;',
'    max-width: 67.5rem;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>\3053\306E\5BFE\8A71\30B0\30EA\30C3\30C9\5185\3067\30C7\30FC\30BF\3092\76F4\63A5\633F\5165\3001\66F4\65B0\304A\3088\3073\524A\9664\3067\304D\307E\3059\3002<br>'),
unistr('  \300C\884C\306E\8FFD\52A0\300D\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\65B0\3057\3044\884C\3092\633F\5165\3067\304D\307E\3059\3002<br>'),
unistr('  \30BB\30EB\5185\3092\30C0\30D6\30EB\30AF\30EA\30C3\30AF\3059\308B\304B\3001<strong>\300C\7DE8\96C6\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\30B9\30D7\30EC\30C3\30C9\30B7\30FC\30C8\3067\30C7\30FC\30BF\3092\7DE8\96C6\3059\308B\5834\5408\3068\540C\3058\3088\3046\306B\30C7\30FC\30BF\5024\3092\66F4\65B0\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30EC\30DD\30FC\30C8\306E\4E00\756A\4E0A\306B\3042\308B\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC(<span class="fa fa-bars" aria-hidden="true"></span>)\3092\4F7F\7528\3057\3066\3001\9078\629E\3057\305F\884C\3092\8907\88FD\3001\524A\9664\3001\30EA\30D5\30EC\30C3\30B7\30E5\307E\305F\306F\56DE\5FA9\3057\307E\3059\3002<br>'),
unistr('  \500B\3005\306E\884C\306E\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\3092\4F7F\7528\3057\3066\3001\5358\4E00\884C\30D3\30E5\30FC\306B\30A2\30AF\30BB\30B9\3057\305F\308A\3001\65B0\3057\3044\884C\3092\8FFD\52A0\3057\305F\308A\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30C7\30FC\30BF\3092\898B\3064\3051\308B\306B\306F\3001\691C\7D22\30C0\30A4\30A2\30ED\30B0\306B\691C\7D22\6587\5B57\5217\3092\5165\529B\3059\308B\304B\3001\5217\30D8\30C3\30C0\30FC\3092\30AF\30EA\30C3\30AF\3057\3066\623B\3055\308C\308B\30EC\30B3\30FC\30C9\3092\5236\9650\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30A2\30AF\30B7\30E7\30F3\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\591A\304F\306E\6A5F\80FD\3092\5B9F\884C\3067\304D\307E\3059\3002\3053\308C\306B\306F\3001\8868\793A\5217\307E\305F\306F\975E\8868\793A\5217\306E\9078\629E\3068\305D\306E\8868\793A\9806\5E8F\306B\52A0\3048\3001\591A\304F\306E\30C7\30FC\30BF\304A\3088\3073\66F8\5F0F\8A2D\5B9A\6A5F\80FD\304C\542B\307E\308C\307E\3059\3002\30C1\30E3\30FC\30C8\30FB\30AA\30D7\30B7\30E7\30F3\3092\4F7F\7528\3057\3066\3001\30C7\30FC\30BF\306E\8FFD\52A0\30D3\30E5\30FC\3092\5B9A\7FA9\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\72EC\81EA\306E\30AB\30B9\30BF\30DE\30A4\30BA\5185\5BB9\3092\4FDD\5B58\3059\308B\5834\5408\3001\30EC\30DD\30FC\30C8\3092\9078\629E\3059\308B\304B\3001\300C\30C0\30A6\30F3\30ED\30FC\30C9\300D\3092\30AF\30EA\30C3\30AF\3057\3066\30C7\30FC\30BF\3092\30A2\30F3\30ED\30FC\30C9\3057\307E\3059\3002<p>'),
'',
unistr('<p>\8FFD\52A0\60C5\5831\3092\5165\624B\3059\308B\306B\306F\3001\300C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\306E\4E00\756A\4E0B\306E\300C\30D8\30EB\30D7\300D\3092\30AF\30EA\30C3\30AF\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30EA\30BB\30C3\30C8\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\5BFE\8A71\30B0\30EA\30C3\30C9\3092\30C7\30D5\30A9\30EB\30C8\8A2D\5B9A\306B\623B\3059\3053\3068\304C\3067\304D\307E\3059\3002</p>')))
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230901065014'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78615491005882332)
,p_plug_name=>'Maximum Temperatures (2m)'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(80439981362924716)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78616454464882342)
,p_plug_name=>'Temperatures'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(80374741575924679)
,p_plug_display_sequence=>20
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_chart clob;',
'    l_month_str varchar2(7);',
'    l_month     date;',
unistr('    l_months constant number := :G_MONTH; -- \8868\793A\3059\308B\6708\6570\306F\56FA\5B9A\3002'),
'begin',
'    l_chart := q''~',
'<div id="chart-container" class="oj-sm-padding-2x-horizontal">',
'    <div class="oj-typography-body-lg oj-typography-bold">Daily Temperatures For ~'' || :P1_TAG || q''~</div>',
'    <div class="oj-flex oj-sm-flex-items-initial">~'';',
' ',
unistr('    /* \6700\521D\306B\8868\793A\3059\308B\6708\3092\8A2D\5B9A\3059\308B\3002 */'),
'    l_month_str := :P1_YEAR || ''-'' || case when length(:P1_MONTH) = 1 then ''0'' else '''' end || :P1_MONTH;',
unistr('    for i in 1..l_months -- \6708\6570\306F\56FA\5B9A'),
'    loop',
'        l_chart := l_chart || q''~',
'        <div class="oj-flex-item oj-sm-margin-4x-end">',
'            <div class="oj-typography-body-sm oj-typography-bold oj-sm-margin-4x-vertical">~'' || l_month_str || q''~</div>',
'            <div class="oj-sm-margin-1x-start demo-datavisualizations-blockcalendar-wordspacing">',
'                S M T W T F S',
'            </div>',
'            <oj-picto-chart',
'                id="pictochart1"',
'                data="[[m~'' || i || q''~DataProvider]]"',
'                layout="horizontal"',
'                row-height="20"',
'                column-count="7">',
'                <template slot="itemTemplate" data-oj-as="item">',
'                    <oj-picto-chart-item',
'                        short-desc=''[[getTooltip("~'' || l_month_str || q''~", item.data.date, item.data.value)]]''',
'                        color="[[getColor(item.data.value)]]">',
'                    </oj-picto-chart-item>',
'                </template>',
'            </oj-picto-chart>',
'        </div>~'';',
unistr('        /* \6B21\306B\8868\793A\3059\308B\6708\3092\8A2D\5B9A\3059\308B. */'),
'        l_month := to_date(l_month_str, ''YYYY-MM'');',
'        l_month := add_months(l_month, 1);',
'        l_month_str := to_char(l_month, ''YYYY-MM'');',
'    end loop;',
'',
unistr('    /* \30EC\30B8\30A7\30F3\30C9\306E\8868\793A\9818\57DF */'),
'    l_chart := l_chart || q''~',
'    </div>',
'',
'    <oj-legend',
'        id="legend1"',
'        class="oj-sm-padding-6x-horizontal demo-datavisualizations-blockcalendar-style"',
'        orientation="horizontal"',
'        data="[[legendDataProvider]]"',
'        symbol-width="15"',
'        symbol-height="15">',
'        <template slot="itemTemplate" data-oj-as="item">',
'            <oj-legend-item text="[[item.data.text]]" color="[[item.data.color]]"></oj-legend-item>',
'        </template>',
'    </oj-legend>',
'</div>~'';',
'    return l_chart;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80632637765924946)
,p_plug_name=>'Hmt Temperatures'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(80412241368924700)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'HMT_TEMPERATURES'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Temperatures'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80633985106924951)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80634486508924952)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>unistr('\30A2\30AF\30B7\30E7\30F3')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80635420489924955)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'ID'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80636424776924956)
,p_name=>'TAG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TAG'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Tag'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80637479358924957)
,p_name=>'DATE_REC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DATE_REC'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Date Rec'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(80638422725924958)
,p_name=>'TEMPERATURE_2M_MAX'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TEMPERATURE_2M_MAX'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Temperature 2m Max'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(80633160965924948)
,p_internal_uid=>80633160965924948
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>300
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(80633565911924949)
,p_interactive_grid_id=>wwv_flow_imp.id(80633160965924948)
,p_static_id=>'806336'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(80633758666924950)
,p_report_id=>wwv_flow_imp.id(80633565911924949)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(80634856500924953)
,p_view_id=>wwv_flow_imp.id(80633758666924950)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(80634486508924952)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(80635866955924955)
,p_view_id=>wwv_flow_imp.id(80633758666924950)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(80635420489924955)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(80636876796924956)
,p_view_id=>wwv_flow_imp.id(80633758666924950)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(80636424776924956)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(80637890244924957)
,p_view_id=>wwv_flow_imp.id(80633758666924950)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(80637479358924957)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(80638837337924958)
,p_view_id=>wwv_flow_imp.id(80633758666924950)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(80638422725924958)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(78616137395882339)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(78615491005882332)
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(80513180339924770)
,p_button_image_alt=>'Load from Open-Meteo.com'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78615549182882333)
,p_name=>'P1_TAG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(78615491005882332)
,p_item_default=>'Tokyo (2023)'
,p_prompt=>'Tag'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(80510609300924768)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78615654541882334)
,p_name=>'P1_YEAR'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(78615491005882332)
,p_item_default=>'2023'
,p_prompt=>'Year'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select y as d, y as r from (',
'    select (extract(year from sysdate) - l + 1) as y from (',
'        select level as l from dual connect by level <= 30',
'    )',
')'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(80510609300924768)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78615751778882335)
,p_name=>'P1_MONTH'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(78615491005882332)
,p_item_default=>'1'
,p_prompt=>'Month'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l as d, l as r from (',
'    select level as l from dual connect by level <= 12',
')'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(80510609300924768)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78615847777882336)
,p_name=>'P1_LAT'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(78615491005882332)
,p_item_default=>'35.6895'
,p_prompt=>'Latitude'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(80510609300924768)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78615958841882337)
,p_name=>'P1_LON'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(78615491005882332)
,p_item_default=>'139.6917'
,p_prompt=>'Longitude'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(80510609300924768)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78616001326882338)
,p_name=>'P1_TIMEZONE'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(78615491005882332)
,p_item_default=>'Asia/Tokyo'
,p_prompt=>'Timezone'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(80510609300924768)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(78616205642882340)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load from Open-Meteo.com'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
unistr('    /* \30C7\30FC\30BF\53D6\5F97\671F\9593 */'),
'    l_start_date_str varchar2(10);',
'    l_end_date_str   varchar2(10);',
'    l_start_date date;',
'    l_end_date   date;',
unistr('    l_months     constant number := :G_MONTH; -- \8868\793A\3059\308B\6708\6570\306F\56FA\5B9A\3002'),
unistr('    /* API\547C\3073\51FA\3057 */'),
'    l_response clob;',
'    l_response_json json_object_t;',
'    l_parm_name constant varchar2(400) := ''latitude:longitude:start_date:end_date:daily:temperature_unit:timezone'';',
'    l_parm_value varchar2(400);',
unistr('    /* \30EC\30B9\30DD\30F3\30B9\304B\3089\65E5\4ED8\3068\6700\9AD8\6C17\6E29\3092\53D6\308A\51FA\3059\3002 */'),
'    l_daily json_object_t;',
'    l_count pls_integer;',
'    l_date_arr json_array_t;',
'    l_temp_arr json_array_t;',
'    l_date date;',
'    l_temp number;',
'    e_open_meteo_get_failed exception;',
'begin',
unistr('    /* \30C7\30FC\30BF\53D6\5F97\671F\9593\3092\6C7A\3081\308B\3002 */'),
'    l_start_date_str := :P1_YEAR || ''-'' || case when length(:P1_MONTH) = 1 then ''0'' else '''' end || :P1_MONTH || ''-01'';',
'    l_start_date := to_date(l_start_date_str, ''YYYY-MM-DD'');',
'    l_end_date := add_months(l_start_date, l_months) - 1;',
unistr('    /* \7D42\4E86\65E5\306F\4ECA\65E5\306E\65E5\4ED8\3092\8D85\3048\3066\306F\3044\3051\306A\3044\3002 */'),
'    if l_end_date > trunc(sysdate) then',
'        l_end_date := trunc(sysdate);',
'    end if;',
'    l_end_date_str := to_char(l_end_date, ''YYYY-MM-DD'');',
unistr('    /* Open Meteo\306E\547C\3073\51FA\3057\30D1\30E9\30E1\30FC\30BF */'),
'    l_parm_value := :P1_LAT || '':'' || :P1_LON || '':'' || l_start_date_str || '':'' || l_end_date_str || '':temperature_2m_max:celsius:'' || :P1_TIMEZONE;',
'    apex_debug.info(l_parm_value);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => ''https://archive-api.open-meteo.com/v1/archive''',
'        ,p_http_method => ''GET''',
'        ,p_parm_name => apex_string.string_to_table(l_parm_name)',
'        ,p_parm_value => apex_util.string_to_table(l_parm_value)',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        apex_debug.info(l_response);',
'        raise e_open_meteo_get_failed;',
'    end if;',
'    l_response_json := json_object_t(l_response);',
unistr('    /* \672C\5F53\306F\30EC\30B9\30DD\30F3\30B9\306E\691C\8A3C\306F\5FC5\8981 */'),
'    l_daily :=  l_response_json.get_object(''daily'');',
'    l_date_arr := l_daily.get_array(''time'');',
'    l_temp_arr := l_daily.get_array(''temperature_2m_max'');',
unistr('    l_count := l_date_arr.get_size(); -- l_temp_arr\306E\30B5\30A4\30BA\3082\540C\3058\3002'),
unistr('    /* \540C\3058\30BF\30B0\306E\30C7\30FC\30BF\306F\6D88\53BB\3059\308B\3002 */'),
'    delete from hmt_temperatures where tag = :P1_TAG;',
'    for i in 1..l_count',
'    loop',
'        l_date := to_date(l_date_arr.get_string(i-1), ''YYYY-MM-DD'');',
'        l_temp := l_temp_arr.get_number(i-1);',
'        insert into hmt_temperatures(tag, date_rec, temperature_2m_max)',
'        values(:P1_TAG, l_date, l_temp);',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(78616137395882339)
,p_internal_uid=>78616205642882340
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80639402502924959)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(80632637765924946)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Temperatures - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>80639402502924959
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(78616360968882341)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response_json json_object_t;',
'    l_days json_array_t;',
'    l_day pls_integer;',
'    l_date_str varchar2(7);',
'    l_start_date date;',
'    l_end_date   date;',
'begin',
unistr('    /* \8868\793A\306B\4F7F\7528\3059\308B\671F\9593 */'),
'    l_start_date := to_date(:P1_YEAR || case when length(:P1_MONTH) = 1 then ''0'' else '''' end || :P1_MONTH, ''YYYYMM'');',
'    l_end_date := add_months(l_start_date, :G_MONTH) - 1;',
'',
unistr('    /* JET Picto Chart\304C\6271\3046\5F62\5F0F\3067\51FA\529B */'),
'    l_response_json := json_object_t();',
'    for r in (',
'        select',
'            trunc(date_rec, ''MONTH'') year_month',
'            ,json_arrayagg(',
'                json_object(',
'                    key ''date'' value extract(day from date_rec)',
'                    ,key ''value'' value temperature_2m_max',
'                )',
'                order by date_rec asc',
'            ) as value',
'        from hmt_temperatures where tag = :P1_TAG',
'            and date_rec between l_start_date and l_end_date',
'            and temperature_2m_max is not null',
'        group by trunc(date_rec, ''MONTH'')',
'        order by trunc(date_rec, ''MONTH'')',
'    )',
'    loop',
'        l_date_str := to_char(r.year_month, ''YYYY-MM'');',
'        l_days := json_array_t(r.value);',
unistr('        /* \65E5\66DC\65E5\304B\30891\65E5\307E\3067\306E\7A74\57CB\3081\3092\3059\308B */'),
'        l_day := to_number(to_char(r.year_month,''D''));',
'        for i in 1..(l_day-1)',
'        loop',
'            l_days.put(0, json_object_t(''{ "date": 0, "value": null }''));',
'        end loop;',
'        l_response_json.put(l_date_str, l_days);',
'    end loop;',
'    htp.p(l_response_json.to_clob());',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>78616360968882341
);
wwv_flow_imp.component_end;
end;
/
