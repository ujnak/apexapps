prompt --application/shared_components/logic/application_computations/g_preauth_url
begin
--   Manifest
--     APPLICATION COMPUTATION: G_PREAUTH_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(15652739405239573)
,p_computation_sequence=>10
,p_computation_item=>'G_PREAUTH_URL'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response dbms_cloud_oci_obs_object_storage_create_preauthenticated_request_response_t;',
'    l_result   dbms_cloud_oci_object_storage_preauthenticated_request_t;',
'    l_details dbms_cloud_oci_object_storage_create_preauthenticated_request_details_t;',
'    l_url varchar2(4000);',
'    preauth_request_error exception;',
'begin',
'    l_details := dbms_cloud_oci_object_storage_create_preauthenticated_request_details_t;',
'    l_details.name := ''standard-'' || sys_guid();',
unistr('    l_details.bucket_listing_action := ''Deny''; -- \30AA\30D6\30B8\30A7\30AF\30C8\306E\30EA\30B9\30C8\306F\7981\6B62'),
unistr('    l_details.object_name := null; -- \30D0\30B1\30C3\30C8\5185\306E\3059\3079\3066\306E\30AA\30D6\30B8\30A7\30AF\30C8\304C\5BFE\8C61'),
unistr('    l_details.access_type := ''AnyObjectRead''; -- \30D0\30B1\30C3\30C8\5185\306E\30AA\30D6\30B8\30A7\30AF\30C8\306E\8AAD\307F\8FBC\307F\3092\8A31\53EF'),
unistr('    l_details.time_expires := systimestamp + interval ''1'' day;  -- \6709\52B9\671F\9650\306F\FF11\65E5'),
'    l_response := dbms_cloud_oci_obs_object_storage.create_preauthenticated_request (',
'        namespace_name => :G_NAMESPACE',
'        , bucket_name => :G_BUCKET',
'        , create_preauthenticated_request_details => l_details',
'        , region => :G_REGION',
'        , credential_name => :G_CREDENTIAL',
'    );',
'    if l_response.status_code != 200 then',
'        raise preauth_request_error;',
'    end if;',
'    l_result := l_response.response_body;',
'    l_url := ''https://objectstorage.'' || :G_REGION || ''.oraclecloud.com'' || l_result.access_uri;',
'    return l_url;',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
