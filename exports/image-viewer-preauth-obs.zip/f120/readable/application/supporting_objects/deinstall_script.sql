drop table img_images;
drop table img_items;