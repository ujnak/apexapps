prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(25253546509555205)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table img_images;',
'drop table img_items;'))
,p_prompt_sub_string_02=>'Y'
,p_prompt_sub_string_03=>'Y'
,p_prompt_sub_string_04=>'Y'
,p_prompt_sub_string_05=>'Y'
);
wwv_flow_imp.component_end;
end;
/
