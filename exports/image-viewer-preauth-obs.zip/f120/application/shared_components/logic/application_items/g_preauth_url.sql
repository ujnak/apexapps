prompt --application/shared_components/logic/application_items/g_preauth_url
begin
--   Manifest
--     APPLICATION ITEM: G_PREAUTH_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(25244252821394088)
,p_name=>'G_PREAUTH_URL'
,p_protection_level=>'I'
);
wwv_flow_imp.component_end;
end;
/
