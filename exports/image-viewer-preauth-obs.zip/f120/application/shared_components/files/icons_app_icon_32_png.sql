prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000CC494441545847636CDC1DFF9F610001E3A8034643603404464360D08700EB1F2E06D6BF1C2865E5CB2F4F187885B9A8527E12';
wwv_flow_imp.g_varchar2_table(2) := '2C09B97E0A31A82BEA605876F6E671863F2CDF18D83859297208D90E00D9FAE0E56D869FDF7EE274C0877F2F093A906C07BCFFF89641805D14AFEFEF3EBFC1F099FD055E35041DC0FB538241595203C3107B756F82417FF0E656860BEF0E50E600032107';
wwv_flow_imp.g_varchar2_table(3) := '06622CC366CBA8034643607884C0E7B7DF186C55BD0866396C0A0EDFDE46B0C826580E906533099A461D301A02A321301A02031E020091A5A261A521A3560000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(25220010258326856)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
