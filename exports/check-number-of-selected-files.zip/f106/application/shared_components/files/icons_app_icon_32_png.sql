prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 106
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495801124689411
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE900000104494441545847638CCA58FB9F610001E3A8034643603404864C0808F3FF6130D095C559625CBCFC80E1E9CB5F0CEC1CBC2495';
wwv_flow_imp.g_varchar2_table(2) := '2A4497032EB6520CBEEE3A380DEF98B8878193839DE1FAED57243982AA0ED050956578F8F815498EA09A03E62E3EC6F0FADD377008FDFEF59DE1CD4776A2A2826A0E40B66DF3CE2B0C7B0E3FA3BD032E5E79C6A0AF238561115D1C70FCF403B0C596A60A';
wwv_flow_imp.g_varchar2_table(3) := '0C9B765C863BC2CF439781A60E98B7F41883BCAC080317271BD8721000590803A09C4253077CFFFE9BE1E6DDD70C0658821EE6089A3A8098944537078C26C2D144882B41D2241182AA63433D39623201C385CB4F19DE7C60244A2DD1750151A691A168D4';
wwv_flow_imp.g_varchar2_table(4) := '01A321301A02031E02000311E0E1A28C6B590000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(10139734215964575)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
