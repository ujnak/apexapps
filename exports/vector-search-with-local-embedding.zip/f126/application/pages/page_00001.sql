prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>126
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\753B\50CF\691C\7D22')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[module]#APP_FILES#app#MIN#.js'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#RESULTS img {',
'  width: 20%;',
unistr('  height: auto; /* \30A2\30B9\30DA\30AF\30C8\6BD4\3092\7DAD\6301 */'),
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23315518855054908)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23317563498054928)
,p_plug_name=>'Preview'
,p_parent_plug_id=>wwv_flow_imp.id(23315518855054908)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img id="image" style="width:100%;"></img>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(23317772361054930)
,p_name=>unistr('\691C\7D22\7D50\679C')
,p_region_name=>'RESULTS'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ID,',
'    TITLE,',
'    sys.dbms_lob.getlength(IMAGE) image,',
'    IMAGE_FILENAME,',
'    IMAGE_MIMETYPE,',
'    IMAGE_CHARSET,',
'    IMAGE_LASTUPD,',
'    EMBEDDING,',
'    (1 - vector_distance(embedding, to_vector(:P1_EMBEDDING))) similarity',
'from EBAJ_TEST_IMAGES'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P1_EMBEDDING'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23317846753054931)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23317929579054932)
,p_query_column_id=>2
,p_column_alias=>'TITLE'
,p_column_display_sequence=>20
,p_column_heading=>'Title'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23318092761054933)
,p_query_column_id=>3
,p_column_alias=>'IMAGE'
,p_column_display_sequence=>40
,p_column_heading=>'Image'
,p_column_format=>'IMAGE:EBAJ_TEST_IMAGES:IMAGE:ID::IMAGE_MIMETYPE:IMAGE_FILENAME:IMAGE_LASTUPD::::'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23318199714054934)
,p_query_column_id=>4
,p_column_alias=>'IMAGE_FILENAME'
,p_column_display_sequence=>50
,p_column_heading=>'Image Filename'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(23670450692336681)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23318227483054935)
,p_query_column_id=>5
,p_column_alias=>'IMAGE_MIMETYPE'
,p_column_display_sequence=>60
,p_column_heading=>'Image Mimetype'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(23670450692336681)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23318312339054936)
,p_query_column_id=>6
,p_column_alias=>'IMAGE_CHARSET'
,p_column_display_sequence=>70
,p_column_heading=>'Image Charset'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(23670450692336681)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23318450931054937)
,p_query_column_id=>7
,p_column_alias=>'IMAGE_LASTUPD'
,p_column_display_sequence=>80
,p_column_heading=>'Image Lastupd'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(23670450692336681)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23318547697054938)
,p_query_column_id=>8
,p_column_alias=>'EMBEDDING'
,p_column_display_sequence=>90
,p_column_heading=>'Embedding'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(23670450692336681)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23318655629054939)
,p_query_column_id=>9
,p_column_alias=>'SIMILARITY'
,p_column_display_sequence=>30
,p_column_heading=>'Similarity'
,p_column_format=>'999G999G999G999G990D0000'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_default_sort_column_sequence=>1
,p_default_sort_dir=>'desc'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23684108949336704)
,p_plug_name=>unistr('\753B\50CF\691C\7D22')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23315717648054910)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(23315518855054908)
,p_button_name=>'SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Search'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="SEARCH"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23315651467054909)
,p_name=>'P1_STATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(23315518855054908)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23315870494054911)
,p_name=>'P1_TEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(23315518855054908)
,p_prompt=>'Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23315905330054912)
,p_name=>'P1_IMAGE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(23315518855054908)
,p_prompt=>'Image'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_cropping', 'N',
  'allow_multiple_files', 'N',
  'display_as', 'INLINE',
  'purge_files_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23317648148054929)
,p_name=>'P1_EMBEDDING'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(23315518855054908)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23318785108054940)
,p_name=>'onChange P1_IMAGE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_IMAGE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23318841018054941)
,p_event_id=>wwv_flow_imp.id(23318785108054940)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.invoke("CHANGE");',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23317341263054926)
,p_name=>'onChange P1_EMBEDDING'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_EMBEDDING'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23318979900054942)
,p_name=>'onChange P1_EMBEDDING'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_EMBEDDING'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23319035658054943)
,p_event_id=>wwv_flow_imp.id(23318979900054942)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(23317772361054930)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
