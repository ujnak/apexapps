prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>222
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'JSON Download'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(116045940005873145)
,p_plug_name=>'All_OBJECTS'
,p_region_name=>'ALL_OBJECTS'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(120253831833706197)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'ALL_OBJECTS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(116046005092873146)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>116046005092873146
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(116046117511873147)
,p_db_column_name=>'OWNER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(116046201816873148)
,p_db_column_name=>'OBJECT_NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Object Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(116046332345873149)
,p_db_column_name=>'SUBOBJECT_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Subobject Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(116046451993873150)
,p_db_column_name=>'OBJECT_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Object Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120463759162709701)
,p_db_column_name=>'DATA_OBJECT_ID'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Data Object Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120463805301709702)
,p_db_column_name=>'OBJECT_TYPE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Object Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120463949078709703)
,p_db_column_name=>'CREATED'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120464022171709704)
,p_db_column_name=>'LAST_DDL_TIME'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Last Ddl Time'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120464165893709705)
,p_db_column_name=>'TIMESTAMP'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Timestamp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120464242115709706)
,p_db_column_name=>'STATUS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120464311843709707)
,p_db_column_name=>'TEMPORARY'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Temporary'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120464498719709708)
,p_db_column_name=>'GENERATED'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Generated'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120464585576709709)
,p_db_column_name=>'SECONDARY'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Secondary'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120464608854709710)
,p_db_column_name=>'NAMESPACE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Namespace'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120464797722709711)
,p_db_column_name=>'EDITION_NAME'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Edition Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120464895549709712)
,p_db_column_name=>'SHARING'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Sharing'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120464943747709713)
,p_db_column_name=>'EDITIONABLE'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Editionable'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120465009983709714)
,p_db_column_name=>'ORACLE_MAINTAINED'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Oracle Maintained'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120465189486709715)
,p_db_column_name=>'APPLICATION'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Application'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120465258686709716)
,p_db_column_name=>'DEFAULT_COLLATION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Default Collation'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120465378183709717)
,p_db_column_name=>'DUPLICATED'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Duplicated'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120465439791709718)
,p_db_column_name=>'SHARDED'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Sharded'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120465520395709719)
,p_db_column_name=>'IMPORTED_OBJECT'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Imported Object'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120465605858709720)
,p_db_column_name=>'SYNCHRONOUS_DUPLICATED'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Synchronous Duplicated'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120465734745709721)
,p_db_column_name=>'CREATED_APPID'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Created Appid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120465879131709722)
,p_db_column_name=>'CREATED_VSNID'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Created Vsnid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120465944860709723)
,p_db_column_name=>'MODIFIED_APPID'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Modified Appid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120466046523709724)
,p_db_column_name=>'MODIFIED_VSNID'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Modified Vsnid'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(120477762114711019)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1204778'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OWNER:OBJECT_NAME:SUBOBJECT_NAME:OBJECT_ID:DATA_OBJECT_ID:OBJECT_TYPE:CREATED:LAST_DDL_TIME:TIMESTAMP:STATUS:TEMPORARY:GENERATED:SECONDARY:NAMESPACE:EDITION_NAME:SHARING:EDITIONABLE:ORACLE_MAINTAINED:APPLICATION:DEFAULT_COLLATION:DUPLICATED:SHARDED:I'
||'MPORTED_OBJECT:SYNCHRONOUS_DUPLICATED:CREATED_APPID:CREATED_VSNID:MODIFIED_APPID:MODIFIED_VSNID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120461536940706986)
,p_plug_name=>'JSON Download'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(120230359673706146)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120466219679709726)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(120199857737706074)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(120466155864709725)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(120466219679709726)
,p_button_name=>'DOWNLOAD_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(120337285159706411)
,p_button_image_alt=>'Download All'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(120466560897709729)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(120466219679709726)
,p_button_name=>'DOWNLOAD_SELECTED'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(120337285159706411)
,p_button_image_alt=>'Download Selected'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(120467770959709741)
,p_name=>'P1_FILENAME'
,p_item_sequence=>10
,p_item_default=>'all_objects.json'
,p_prompt=>'Filename'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(120334788788706402)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(120466317437709727)
,p_name=>'onClick DOWNLOAD_ALL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(120466155864709725)
,p_bind_type=>'bind'
,p_execution_type=>'DEBOUNCE'
,p_execution_time=>2000
,p_execution_immediate=>true
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(120466412225709728)
,p_event_id=>wwv_flow_imp.id(120466317437709727)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DOWNLOAD'
,p_attribute_01=>'N'
,p_attribute_03=>'ATTACHMENT'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    json_serialize(',
'        json_object(',
'            ''objects'' value',
'                json_arrayagg(',
'                    json_object(*)',
'                returning clob)',
'        returning clob)',
'    returning clob pretty)    ',
'    ,:P1_FILENAME',
'    ,''application/json''',
'from all_objects'))
,p_attribute_06=>'P1_FILENAME'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(120466631482709730)
,p_name=>'onClick DOWNLOAD_SELECTED'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(120466560897709729)
,p_bind_type=>'bind'
,p_execution_type=>'DEBOUNCE'
,p_execution_time=>2000
,p_execution_immediate=>true
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(120466705464709731)
,p_event_id=>wwv_flow_imp.id(120466631482709730)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_region_id apex_application_page_regions.region_id%type;',
'    l_context apex_exec.t_context;',
'    l_clob clob;',
'begin',
'    select region_id into l_region_id from apex_application_page_regions',
'    where static_id = ''ALL_OBJECTS'';',
'    l_context := apex_region.open_query_context(',
'        p_page_id => :APP_PAGE_ID',
'        ,p_region_id => l_region_id',
'    );',
'    apex_json.initialize_clob_output;',
'    apex_json.open_object;',
'    apex_json.write_context( ''objects'', l_context );',
'    apex_json.close_object;',
'    --',
'    l_clob := apex_json.get_clob_output;',
'    apex_collection.create_or_truncate_collection(''JSON_CONTENT'');',
'    apex_collection.add_member(',
'        p_collection_name => ''JSON_CONTENT''',
'        ,p_n001 => 1',
'        ,p_clob001 => l_clob',
'    );',
'    --',
'    apex_json.free_output;',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(120466805216709732)
,p_event_id=>wwv_flow_imp.id(120466631482709730)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DOWNLOAD'
,p_attribute_01=>'N'
,p_attribute_03=>'ATTACHMENT'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    clob001',
'    ,:P1_FILENAME',
'    ,''application/json''',
'from apex_collections',
'where collection_name = ''JSON_CONTENT'' and N001 = 1;'))
,p_attribute_06=>'P1_FILENAME'
);
wwv_flow_imp.component_end;
end;
/
