prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>131
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Cytoscape Sample'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://unpkg.com/cytoscape@3.23.0/dist/cytoscape.min.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var cy;',
'',
'const RENDER_CY = {',
'    name: "render-cy",',
'    action: (event, element, args) => {',
'        let result = apex.server.process("GET_DATA", {',
'            x01: "get_data"',
'        });',
'        result.done( (data) => {',
'            cy = cytoscape({',
'                container: document.getElementById(''cy''), // container to render in',
'                elements: data.elements,',
'                style: data.style,',
'                layout: {',
'                    name: ''grid'',',
'                    rows: 1',
'                }',
'            })',
'        });',
'    }',
'};'))
,p_javascript_code_onload=>'apex.actions.add([RENDER_CY]);'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#cy {',
'  width: 300px;',
'  height: 300px;',
'  display: block;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230131054435'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36488188239314730)
,p_plug_name=>'Cytoscape'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39078311803683949)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<div id="cy"></div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39253271448684063)
,p_plug_name=>'Cytoscape Sample'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(39111399418683966)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36488371713314732)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(36488188239314730)
,p_button_name=>'RENDER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39217273845684021)
,p_button_image_alt=>'Render'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$render-cy"'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(36488280454314731)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'    l_response_json json_object_t;',
'    l_data_array json_array_t;',
'    l_data       json_object_t;',
'    l_style_array   json_array_t;',
'    l_style    json_object_t;',
'begin',
unistr('    /* elements\306E\4F5C\6210 */'),
'    l_data_array := json_array_t();',
'    l_data := json_object_t();',
'    l_data.put(''data'', json_object_t(',
'        json_object(',
'            ''id'' value ''a''',
'    )));',
'    l_data_array.append(l_data);',
'    l_data := json_object_t();',
'    l_data.put(''data'', json_object_t(',
'        json_object(',
'            ''id'' value ''b''',
'    )));',
'    l_data_array.append(l_data);',
'    l_data := json_object_t();',
'    l_data.put(''data'', json_object_t(',
'        json_object(',
'            ''id'' value ''ab''',
'            ,''source'' value ''a''',
'            ,''target'' value ''b''',
'    )));',
'    l_data_array.append(l_data);',
unistr('    /* sytle\306E\4F5C\6210 */'),
'    l_style_array := json_array_t();',
'    l_style := json_object_t();',
'    l_style.put(''style'', json_object_t(',
'        json_object(',
'            ''background-color'' value ''#666''',
'            ,''label'' value ''data(id)''',
'    )));',
'    l_style_array.append(l_style);',
'    l_style := json_object_t();',
'    l_style.put(''selector'',''node'');',
'    l_style.put(''style'', json_object_t(',
'        json_object(',
'            ''background-color'' value ''#666''',
'            ,''label'' value ''data(id)''',
'    )));',
'    l_style_array.append(l_style);',
'    l_style := json_object_t();',
'    l_style.put(''selector'',''edge'');',
'    l_style.put(''style'', json_object_t(',
'        json_object(',
'            ''width'' value 3',
'            ,''line-color'' value ''#ccc''',
'            ,''target-arrow-color'' value ''#ccc''',
'            ,''target-arrow-shape'' value ''triangle''',
'            ,''curve-style'' value ''bezier''',
'    )));',
'    l_style_array.append(l_style);',
unistr('    /* \5FDC\7B54\3068\306A\308BJSON\3092\751F\6210 */'),
'    l_response_json := json_object_t();',
'    l_response_json.put(''elements'', l_data_array);',
'    l_response_json.put(''style'', l_style_array);',
'    l_response := l_response_json.to_clob();',
'    apex_debug.info(l_response);',
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
