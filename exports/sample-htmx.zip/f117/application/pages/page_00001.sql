prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7216617235130697
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample htmx'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://unpkg.com/htmx.org@2.0.0'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.body.addEventListener(''htmx:configRequest'', function(evt) {',
'    evt.detail.headers[''Apex-Session''] = apex.env.APP_ID + '','' + apex.env.APP_SESSION;',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'img {',
'  max-width:100%;',
'  max-height: 100%;',
'  width: auto;',
'  height: auto;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8287812598090108)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8383953104967988)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8287931927090109)
,p_plug_name=>'Image'
,p_region_name=>'image'
,p_region_css_classes=>'w800 h800 margin-auto'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8382537593967984)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8646542127968910)
,p_plug_name=>'Sample htmx'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(8414474906968052)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8288023558090110)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8287812598090108)
,p_button_name=>'BUTTON1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(8521326670968302)
,p_button_image_alt=>unistr('\305F\306C\304D')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>unistr('hx-get="apexdev/htmx/image/\305F\306C\304D" hx-target="#image" hx-swap="innerHTML"')
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8288184271090111)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8287812598090108)
,p_button_name=>'BUTTON2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(8521326670968302)
,p_button_image_alt=>unistr('\30B7\30DE\30A6\30DE')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>unistr('hx-get="apexdev/htmx/image/\30B7\30DE\30A6\30DE" hx-target="#image" hx-swap="innerHTML"')
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8288205632090112)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(8287812598090108)
,p_button_name=>'BUTTON3'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(8521326670968302)
,p_button_image_alt=>unistr('\30EC\30C3\30B5\30FC\30D1\30F3\30C0')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>unistr('hx-get="apexdev/htmx/image/\30EC\30C3\30B5\30FC\30D1\30F3\30C0" hx-target="#image" hx-swap="innerHTML"')
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp.component_end;
end;
/
