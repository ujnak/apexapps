prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>121
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'AI Language Service'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230302013107'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58611654864082371)
,p_plug_name=>'AI Language Service'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(58469717791082241)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(58614029714087802)
,p_button_sequence=>50
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(58575680230082305)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54895589424513349)
,p_name=>'P1_TEXT'
,p_item_sequence=>10
,p_prompt=>'Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(58573127749082302)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58613946447087801)
,p_name=>'P1_RESULT'
,p_data_type=>'CLOB'
,p_item_sequence=>60
,p_prompt=>'Result'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(58573127749082302)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58614284927087804)
,p_name=>'P1_LANGUAGE_CODE'
,p_item_sequence=>30
,p_prompt=>'Language Code'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:en;en,es;es,ja;ja'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(58573127749082302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58614452208087806)
,p_name=>'P1_REQUEST'
,p_data_type=>'CLOB'
,p_item_sequence=>70
,p_prompt=>'Request'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(58573127749082302)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58614796194087809)
,p_name=>'P1_ENDPOINT'
,p_item_sequence=>40
,p_prompt=>'AI Service'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Key Phrases;/20210101/actions/batchDetectLanguageKeyPhrases,Text Classification;/20210101/actions/batchDetectLanguageTextClassification,Sentiments;/20210101/actions/batchDetectLanguageSentiments,Dominant Language;/20210101/actions/batchDetectD'
||'ominantLanguage,Entities;/20210101/actions/batchDetectLanguageEntities'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(58573127749082302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(58614652026087808)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prepare Documents'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request json_object_t;',
'    l_documents json_array_t;',
'    l_document  json_object_t;',
'    l_request_clob clob;',
'begin',
unistr('    /* \30EA\30AF\30A8\30B9\30C8\306E\6E96\5099 */'),
'    l_document := json_object_t();',
'    l_document.put(''key'',''1'');',
'    l_document.put(''text'',:P1_TEXT);',
'    if :P1_LANGUAGE_CODE is not null then',
'        l_document.put(''languageCode'',:P1_LANGUAGE_CODE);',
'    end if;',
'    l_documents := json_array_t();',
'    l_documents.append(l_document);',
'    l_request := json_object_t();',
'    l_request.put(''documents'',l_documents);',
'    :P1_REQUEST := l_request.to_clob();',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(58614162697087803)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'AI Language Service'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response_clob clob;',
'    l_endpoint varchar2(400);',
'begin',
'    l_endpoint := v(''G_API_SERVER'') || :P1_ENDPOINT;',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'');',
'    l_response_clob := apex_web_service.make_rest_request(',
'        p_url => l_endpoint',
'        ,p_http_method => ''POST''',
'        ,p_body => :P1_REQUEST',
'        ,p_credential_static_id => ''OCI_API_ACCESS''',
'    );',
'    :P1_RESULT := l_response_clob;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(58614029714087802)
);
wwv_flow_imp.component_end;
end;
/
