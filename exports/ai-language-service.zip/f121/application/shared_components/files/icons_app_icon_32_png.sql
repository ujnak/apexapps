prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 121
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>121
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000CC494441545847637C191DF29F610001E3A8034643603404464360D087C0376E1E866F9C9C2865E5DFC78F19C43939A8527E12';
wwv_flow_imp.g_varchar2_table(2) := '2C09DF888832C8E8E86258F6E8E85106AE6F5F19785859287208D90E00D9FAE1D64D862FBF7EE17400C7F3E7041D48B603BEBE7DCBF05F4C1CAFEFDF5EBBCA20FEFC295E35041DF052529A41584B1BC310515F7F8241FF7AF3460696BDBB2873C01F6737';
wwv_flow_imp.g_varchar2_table(3) := '06622CC366CBA8034643607884C0CBEF3F18847DFC0866396C0ADE6ED944B0C826580E906533099A461D301A02A321301A02031E0200FA88A1014AACA7E10000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(58601937768082339)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
