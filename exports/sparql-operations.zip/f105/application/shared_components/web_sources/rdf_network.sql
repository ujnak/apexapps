prompt --application/shared_components/web_sources/rdf_network
begin
--   Manifest
--     WEB SOURCE: RDF network
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>105
,p_default_id_offset=>11410637118181436
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(22783250098281801)
,p_name=>'RDF network'
,p_static_id=>'rdf_network'
,p_web_source_type=>'NATIVE_ORDS'
,p_data_profile_id=>wwv_flow_imp.id(22781151182281798)
,p_remote_server_id=>wwv_flow_imp.id(22773778094109076)
,p_url_path_prefix=>'/database/rdf/networks/'
,p_credential_id=>wwv_flow_imp.id(22774079129114182)
,p_attribute_01=>'N'
,p_attribute_02=>'HIGHEST'
,p_version_scn=>4826944
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(22783491579281802)
,p_web_src_module_id=>wwv_flow_imp.id(22783250098281801)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(22783878552281803)
,p_web_src_module_id=>wwv_flow_imp.id(22783250098281801)
,p_operation=>'POST'
,p_database_operation=>'INSERT'
,p_url_pattern=>'.'
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
