prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>116
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30B0\30EC\30FC\30B9\30B1\30FC\30EB\5909\63DB')
,p_alias=>unistr('\30B0\30EC\30FC\30B9\30B1\30FC\30EB\5909\63DB')
,p_step_title=>unistr('\30B0\30EC\30FC\30B9\30B1\30FC\30EB\5909\63DB')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21335267959028716)
,p_plug_name=>'Ebaj Demo Image'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>60
,p_query_type=>'TABLE'
,p_query_table=>'EBAJ_DEMO_IMAGES'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21342672177028720)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(21321520614028683)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21341210785028719)
,p_button_sequence=>30
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_condition=>'P1_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21340844142028719)
,p_button_sequence=>40
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_condition=>'P1_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21340411796028719)
,p_button_sequence=>50
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\524A\9664')
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P1_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17013780243529624)
,p_name=>'P1_SOURCE'
,p_item_sequence=>70
,p_prompt=>'Source'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'SQL',
  'sql_statement', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select source_image, null, filename, mime_type',
    'from ebaj_demo_images',
    'where id = :P1_ID')))).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17013847349529625)
,p_name=>'P1_TARGET'
,p_item_sequence=>80
,p_prompt=>'Target'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'SQL',
  'sql_statement', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select target_image, null, filename, mime_type',
    'from ebaj_demo_images',
    'where id = :P1_ID')))).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21335616090028716)
,p_name=>'P1_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_item_source_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21336066313028717)
,p_name=>'P1_FILENAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_item_source_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_source=>'FILENAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21336426096028718)
,p_name=>'P1_MIME_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_item_source_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_source=>'MIME_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21336846969028718)
,p_name=>'P1_OPERATION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_item_source_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_source=>'OPERATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21337265123028718)
,p_name=>'P1_SOURCE_IMAGE'
,p_source_data_type=>'BLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_item_source_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_prompt=>'Source Image'
,p_source=>'SOURCE_IMAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_cropping', 'N',
  'display_as', 'DROPZONE_ICON',
  'display_download_link', 'Y',
  'filename_column', 'FILENAME',
  'mime_type_column', 'MIME_TYPE',
  'preview_size', 'AUTO',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21337662523028718)
,p_name=>'P1_TARGET_IMAGE'
,p_source_data_type=>'BLOB'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_item_source_plug_id=>wwv_flow_imp.id(21335267959028716)
,p_source=>'TARGET_IMAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(17013643689529623)
,p_computation_sequence=>10
,p_computation_item=>'P1_OPERATION'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'greyscale'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(21342076236028719)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(21335267959028716)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0\30B0\30EC\30FC\30B9\30B1\30FC\30EB\5909\63DB')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>21342076236028719
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17013993029529626)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'greyscale'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \3053\306E\30B3\30FC\30C9\306F Martin Back\3055\3093\306B\3088\308B\4EE5\4E0B\306E\30D6\30ED\30B0\8A18\4E8B\304B\3089\5F15\7528\3057\3066\3044\307E\3059\3002'),
' * ',
' * Multilingual Engine: polyfill timeouts and intervals',
' * https://martincarstenbach.com/2025/05/22/multilingual-engine-polyfill-timeouts-and-intervals/',
' * ',
unistr(' * \30B3\30FC\30C9\306E\5909\66F4\70B9\306F\30B3\30FC\30C9\4E2D\306E\30B3\30E1\30F3\30C8\306B\8A18\8F09\3057\3066\3044\307E\3059\3002'),
' */',
'const { image2Greyscale } = await import (''jimp'');',
'const { setTimeout, clearTimeout, setInterval, clearInterval } = await import (''polyfill'');',
' ',
'globalThis.setTimeout = setTimeout;',
'globalThis.clearTimeout = clearTimeout;',
'globalThis.setInterval = setInterval;',
'globalThis.clearInterval = clearInterval;',
'',
'let rows;',
'',
'function needsSalaryRaise( empno ) {',
'    // placeholder for some complicated logic to calculate if employee needs a raise',
'    return true;',
'}',
'',
'/*',
unistr(' * APEX\306E\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306F\6587\5B57\5217\306A\306E\3067\3001\6570\5024\306B\5909\63DB\3059\308B\3002'),
' */',
'const id = Number(apex.env.P1_ID);',
'',
'/*',
unistr(' * \30AA\30EA\30B8\30CA\30EB\306E\30B3\30FC\30C9\3067 1 \304C\6307\5B9A\3055\308C\3066\3044\308B\90E8\5206\3092\5909\6570id\306B\7F6E\304D\63DB\3048\3066\3044\307E\3059\3002'),
unistr(' * \4FDD\5B58\3059\308B\8868\3092EBAJ_DEMO_IMAGES\3001\5217\3092SOURCE_IMAGE\306B\5909\66F4\3057\3066\3044\307E\3059\3002'),
' */',
'let result = session.execute(',
'    ''select SOURCE_IMAGE from ebaj_demo_images where id = :id'',',
'    [ id ],',
'    {',
'        fetchInfo: {',
'            SOURCE_IMAGE: {',
'                type: oracledb.UINT8ARRAY',
'            }',
'        }',
'    }',
');',
' ',
'console.log(`fetched ${result.rows.length} rows`);',
' ',
'const file = result.rows[0].SOURCE_IMAGE.buffer;',
'const transformedFile = await image2Greyscale(file);',
' ',
'console.log(''file successfully transformed'');',
' ',
'let theBLOB = OracleBlob.createTemporary(false);',
'console.log(''new blob allocated'');',
' ',
'theBLOB.open(OracleBlob.LOB_READWRITE);',
'console.log(''blob opened r/w'');',
' ',
'theBLOB.write(1, transformedFile);',
'',
'/*',
unistr(' * \5143\306E\30B3\30FC\30C9\306Finsert\306E\3068\3053\308D\3092update\306B\5909\66F4\3057\3001\30B0\30EC\30FC\30B9\30B1\30FC\30EB\5909\63DB\3057\305F'),
unistr(' * \753B\50CF\3092SOURCE_IMAGE\3068\540C\3058\884C\306ETARGET_IMAGE\306B\4FDD\5B58\3057\3066\3044\307E\3059\3002'),
' */',
'result = session.execute(',
'    ''update ebaj_demo_images set target_image = :theBLOB where id = :id'',',
'    {',
'        id: {',
'            type: oracledb.DB_TYPE_NUMBER,',
'            dir: oracledb.BIND_IN,',
'            val: id',
'        },',
'        theBLOB:{',
'            type: oracledb.ORACLE_BLOB,',
'            dir: oracledb.BIND_IN,',
'            val: theBLOB',
'        }',
'    }',
');',
'',
'theBLOB.close();',
'console.log(''transformed image successfully saved'');'))
,p_process_clob_language=>'JAVASCRIPT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>17013993029529626
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17014060628529627)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(21340411796028719)
,p_internal_uid=>17014060628529627
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(21341697607028719)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(21335267959028716)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0\30B0\30EC\30FC\30B9\30B1\30FC\30EB\5909\63DB')
,p_internal_uid=>21341697607028719
);
wwv_flow_imp.component_end;
end;
/
