prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>109
,p_default_id_offset=>20144468729316259
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\65E5\4ED8\7BC4\56F2\30D4\30C3\30AB\30FC')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'const DATE_FORMAT = "yyyy/mm/dd";'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.item("P1_DATE_RANGE").dayFormatter = (iso8860DateString) => {',
'    // Parse the day being formatted using ISO8860',
'    const currentDate = apex.date.parse(iso8860DateString,',
'                                        "YYYY-MM-DD");',
'    const startDateValue = apex.items.P1_DATE_START.value;',
'    // Parse start date using start page item format',
'    const startDate = startDateValue ? ',
'        apex.date.parse(startDateValue,DATE_FORMAT) : null;',
'    const endDateValue = apex.items.P1_DATE_END.value;',
'    // Parse end date using end page item format',
'    const endDate = endDateValue ? ',
'        apex.date.parse(endDateValue,DATE_FORMAT) : null;',
'    ',
'    let dateRangeClass = "";',
unistr('    // \958B\59CB\65E5\306E\8A2D\5B9A\306F\5FC5\9808\3002'),
'    if (startDateValue) {',
unistr('        // \958B\59CB\65E5\304C\51E6\7406\5BFE\8C61\3067\3042\308B\3002'),
'        if (apex.date.isSame(currentDate,startDate)) {',
unistr('            // \958B\59CB\65E5\3068\7D42\4E86\65E5\304C\540C\3058\3067\3042\308C\3070\3001\30B9\30BF\30A4\30EBdateRangeSingleDay\3092\9069\7528\3059\308B\3002'),
'            if (endDateValue && apex.date.isSame(currentDate,endDate)) {',
'                dateRangeClass = "dateRangeSingleDay";',
'            }',
'            else {',
'                dateRangeClass = "dateRangeStart";',
'            }',
'        }',
unistr('        // \51E6\7406\5BFE\8C61\304C\958B\59CB\65E5\4EE5\5916\3002'),
'        else if (endDateValue) {',
unistr('            // \51E6\7406\5BFE\8C61\304C\7D42\4E86\65E5\3067\3042\308C\3070\3001\30B9\30BF\30A4\30EBdateRangeEnd\3092\9069\7528\3059\308B\3002'),
'            if (apex.date.isSame(currentDate,endDate)) {',
'                dateRangeClass = "dateRangeEnd"',
'            } else if (apex.date.isBetween(currentDate,startDate,endDate)) {',
unistr('                // \51E6\7406\5BFE\8C61\304C\958B\59CB\65E5\3068\7D42\4E86\65E5\306E\9593\3067\3042\308C\3070\30B9\30BF\30A4\30EBdateRangeMiddle\3092\9069\7528\3059\308B\3002'),
'                dateRangeClass = "dateRangeMiddle";',
'            }',
'        }',
unistr('        // \305D\308C\4EE5\5916\306F\30B9\30BF\30A4\30EB\3092\9069\7528\3057\306A\3044\3002'),
'    };',
'    return {',
'        disabled: false,',
'        class: dateRangeClass',
'    };',
'};'))
,p_css_file_urls=>'#APP_FILES#dateRangePicker#MIN#.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78762683702404103)
,p_plug_name=>unistr('\65E5\4ED8\7BC4\56F2')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>3
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79560221497011400)
,p_plug_name=>unistr('\65E5\4ED8\7BC4\56F2\30D4\30C3\30AB\30FC')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78762645329404102)
,p_name=>'P1_DATE_RANGE'
,p_item_sequence=>20
,p_prompt=>unistr('\65E5\4ED8\7BC4\56F2')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_tag_css_classes=>'date-range-picker'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER:CLEAR-BUTTON',
  'days_outside_month', 'VISIBLE',
  'display_as', 'INLINE',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78762840288404104)
,p_name=>'P1_DATE_START'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(78762683702404103)
,p_prompt=>'Date Start'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78762918441404105)
,p_name=>'P1_DATE_END'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(78762683702404103)
,p_prompt=>'Date End'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(78762996317404106)
,p_name=>'onClick Specific Date'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_DATE_RANGE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(78763135974404107)
,p_event_id=>wwv_flow_imp.id(78762996317404106)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_DATE_START,P1_DATE_END'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \5F71\97FF\3092\53D7\3051\308B\8981\7D20\3068\3057\3066\3001\958B\59CB\65E5\3068\7D42\4E86\65E5\306E\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\3092\8A2D\5B9A\3059\308B\3002'),
unistr(' * \958B\59CB\65E5\306E\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\3092\5148\306B\8A2D\5B9A\3059\308B\3002'),
' */',
'const dateItemStart   = this.affectedElements[0];',
'const dateItemEnd     = this.affectedElements[1];',
'const dateItemClicked = this.triggeringElement;',
unistr('// dateItemClicked.value\3067\306F\306A\304F$v\3067\5024\3092\53D6\5F97\3059\308B\3088\3046\306B\5909\66F4\3002'),
'const dateItemClicked_value = $v(dateItemClicked);',
'',
'/*',
unistr(' * \5024\304C\8A2D\5B9A\3055\308C\3066\3044\306A\3044\3068\304D\306F\3001\30AF\30EA\30A2\304C\30AF\30EA\30C3\30AF\3055\308C\3066\3044\308B\3002'),
unistr(' * \958B\59CB\65E5\3068\7D42\4E86\65E5\3092\30AF\30EA\30A2\3057\3066\3001\30EA\30D5\30EC\30C3\30B7\30E5\3059\308B\3002'),
' */',
'if (!dateItemClicked_value) {',
'    dateItemStart.value = "";',
'    dateItemEnd.value = "";',
'    dateItemClicked.refresh();',
'    return;',
'}',
'',
'if (!dateItemStart.value) {',
unistr('    // \958B\59CB\65E5\304C\672A\8A2D\5B9A\306A\306E\3067\3001\9078\629E\3055\308C\305F\5024\306F\958B\59CB\65E5\3068\3057\3066\6271\3046\3002'),
'    dateItemStart.value = dateItemClicked_value;',
'    if (!dateItemEnd.value) {',
'        /*',
unistr('         * \7D42\4E86\65E5\3082\672A\8A2D\5B9A\306A\306E\3067\3001\540C\3058\65E5\4ED8\3092\7D42\4E86\65E5\306B\8A2D\5B9A\3059\308B\3002'),
unistr('         * \958B\59CB\65E5\3068\7D42\4E86\65E5\304C\540C\3058\65E5\3067\3042\308B\3053\3068\3092\7981\6B62\3059\308B\5834\5408\306F\3001\3053\306E\51E6\7406\3092\5909\66F4\3059\308B\3002'),
'         */',
'        dateItemEnd.value = dateItemClicked_value;',
'    }',
unistr('    // \958B\59CB\65E5\304C\672A\8A2D\5B9A\3067\7D42\4E86\65E5\304C\8A2D\5B9A\3055\308C\3066\3044\308B\3053\3068\306F\7121\3044\306F\305A\3002\306A\306E\3067\7121\8996\3059\308B\3002'),
'}',
'else',
'{',
unistr('    // \958B\59CB\65E5\306F\3059\3067\306B\8A2D\5B9A\3055\308C\3066\3044\308B\3002'),
'    const dateClicked = apex.date.parse(dateItemClicked_value, DATE_FORMAT);',
'    const dateStart   = apex.date.parse(dateItemStart.value, DATE_FORMAT);',
'    if (!dateItemEnd.value) {',
unistr('        // \7D42\4E86\65E5\304C\8A2D\5B9A\3055\308C\3066\3044\306A\3044\3002'),
'        if (apex.date.isBefore(dateClicked, dateStart)) {',
unistr('             // \9078\629E\3057\305F\65E5\4ED8\304C\958B\59CB\65E5\3088\308A\524D\3067\3042\308C\3070\3001\958B\59CB\65E5\3068\7D42\4E86\65E5\3092\5165\308C\66FF\3048\3066\671F\9593\3092\8A2D\5B9A\3059\308B\3002'),
'            dateItemEnd.value     = dateItemStart.value;',
'            dateItemStart.value   = dateItemClicked_value;',
'        }',
'        else',
'        {',
'            /*',
unistr('             * \7D42\4E86\65E5\3092\8A2D\5B9A\3059\308B\3002'),
unistr('             * \65E5\4ED8\306E\7BC4\56F2\3092\6B63\3057\304F\8868\793A\3055\305B\308B\305F\3081\3001\3053\306E\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306B\306F\958B\59CB\65E5\3092\8A2D\5B9A\3059\308B\3002'),
'             */',
'            dateItemEnd.value = dateItemClicked_value;',
'        }',
'    }',
'    else',
'    {',
unistr('        // \958B\59CB\65E5\3068\7D42\4E86\65E5\306E\4E21\65B9\304C\8A2D\5B9A\6E08\307F\3002'),
'        const dateEnd = apex.date.parse(dateItemEnd.value, DATE_FORMAT);',
'        if (apex.date.isBefore(dateClicked, dateStart)) {',
unistr('            // \958B\59CB\65E5\3088\308A\524D\306E\65E5\4ED8\3092\9078\629E\3057\305F\3068\304D\306F\958B\59CB\65E5\3092\5909\66F4\3059\308B\3002'),
'            dateItemStart.value = dateItemClicked_value;',
'        } else if (apex.date.isAfter(dateClicked, dateEnd)) {',
unistr('            // \7D42\4E86\65E5\3088\308A\5F8C\306E\65E5\4ED8\3092\9078\629E\3057\305F\3068\304D\306F\7D42\4E86\65E5\3092\5909\66F4\3059\308B\3002'),
'            dateItemEnd.value = dateItemClicked_value;',
'        } else if (apex.date.isBetween(dateClicked, dateStart, dateEnd)) {',
unistr('            // \958B\59CB\65E5\3068\7D42\4E86\65E5\306E\9593\306E\65E5\4ED8\3092\9078\629E\3057\305F\3068\304D\306F\3001\7D42\4E86\65E5\3092\5909\66F4\3059\308B\3002'),
'            dateItemEnd.value = dateItemClicked_value;',
unistr('            // \958B\59CB\65E5\3092\5F8C\308D\306B\79FB\52D5\3059\308B\306B\306F\3001\4E00\65E6\30AF\30EA\30A2\3059\308B\3002'),
'        }',
'    }',
'    /*',
unistr('     * \3053\306E\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306B\306F\3064\306D\306B\958B\59CB\65E5\3092\8A2D\5B9A\3057\305F\306E\3061\306B\30EA\30D5\30EC\30C3\30B7\30E5\3092\884C\3046\3002'),
unistr('     * \65E5\4ED8\306E\7BC4\56F2\3092\6B63\3057\304F\8868\793A\3059\308B\305F\3081\306B\5FC5\8981\3002'),
'     */',
unistr('    // dateItemClicked.value\306B\4EE3\5165\3067\306F\306A\304F$s\3067\5024\3092\53D6\5F97\3059\308B\3088\3046\306B\5909\66F4\3002'),
'    $s(dateItemClicked, dateItemStart.value, null, true);',
'    dateItemClicked.refresh();',
'}'))
);
wwv_flow_imp.component_end;
end;
/
