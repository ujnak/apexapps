prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'OCI Language'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230227050711'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56247044515518216)
,p_plug_name=>'OCI Language'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(56105053030518131)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54892922570513323)
,p_button_sequence=>60
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(56210998601518184)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54892488815513318)
,p_name=>'P1_SOURCE_TEXT'
,p_item_sequence=>30
,p_prompt=>'Source Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(56208490511518183)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54892580440513319)
,p_name=>'P1_TARGET_TEXT'
,p_item_sequence=>50
,p_prompt=>'Target Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(56208490511518183)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54892744943513321)
,p_name=>'P1_SOURCE_LANG'
,p_item_sequence=>10
,p_prompt=>'Source Lang'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(56208490511518183)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54892826858513322)
,p_name=>'P1_TARGET_LANG'
,p_item_sequence=>40
,p_prompt=>'Target Lang'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(56208490511518183)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54892635164513320)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Translate'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
unistr('    /* OCI Language\306E\7FFB\8A33\51E6\7406\306E\30A8\30F3\30C9\30DD\30A4\30F3\30C8 */'),
'    C_ENDPOINT constant varchar2(120) := ''https://language.aiservice.us-ashburn-1.oci.oraclecloud.com/20221001/actions/batchLanguageTranslation'';',
'    l_request json_object_t;',
'    l_request_clob clob;',
'    l_response json_object_t;',
'    l_response_clob clob;',
'    l_documents json_array_t;',
'    l_document json_object_t;',
'begin',
unistr('    /* \7FFB\8A33\3092\4F9D\983C\3059\308B\30E1\30C3\30BB\30FC\30B8\3092\4F5C\6210\3059\308B\3002 */'),
'    l_request := json_object_t();',
'    l_document := json_object_t();',
'    l_document.put(''key'', ''1'');',
'    l_document.put(''text'', :P1_SOURCE_TEXT);',
'    l_document.put(''languageCode'',:P1_SOURCE_LANG);',
'    l_documents := json_array_t();',
'    l_documents.append(l_document);',
'    l_request.put(''documents'',l_documents);',
'    l_request.put(''targetLanguageCode'',:P1_TARGET_LANG);',
'    l_request_clob := l_request.to_clob();',
unistr('    /* \7FFB\8A33\30EA\30AF\30A8\30B9\30C8\306E\767A\884C */'),
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'');',
'    l_response_clob := apex_web_service.make_rest_request(',
'        p_url => C_ENDPOINT',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'        ,p_credential_static_id => ''OCI_API_ACCESS''',
'    );',
unistr('    /* \5FDC\7B54\306E\3059\3079\3066\3092JSON\5F62\5F0F\3067\78BA\8A8D\3059\308B\3002 */'),
'    -- :P1_TARGET_TEXT := l_response_clob;  ',
unistr('    /* \7FFB\8A33\3055\308C\305F\6587\7AE0\3060\3051\3092\78BA\8A8D\3059\308B\3002 */'),
'    l_response := json_object_t(l_response_clob);',
'    l_documents := l_response.get_array(''documents'');',
unistr('    /* \9001\4FE1\3057\305Fkey\306F1\3060\3051\306A\306E\3067\3001\7FFB\8A33\3055\308C\305F\6587\7AE0\3082\FF11\3064\3060\3051 */'),
'    l_document := json_object_t(l_documents.get(0)); ',
'    :P1_TARGET_TEXT := l_document.get_string(''translatedText'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
