prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>295
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>unistr('\884C\653F\533A\57DF\30D5\30A1\30A4\30EB\7DE8\96C6')
,p_alias=>unistr('\884C\653F\533A\57DF\30D5\30A1\30A4\30EB\7DE8\96C6')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\884C\653F\533A\57DF\30D5\30A1\30A4\30EB\7DE8\96C6')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(120235326869007745)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231031023843'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120570508187092207)
,p_plug_name=>unistr('\884C\653F\533A\57DF\30D5\30A1\30A4\30EB\7DE8\96C6')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(120271240434007800)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'MLIT_DATA'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120574949113092218)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(120301493212007824)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(117532240122902540)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(120411092308007932)
,p_button_image_alt=>'Load'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(120575335204092218)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(120574949113092218)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(120411092308007932)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(120576704402092222)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(120574949113092218)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(120411092308007932)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(120577173553092222)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(120574949113092218)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(120411092308007932)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(120577539523092223)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(120574949113092218)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(120411092308007932)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(120570889673092208)
,p_name=>'P3_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_item_source_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(120408522752007924)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(120571117812092212)
,p_name=>'P3_CONTENT'
,p_source_data_type=>'BLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_item_source_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_prompt=>'Content'
,p_source=>'CONTENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(120408522752007924)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_02=>'CONTENT_MIMETYPE'
,p_attribute_03=>'CONTENT_FILENAME'
,p_attribute_04=>'CONTENT_CHARSET'
,p_attribute_05=>'CONTENT_LASTUPD'
,p_attribute_06=>'Y'
,p_attribute_08=>'attachment'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(120571542323092213)
,p_name=>'P3_CONTENT_FILENAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_item_source_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_prompt=>'Content Filename'
,p_source=>'CONTENT_FILENAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>512
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(120408522752007924)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(120233995376007736)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(120571973738092213)
,p_name=>'P3_CONTENT_MIMETYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_item_source_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_prompt=>'Content Mimetype'
,p_source=>'CONTENT_MIMETYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>512
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(120408522752007924)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(120233995376007736)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(120572309701092213)
,p_name=>'P3_CONTENT_CHARSET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_item_source_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_prompt=>'Content Charset'
,p_source=>'CONTENT_CHARSET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>512
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(120408522752007924)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(120233995376007736)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(120572785292092214)
,p_name=>'P3_CONTENT_LASTUPD'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_item_source_plug_id=>wwv_flow_imp.id(120570508187092207)
,p_prompt=>'Content Lastupd'
,p_source=>'CONTENT_LASTUPD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(120408522752007924)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(120233995376007736)
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(120575466102092218)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(120575335204092218)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(120576230902092221)
,p_event_id=>wwv_flow_imp.id(120575466102092218)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(120578358196092223)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(120570508187092207)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0\884C\653F\533A\57DF\30D5\30A1\30A4\30EB\7DE8\96C6')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>120578358196092223
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(117532459051902542)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>unistr('\884C\653F\533A\57DF\30C7\30FC\30BF\306E\30ED\30FC\30C9')
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'IGNORE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(117532240122902540)
,p_internal_uid=>117532459051902542
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(120578767309092224)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE,LOAD'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>120578767309092224
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(120577931922092223)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(120570508187092207)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0\884C\653F\533A\57DF\30D5\30A1\30A4\30EB\7DE8\96C6')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>120577931922092223
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(117532596430902543)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(117532459051902542)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\30ED\30FC\30C9')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('/* \6700\521D\306B\4EE5\524D\306E\30C7\30FC\30BF\3092\5168\524A\9664\3059\308B */'),
'delete from mlit_municipality_admins where data_id = :P3_ID;',
'',
unistr('/* \30C7\30FC\30BF\306E\30ED\30FC\30C9 */'),
'insert into mlit_municipality_admins',
'(',
'    prefecture_name,',
'    branch_in_hokkaido,',
'    major_city, city_name,',
'    admin_code,',
'    geometry,',
'    data_id',
')',
'select',
'    jt.N03_001             prefecture_name',
'    ,jt.N03_002            branch_in_hokkaido',
'    ,jt.N03_003            major_city',
'    ,jt.N03_004            city_name',
'    ,nvl(jt.N03_007,''N/A'') admin_code',
'    ,jt.geometry           geometry',
'    ,mlit_data.id',
'from mlit_data,',
'json_table(content, ''$.features[*]''',
'    columns(',
'        N03_001 varchar2(255) path ''$.properties.N03_001'',',
'        N03_002 varchar2(255) path ''$.properties.N03_002'',',
'        N03_003 varchar2(255) path ''$.properties.N03_003'',',
'        N03_004 varchar2(255) path ''$.properties.N03_004'',',
'        N03_007 varchar2(255) path ''$.properties.N03_007'',',
'        geometry sdo_geometry path ''$.geometry''',
'    )',
') jt',
'where mlit_data.id = :P3_ID;',
'',
unistr('/* recitify\3059\308B\3002 */'),
'update mlit_municipality_admins set geom_r = sdo_util.rectify_geometry(geometry,0.05)',
'where data_id = :P3_ID;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>117532596430902543
);
wwv_flow_imp.component_end;
end;
/
