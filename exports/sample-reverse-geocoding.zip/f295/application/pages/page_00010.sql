prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>295
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>unistr('\884C\653F\533A\57DF\306B\542B\307E\308C\306A\3044\4F4F\6240')
,p_alias=>unistr('\884C\653F\533A\57DF\306B\542B\307E\308C\306A\3044\4F4F\6240')
,p_step_title=>unistr('\884C\653F\533A\57DF\306B\542B\307E\308C\306A\3044\4F4F\6240')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231031072003'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120724015081314174)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(120350211081007867)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(120234593476007740)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(120412668209007933)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120724696155314175)
,p_plug_name=>unistr('\884C\653F\533A\57DF\306B\542B\307E\308C\306A\3044\4F4F\6240')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(120272675153007801)
,p_plug_display_sequence=>10
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(120725020201314175)
,p_region_id=>wwv_flow_imp.id(120724696155314175)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(120725518502314177)
,p_map_region_id=>wwv_flow_imp.id(120725020201314175)
,p_name=>unistr('\884C\653F\533A\57DF\306B\542B\307E\308C\306A\3044\4F4F\6240')
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select location, municipality, street, sec_unit from mlit_location_references ',
'where municipality_id is null and operation_current_year <> 3'))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'LOCATION'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'&REGION. &MUNICIPALITY. &STREET. &SEC_UNIT.'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp.component_end;
end;
/
