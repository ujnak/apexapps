prompt --application/shared_components/json_source/opentelemetry_traces
begin
--   Manifest
--     DOCUMENT SOURCE: OpenTelemetry Traces
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_document_source(
 p_id=>wwv_flow_imp.id(19177141061599011)
,p_name=>'OpenTelemetry Traces'
,p_static_id=>'opentelemetry_traces'
,p_document_source_type=>'JSON_TABLE'
,p_location=>'LOCAL'
,p_object_name=>'EBAJ_OTEL_TRACES'
,p_data_profile_id=>wwv_flow_imp.id(19177229310599011)
,p_version_scn=>4966348
);
wwv_flow_imp.component_end;
end;
/
