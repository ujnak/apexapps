prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>202
,p_default_id_offset=>106271939955054354
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'TensorFlow.js'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/tf.min.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var model;',
'var INCEPTION_CLASSES = [];'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \30DA\30FC\30B8\30FB\30ED\30FC\30C9\6642\306BTensorFlow.js\304C\8AAD\307F\8FBC\307E\308C\308B\3002TensorFlow.js\304CReady\306B\306A\3063\305F\3089\3001\7D9A\3051\3066\30E2\30C7\30EB\3092\8AAD\307F\8FBC\3080\3002'),
unistr(' * \30DA\30FC\30B8\3092\96E2\308C\305F\3089\30ED\30FC\30C9\3057\305F\30E2\30C7\30EB\306F\7834\68C4\3055\308C\308B\3068\601D\3046\306E\3067\3001\30E2\30C7\30EB\306B\305F\3044\3057\3066\306Fdispose()\306F\547C\3073\51FA\3057\3066\3044\306A\3044\3002'),
' */',
'tf.ready().then(() => {',
'    // const modelPath = "https://tfhub.dev/google/tfjs-model/imagenet/inception_v3/classification/3/default/1";',
'    const modelPath = "https://www.kaggle.com/models/google/inception-v3/TfJs/classification/2";',
'    apex.items.P1_STATUS.setValue("TensorFlow.js is Ready, Loading Model...");',
'    tf.loadGraphModel(modelPath, { fromTFHub: true }).then((m) => {',
unistr('        model = m; // model\306F\30DA\30FC\30B8\30FB\30B0\30ED\30FC\30D0\30EB\306A\5909\6570'),
'        apex.items.P1_STATUS.setValue("Model is Loaded");',
'    });',
'});',
'',
'/*',
unistr(' * ImageNet\306E\30E9\30D9\30EB\3092\914D\5217INCEPTION_CLASSES\306B\8AAD\307F\8FBC\3080\3002'),
' */',
'fetch(''https://storage.googleapis.com/download.tensorflow.org/data/ImageNetLabels.txt'')',
'    .then(response => {',
'        if (!response.ok) {',
'            throw new Error(''Failed to get ImageNetLabels.txt'');',
'        }',
'        return response.text();',
'    })',
'    .then( (text) => {',
unistr('        // \30C6\30AD\30B9\30C8\3092\884C\3054\3068\306B\5206\5272\3057\3001\914D\5217\306B\5909\63DB'),
'        INCEPTION_CLASSES = text.split(''\n'').filter(label => label.trim() !== '''');',
'        console.log(INCEPTION_CLASSES);',
'    })',
'    .catch(error => {',
'        console.error(''Failed to read ImageNetLabels.txt:'', error);',
'    });'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(318234575095695578)
,p_plug_name=>'Image'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(318574473216700259)
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source=>'<img id="mystery" src="" class="w80p" />'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(318234584420695579)
,p_button_sequence=>20
,p_button_name=>'DETECT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(318648040779700442)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Detect'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105696377581803727)
,p_name=>'P1_OBJECTS'
,p_item_sequence=>40
,p_prompt=>'Objects'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(318645573841700433)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318233832588695571)
,p_name=>'P1_STATUS'
,p_item_sequence=>30
,p_prompt=>'Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(318645346779700432)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318233999283695573)
,p_name=>'P1_IMAGE'
,p_item_sequence=>50
,p_prompt=>'Image'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(318645573841700433)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
,p_attribute_18=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(318234226639695575)
,p_name=>'onChange Image'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_IMAGE'
,p_condition_element=>'P1_IMAGE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(318234298943695576)
,p_event_id=>wwv_flow_imp.id(318234226639695575)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// get image file and its URL for img src.',
'const imageFile = this.triggeringElement.files[0];',
'const imageUrl = URL.createObjectURL(imageFile);',
'document.getElementById("mystery").src = imageUrl;',
'// Reset Status',
'apex.items.P1_OBJECTS.setValue("");',
'apex.items.P1_STATUS.setValue("Ready for Detection");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(318234735980695580)
,p_name=>'onClick DETECT'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(318234584420695579)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105696461201803728)
,p_event_id=>wwv_flow_imp.id(318234735980695580)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tf.tidy(() => {',
'    const mysteryImage = document.getElementById("mystery");',
'    const myTensor = tf.browser.fromPixels(mysteryImage);',
'    // Inception v3 expects an image resized to 299x299',
'    const readyfied = tf.image',
'        .resizeBilinear(myTensor, [299,299], true)',
'        .div(255)',
'        .reshape([1,299,299,3]);',
'    apex.items.P1_STATUS.setValue("Start prediction !");',
'    // predict.',
'    const result = model.predict(readyfied);',
'    result.print();',
'    apex.items.P1_STATUS.setValue("Prediction Done !");',
'',
'    const { values, indices } = tf.topk(result, 3);',
'    indices.print();',
'',
'    // Let''s hear those winners',
'    const winners = indices.dataSync();',
'    ',
'    apex.items.P1_OBJECTS.setValue(',
'`First place ${INCEPTION_CLASSES[winners[0]]},',
'Second place ${INCEPTION_CLASSES[winners[1]]},',
'Third place ${INCEPTION_CLASSES[winners[2]]}`);',
'',
'});'))
);
wwv_flow_imp.component_end;
end;
/
