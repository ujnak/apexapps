prompt --application/deployment/install/install_emp_dept_ctx_sql
begin
--   Manifest
--     INSTALL: INSTALL-emp_dept_ctx.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8758838051227582)
,p_install_id=>wwv_flow_imp.id(8756693582212726)
,p_name=>'emp_dept_ctx.sql'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\30FB\30B3\30F3\30C6\30AD\30B9\30C8emp_dept_ctx\3092\4F5C\6210\3059\308B\3002'),
'create or replace context emp_dept_ctx using emp_dept_ctx_pkg;',
'',
unistr('-- \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\30FB\30B3\30F3\30C6\30AD\30B9\30C8\3092\64CD\4F5C\3059\308B\30D1\30C3\30B1\30FC\30B8emp_dept_ctx_pkg\3092\4F5C\6210\3059\308B\3002'),
'create or replace package emp_dept_ctx_pkg is',
'procedure set_ename(p_ename in varchar2);',
'end emp_dept_ctx_pkg;',
'/',
'',
'create or replace package body emp_dept_ctx_pkg is',
'procedure set_ename(p_ename in varchar2)',
'is',
'begin',
'    dbms_session.set_context(''emp_dept_ctx'', ''ename'', p_ename);',
'end set_ename;',
'end emp_dept_ctx_pkg;',
'/',
'',
unistr('-- \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\30FB\30B3\30F3\30C6\30AD\30B9\30C8\3092\4F7F\3063\305F\30D3\30E5\30FC\306E\4F5C\6210'),
'create or replace view emp_in_dept_appctx_v(empno, ename, job, mgr, hiredate, sal, comm, deptno)',
'as',
'select',
'    empno',
'    , ename',
'    , job',
'    , mgr',
'    , hiredate',
'    , sal',
'    , comm',
'    , deptno',
'from emp',
'where deptno in ',
'(',
'    select deptno from emp where ename = sys_context(''EMP_DEPT_CTX'',''ENAME'')',
');'))
);
wwv_flow_imp.component_end;
end;
/
