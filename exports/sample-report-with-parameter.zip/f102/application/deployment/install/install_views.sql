prompt --application/deployment/install/install_views
begin
--   Manifest
--     INSTALL: INSTALL-views
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8757850124222432)
,p_install_id=>wwv_flow_imp.id(8756693582212726)
,p_name=>'views'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE FORCE EDITIONABLE VIEW "EMP_IN_DEPT_V" ("EMPNO", "ENAME", "JOB", "MGR", "HIREDATE", "SAL", "COMM", "DEPTNO") AS ',
'  select',
'    empno',
'    , ename',
'    , job',
'    , mgr',
'    , hiredate',
'    , sal',
'    , comm',
'    , deptno',
'from emp',
'where deptno in ',
'(',
'    select deptno from emp where ename = V(''G_ENAME'')',
')',
';',
'',
'CREATE OR REPLACE FORCE EDITIONABLE VIEW "EMP_IN_SAME_DEPT_V" ("EMPNO", "ENAME", "JOB", "MGR", "HIREDATE", "SAL", "COMM", "DEPTNO") AS ',
'  select',
'    empno',
'    , ename',
'    , job',
'    , mgr',
'    , hiredate',
'    , sal',
'    , comm',
'    , deptno',
'from emp',
'where deptno in ',
'(',
'    select deptno from emp where ename = V(''P2_ENAME'')',
')',
';',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(8757990144222433)
,p_script_id=>wwv_flow_imp.id(8757850124222432)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'EMP_IN_DEPT_V'
,p_last_updated_by=>'APEXDEV'
,p_last_updated_on=>to_date('20220822123927','YYYYMMDDHH24MISS')
,p_created_by=>'APEXDEV'
,p_created_on=>to_date('20220822123927','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(8758143538222433)
,p_script_id=>wwv_flow_imp.id(8757850124222432)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'EMP_IN_SAME_DEPT_V'
,p_last_updated_by=>'APEXDEV'
,p_last_updated_on=>to_date('20220822123927','YYYYMMDDHH24MISS')
,p_created_by=>'APEXDEV'
,p_created_on=>to_date('20220822123927','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
