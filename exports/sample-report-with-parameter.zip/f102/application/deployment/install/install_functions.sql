prompt --application/deployment/install/install_functions
begin
--   Manifest
--     INSTALL: INSTALL-functions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8757211954219438)
,p_install_id=>wwv_flow_imp.id(8756693582212726)
,p_name=>'functions'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE EDITIONABLE FUNCTION "GEN_SELECT_EMP_IN_SAME_DEPT" (',
'    p_ename in varchar2',
')',
'return varchar2',
'as',
'    l_stmt varchar2(32767);',
'begin',
'    l_stmt := ''select empno, ename, job, mgr, hiredate, sal, comm, deptno from emp'';',
'    l_stmt := l_stmt || '' where  deptno in (select deptno from emp where ename = '' || dbms_assert.enquote_literal(p_ename) || '')'';',
'    return l_stmt;',
'end gen_select_emp_in_same_dept;',
'/',
'',
'CREATE OR REPLACE EDITIONABLE FUNCTION "MACRO_SELECT_EMP_IN_SAME_DEPT" (',
'    p_ename in varchar2',
')',
'return clob sql_macro',
'as',
'    l_stmt clob;',
'begin',
'    l_stmt := ''select empno, ename, job, mgr, hiredate, sal, comm, deptno from emp'';',
'    l_stmt := l_stmt || '' where  deptno in (select deptno from emp where ename = p_ename)'';',
'    return l_stmt;',
'end macro_select_emp_in_same_dept;',
'/',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(8757329897219443)
,p_script_id=>wwv_flow_imp.id(8757211954219438)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'GEN_SELECT_EMP_IN_SAME_DEPT'
,p_last_updated_by=>'APEXDEV'
,p_last_updated_on=>to_date('20220822123858','YYYYMMDDHH24MISS')
,p_created_by=>'APEXDEV'
,p_created_on=>to_date('20220822123858','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(8757474935219446)
,p_script_id=>wwv_flow_imp.id(8757211954219438)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'MACRO_SELECT_EMP_IN_SAME_DEPT'
,p_last_updated_by=>'APEXDEV'
,p_last_updated_on=>to_date('20220822123858','YYYYMMDDHH24MISS')
,p_created_by=>'APEXDEV'
,p_created_on=>to_date('20220822123858','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
