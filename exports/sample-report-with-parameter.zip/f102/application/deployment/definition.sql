prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(8756693582212726)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop view emp_in_same_dept_v;',
'drop function gen_select_emp_in_same_dept;',
'drop function macro_select_emp_in_same_dept;',
'drop view EMP_IN_SAME_DEPT_V;',
'drop view EMP_IN_DEPT_V;',
'drop context emp_dept_ctx;',
'drop package emp_dept_ctx_pkg;',
'drop view emp_in_dept_appctx_v;'))
);
wwv_flow_imp.component_end;
end;
/
