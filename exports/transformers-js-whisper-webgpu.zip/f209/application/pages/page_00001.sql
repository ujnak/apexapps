prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Transformers.js Whisper'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var transcriber;'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107435811490244438)
,p_plug_name=>'Loading Whisper'
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="module" defer>',
'import { pipeline } from ''https://cdn.jsdelivr.net/npm/@huggingface/transformers/+esm'';',
'',
'/*',
unistr(' * WebGPU\306E\4F7F\7528\3092\6C7A\5B9A\3059\308B\3002'),
' */',
'let config = {};',
'if ( apex.item("P1_USE_GPU").getValue() !== ''Y'' ) {',
'    apex.item("P1_GPU").setValue("WebGPU is not used.");',
'}',
'else',
'{',
'    if ( ''gpu'' in navigator ) {',
'        config.device = "webgpu";',
'        apex.item("P1_GPU").setValue("WebGPU is available.");',
'    }',
'    else',
'    {',
'        apex.item("P1_GPU").setValue("WebGPU is not available");',
'    }',
'}',
'',
'/*',
unistr(' * Whisper\306E\30E2\30C7\30EB\3092\30ED\30FC\30C9\3059\308B\3002'),
unistr(' * whisper-small\306F\305D\3053\305D\3053\5927\304D\3044\306E\3067\6642\9593\306F\304B\304B\308B\3002'),
' * ',
unistr(' * \30E2\30C7\30EB\306Fonnx-comminity\4EE5\4E0B\3088\308A\9078\629E\3002'),
' * https://huggingface.co/models?pipeline_tag=automatic-speech-recognition&library=transformers.js',
' */',
'let model;',
'// whisper-small',
'model= ''onnx-community/whisper-small'';',
'config.dtype=''fp32'';',
'// whisper-large-v3-trubo',
'// model=''onnx-community/whisper-large-v3-turbo'';',
unistr('// config.dtype=''q4''; // fp16,q8,int8,uint8,q4,q4fp16,bnb4 \9078\629E\3067\304D\308B\6A21\69D8\3002'),
'apex.item("P1_STATUS").setValue("Loading Transcriber...");',
'transcriber = await pipeline(',
'    ''automatic-speech-recognition'', ',
'    model,',
'    config',
');',
'apex.item("P1_STATUS").setValue("Transcriber loaded");',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108761695827738482)
,p_plug_name=>'Transformers.js Whisper'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(108530659844735473)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(107436419942244444)
,p_button_sequence=>80
,p_button_name=>'TRANSCRIBE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(108637592661735866)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Transcribe'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107435937748244439)
,p_name=>'P1_STATUS'
,p_item_sequence=>30
,p_prompt=>'Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(108635068879735856)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107436096477244440)
,p_name=>'P1_AUDIO'
,p_item_sequence=>60
,p_prompt=>'Audio File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(108635068879735856)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107436165728244441)
,p_name=>'P1_OUTPUT'
,p_item_sequence=>90
,p_prompt=>'Output'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>10
,p_field_template=>wwv_flow_imp.id(108635068879735856)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107436900429244449)
,p_name=>'P1_GPU'
,p_item_sequence=>20
,p_prompt=>'GPU'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(108635068879735856)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107437056016244450)
,p_name=>'P1_ELAPSED_TIME'
,p_item_sequence=>40
,p_prompt=>'Elapsed Time (ms)'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>wwv_flow_imp.id(108635068879735856)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(108783192089459101)
,p_name=>'P1_USE_GPU'
,p_is_required=>true
,p_item_sequence=>50
,p_item_default=>'Y'
,p_prompt=>'Use GPU'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_field_template=>wwv_flow_imp.id(108635068879735856)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(107436795529244447)
,p_name=>'onClick TRANSCRIBE'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(107436419942244444)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107436860974244448)
,p_event_id=>wwv_flow_imp.id(107436795529244447)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * P1_AUDIO\3067\9078\629E\3057\305F\97F3\58F0\30D5\30A1\30A4\30EB\3092\30C6\30AD\30B9\30C8\306B\8D77\3053\3059\3002'),
' */',
'apex.item("P1_STATUS").setValue("Start transcribe...");',
'const audioFile = document.getElementById("P1_AUDIO").files[0];',
'const audioURL = URL.createObjectURL(audioFile);',
unistr('// \6587\5B57\8D77\3053\3057\306E\958B\59CB\3002\65E5\672C\8A9E\306F\6C7A\3081\6253\3061\3002'),
'const startTime = performance.now();',
'transcriber(audioURL, { language: "ja" } ).then( (output) => {',
'    apex.item("P1_STATUS").setValue("Transcribe done.");',
'    const endTime = performance.now();',
'    apex.item("P1_OUTPUT").setValue(output.text);',
'    apex.item("P1_ELAPSED_TIME").setValue((endTime - startTime));',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(108783208118459102)
,p_name=>'onChange USE_GPU'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_USE_GPU'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(108783383483459103)
,p_event_id=>wwv_flow_imp.id(108783208118459102)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(108783426747459104)
,p_name=>'onChange AUDIO'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_AUDIO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(108783555633459105)
,p_event_id=>wwv_flow_imp.id(108783426747459104)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_ELAPSED_TIME,P1_OUTPUT'
);
wwv_flow_imp.component_end;
end;
/
