prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>169
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Drawing lines'
,p_alias=>'DRAWING-LINES'
,p_step_title=>'Drawing lines'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'  {',
'    "imports": {',
'      "three": "https://cdn.jsdelivr.net/npm/three@0.168.0/build/three.module.js",',
'      "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.168.0/examples/jsm/"',
'    }',
'  }',
'</script>'))
,p_javascript_file_urls=>'[module, defer]#APP_FILES#drawingLines.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104964176301197619)
,p_plug_name=>'Drawing lines'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(56856252982840301)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>'<div id="container"></div>'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
