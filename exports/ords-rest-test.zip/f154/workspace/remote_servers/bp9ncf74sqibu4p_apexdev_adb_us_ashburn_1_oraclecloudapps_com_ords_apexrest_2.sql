prompt --workspace/remote_servers/bp9ncf74sqibu4p_apexdev_adb_us_ashburn_1_oraclecloudapps_com_ords_apexrest_2
begin
--   Manifest
--     REMOTE SERVER: bp9ncf74sqibu4p-apexdev-adb-us-ashburn-1-oraclecloudapps-com-ords-apexrest (2)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>154
,p_default_id_offset=>47267033025239801
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(94518340779073410)
,p_name=>'bp9ncf74sqibu4p-apexdev-adb-us-ashburn-1-oraclecloudapps-com-ords-apexrest (2)'
,p_static_id=>'bp9ncf74sqibu4p_apexdev_adb_us_ashburn_1_oraclecloudapps_com_ords_apexrest__2_'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('bp9ncf74sqibu4p_apexdev_adb_us_ashburn_1_oraclecloudapps_com_ords_apexrest__2_'),'https://bp9ncf74sqibu4p-apexdev.adb.us-ashburn-1.oraclecloudapps.com/ords/apexrest/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('bp9ncf74sqibu4p_apexdev_adb_us_ashburn_1_oraclecloudapps_com_ords_apexrest__2_'),'')
,p_server_type=>'AUTHENTICATION'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('bp9ncf74sqibu4p_apexdev_adb_us_ashburn_1_oraclecloudapps_com_ords_apexrest__2_'),'')
,p_credential_id=>wwv_flow_imp.id(94298417389918726)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('bp9ncf74sqibu4p_apexdev_adb_us_ashburn_1_oraclecloudapps_com_ords_apexrest__2_'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('bp9ncf74sqibu4p_apexdev_adb_us_ashburn_1_oraclecloudapps_com_ords_apexrest__2_'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
