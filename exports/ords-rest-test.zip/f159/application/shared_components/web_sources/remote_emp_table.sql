prompt --application/shared_components/web_sources/remote_emp_table
begin
--   Manifest
--     WEB SOURCE: Remote EMP Table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>159
,p_default_id_offset=>49826567923400963
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(193246128050567987)
,p_name=>'Remote EMP Table'
,p_static_id=>'Remote_EMP_Table'
,p_web_source_type=>'NATIVE_ORDS'
,p_data_profile_id=>wwv_flow_imp.id(193243205145567976)
,p_remote_server_id=>wwv_flow_imp.id(99646803774665155)
,p_url_path_prefix=>'/hr/employees/'
,p_auth_remote_server_id=>wwv_flow_imp.id(99647036885668752)
,p_auth_url_path_prefix=>'/oauth/token'
,p_credential_id=>wwv_flow_imp.id(193023050087413290)
,p_pass_ecid=>true
,p_attribute_01=>'N'
,p_version_scn=>41131481839781
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(193246355892567989)
,p_web_src_module_id=>wwv_flow_imp.id(193246128050567987)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
