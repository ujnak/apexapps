prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>159
,p_default_id_offset=>49826567923400963
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'ORDS REST Test'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(192675939199198976)
,p_plug_name=>'EMP'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(193089445341431745)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response blob;',
'    l_pretty clob;',
'    l_apex_path varchar2(400);',
'    l_pattern   varchar2(80);',
'begin',
unistr('    /* URL\306E\5148\982D\90E8\5206 */'),
'    l_apex_path := apex_util.host_url(''APEX_PATH'');',
unistr('    /* ORDS\30B9\30AD\30FC\30DE\30FB\30A8\30A4\30EA\30A2\30B9 */'),
'    select pattern into l_pattern from user_ords_schemas',
'    where parsing_schema = sys_context(''USERENV'',''CURRENT_USER'');',
unistr('    /* REST API\306E\547C\3073\51FA\3057 - p_token_url\3092\6307\5B9A\3059\308B\3002 */'),
'    apex_web_service.clear_request_headers;',
'    l_response := apex_web_service.make_rest_request_b(',
'        p_url => l_apex_path || l_pattern || ''/hr/employees/'' || :P1_EMPNO',
'        ,p_http_method => ''GET''',
'        ,p_credential_static_id => ''HR_EXAMPLE_CRED''',
'        ,p_token_url => l_apex_path || l_pattern || ''/oauth/token''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise_application_error(-20001, ''REST API Error'');',
'    end if;',
unistr('    /* JSON\306E\6574\5F62 */'),
'    select json_serialize(l_response returning clob pretty) into l_pretty from dual;',
'    l_pretty := replace(l_pretty,l_apex_path,''https://hide_url/ords/'');',
'    return l_pretty;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_EMPNO'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'EMP'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_header=>'<pre>'
,p_plug_footer=>'</pre>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(193239332601431916)
,p_plug_name=>'ORDS REST Test'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(193136565505431768)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(192675816894198975)
,p_button_sequence=>20
,p_button_name=>'FIND'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(193203329809431819)
,p_button_image_alt=>'Find'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(192675743851198974)
,p_name=>'P1_EMPNO'
,p_item_sequence=>10
,p_prompt=>'Empno'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(193200766435431814)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(192676075215198978)
,p_name=>'Refresh EMP'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(192675816894198975)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(192676220376198979)
,p_event_id=>wwv_flow_imp.id(192676075215198978)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(192675939199198976)
);
wwv_flow_imp.component_end;
end;
/
