prompt --workspace/credentials/hr_example_cred
begin
--   Manifest
--     CREDENTIAL: HR Example Cred
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>159
,p_default_id_offset=>49826567923400963
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(193023050087413290)
,p_name=>'HR Example Cred'
,p_static_id=>'HR_EXAMPLE_CRED'
,p_authentication_type=>'OAUTH2_CLIENT_CREDENTIALS'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
