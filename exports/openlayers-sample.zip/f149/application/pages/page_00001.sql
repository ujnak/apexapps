prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>149
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'OpenLayers'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/ol@v7.2.2/dist/ol.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * This code is based on the article wrtten by Lech Cie\015Blik, Pretius.'),
' * Drawing objects on maps in Oracle APEX - MapLibre vs OpenLayers',
' * https://pretius.com/blog/maplibre-vs-openlayers/',
' */',
'',
'//Create Raster Source',
'const sourceRaster = new ol.source.OSM();',
'//Create new layer - Open Street Maps',
'const raster = new ol.layer.Tile({',
'  source: sourceRaster',
'});',
'//Create Vector Source',
'const source = new ol.source.Vector({wrapX: false});',
'//Create new layer - Vector Source',
'const vector = new ol.layer.Vector ({',
'  source: source,',
'});',
'',
'/*',
unistr(' * \30DE\30C3\30D7\306B\66F8\304D\8FBC\307E\308C\305F\56F3\5F62\306E\30B8\30AA\30E1\30C8\30EA\3092\53D6\5F97\3059\308B\3002'),
' */',
'const GET_FEATURES = {',
'    name: "get-features",',
'    action: (event, element, args) => {',
'        let geojson = new ol.format.GeoJSON().writeFeatures(vector.getSource().getFeatures(), { ',
'            dataProjection: ''EPSG:4326'',',
'            featureProjection: ''EPSG:3857''',
'        });',
'        apex.items.P1_COORDINATE.setValue(geojson);',
'    }',
'};',
'',
'/*',
unistr(' * \30DA\30FC\30B8\306E\6E96\5099\304C\3067\304D\3066\304B\3089\5B9F\884C\3059\308B\3002'),
' */',
'apex.jQuery(window).on(''theme42ready'', () => {',
unistr('    // apex.actions\306B\30A2\30AF\30B7\30E7\30F3\3092\767B\9332\3059\308B\3002'),
'    apex.actions.add([GET_FEATURES]);',
'    ',
'    //Create map',
'    const map = new ol.Map({',
'        //set layer(s)',
'        layers: [raster, vector],',
'        //set container',
'        target: "map",',
'        //set view',
'        view: new ol.View({',
'            center: ol.proj.fromLonLat([12.48, 41.85]),',
'            zoom: 8 ',
'        })',
'    });',
'',
'    //Add Interaction (Draw object functionality)',
'    var draw = new ol.interaction.Draw({',
'        source: source,',
'        type: "Polygon", //you can use ''Point'' or ''LineString''',
'    });',
'    map.addInteraction(draw);',
'});'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/ol@v7.2.2/ol.css',
'',
''))
,p_inline_css=>'#map {height: 500px; width: 100%;}'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230213090337'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43038909517984850)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(46570791168443181)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<div id="map"></div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46679732607443269)
,p_plug_name=>'OpenLayers'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(46537767167443166)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46683750382464606)
,p_button_sequence=>10
,p_button_name=>'GET_FEATURES'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(46643644962443222)
,p_button_image_alt=>'Get Features'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$get-features"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46683651927464605)
,p_name=>'P1_COORDINATE'
,p_item_sequence=>20
,p_prompt=>'Coordinate'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(46641125041443220)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
