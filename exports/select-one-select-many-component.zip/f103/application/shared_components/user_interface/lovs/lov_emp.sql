prompt --application/shared_components/user_interface/lovs/lov_emp
begin
--   Manifest
--     LOV_EMP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(21989074254967133)
,p_lov_name=>'LOV_EMP'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    empno',
'  , ename',
'  , job',
'  , mgr',
'  , hiredate',
'  , sal',
'  , comm',
'  , deptno',
'  , dname',
'  , loc',
'  , case deptno',
'    when 10 then ''fa-table-user''',
'    when 20 then ''fa-database-user''',
'    when 30 then ''fa-calendar-user''',
'    when 40 then ''fa-folder-user''',
'    else ''fa-lock-user''',
'    end icon ',
'from emp_dept_v'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'EMPNO'
,p_display_column_name=>'ENAME'
,p_icon_column_name=>'ICON'
,p_group_column_name=>'JOB'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'ENAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41127003963794
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(22549531594703645)
,p_query_column_name=>'EMPNO'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(22552273350709697)
,p_query_column_name=>'DNAME'
,p_heading=>'Dname'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(22549996919703646)
,p_query_column_name=>'ENAME'
,p_heading=>'Ename'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(22552689704709698)
,p_query_column_name=>'LOC'
,p_heading=>'Loc'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(22550338541703647)
,p_query_column_name=>'JOB'
,p_heading=>'Job'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(22550791998703647)
,p_query_column_name=>'ICON'
,p_heading=>'Icon'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
