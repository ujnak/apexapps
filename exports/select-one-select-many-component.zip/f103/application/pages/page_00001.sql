prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\5024\3092\9078\629E\3059\308B\30B3\30F3\30DD\30FC\30CD\30F3\30C8')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19364999416069234)
,p_plug_name=>'Select One Items'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(21777048192570049)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19365363995069238)
,p_plug_name=>'Select Many Items'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(21777048192570049)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21974931930570624)
,p_plug_name=>unistr('\5024\3092\9078\629E\3059\308B\30B3\30F3\30DD\30FC\30CD\30F3\30C8')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(21743792597569982)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22554079518796602)
,p_plug_name=>unistr('\9078\629E\30EA\30B9\30C8\306E\6D88\53BB')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(21777048192570049)
,p_plug_display_sequence=>80
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22554338446796605)
,p_plug_name=>'Select List Single with X'
,p_region_name=>'select-list-single'
,p_parent_plug_id=>wwv_flow_imp.id(22554079518796602)
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--alignStretch:t-Form--noPadding'
,p_plug_template=>wwv_flow_imp.id(21769339999570033)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22554731309796609)
,p_plug_name=>'Select List Multi with X'
,p_region_name=>'select-list-multi'
,p_parent_plug_id=>wwv_flow_imp.id(22554079518796602)
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--alignStart:t-Form--noPadding'
,p_plug_template=>wwv_flow_imp.id(21769339999570033)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19366125013069246)
,p_button_sequence=>50
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(21850658241570213)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22554456428796606)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(22554338446796605)
,p_button_name=>'CLEAR_EMPNO_SLX'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_imp.id(21849970102570211)
,p_button_image_alt=>'Clear Empno Slx'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-remove'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22554847845796610)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(22554731309796609)
,p_button_name=>'CLEAR_EMPNO_SL2X'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_imp.id(21849970102570211)
,p_button_image_alt=>'Clear Empno Sl2x'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-remove'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19365041784069235)
,p_name=>'P1_EMPNO_SL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19364999416069234)
,p_prompt=>'Employee'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_EMP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    empno',
'  , ename',
'  , job',
'  , mgr',
'  , hiredate',
'  , sal',
'  , comm',
'  , deptno',
'  , dname',
'  , loc',
'  , case deptno',
'    when 10 then ''fa-table-user''',
'    when 20 then ''fa-database-user''',
'    when 30 then ''fa-calendar-user''',
'    when 40 then ''fa-folder-user''',
'    else ''fa-lock-user''',
'    end icon ',
'from emp_dept_v'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Employee -'
,p_cHeight=>1
,p_tag_css_classes=>'changeme'
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19365115003069236)
,p_name=>'P1_EMPNO_PL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(19364999416069234)
,p_prompt=>'Employee'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_EMP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    empno',
'  , ename',
'  , job',
'  , mgr',
'  , hiredate',
'  , sal',
'  , comm',
'  , deptno',
'  , dname',
'  , loc',
'  , case deptno',
'    when 10 then ''fa-table-user''',
'    when 20 then ''fa-database-user''',
'    when 30 then ''fa-calendar-user''',
'    when 40 then ''fa-folder-user''',
'    else ''fa-lock-user''',
'    end icon ',
'from emp_dept_v'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Employee -'
,p_cSize=>30
,p_tag_css_classes=>'changeme'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_09=>'400'
,p_attribute_10=>'JOB:P1_JOB'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19365298949069237)
,p_name=>'P1_EMPNO_SO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(19364999416069234)
,p_prompt=>'Employee'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_named_lov=>'LOV_EMP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    empno',
'  , ename',
'  , job',
'  , mgr',
'  , hiredate',
'  , sal',
'  , comm',
'  , deptno',
'  , dname',
'  , loc',
'  , case deptno',
'    when 10 then ''fa-table-user''',
'    when 20 then ''fa-database-user''',
'    when 30 then ''fa-calendar-user''',
'    when 40 then ''fa-folder-user''',
'    else ''fa-lock-user''',
'    end icon ',
'from emp_dept_v'))
,p_cSize=>30
,p_tag_css_classes=>'changeme'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="cc-container">',
'    <span class="cc-item">&ENAME.</span>',
'    <span class="cc-item">- &DNAME.</span>',
'    <span class="cc-item">- &LOC.</span>',
'</div>'))
,p_attribute_04=>'Y'
,p_attribute_05=>'5'
,p_attribute_09=>'0'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19365463504069239)
,p_name=>'P1_EMPNO_SL2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19365363995069238)
,p_prompt=>'Employees'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_EMP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    empno',
'  , ename',
'  , job',
'  , mgr',
'  , hiredate',
'  , sal',
'  , comm',
'  , deptno',
'  , dname',
'  , loc',
'  , case deptno',
'    when 10 then ''fa-table-user''',
'    when 20 then ''fa-database-user''',
'    when 30 then ''fa-calendar-user''',
'    when 40 then ''fa-folder-user''',
'    else ''fa-lock-user''',
'    end icon ',
'from emp_dept_v'))
,p_lov_display_null=>'YES'
,p_cHeight=>10
,p_tag_css_classes=>'changeme'
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_multi_value_type=>'JSON_ARRAY'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19365508965069240)
,p_name=>'P1_EMPNO_PL2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(19365363995069238)
,p_prompt=>'Employees'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_EMP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    empno',
'  , ename',
'  , job',
'  , mgr',
'  , hiredate',
'  , sal',
'  , comm',
'  , deptno',
'  , dname',
'  , loc',
'  , case deptno',
'    when 10 then ''fa-table-user''',
'    when 20 then ''fa-database-user''',
'    when 30 then ''fa-calendar-user''',
'    when 40 then ''fa-folder-user''',
'    else ''fa-lock-user''',
'    end icon ',
'from emp_dept_v'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Employee -'
,p_cSize=>30
,p_tag_css_classes=>'changeme'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_09=>'400'
,p_multi_value_type=>'JSON_ARRAY'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19365621211069241)
,p_name=>'P1_EMPNO_SM'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(19365363995069238)
,p_prompt=>'Employees'
,p_display_as=>'NATIVE_SELECT_MANY'
,p_named_lov=>'LOV_EMP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    empno',
'  , ename',
'  , job',
'  , mgr',
'  , hiredate',
'  , sal',
'  , comm',
'  , deptno',
'  , dname',
'  , loc',
'  , case deptno',
'    when 10 then ''fa-table-user''',
'    when 20 then ''fa-database-user''',
'    when 30 then ''fa-calendar-user''',
'    when 40 then ''fa-folder-user''',
'    else ''fa-lock-user''',
'    end icon ',
'from emp_dept_v'))
,p_cSize=>30
,p_tag_css_classes=>'changeme'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="cc-container">',
'    <span class="cc-item">&ENAME.</span>',
'    <span class="cc-item">- &DNAME.</span>',
'    <span class="cc-item">- &LOC.</span>',
'</div>'))
,p_attribute_04=>'N'
,p_attribute_05=>'10'
,p_attribute_09=>'0'
,p_attribute_13=>'N'
,p_attribute_14=>'separated'
,p_multi_value_type=>'JSON_ARRAY'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19365864893069243)
,p_name=>'P1_VALUE'
,p_item_sequence=>30
,p_prompt=>'Actual Value'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19366217015069247)
,p_name=>'P1_SUBMITTED_VALUES'
,p_item_sequence=>70
,p_prompt=>'Submitted Values'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19366455838069249)
,p_name=>'P1_JOB'
,p_item_sequence=>40
,p_prompt=>'JOB'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22554181003796603)
,p_name=>'P1_EMPNO_SLX'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(22554338446796605)
,p_prompt=>'Emoloyee'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_EMP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    empno',
'  , ename',
'  , job',
'  , mgr',
'  , hiredate',
'  , sal',
'  , comm',
'  , deptno',
'  , dname',
'  , loc',
'  , case deptno',
'    when 10 then ''fa-table-user''',
'    when 20 then ''fa-database-user''',
'    when 30 then ''fa-calendar-user''',
'    when 40 then ''fa-folder-user''',
'    else ''fa-lock-user''',
'    end icon ',
'from emp_dept_v'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_css_classes=>'changeme'
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22554268721796604)
,p_name=>'P1_EMPNO_SL2X'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(22554731309796609)
,p_prompt=>'Employees'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_EMP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    empno',
'  , ename',
'  , job',
'  , mgr',
'  , hiredate',
'  , sal',
'  , comm',
'  , deptno',
'  , dname',
'  , loc',
'  , case deptno',
'    when 10 then ''fa-table-user''',
'    when 20 then ''fa-database-user''',
'    when 30 then ''fa-calendar-user''',
'    when 40 then ''fa-folder-user''',
'    else ''fa-lock-user''',
'    end icon ',
'from emp_dept_v'))
,p_cHeight=>5
,p_tag_css_classes=>'changeme'
,p_field_template=>wwv_flow_imp.id(21848177143570207)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_multi_value_type=>'JSON_ARRAY'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19365980807069244)
,p_name=>'onChange changeme'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.changeme'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19366089039069245)
,p_event_id=>wwv_flow_imp.id(19365980807069244)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_VALUE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$v(this.triggeringElement)'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22554540098796607)
,p_name=>'onClick ERASE P1_EMPNO_SLX'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(22554456428796606)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22554688368796608)
,p_event_id=>wwv_flow_imp.id(22554540098796607)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_EMPNO_SLX'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22554944345796611)
,p_name=>'onClick CLEAR P1_EMPNO_SL2X'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(22554847845796610)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22555021469796612)
,p_event_id=>wwv_flow_imp.id(22554944345796611)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_EMPNO_SL2X'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19366393706069248)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Print'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response varchar2(4000);',
'begin',
'    l_response := '''';',
'    l_response := l_response || ''P1_EMPNO_SL = '' || :P1_EMPNO_SL || apex_application.CRLF;',
'    l_response := l_response || ''P1_EMPNO_PL = '' || :P1_EMPNO_PL || apex_application.CRLF;',
'    l_response := l_response || ''P1_EMPNO_SO = '' || :P1_EMPNO_SO || apex_application.CRLF;',
'    l_response := l_response || ''P1_EMPNO_SL2 = '' || :P1_EMPNO_SL2 || apex_application.CRLF;',
'    l_response := l_response || ''P1_EMPNO_PL2 = '' || :P1_EMPNO_PL2 || apex_application.CRLF;',
'    l_response := l_response || ''P1_EMPNO_SM = '' || :P1_EMPNO_SM || apex_application.CRLF;',
'    :P1_SUBMITTED_VALUES := l_response;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(19366125013069246)
,p_internal_uid=>19366393706069248
);
wwv_flow_imp.component_end;
end;
/
