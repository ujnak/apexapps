prompt --workspace/remote_servers/api_data_metro_tokyo_lg_jp
begin
--   Manifest
--     REMOTE SERVER: api-data-metro-tokyo-lg-jp
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>19860757903336071
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'WKSP_TOKYO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(21098324857898460)
,p_name=>'api-data-metro-tokyo-lg-jp'
,p_static_id=>'api_data_metro_tokyo_lg_jp'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('api_data_metro_tokyo_lg_jp'),'https://api.data.metro.tokyo.lg.jp/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('api_data_metro_tokyo_lg_jp'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('api_data_metro_tokyo_lg_jp'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('api_data_metro_tokyo_lg_jp'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('api_data_metro_tokyo_lg_jp'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('api_data_metro_tokyo_lg_jp'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('api_data_metro_tokyo_lg_jp'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('api_data_metro_tokyo_lg_jp'),'')
);
wwv_flow_imp.component_end;
end;
/
