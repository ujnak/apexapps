prompt --application/shared_components/web_sources/tokyo_cultural_properties
begin
--   Manifest
--     WEB SOURCE: Tokyo Cultural Properties
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>19860757903336071
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'WKSP_TOKYO'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(21109409327898466)
,p_name=>'Tokyo Cultural Properties'
,p_static_id=>'tokyo_cultural_properties'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(21098515405898461)
,p_remote_server_id=>wwv_flow_imp.id(21098324857898460)
,p_url_path_prefix=>'/v1/CulturalProperty'
,p_sync_table_name=>'EBAJ_TOKYO_CULTURAL_PROPERTIES'
,p_sync_type=>'APPEND'
,p_sync_max_http_requests=>1000
,p_attribute_01=>'PAGE_TOKEN_FLEXIBLE_SIZE'
,p_attribute_02=>'limit'
,p_attribute_03=>'100'
,p_attribute_13=>'cursor'
,p_attribute_14=>'[1].endCursor'
,p_version_scn=>6212357
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(21109684017898470)
,p_web_src_module_id=>wwv_flow_imp.id(21109409327898466)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
