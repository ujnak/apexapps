prompt --workspace/credentials/openai_api_key
begin
--   Manifest
--     CREDENTIAL: OpenAI API Key
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>218
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(112588866028413389)
,p_name=>'OpenAI API Key'
,p_static_id=>'OPENAI_API_KEY'
,p_authentication_type=>'HTTP_HEADER'
,p_valid_for_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://api.openai.com/',
''))
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
