prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>218
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Batches'
,p_alias=>'BATCHES'
,p_step_title=>'Batches'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(115712404709715429)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(115434624235007385)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(115318996460007141)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(115497426899007532)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(115713187525715432)
,p_plug_name=>'Batches'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(115412421538007338)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SUBMISSION_ID,',
'       INPUT_FILE_ID,',
'       ENDPOINT,',
'       COMPLETION_WINDOW,',
'       dbms_lob.getlength(REQUEST_FILE) request_file,',
'       BATCH_OBJECT,',
'       BATCH_ID,',
'       OUTPUT_FILE_ID,',
'       STATUS,',
'       dbms_lob.getlength(RESPONSE_FILE) response_file,',
'       ERROR_FILE_ID,',
'       dbms_lob.getlength(ERROR_FILE) error_file',
'  from OPENAI_BATCH_SUBMISSIONS'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Batches'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(115713262252715432)
,p_name=>'Batches'
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>115713262252715432
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115713841056715618)
,p_db_column_name=>'SUBMISSION_ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Submission ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115714209430715620)
,p_db_column_name=>'INPUT_FILE_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Input File ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115714667266715621)
,p_db_column_name=>'ENDPOINT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Endpoint'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115715029936715622)
,p_db_column_name=>'COMPLETION_WINDOW'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Completion Window'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115715819456715625)
,p_db_column_name=>'BATCH_OBJECT'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Batch Object'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115716232000715626)
,p_db_column_name=>'BATCH_ID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Batch ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115716665007715627)
,p_db_column_name=>'OUTPUT_FILE_ID'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Output File ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115717068829715628)
,p_db_column_name=>'STATUS'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(116043952334873125)
,p_db_column_name=>'ERROR_FILE_ID'
,p_display_order=>39
,p_column_identifier=>'M'
,p_column_label=>'Error File Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(116044152040873127)
,p_db_column_name=>'REQUEST_FILE'
,p_display_order=>49
,p_column_identifier=>'O'
,p_column_label=>'Request File'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:OPENAI_BATCH_SUBMISSIONS:REQUEST_FILE:SUBMISSION_ID::::::attachment::'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(116044276259873128)
,p_db_column_name=>'RESPONSE_FILE'
,p_display_order=>59
,p_column_identifier=>'P'
,p_column_label=>'Response File'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:OPENAI_BATCH_SUBMISSIONS:RESPONSE_FILE:SUBMISSION_ID::::::attachment::'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(116044301234873129)
,p_db_column_name=>'ERROR_FILE'
,p_display_order=>69
,p_column_identifier=>'Q'
,p_column_label=>'Error File'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:OPENAI_BATCH_SUBMISSIONS:ERROR_FILE:SUBMISSION_ID::::::attachment::'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(115717895690716314)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1157179'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SUBMISSION_ID:INPUT_FILE_ID:ENDPOINT:COMPLETION_WINDOW:BATCH_OBJECT:BATCH_ID:OUTPUT_FILE_ID:STATUS:ERROR_FILE:ERROR_FILE_ID:REQUEST_FILE:RESPONSE_FILE:'
);
wwv_flow_imp.component_end;
end;
/
