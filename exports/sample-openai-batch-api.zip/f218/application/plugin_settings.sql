prompt --application/plugin_settings
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>218
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115314474725007128)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'include_slider', 'Y')).to_clob
,p_version_scn=>41795265133017
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115314742173007131)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SELECT_MANY'
,p_attribute_01=>'separated'
,p_version_scn=>41795265133081
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115315013517007132)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_MAP_REGION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_vector_tile_layers', 'Y')).to_clob
,p_version_scn=>41795265133107
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115315339277007132)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attribute_01=>'Y'
,p_attribute_03=>'N'
,p_attribute_05=>'SWITCH_CB'
,p_version_scn=>41795265133142
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115315698619007133)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'actions_menu_structure', 'IG')).to_clob
,p_version_scn=>41795265133173
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115315927327007134)
,p_plugin_type=>'DYNAMIC ACTION'
,p_plugin=>'NATIVE_OPEN_AI_ASSISTANT'
,p_version_scn=>41795265133197
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115316289071007135)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attribute_01=>'fa-star'
,p_attribute_04=>'#VALUE#'
,p_version_scn=>41795265133233
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115316588895007135)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_GEOCODED_ADDRESS'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_attribute_02=>'N'
,p_attribute_03=>'POPUP:ITEM'
,p_attribute_04=>'default'
,p_attribute_06=>'LIST'
,p_version_scn=>41795265133260
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115316806692007136)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_ADFBC'
,p_version_scn=>41795265133282
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115317136801007137)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attribute_01=>'FULL'
,p_attribute_02=>'POPUP'
,p_version_scn=>41795265133292
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115317451187007137)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_APEX'
,p_attribute_01=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_02=>'VISIBLE'
,p_attribute_03=>'15'
,p_attribute_04=>'FOCUS'
,p_version_scn=>41795265133292
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115317702553007138)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_version_scn=>41795265133292
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(115318016604007139)
,p_plugin_type=>'PROCESS TYPE'
,p_plugin=>'NATIVE_GEOCODING'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_version_scn=>41795265133292
);
wwv_flow_imp.component_end;
end;
/
