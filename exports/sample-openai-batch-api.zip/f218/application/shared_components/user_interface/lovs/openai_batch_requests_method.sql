prompt --application/shared_components/user_interface/lovs/openai_batch_requests_method
begin
--   Manifest
--     OPENAI_BATCH_REQUESTS.METHOD
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>218
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(116429409015233507)
,p_lov_name=>'OPENAI_BATCH_REQUESTS.METHOD'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'OPENAI_BATCH_REQUESTS'
,p_return_column_name=>'CUSTOM_ID'
,p_display_column_name=>'METHOD'
,p_default_sort_column_name=>'METHOD'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41795458556684
);
wwv_flow_imp.component_end;
end;
/
