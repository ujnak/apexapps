prompt --application/shared_components/web_sources/list_batch
begin
--   Manifest
--     WEB SOURCE: List batch
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>218
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(116475132257482751)
,p_name=>'List batch'
,p_static_id=>'list_batch'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(116468349909482724)
,p_remote_server_id=>wwv_flow_imp.id(242871567290514291)
,p_url_path_prefix=>'v1/batches'
,p_credential_id=>wwv_flow_imp.id(112588866028413389)
,p_version_scn=>41795474196415
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(116475381043482755)
,p_web_src_module_id=>wwv_flow_imp.id(116475132257482751)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
