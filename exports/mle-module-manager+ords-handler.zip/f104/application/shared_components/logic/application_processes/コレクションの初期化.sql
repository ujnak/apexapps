prompt --application/shared_components/logic/application_processes/コレクションの初期化
begin
--   Manifest
--     APPLICATION PROCESS: コレクションの初期化
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>104
,p_default_id_offset=>10435508148729379
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(34118241861640166)
,p_process_sequence=>1
,p_process_point=>'AFTER_LOGIN'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\30B3\30EC\30AF\30B7\30E7\30F3\306E\521D\671F\5316')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_collection.create_or_truncate_collection(''MLE_MODULES'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>41103067993814
);
wwv_flow_imp.component_end;
end;
/
