prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>143
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'APEX Google Drive'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230607060551'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43034416746984805)
,p_plug_name=>'Google API Response'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(43151789641740326)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response blob;',
'    l_response_pretty clob;',
'begin',
'    if :P1_GOOGLE_API is not null then',
'        l_response := apex_web_service.make_rest_request_b(',
'            p_url => :P1_GOOGLE_API',
'            ,p_http_method => ''GET''',
'            ,p_credential_static_id => ''GOOGLE_DRIVE_CRED''',
'        );',
'        select json_serialize(l_response returning clob pretty) into l_response_pretty from dual;',
'    end if;',
'    return ''<pre><code>'' || l_response_pretty || ''</code></pre>'';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_GOOGLE_API'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43260745608740401)
,p_plug_name=>'APEX Google Drive'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(43118792499740309)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43034361373984804)
,p_button_sequence=>20
,p_button_name=>'SUBMIT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(43224691839740363)
,p_button_image_alt=>'Submit'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91347390562248849)
,p_button_sequence=>40
,p_button_name=>'REFRESH_TOKEN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(43224691839740363)
,p_button_image_alt=>'Refresh Token'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43034249998984803)
,p_name=>'P1_GOOGLE_API'
,p_item_sequence=>10
,p_prompt=>'Google API'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(43222105283740361)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43034521286984806)
,p_name=>'Click Submit'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(43034361373984804)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43034602596984807)
,p_event_id=>wwv_flow_imp.id(43034521286984806)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Call Google API'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43034416746984805)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91347454316248850)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Refresh Token'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_refresh_token varchar2(4000) := :G_REFRESH_TOKEN;',
'    l_response clob;',
'    l_response_json json_object_t;',
'    l_access_token varchar2(4000);',
'    l_expires_in_sec number;',
'    C_CRED_OAUTH2 constant varchar2(20) := ''GOOGLE_DRIVE_CRED'';',
'    C_CRED_BASIC  constant varchar2(20) := ''GOOGLE_OIDC_BASIC'';',
'begin',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Content-Type'',''application/x-www-form-urlencoded'',p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => ''https://oauth2.googleapis.com/token''',
'        ,p_http_method => ''POST''',
'        ,p_body => ''grant_type=refresh_token'' || chr(38) || ''refresh_token='' || l_refresh_token',
'        ,p_credential_static_id => C_CRED_BASIC',
'    );',
'    l_response_json  := json_object_t.parse(l_response);',
unistr('    /* \30A2\30AF\30BB\30B9\30FB\30C8\30FC\30AF\30F3\306E\30A2\30C3\30D7\30C7\30FC\30C8 */'),
'    l_access_token   := l_response_json.get_string(''access_token'');',
'    l_expires_in_sec := l_response_json.get_number(''expires_in'');',
'    if l_access_token is not null then',
'        apex_credential.set_session_token(',
'            p_credential_static_id => C_CRED_OAUTH2',
'            ,p_token_type          => APEX_CREDENTIAL.C_TOKEN_ACCESS',
'            ,p_token_value         => l_access_token',
'            ,p_token_expires       => (sysdate + l_expires_in_sec/86400)',
'        );',
'        apex_debug.info(''Access Token is updated by %s'', substr(l_access_token, 1,20));',
'    else',
'        apex_debug.info(''Access Token is not updated.'');',
'    end if;',
'    /*',
unistr('     * Google\306E\5834\5408\3001\30EA\30D5\30EC\30C3\30B7\30E5\30FB\30C8\30FC\30AF\30F3\306B\6709\52B9\671F\9650\304C\306A\304F\3001\30A2\30AF\30BB\30B9\30FB\30C8\30FC\30AF\30F3\306E\30EA\30D5\30EC\30C3\30B7\30E5\6642\306B'),
unistr('     * \518D\767A\884C\3082\3055\308C\306A\3044\6A21\69D8\3002'),
'     */',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91347390562248849)
,p_internal_uid=>91347454316248850
);
wwv_flow_imp.component_end;
end;
/
