prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7614450350901070
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000CC49444154584763D4DBBFE73FC30002C651078C86C068088C86C0A00F01A13F7F18F8FEFC41292B6F7FFDCAC02A2C4C95F293';
wwv_flow_imp.g_varchar2_table(2) := '6049A8F0E3078391822286657B6EDD62F8C0C2C2C0C4C5499143C87600C8D6CBAF5E32FCFEF60DA703EEFDFB4FD081643BE0D5A74F0C72ECEC787D7FFED93386EB9C1C78D5107480E6F71F0C8652521886C4ABAA110CFA85B76F312C7BFF8E320744090A';
wwv_flow_imp.g_varchar2_table(3) := '31106319365B461D301A02C323047EBF7DCB10AFA24A30CB61CD05776E132CB209960364D94C82A651078C86C068088C86C0808700000EADA8213EF79B2E0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(8284980203961749)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
