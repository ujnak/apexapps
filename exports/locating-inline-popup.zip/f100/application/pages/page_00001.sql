prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7614450350901070
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'EMP'
,p_alias=>'HOME'
,p_step_title=>'Locating Inline Popup'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add(',
'    [',
'        {',
'            /*',
'             * Ref:',
'             * Oracle APEX anchored inline popups for data input, Philipp Hartenfeller',
'             * https://hartenfeller.dev/blog/apex-anchored-inline-popups',
'             */',
'            name: "open-update-salary",',
'            action: (event, element, args) => {',
'                //',
'                apex.items.P1_EMPNO.setValue(args.empno);',
'                apex.items.P1_SAL.setValue(args.sal);',
'                apex.items.P1_SAL_OLD.setValue(args.sal);',
'                const $popupAnchor = $(`#EMP-SAL-${args.empno}`);',
'                let popup = $(''#UPDATE_SALARY'').data(''apexPopup'');',
'                popup.positionTo$ = $popupAnchor;',
'                popup.options.parentElement = `#EMP-SAL-${args.empno}`;',
'                popup.options.position.of =  $popupAnchor;',
'                popup.options.minHeight = null;',
'                // console.log(popup);',
'                /*',
unistr('                 * setTimeout\306E\547C\3073\51FA\3057\304C\5FC5\8981\304B\3069\3046\304B\4E0D\660E\3002'),
unistr('                 * apex.theme.openRegion\3067\306F\306A\304Fpopup.open\3067\3042\308C\3070'),
unistr('                 * \5F85\305F\306A\304F\3066\3082\3088\3044\3088\3046\306B\601D\3046\3002'),
'                 */',
'                popup.open();',
'            }',
'        },',
'        {',
'            /*',
unistr('             * callout\3092\8868\793A\3057\306A\3051\308C\3070\3001parentElement\306B\95A2\3059\308B\6307\5B9A\304C\7DE9\304F\306A\308A\7C21\5358\3002 '),
'             */',
'            name: "open-update-salary-nocallout",',
'            action: (event, element, args) => {',
'                apex.items.P1_EMPNO.setValue(args.empno);',
'                apex.items.P1_SAL.setValue(args.sal);',
'                apex.items.P1_SAL_OLD.setValue(args.sal);',
'                let popup = $(''#UPDATE_SALARY'').data(''apexPopup'');',
'                popup.options.position = { my: "left top", at: "left bottom", of: `#EMP-SAL-${args.empno}`};',
'                popup.options.minHeight = null;',
'                popup.options.minWidth  = null;',
'                popup.options.height = 140;',
'                popup.options.width  = 300;',
'                // console.log(popup);',
'                popup.open();',
'            }',
'        }',
'    ]',
');'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>\30C7\30FC\30BF\3092\898B\3064\3051\308B\306B\306F\3001\691C\7D22\30C0\30A4\30A2\30ED\30B0\306B\691C\7D22\6587\5B57\5217\3092\5165\529B\3059\308B\304B\3001\5217\30D8\30C3\30C0\30FC\3092\30AF\30EA\30C3\30AF\3057\3066\623B\3055\308C\308B\30EC\30B3\30FC\30C9\3092\5236\9650\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30A2\30AF\30B7\30E7\30F3\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\591A\304F\306E\6A5F\80FD\3092\5B9F\884C\3067\304D\307E\3059\3002\3053\308C\306B\306F\3001\8868\793A\5217\307E\305F\306F\975E\8868\793A\5217\306E\9078\629E\3068\305D\306E\8868\793A\9806\5E8F\306B\52A0\3048\3001\591A\304F\306E\30C7\30FC\30BF\304A\3088\3073\66F8\5F0F\8A2D\5B9A\6A5F\80FD\304C\542B\307E\308C\307E\3059\3002\30C1\30E3\30FC\30C8\3001\30B0\30EB\30FC\30D7\5316\304A\3088\3073\30D4\30DC\30C3\30C8\30FB\30AA\30D7\30B7\30E7\30F3\3092\4F7F\7528\3057\3066\3001\30C7\30FC\30BF\306E\8FFD\52A0\30D3\30E5\30FC\3092\5B9A\7FA9\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\72EC\81EA\306E\30AB\30B9\30BF\30DE\30A4\30BA\5185\5BB9\3092\4FDD\5B58\3059\308B\5834\5408\3001\30EC\30DD\30FC\30C8\3092\9078\629E\3059\308B\304B\3001\300C\30C0\30A6\30F3\30ED\30FC\30C9\300D\3092\30AF\30EA\30C3\30AF\3057\3066\30C7\30FC\30BF\3092\30A2\30F3\30ED\30FC\30C9\3057\307E\3059\3002\5B9A\671F\7684\306B\30C7\30FC\30BF\3092\9001\4FE1\3059\308B\30B5\30D6\30B9\30AF\30EA\30D7\30B7\30E7\30F3\3067\96FB\5B50\30E1\30FC\30EB\30FB\30A2\30C9\30EC\30B9\3068\6642\9593\67A0\3092\5165\529B\3057\307E\3059\3002<p>'),
'',
unistr('<p>\8FFD\52A0\60C5\5831\3092\5165\624B\3059\308B\306B\306F\3001\300C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\306E\4E00\756A\4E0B\306E\300C\30D8\30EB\30D7\300D\3092\30AF\30EA\30C3\30AF\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30EA\30BB\30C3\30C8\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\5BFE\8A71\30E2\30FC\30C9\30FB\30EC\30DD\30FC\30C8\3092\30C7\30D5\30A9\30EB\30C8\8A2D\5B9A\306B\623B\3059\3053\3068\304C\3067\304D\307E\3059\3002</p>')))
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8295925381961783)
,p_plug_name=>'Employees'
,p_region_name=>'EMP'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8087723303961188)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'EMP'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'EMP'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(8296081846961783)
,p_name=>'EMP'
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>8296081846961783
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8297265215961915)
,p_db_column_name=>'EMPNO'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Empno'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8297656639961916)
,p_db_column_name=>'ENAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Employee Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8298031948961917)
,p_db_column_name=>'JOB'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Job'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8298496461961918)
,p_db_column_name=>'MGR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Manager'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_named_lov=>wwv_flow_imp.id(8296158901961911)
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8298833097961920)
,p_db_column_name=>'HIREDATE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Hired'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8299291282961921)
,p_db_column_name=>'SAL'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Salary'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button type="button" class="t-Button t-Button--link"',
'    id="EMP-SAL-#EMPNO#"',
'    data-action="open-update-salary?empno=#EMPNO#&sal=#SAL#">',
'    <span class="t-Button-label">#SAL#</span>',
'</button>'))
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8299692723961922)
,p_db_column_name=>'COMM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Commission'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8300081573961923)
,p_db_column_name=>'DEPTNO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Deptno'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_named_lov=>wwv_flow_imp.id(8296300020961912)
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8302228583961932)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'83023'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ENAME:JOB:MGR:HIREDATE:SAL:COMM:DEPTNO'
,p_sort_column_1=>'ENAME'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8301399513961928)
,p_plug_name=>'Locating Inline Popup'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(8064273719961138)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17840890291699636)
,p_plug_name=>'Update Salary'
,p_region_name=>'UPDATE_SALARY'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-nosize'
,p_region_attributes=>'data-parent-element="#EMP"'
,p_plug_template=>wwv_flow_imp.id(8082349269961176)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17841095544699638)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17840890291699636)
,p_button_name=>'UPDATE_SALARY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(8171198706961373)
,p_button_image_alt=>'Update'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8300423726961924)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8295925381961783)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8171251146961374)
,p_button_image_alt=>unistr('\30EA\30BB\30C3\30C8')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8326379230469408)
,p_name=>'P1_ERROR'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17840902810699637)
,p_name=>'P1_SAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(17840890291699636)
,p_prompt=>'Salary'
,p_format_mask=>'999G999G999G999G999G999G999G999G999G990'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(8168693685961367)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17841107800699639)
,p_name=>'P1_SAL_OLD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(17840890291699636)
,p_format_mask=>'999G999G999G999G999G999G999G999G999G990'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17841933375699647)
,p_name=>'P1_EMPNO'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8325927795469404)
,p_name=>'Update Salary'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(17841095544699638)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8326087616469405)
,p_event_id=>wwv_flow_imp.id(8325927795469404)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_empno emp.empno%type;',
'    e_sal_was_changed exception;',
'    l_sal_current emp.sal%type;',
'    l_sal_old     emp.sal%type;',
'    l_sal         emp.sal%type;',
'begin',
'    :P1_ERROR := '''';',
'    begin',
'        select empno, sal into l_empno, l_sal_current from emp where empno = :P1_EMPNO for update nowait;',
'    exception',
'        when others then',
unistr('            /* \307B\307C ORA-00054 resource busy */'),
unistr('            :P1_ERROR := ''\884C\304C\66F4\65B0\4E2D\3067\3059\3002'';'),
'            return;',
'    end;',
'    /*',
unistr('     * \5909\66F4\524D\306E\5024\304Cl_sal_old\3001\5909\66F4\5F8C\306E\5024\304Cl_sal\3002'),
'     */',
'    l_sal_old := to_number(:P1_SAL_OLD,''999G999G999G999G999G999G999G999G999G990'');',
'    l_sal     := to_number(:P1_SAL,''999G999G999G999G999G999G999G999G999G990'');',
'    if l_sal_current = l_sal then',
'        /*',
unistr('         * \73FE\5728\306E\7D66\4E0E\3068\5909\66F4\3057\3088\3046\3068\3057\3066\308B\7D66\4E0E\304C\540C\3058\3002 '),
'         */',
'        null;',
'    elsif l_sal_current <> l_sal_old then',
'        /*',
unistr('         * \4ED6\306E\30BB\30C3\30B7\30E7\30F3\306B\3088\308A\66F4\65B0\6E08\307F\3002'),
'         */',
unistr('        :P1_ERROR := ''\4ED6\306E\30BB\30C3\30B7\30E7\30F3\3067\66F4\65B0\3055\308C\3066\3044\307E\3059\3002'';'),
'    else',
'        /*',
unistr('         * \7D66\4E0E\3092\66F4\65B0\3059\308B\3002'),
'         */',
'        update emp set sal = l_sal where empno = l_empno;',
'        commit;',
'    end if;',
'    rollback;',
'    return;',
'end;'))
,p_attribute_02=>'P1_EMPNO,P1_SAL_OLD,P1_SAL'
,p_attribute_03=>'P1_ERROR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8326424439469409)
,p_event_id=>wwv_flow_imp.id(8325927795469404)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>unistr('\30A8\30E9\30FC\306E\8868\793A')
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.message.clearErrors();',
'apex.message.showErrors( [',
'    {',
'        type:       "error",',
'        location:   "page",',
'        message:    apex.items.P1_ERROR.value,',
'        unsafe:     false',
'    }',
'] );'))
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P1_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8326179037469406)
,p_event_id=>wwv_flow_imp.id(8325927795469404)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(17840890291699636)
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P1_ERROR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8326201404469407)
,p_event_id=>wwv_flow_imp.id(8325927795469404)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8295925381961783)
);
wwv_flow_imp.component_end;
end;
/
