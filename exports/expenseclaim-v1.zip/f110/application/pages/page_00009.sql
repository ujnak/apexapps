prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>110
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>unistr('\9032\6357\306E\8868\793A')
,p_alias=>unistr('\9032\6357\306E\8868\793A')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\9032\6357\306E\8868\793A')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'550'
,p_dialog_width=>'900'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221221014414'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25847143330972109)
,p_plug_name=>unistr('\9032\6357\306E\8868\793A')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(25539076526852027)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'TABLE'
,p_query_table=>'FLOW_INSTANCE_DETAILS_VW'
,p_query_where=>'dgrm_name = :APP_NAME and prcs_id = :P9_PRCS_ID'
,p_include_rowid_column=>false
,p_plug_source_type=>'PLUGIN_COM.FLOWS4APEX.VIEWER.REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'DGRM_CONTENT'
,p_attribute_02=>'ALL_CURRENT'
,p_attribute_03=>'PRDG_ID'
,p_attribute_04=>'ALL_COMPLETED'
,p_attribute_06=>'ALL_ERRORS'
,p_attribute_08=>'Y'
,p_attribute_09=>'Y'
,p_attribute_11=>'N'
,p_attribute_14=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25847277360972110)
,p_name=>'P9_PRCS_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(25847143330972109)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
