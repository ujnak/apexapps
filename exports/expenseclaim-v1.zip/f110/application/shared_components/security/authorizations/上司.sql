prompt --application/shared_components/security/authorizations/上司
begin
--   Manifest
--     SECURITY SCHEME: 上司
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>110
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(25944677548156977)
,p_name=>unistr('\4E0A\53F8')
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>unistr('\4E0A\53F8')
,p_attribute_02=>'A'
,p_error_message=>unistr('\4E0A\53F8\3067\306F\3042\308A\307E\305B\3093\3002')
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
