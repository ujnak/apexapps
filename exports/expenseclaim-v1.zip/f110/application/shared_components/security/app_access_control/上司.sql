prompt --application/shared_components/security/app_access_control/上司
begin
--   Manifest
--     ACL ROLE: 上司
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>110
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(25939968132831152)
,p_static_id=>'MANAGER'
,p_name=>unistr('\4E0A\53F8')
);
wwv_flow_imp.component_end;
end;
/
