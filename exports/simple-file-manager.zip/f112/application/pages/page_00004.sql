prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>112
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'download'
,p_alias=>'DOWNLOAD'
,p_step_title=>'download'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_deep_linking=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221209011330'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13626398602176349)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\30C0\30A6\30F3\30ED\30FC\30C9')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_exist integer;',
'begin',
unistr('    -- ID\304C\5B58\5728\3057\306A\3051\308C\3070\3001ORA-1403 \3092\767A\751F\3055\305B\308B\3002'),
'    select 1 into l_exist from sfm_contents where id = :ID;',
'    apex_util.redirect_url(',
'        apex_util.get_blob_file_src(',
'            p_item_name => ''P3_CONTENT'',',
'            p_v1 => :ID,',
'            p_content_disposition => ''attachment''',
'        )',
'    );',
'    apex_application.stop_apex_engine;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp.component_end;
end;
/
