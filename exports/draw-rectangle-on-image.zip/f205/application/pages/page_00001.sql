prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>205
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Draw Rectangle on Image'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.bounding-box {',
'    border-color: #0F0;',
'    position: absolute;',
'    box-sizing: border-box;',
'    border-width: 2px;',
'    border-style: solid;',
'}',
'',
'.bounding-box-label {',
'    color: black;',
'    background-color: #0F0;',
'    position: absolute;',
'    top: 0;',
'    left: 0;',
'    font-size: 12px;',
'    padding: 1px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107424623416098723)
,p_plug_name=>'Draw Rectangle on Image'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(107203929312092188)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107432164638244401)
,p_plug_name=>'CANVAS_ONLY'
,p_title=>'Canvas Only'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(107227269874092507)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107432816374244408)
,p_plug_name=>'CONTAINER_CANVAS_ONLY'
,p_title=>'Container'
,p_parent_plug_id=>wwv_flow_imp.id(107432164638244401)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(107160678216091867)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>'<canvas id="canvas-only" class="w100p"><canvas/>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107432211581244402)
,p_plug_name=>'CANVAS_ON_IMG'
,p_title=>'Canvas on Img'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(107227269874092507)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107432951419244409)
,p_plug_name=>'CONTAINER_CANVAS_ON_IMG'
,p_title=>'Container'
,p_parent_plug_id=>wwv_flow_imp.id(107432211581244402)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(107160678216091867)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="position: relative;" class="w100p">',
'    <img id="canvas-on-img-image" src="" width="100%" />',
'    <canvas id="canvas-on-img-canvas" style="position: absolute; left: 0; "></canvas>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107432330065244403)
,p_plug_name=>'DIV_ON_IMG'
,p_title=>'Div on Img'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(107227269874092507)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107433005456244410)
,p_plug_name=>'CONTAINER_DIV_ON_IMG'
,p_title=>'Container'
,p_parent_plug_id=>wwv_flow_imp.id(107432330065244403)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(107160678216091867)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="image-container" class="w100p">',
'<img id="image" src="" width="100%"></img>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107432437635244404)
,p_plug_name=>'REGION_SELECTOR'
,p_title=>'Region Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(107160678216091867)
,p_plug_display_sequence=>70
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(107432508959244405)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(107432164638244401)
,p_button_name=>'RUN_CANVAS_ONLY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(107300830677093121)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Run'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(107432611514244406)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(107432211581244402)
,p_button_name=>'RUN_CANVAS_ON_IMG'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(107300830677093121)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Run'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(107432744332244407)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(107432330065244403)
,p_button_name=>'RUN_DIV_ON_IMG'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(107300830677093121)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Run'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105698289977803746)
,p_name=>'P1_IMAGE'
,p_item_sequence=>10
,p_prompt=>'Image'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(107298389944093109)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'DROPZONE_INLINE'
,p_attribute_18=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105698345752803747)
,p_name=>'P1_X0'
,p_item_sequence=>20
,p_item_default=>'0.3'
,p_prompt=>'X0'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(107298389944093109)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_02=>'1'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105698495903803748)
,p_name=>'P1_X1'
,p_item_sequence=>40
,p_item_default=>'0.7'
,p_prompt=>'X1'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(107298389944093109)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_02=>'1'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105698559000803749)
,p_name=>'P1_Y0'
,p_item_sequence=>30
,p_item_default=>'0.3'
,p_prompt=>'Y0'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(107298389944093109)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_02=>'1'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105698685961803750)
,p_name=>'P1_Y1'
,p_item_sequence=>60
,p_item_default=>'0.7'
,p_prompt=>'Y1'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(107298389944093109)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_02=>'1'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(107433173068244411)
,p_name=>'onClick Canvas Only'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(107432508959244405)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107433279653244412)
,p_event_id=>wwv_flow_imp.id(107433173068244411)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0P1_IMAGE\306B\9078\629E\3055\308C\305F\753B\50CF\306EURL\3092\53D6\308A\51FA\3059\3002'),
' */',
'const imageFile = document.getElementById("P1_IMAGE").files[0];',
'const imageUrl = URL.createObjectURL(imageFile);',
'const img = new Image();',
'/*',
unistr(' * Canvas\8981\7D20\3078\306E\753B\50CF\306E\63CF\753B\306B\7D9A\304D\3001\77E9\5F62\3092\63CF\753B\3059\308B\3002'),
' */',
'img.onload = () => {',
unistr('    // \753B\50CF\306E\63CF\753B'),
'    const canvas = document.getElementById("canvas-only");',
'    const ctx = canvas.getContext("2d");',
'    ctx.clearRect(0, 0, canvas.width, canvas.height);',
'    canvas.height = Math.ceil(img.height * ( canvas.width / img.width ));',
unistr('    // \89E3\50CF\5EA6\3092\4E0A\3052\308B\3002'),
'    const dpr = window.devicePixelRatio;',
'    const cw = canvas.width;',
'    const ch = canvas.height;',
'    canvas.width  = cw * dpr;',
'    canvas.height = ch * dpr;',
unistr('    // canvas\306B\8A2D\5B9A\3057\305F\81EA\52D5\30B9\30B1\30FC\30EB\306B\4EFB\305B\308B\3002'),
'    // ctx.scale(dpr, dpr);',
unistr('    // \753B\50CF\306E\63CF\753B'),
'    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);',
unistr('    // \77E9\5F62\306E\63CF\753B'),
'    const x0 = Number(apex.items.P1_X0.value);',
'    const y0 = Number(apex.items.P1_Y0.value);',
'    const x1 = Number(apex.items.P1_X1.value);',
'    const y1 = Number(apex.items.P1_Y1.value);',
'    const startX = x0 * canvas.width;',
'    const startY = y0 * canvas.height;',
'    const width  = (x1 - x0) * canvas.width;',
'    const height = (y1 - y0) * canvas.height;',
'    ctx.strokeStyle = "#0F0";',
'    ctx.lineWidth = 4;',
'    ctx.strokeRect(startX, startY, width, height);',
'}',
'/*',
unistr(' * \30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306B\9078\629E\3055\308C\3066\3044\308B\753B\50CF\3092\8AAD\307F\8FBC\3080\3002'),
' */',
'img.src = imageUrl;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(107433332964244413)
,p_name=>'onClick Canvas on Img'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(107432611514244406)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107433450660244414)
,p_event_id=>wwv_flow_imp.id(107433332964244413)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0P1_IMAGE\306B\9078\629E\3055\308C\305F\753B\50CF\3092IMG\8981\7D20\306B\63CF\753B\3059\308B\3002'),
' */',
'const imageFile = document.getElementById("P1_IMAGE").files[0];',
'const imageUrl = URL.createObjectURL(imageFile);',
'const img = document.getElementById("canvas-on-img-image");',
'/*',
unistr(' * IMG\8981\7D20\306B\753B\50CF\304C\8868\793A\3055\308C\305F\5F8C\306BCANVAS\8981\7D20\306B\77E9\5F62\3092\63CF\753B\3059\308B\3002'),
' */',
'img.onload = () => {',
'    const x0 = Number(apex.items.P1_X0.value);',
'    const y0 = Number(apex.items.P1_Y0.value);',
'    const x1 = Number(apex.items.P1_X1.value);',
'    const y1 = Number(apex.items.P1_Y1.value);',
'    const canvas = document.getElementById("canvas-on-img-canvas");',
'    const imgWidth  = img.width;',
'    const imgHeight = img.height;',
'    canvas.width  = imgWidth;',
'    canvas.height = imgHeight;',
'    const startX = x0 * imgWidth;',
'    const startY = y0 * imgHeight;',
'    const width  = (x1 - x0) * imgWidth;',
'    const height = (y1 - y0) * imgHeight;',
'    const ctx = canvas.getContext(''2d'');',
'    ctx.strokeStyle = ''#0F0'';',
'    ctx.lineWidth = 4;',
'    ctx.strokeRect(startX, startY, width, height);',
'}',
'/*',
unistr(' * \30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306B\9078\629E\3055\308C\3066\3044\308B\753B\50CF\3092\8AAD\307F\8FBC\3080\3002'),
' */',
'img.src = imageUrl;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(107433540023244415)
,p_name=>'onClick Div on Img'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(107432744332244407)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107433617986244416)
,p_event_id=>wwv_flow_imp.id(107433540023244415)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0P1_IMAGE\306B\9078\629E\3055\308C\305F\753B\50CF\3092IMG\8981\7D20\306B\63CF\753B\3059\308B\3002'),
' */',
'const imageFile = document.getElementById("P1_IMAGE").files[0];',
'const imageUrl = URL.createObjectURL(imageFile);',
'const imageContainer = document.getElementById("image-container");',
'const img = document.getElementById("image");',
'/*',
unistr(' * IMG\8981\7D20\306B\753B\50CF\304C\8868\793A\3055\308C\305F\5F8C\306BCANVAS\8981\7D20\306B\77E9\5F62\3092\63CF\753B\3059\308B\3002'),
' */',
'img.onload = () => {',
'    const x0 = Number(apex.items.P1_X0.value);',
'    const y0 = Number(apex.items.P1_Y0.value);',
'    const x1 = Number(apex.items.P1_X1.value);',
'    const y1 = Number(apex.items.P1_Y1.value);',
unistr('    // \63CF\753B\3059\308B\77E9\5F62\3092\5B9A\7FA9\3059\308B\3002'),
'    const boxElement = document.createElement("div");',
'    boxElement.className = "bounding-box";',
'    Object.assign(boxElement.style, {',
'        left: 100 * x0 + ''%'',',
'        top: 100 * y0 + ''%'',',
'        width: 100 * (x1 - x0) + ''%'',',
'        height: 100 * (y1 - y0) + ''%'',',
'    });',
unistr('    // \63CF\753B\3059\308B\77E9\5F62\306E\5DE6\4E0A\306B\30E9\30D9\30EB\3092\3064\3051\308B\3002'),
'    const labelElement = document.createElement(''span'');',
unistr('    labelElement.textContent = ''\30B5\30F3\30D7\30EB\306E\30E9\30D9\30EB'';'),
'    labelElement.className   = ''bounding-box-label'';',
'    boxElement.appendChild(labelElement);',
unistr('    // \77E9\5F62\3092\63CF\753B\3059\308B\3002'),
'    imageContainer.appendChild(boxElement);',
'}',
'/*',
unistr(' * \30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306B\9078\629E\3055\308C\3066\3044\308B\753B\50CF\3092\8AAD\307F\8FBC\3080\3002'),
' */',
'img.src = imageUrl;'))
);
wwv_flow_imp.component_end;
end;
/
