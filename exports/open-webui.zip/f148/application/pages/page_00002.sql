prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>148
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Open WebUI'
,p_alias=>'OPEN-WEBUI'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Open WebUI'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'const channel = new BroadcastChannel(''submit-message'');'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'channel.addEventListener("message", (event) => {',
'    console.log(event.data.message);',
'    // iframe',
'    const iframe = document.querySelector(''iframe'');',
'    const input = iframe.contentDocument.getElementById("chat-input");',
'    input.innerText = event.data.message;',
'',
unistr('    // send-message-button\304C\8868\793A\3055\308C\308B\307E\3067\5F85\3064\3002'),
'    setTimeout(() => {',
'        const button = iframe.contentDocument.getElementById("send-message-button");',
'        button.click();',
'    }, 1000);',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'iframe {',
'    width: 100%;',
'    height: 100vh; /* Full viewport height */',
'    border: none;  /* Optional: removes the border */',
'}'))
,p_page_template_options=>'#DEFAULT#:t-Dialog--noPadding:t-PageBody--noContentPadding'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'09'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43343030714382426)
,p_plug_name=>'Open WebUI'
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_URL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'inclusion_mode', 'IFRAME',
  'url', 'http://localhost:8822')).to_clob
);
wwv_flow_imp.component_end;
end;
/
