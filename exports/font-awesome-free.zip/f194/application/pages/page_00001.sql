prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>194
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Font Awesome Free'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230514072100'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85354987369585908)
,p_plug_name=>'Font Awesome'
,p_icon_css_classes=>'fawe-cog'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(86408602198339036)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fawe fawe-cog" aria-hidden="true"></span>',
'<span class="fawe fawe-trash-o" aria-hidden="true"></span>',
'<span class="fawe fawe-bars" aria-hidden="true"></span>',
'<span class="fawe fawe-envelope-o" aria-hidden="true"></span>',
'<span class="fawe fawe-key" aria-hidden="true"></span>',
'<span class="fawe fawe-shopping-cart" aria-hidden="true"></span>',
'<span class="fawe fawe-battery-half" aria-hidden="true"></span>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85355074766585909)
,p_plug_name=>'Font APEX'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(86408602198339036)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="fa fa-cog" aria-hidden="true"></span>',
'<span class="fa fa-trash-o" aria-hidden="true"></span>',
'<span class="fa fa-bars" aria-hidden="true"></span>',
'<span class="fa fa-envelope-o" aria-hidden="true"></span>',
'<span class="fa fa-key" aria-hidden="true"></span>',
'<span class="fa fa-shopping-cart" aria-hidden="true"></span>',
'<span class="fa fa-battery-half" aria-hidden="true"></span>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86517683560339137)
,p_plug_name=>'Font Awesome Free'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(86375687924339016)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85355107349585910)
,p_name=>'P1_ITEM'
,p_item_sequence=>30
,p_prompt=>'Item'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(86479004088339083)
,p_item_icon_css_classes=>'fawe-battery-half'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
