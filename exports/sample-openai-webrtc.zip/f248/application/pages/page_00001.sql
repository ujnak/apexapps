prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>248
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'OpenAI WebRTC'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[module,defer]#APP_FILES#js/app#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133585434098783041)
,p_plug_name=>'Button Controls'
,p_region_name=>'CONTROLS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(134184191181513594)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134425885709514479)
,p_plug_name=>'OpenAI WebRTC'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(134204554797513641)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133585350791783040)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(133585434098783041)
,p_button_name=>'START'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(134301442536513901)
,p_button_image_alt=>'Start'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="START"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133585661189783043)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(133585434098783041)
,p_button_name=>'STOP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(134301442536513901)
,p_button_image_alt=>'Stop'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="STOP"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133586007150783047)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(133585434098783041)
,p_button_name=>'SEND'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(134301442536513901)
,p_button_image_alt=>'Send'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="SEND"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133584730652783034)
,p_button_sequence=>70
,p_button_name=>'GET_EPHEMERAL_TOKEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(134301442536513901)
,p_button_image_alt=>'Get Ephemeral Token'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133585094436783037)
,p_name=>'P1_RESPONSE'
,p_item_sequence=>60
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(134298925808513890)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133585773833783044)
,p_name=>'P1_CONNECTION_STATE'
,p_item_sequence=>50
,p_prompt=>'Connection State'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(134298925808513890)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133585841226783045)
,p_name=>'P1_TEXT'
,p_item_sequence=>80
,p_prompt=>'Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(134298925808513890)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133584802954783035)
,p_name=>'onClick GET_EPHEMERAL_TOKEN'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133584730652783034)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133584951436783036)
,p_event_id=>wwv_flow_imp.id(133584802954783035)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process( "GET_EPHEMERAL_TOKEN", {},',
'{',
'    success: ( data ) => {',
'        apex.item("P1_RESPONSE").setValue(JSON.stringify(data));',
'    }',
'}',
');'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(133584675413783033)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_EPHEMERAL_TOKEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_TOKEN_URL constant varchar2(80) := ''https://api.openai.com/v1/realtime/sessions'';',
'    l_response clob;',
'    l_response_json json_object_t;',
'    l_request clob;',
'    e_api_call_failed exception;',
'begin',
'    l_request := json_object(',
'        ''model'' value ''gpt-4o-realtime-preview-2024-12-17''',
'        ,''voice'' value ''verse''',
'    );',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'');',
'    apex_debug.info(''request: %s'', l_request);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_TOKEN_URL',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''OPENAI_API_KEY''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_api_call_failed;',
'    end if;',
'    apex_debug.info(''response'', l_response);',
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>133584675413783033
);
wwv_flow_imp.component_end;
end;
/
