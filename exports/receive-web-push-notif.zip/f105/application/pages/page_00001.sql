prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7335198607042437
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(10165851186220657)
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\30A6\30A7\30D6\30D7\30C3\30B7\30E5\53D7\4FE1')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var firebaseVapidPublicKey = ''&G_FIREBASE_VAPID_PUBLICKEY.'';',
'var firebaseNotificationEndpoint = ''&G_FIREBASE_DATABASE_URL./notifications.json'';',
'',
'// Web-Push',
'// Public base64 to Uint',
'// from https://gist.github.com/Klerith/80abd742d726dd587f4bd5d6a0ab26b6',
'function urlBase64ToUint8Array(base64String) {',
'    var padding = ''=''.repeat((4 - base64String.length % 4) % 4);',
'    var base64 = (base64String + padding)',
'        .replace(/\-/g, ''+'')',
'        .replace(/_/g, ''/'');',
'',
'    var rawData = window.atob(base64);',
'    var outputArray = new Uint8Array(rawData.length);',
'',
'    for (var i = 0; i < rawData.length; ++i) {',
'        outputArray[i] = rawData.charCodeAt(i);',
'    }',
'    return outputArray;',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add([',
'{',
'    name: "subscribe",',
'    action: function( event, element, args ) {',
'        // Request permission to subscribe to notifications',
'        Notification.requestPermission(function (result) { // (1)',
'            if (result === ''granted'') {',
'                console.log(''Notification permission granted!'');',
'                // Subscribe to the notification',
'                navigator.serviceWorker.ready.then(function(serviceWorkerRegistration) {',
'                    // Check subscription, if not subscribed, do nothing.',
'                    serviceWorkerRegistration.pushManager.getSubscription()',
'                    .then(function(subscription) {',
'                        if (!subscription) {',
'                            // Subscribe notification as a new client.',
'                            serviceWorkerRegistration.pushManager.subscribe({ // (2)',
'                                userVisibleOnly: true,',
'                                applicationServerKey: urlBase64ToUint8Array(firebaseVapidPublicKey)',
'                            })',
'                            .then(function (notification) {',
'                                // POST the notification subscription to Firebase',
'                                // notification.json below could be anything',
'                                return fetch(firebaseNotificationEndpoint, { // (3)',
'                                    method: ''POST'',',
'                                    headers: {',
'                                        ''Content-Type'': ''application/json''',
'                                    },',
'                                    body: JSON.stringify(notification)',
'                                });',
'                            })',
'                            .then(function (res) {',
'                                if (res.ok) {',
'                                    // Show the first notification (4)',
'                                    serviceWorkerRegistration.showNotification(''Successfully subscribed!'', {',
'                                        body: ''You have successfully subscribed to our APEX notification service.'',',
'                                        icon: apex.env.APP_FILES + ''icons/app-icon-32.png'',',
'                                        badge: apex.env.APP_FILES + ''icons/app-icon-32.png''',
'                                    })',
'                                    .then(function() {',
'                                        console.log(''Successfully subscribed!'');',
'                                    });',
'                                }',
'                            })',
'                            .catch(function (err) {',
'                                console.error(''Subscribing to notifications failed.'', err);',
'                            });',
'                        } else {',
'                            console.log("Web Push has already subscribed.");',
'                        }',
'                    });',
'                });',
'            } else {',
'                console.warn(''Notification permission denied.'');',
'            }',
'        });',
'    }',
'}',
']);'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20220908085849'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10174753698220668)
,p_plug_name=>unistr('\30A6\30A7\30D6\30D7\30C3\30B7\30E5\53D7\4FE1')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(10040231817220596)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
