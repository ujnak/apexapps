prompt --application/shared_components/ai_config/generate_geosparql_query
begin
--   Manifest
--     AI CONFIG: Generate GeoSPARQL Query
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>104
,p_default_id_offset=>12237625690706392
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_ai_config(
 p_id=>wwv_flow_imp.id(13237645419527774)
,p_name=>'Generate GeoSPARQL Query'
,p_static_id=>'generate_geosparql_query'
,p_remote_server_id=>wwv_flow_imp.id(13043658548520106)
,p_system_prompt=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\554F\5408\305B\304B\3089GeoSPARQL\306E\30AF\30A8\30EA\3092\751F\6210\3057\3066\304F\3060\3055\3044\3002PREFIX\306F\4EE5\4E0B\3067\3059\3002'),
unistr('\2014'),
'PREFIX geovocab: <http://geovocab.org/geometry#>',
'PREFIX lgd: <http://linkedgeodata.org/ontology/>',
'PREFIX dbpedia: <http://dbpedia.org/resource/>',
'PREFIX ogc: <http://www.opengis.net/ont/geosparql#>',
'PREFIX ogcf: <http://www.opengis.net/def/function/geosparql/>',
unistr('\2014'),
unistr('\9078\629E\3059\308B\306E\306F\4EE5\4E0B\306E?s ?geom ?sport ?label\3067\3059\3002'),
'',
'?s ',
'geovocab:geometry/ogc:asWKT ?geom',
'lgd:featuresSport ?sport',
'rdfs:label ?label',
'',
unistr('GeoSPARQL\306E\30AF\30A8\30EA\306E\4F8B\3067\3059\3002\30CB\30E5\30FC\30E8\30FC\30AF\5E02\306E\9818\57DF\3092POLYGON\3067\4E0E\3048\3066\3001\305D\306EPOLYGON\306B\542B\307E\308C\308B\91CE\7403\304C\3067\304D\308B\65BD\8A2D\306E\4E00\89A7\3067\3059\3002'),
'',
'PREFIX geovocab: <http://geovocab.org/geometry#>',
'PREFIX lgd: <http://linkedgeodata.org/ontology/>',
'PREFIX dbpedia: <http://dbpedia.org/resource/>',
'PREFIX ogc: <http://www.opengis.net/ont/geosparql#>',
'PREFIX ogcf: <http://www.opengis.net/def/function/geosparql/>',
'',
'SELECT ?s ?sport ?label ?geom',
'WHERE {',
'  ?s geovocab:geometry/ogc:asWKT ?geom ;',
'     lgd:featuresSport ?sport ;',
'     rdfs:label ?label .',
'  FILTER(ogcf:sfWithin(?geom,',
'    "POLYGON((-74.2557 40.4961, -73.7004 40.4961, -73.7004 40.9153, -74.2557 40.9153, -74.2557 40.4961))"^^ogc:wktLiteral))',
'  FILTER (?sport = dbpedia:Baseball)',
'}',
'ORDER BY ?label'))
,p_version_scn=>6666400
);
wwv_flow_imp.component_end;
end;
/
