prompt --application/shared_components/web_sources/rdf_models
begin
--   Manifest
--     WEB SOURCE: RDF models
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>104
,p_default_id_offset=>12237625690706392
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(45064175022945479)
,p_name=>'RDF models'
,p_static_id=>'rdf_models'
,p_web_source_type=>'NATIVE_ORDS'
,p_data_profile_id=>wwv_flow_imp.id(45060316984945478)
,p_remote_server_id=>wwv_flow_imp.id(32811586117058080)
,p_url_path_prefix=>'/database/rdf/networks/:network_owner,:network_name/models/'
,p_credential_id=>wwv_flow_imp.id(32811887152063186)
,p_attribute_01=>'N'
,p_attribute_02=>'HIGHEST'
,p_version_scn=>4826200
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(45065207419945479)
,p_web_src_module_id=>wwv_flow_imp.id(45064175022945479)
,p_name=>'network_owner'
,p_param_type=>'URL_PATTERN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(45065643516945479)
,p_web_src_module_id=>wwv_flow_imp.id(45064175022945479)
,p_name=>'network_name'
,p_param_type=>'URL_PATTERN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'NET1'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(45064431532945479)
,p_web_src_module_id=>wwv_flow_imp.id(45064175022945479)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(45064814354945479)
,p_web_src_module_id=>wwv_flow_imp.id(45064175022945479)
,p_operation=>'POST'
,p_database_operation=>'INSERT'
,p_url_pattern=>'.'
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
