prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>104
,p_default_id_offset=>12237625690706392
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'SPARQL Operations'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45026898077682847)
,p_plug_name=>'SPARQL Operations'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45030148013689645)
,p_plug_name=>'Update'
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>120
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45030230394689646)
,p_plug_name=>'Query'
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>130
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45029590758689640)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(45030148013689645)
,p_button_name=>'EXECUTE_SPARQL_UPDATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Execute SPARQL Update'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45029836658689642)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(45030230394689646)
,p_button_name=>'EXECUTE_SPARQL_QUERY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Execute SPARQL Query'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43490188083183080)
,p_button_sequence=>20
,p_button_name=>'CLEAR_RESPONSE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Clear Response'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45029005032689634)
,p_button_sequence=>60
,p_button_name=>'CREATE_RDF_NETWORK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Create RDF network'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45029128584689635)
,p_button_sequence=>70
,p_button_name=>'DROP_RDF_NETWORK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Drop RDF network'
,p_confirm_message=>unistr('\672C\5F53\306B\524A\9664\3057\307E\3059\304B\FF1F')
,p_confirm_style=>'warning'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45029320569689637)
,p_button_sequence=>90
,p_button_name=>'CREATE_RDF_MODEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Create RDF model'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45029456058689638)
,p_button_sequence=>110
,p_button_name=>'DROP_RDF_MODEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Drop RDF model'
,p_confirm_message=>unistr('\672C\5F53\306B\524A\9664\3057\307E\3059\304B\FF1F')
,p_confirm_style=>'warning'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33671909345808413)
,p_button_sequence=>140
,p_button_name=>'TRANSLATE_SPARQL_TO_SQL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Translate SPARQL To SQL'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33672007028808414)
,p_name=>'P1_SQL'
,p_item_sequence=>150
,p_prompt=>'SQL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43490329960183081)
,p_name=>'P1_NETWORK_NAME'
,p_item_sequence=>30
,p_prompt=>'Network Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43490434484183082)
,p_name=>'P1_NETWORK_OWNER'
,p_item_sequence=>40
,p_prompt=>'Network Owner'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45028959632689633)
,p_name=>'P1_TABLESPACE_NAME'
,p_item_sequence=>50
,p_prompt=>'Tablespace Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45029211242689636)
,p_name=>'P1_MODEL_NAME'
,p_item_sequence=>80
,p_prompt=>'Model Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45029502614689639)
,p_name=>'P1_SPARQL_UPDATE'
,p_data_type=>'CLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(45030148013689645)
,p_prompt=>'SPARQL Update'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>15
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45029760467689641)
,p_name=>'P1_SPARQL_QUERY'
,p_data_type=>'CLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(45030230394689646)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT (COUNT(*) AS ?triplesCount)',
'WHERE {',
'  ?s ?p ?o .',
'}'))
,p_prompt=>'SPARQL Query'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>15
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45029993386689644)
,p_name=>'P1_RESPONSE'
,p_item_sequence=>10
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>20
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45029928556689643)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Response'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P1_RESPONSE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(43490188083183080)
,p_internal_uid=>11343857724852811
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45030434534689648)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create RDF network'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_base_url apex_workspace_remote_servers.base_url%type;',
'    l_operation_url varchar2(400);',
'    l_request clob;',
'    l_request_json json_object_t;',
'    l_response clob;',
'    e_call_api_failed exception;',
'    l_status_code number;',
'begin',
'    select base_url into l_base_url from apex_workspace_remote_servers',
'    where remote_server_static_id = :G_REMOTE_SERVER;',
'    l_operation_url := ',
'        apex_string.format(l_base_url || ''/database/rdf/networks/%s,%s'',',
'            :P1_NETWORK_OWNER, :P1_NETWORK_NAME);',
'    apex_debug.info(''operation_url = %s'', l_operation_url);',
'    l_request_json := json_object_t();',
'    l_request_json.put(''tablespace_name'', :P1_TABLESPACE_NAME);',
'    l_request := l_request_json.to_clob();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_operation_url',
'        ,p_http_method => ''PUT''',
'        ,p_body => l_request',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    l_status_code := apex_web_service.g_status_code;',
'    apex_debug.info(''status_code = %s'', l_status_code);',
'    if not l_status_code between 200 and 300 then',
'        raise e_call_api_failed;',
'    end if;',
'    :P1_RESPONSE := l_response;',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(45029005032689634)
,p_process_success_message=>unistr('RDF network\304C\4F5C\6210\3055\308C\307E\3057\305F\3002')
,p_internal_uid=>11344363702852816
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45030569794689649)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Drop RDF network'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_base_url apex_workspace_remote_servers.base_url%type;',
'    l_operation_url varchar2(400);',
'    l_response clob;',
'    e_call_api_failed exception;',
'    l_status_code number;',
'begin',
'    select base_url into l_base_url from apex_workspace_remote_servers',
'    where remote_server_static_id = :G_REMOTE_SERVER;',
'    l_operation_url := ',
'        apex_string.format(l_base_url || ''/database/rdf/networks/%s,%s'',',
'            :P1_NETWORK_OWNER, :P1_NETWORK_NAME);',
'    apex_debug.info(''operation_url = %s'', l_operation_url);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_operation_url',
'        ,p_http_method => ''DELETE''',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    l_status_code := apex_web_service.g_status_code;',
'    apex_debug.info(''status_code = %s'', l_status_code);',
'    if not l_status_code between 200 and 300 then',
'        raise e_call_api_failed;',
'    end if;',
'    :P1_RESPONSE := l_response;',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(45029128584689635)
,p_process_success_message=>unistr('RDF network\304C\524A\9664\3055\308C\307E\3057\305F\3002')
,p_internal_uid=>11344498962852817
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45030660969689650)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create RDF model'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_base_url apex_workspace_remote_servers.base_url%type;',
'    l_operation_url varchar2(400);',
'    l_request clob;',
'    l_request_json json_object_t;',
'    l_response clob;',
'    e_call_api_failed exception;',
'    l_status_code number;',
'begin',
'    select base_url into l_base_url from apex_workspace_remote_servers',
'    where remote_server_static_id = :G_REMOTE_SERVER;',
'    l_operation_url := ',
'        apex_string.format(l_base_url || ''/database/rdf/networks/%s,%s/models/%s'',',
'            :P1_NETWORK_OWNER, :P1_NETWORK_NAME, :P1_MODEL_NAME);',
'    apex_debug.info(''operation_url = %s'', l_operation_url);',
'    l_request_json := json_object_t();',
'    l_request_json.put(''tablespace_name'', :P1_TABLESPACE_NAME);',
'    l_request := l_request_json.to_clob();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_operation_url',
'        ,p_http_method => ''PUT''',
'        ,p_body => l_request',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    l_status_code := apex_web_service.g_status_code;',
'    apex_debug.info(''status_code = %s'', l_status_code);',
'    if not l_status_code between 200 and 300 then',
'        raise e_call_api_failed;',
'    end if;',
'    :P1_RESPONSE := l_response;',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(45029320569689637)
,p_process_success_message=>unistr('RDF model\304C\4F5C\6210\3055\308C\307E\3057\305F\3002')
,p_internal_uid=>11344590137852818
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45030720520689651)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Drop RDF model'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_base_url apex_workspace_remote_servers.base_url%type;',
'    l_operation_url varchar2(400);',
'    l_response clob;',
'    e_call_api_failed exception;',
'    l_status_code number;',
'begin',
'    select base_url into l_base_url from apex_workspace_remote_servers',
'    where remote_server_static_id = :G_REMOTE_SERVER;',
'    l_operation_url := ',
'        apex_string.format(l_base_url || ''/database/rdf/networks/%s,%s/models/%s'',',
'            :P1_NETWORK_OWNER, :P1_NETWORK_NAME, :P1_MODEL_NAME);',
'    apex_debug.info(''operation_url = %s'', l_operation_url);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_operation_url',
'        ,p_http_method => ''DELETE''',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    l_status_code := apex_web_service.g_status_code;',
'    apex_debug.info(''status_code = %s'', l_status_code);',
'    if not l_status_code between 200 and 300 then',
'        raise e_call_api_failed;',
'    end if;',
'    :P1_RESPONSE := l_response;',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(45029456058689638)
,p_process_success_message=>unistr('RDF model\304C\524A\9664\3055\308C\307E\3057\305F\3002')
,p_internal_uid=>11344649688852819
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45030772118689652)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Execute a SPARQL update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_base_url apex_workspace_remote_servers.base_url%type;',
'    l_operation_url varchar2(400);',
'    l_request clob;',
'    l_response clob;',
'    e_call_api_failed exception;',
'    l_status_code number;',
'begin',
'    select base_url into l_base_url from apex_workspace_remote_servers',
'    where remote_server_static_id = :G_REMOTE_SERVER;',
'    l_operation_url := ',
'        apex_string.format(l_base_url || ''/database/rdf/networks/%s,%s/models/%s/sparql/1.1'',',
'            :P1_NETWORK_OWNER, :P1_NETWORK_NAME, :P1_MODEL_NAME);',
'    apex_debug.info(''operation_url = %s'', l_operation_url);',
'    l_request := :P1_SPARQL_UPDATE;',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/sparql-update'', ''Accept'', ''application/sparql-results+json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_operation_url',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    l_status_code := apex_web_service.g_status_code;',
'    apex_debug.info(''status_code = %s'', l_status_code);',
'    if not l_status_code between 200 and 300 then',
'        raise e_call_api_failed;',
'    end if;',
'    :P1_RESPONSE := l_response;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(45029590758689640)
,p_process_success_message=>unistr('SPARQL Update\304C\5B9F\884C\3055\308C\307E\3057\305F\3002')
,p_internal_uid=>11344701286852820
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45030916779689653)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Execute a SPARQL query'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_base_url apex_workspace_remote_servers.base_url%type;',
'    l_operation_url varchar2(400);',
'    l_request clob;',
'    l_response clob;',
'    e_call_api_failed exception;',
'    l_status_code number;',
'begin',
'    select base_url into l_base_url from apex_workspace_remote_servers',
'    where remote_server_static_id = :G_REMOTE_SERVER;',
'    l_operation_url := ',
'        apex_string.format(l_base_url || ''/database/rdf/networks/%s,%s/models/%s/sparql/1.1'',',
'            :P1_NETWORK_OWNER, :P1_NETWORK_NAME, :P1_MODEL_NAME);',
'    apex_debug.info(''operation_url = %s'', l_operation_url);',
'    l_request := :P1_SPARQL_QUERY;',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/sparql-query'', ''Accept'', ''application/sparql-results+json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_operation_url',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    l_status_code := apex_web_service.g_status_code;',
'    apex_debug.info(''status_code = %s'', l_status_code);',
'    if not l_status_code between 200 and 300 then',
'        raise e_call_api_failed;',
'    end if;',
'    :P1_RESPONSE := l_response;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(45029836658689642)
,p_process_success_message=>unistr('SPARQL Query\304C\5B9F\884C\3055\308C\307E\3057\305F\3002')
,p_internal_uid=>11344845947852821
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(33672037048808415)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Translate SPARQL to SQL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_base_url apex_workspace_remote_servers.base_url%type;',
'    l_operation_url varchar2(400);',
'    l_request clob;',
'    l_response clob;',
'    e_call_api_failed exception;',
'    l_status_code number;',
'begin',
'    select base_url into l_base_url from apex_workspace_remote_servers',
'    where remote_server_static_id = :G_REMOTE_SERVER;',
'    l_operation_url := ',
'        apex_string.format(l_base_url || ''/database/rdf/networks/%s,%s/models/%s/sparql2sql/1.1'',',
'            :P1_NETWORK_OWNER, :P1_NETWORK_NAME, :P1_MODEL_NAME);',
'    apex_debug.info(''operation_url = %s'', l_operation_url);',
'    l_request := :P1_SPARQL_QUERY;',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/sparql-query'', ''Accept'', ''text/plain'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_operation_url',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    l_status_code := apex_web_service.g_status_code;',
'    apex_debug.info(''status_code = %s'', l_status_code);',
'    if not l_status_code between 200 and 300 then',
'        raise e_call_api_failed;',
'    end if;',
'    :P1_SQL := l_response;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(33671909345808413)
,p_process_success_message=>unistr('Translate SPARQL to SQL\304C\5B9F\884C\3055\308C\307E\3057\305F\3002')
,p_internal_uid=>11396603335153019
);
wwv_flow_imp.component_end;
end;
/
