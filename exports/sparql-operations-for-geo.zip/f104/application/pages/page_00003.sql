prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>104
,p_default_id_offset=>10037808022949004
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Upload'
,p_alias=>'UPLOAD'
,p_step_title=>'Upload'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9660502658384415)
,p_plug_name=>'NTRIPES'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>90
,p_query_type=>'SQL'
,p_plug_source=>'select n001, n002, substr(clob001, 1, 400) clob from apex_collections where collection_name = ''NTRIPLES'''
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(9661716857384427)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>9661716857384427
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9661818531384428)
,p_db_column_name=>'N001'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'N001'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9661982212384429)
,p_db_column_name=>'N002'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'N002'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9662037417384430)
,p_db_column_name=>'CLOB'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Clob'
,p_column_html_expression=>'<pre>#CLOB#</pre>'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10253650417337870)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'102537'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>10
,p_report_columns=>'N001:N002:CLOB'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9662469568384434)
,p_plug_name=>'Background Process'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT *',
'FROM APEX_APPL_PAGE_BG_PROC_STATUS',
'WHERE APPLICATION_ID = :APP_ID',
'ORDER BY CREATED_ON DESC;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(9662508652384435)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>9662508652384435
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9662600134384436)
,p_db_column_name=>'WORKSPACE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Workspace'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9662751940384437)
,p_db_column_name=>'WORKSPACE_DISPLAY_NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Workspace Display Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9662887781384438)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9662975010384439)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9663020591384440)
,p_db_column_name=>'WORKING_COPY_NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Working Copy Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9663125379384441)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9663273829384442)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9663368395384443)
,p_db_column_name=>'EXECUTION_ID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Execution Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9663458945384444)
,p_db_column_name=>'PROCESS_ID'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Process Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9663524596384445)
,p_db_column_name=>'PROCESS_NAME'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Process Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9663611714384446)
,p_db_column_name=>'SERIAL_EXECUTION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Serial Execution'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9663710194384447)
,p_db_column_name=>'CURRENT_PROCESS_ID'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Current Process Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9663817878384448)
,p_db_column_name=>'CURRENT_PROCESS_NAME'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Current Process Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9663934771384449)
,p_db_column_name=>'CURRENT_PROCESS_SEQUENCE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Current Process Sequence'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9664086293384450)
,p_db_column_name=>'PROCESS_TYPE_PLUGIN_NAME'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Process Type Plugin Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10437524148448701)
,p_db_column_name=>'SESSION_ID'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Session Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10437616552448702)
,p_db_column_name=>'WORKING_SESSION_ID'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Working Session Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10437707360448703)
,p_db_column_name=>'REQUEST'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Request'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10437853044448704)
,p_db_column_name=>'ECID'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Ecid'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10437945838448705)
,p_db_column_name=>'CONTEXT_VALUE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Context Value'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10438045393448706)
,p_db_column_name=>'STATUS'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10438168194448707)
,p_db_column_name=>'STATUS_CODE'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Status Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10438241086448708)
,p_db_column_name=>'STATUS_MESSAGE'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Status Message'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10438391561448709)
,p_db_column_name=>'SOFAR'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Sofar'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10438407246448710)
,p_db_column_name=>'TOTALWORK'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Totalwork'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10438544551448711)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10438673957448712)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Last Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10451759560449012)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'104518'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WORKSPACE:WORKSPACE_DISPLAY_NAME:APPLICATION_ID:APPLICATION_NAME:WORKING_COPY_NAME:PAGE_ID:PAGE_NAME:EXECUTION_ID:PROCESS_ID:PROCESS_NAME:SERIAL_EXECUTION:CURRENT_PROCESS_ID:CURRENT_PROCESS_NAME:CURRENT_PROCESS_SEQUENCE:PROCESS_TYPE_PLUGIN_NAME:SESSI'
||'ON_ID:WORKING_SESSION_ID:REQUEST:ECID:CONTEXT_VALUE:STATUS:STATUS_CODE:STATUS_MESSAGE:SOFAR:TOTALWORK:CREATED_ON:LAST_UPDATED_ON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10238035418161854)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(32776213547976440)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9660409242384414)
,p_button_sequence=>30
,p_button_name=>'UPLOAD_FILE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Upload File'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9662210214384432)
,p_button_sequence=>40
,p_button_name=>'UPLOAD_SERVER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Upload Server'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10438950548448715)
,p_button_sequence=>50
,p_button_name=>'REFRESH_REPORT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Refresh Report'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9660233045384412)
,p_name=>'P3_FILE'
,p_item_sequence=>10
,p_prompt=>'File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'display_as', 'INLINE',
  'purge_file_at', 'REQUEST',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10438709327448713)
,p_name=>'P3_BATCH_LINES'
,p_item_sequence=>60
,p_item_default=>'1000'
,p_prompt=>'Batch Lines'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10438899727448714)
,p_name=>'P3_START_PART'
,p_item_sequence=>70
,p_item_default=>'1'
,p_prompt=>'Start Part'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10439047689448716)
,p_name=>'onClick REFRESH_REPORT'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10438950548448715)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10439111565448717)
,p_event_id=>wwv_flow_imp.id(10439047689448716)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9662469568384434)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9660340336384413)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Upload File'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_COLNAME   constant varchar2(20) := ''NTRIPLES'';',
'    l_blob      blob;',
'    l_ntriples  clob;',
'    l_ntriples_part clob;',
'    l_part_lines number;',
'    l_line      varchar2(32767);',
'    l_total_len pls_integer;',
'    l_offset    pls_integer;',
'    l_eol_pos   pls_integer;',
'    l_part      number;',
'    C_BATCH_LINES constant number := :P3_BATCH_LINES;',
'begin',
unistr('    /* \30A2\30C3\30D7\30ED\30FC\30C9\3057\305FN-Triples\306E\30D5\30A1\30A4\30EB\3092CLOB\3068\3057\3066\53D6\308A\51FA\3059\3002 */'),
'    select blob_content into l_blob from apex_application_temp_files',
'    where name = :P3_FILE;',
'    l_ntriples := apex_util.blob_to_clob(l_blob);',
unistr('    /* APEX\30B3\30EC\30AF\30B7\30E7\30F3\306A\3069\306E\521D\671F\5316 */'),
'    apex_collection.create_or_truncate_collection(C_COLNAME);',
'    l_total_len  := dbms_lob.getlength(l_ntriples);',
'    l_offset     := 1;',
'    l_part_lines := 0;',
'    l_part       := 0;',
'    /*',
unistr('     * N-Triples\3092\6539\884C\3067\5206\5272\3057\3001C_BATCH_LINES\3092\4E0A\9650\3068\3057\3066\3072\3068\307E\3068\3081\306B\3059\308B\3002'),
unistr('     * \307E\3068\3081\305FCLOB\3092APEX\30B3\30EC\30AF\30B7\30E7\30F3\306B\4FDD\5B58\3059\308B\3002'),
unistr('     * \3053\306EC_BATCH_LINES\6BCE\306B\307E\3068\3081\3089\308C\305FN-Triples\3092\3001\FF11\3064\306ESPARQL Update\306E'),
unistr('     * \30EA\30AF\30A8\30B9\30C8\306B\3057\3066\3001RDF Graph REST API\3092\547C\3073\51FA\3059\3002\FF08\5225\30D7\30ED\30BB\30B9\FF09'),
'     */',
'    while l_offset <= l_total_len loop',
unistr('        /* \6539\884C\4F4D\7F6E\3092\63A2\3059\3002 */'),
'        l_eol_pos := dbms_lob.instr(l_ntriples, CHR(10), l_offset);',
'        if l_eol_pos = 0 then',
unistr('            /* \6539\884C\304C\898B\3064\304B\3089\306A\3044\306E\3067\6700\7D42\884C */'),
'            l_line := dbms_lob.substr(l_ntriples, l_total_len - l_offset + 1, l_offset);',
unistr('            l_offset := l_total_len + 1; /* \7D42\4E86 */'),
'        else',
'            l_line := dbms_lob.substr(l_ntriples, l_eol_pos - l_offset, l_offset);',
'            l_offset := l_eol_pos + 1;',
'        end if;',
'        l_part_lines := l_part_lines + 1;',
'        l_ntriples_part := l_ntriples_part || CHR(10) || l_line;',
'        /*',
unistr('         * \884C\6570\306E\4E0A\9650\306B\9054\3057\305F\3089\3001APEX\30B3\30EC\30AF\30B7\30E7\30F3\306B\4FDD\5B58\3059\308B\3002'),
'         */',
'        if l_part_lines >= C_BATCH_LINES then',
'            l_part := l_part + 1;',
'            apex_collection.add_member(',
'                p_collection_name => C_COLNAME',
'                ,p_n001           => l_part',
'                ,p_n002           => l_part_lines',
'                ,p_clob001        => l_ntriples_part',
'            );',
unistr('            /* \6B21\306E\30D0\30C3\30C1\306B\5411\3051\521D\671F\5316\3059\308B\3002 */'),
'            l_part_lines    := 0;',
'            l_ntriples_part := '''';',
'        end if;',
'    end loop;',
'    /*',
unistr('     * \6B8B\308A\3092\4FDD\5B58\3059\308B\3002'),
'     */',
'    if l_part_lines > 0 then',
'        l_part := l_part + 1;',
'        apex_collection.add_member(',
'            p_collection_name => C_COLNAME',
'            ,p_n001           => l_part',
'            ,p_n002           => l_part_lines',
'            ,p_clob001        => l_ntriples_part',
'        );',
'    end if;',
' end;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9660409242384414)
,p_internal_uid=>9660340336384413
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9662183181384431)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Background'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'IGNORE'
,p_attribute_09=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9662210214384432)
,p_internal_uid=>9662183181384431
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9662328128384433)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(9662183181384431)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Upload Server'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_COLNAME   constant varchar2(20) := ''NTRIPLES'';',
'    l_part number;',
'    l_lines number;',
'    l_clob clob;',
'    l_base_url apex_workspace_remote_servers.base_url%type;',
'    l_operation_url varchar2(400);',
'    l_request  clob;',
'    l_response clob;',
'    l_total_part number;',
'    l_sofar      number := 0;',
'    l_status_code     number;',
'    e_call_api_failed exception;',
'begin',
'    select base_url into l_base_url from apex_workspace_remote_servers',
'    where remote_server_static_id = :G_REMOTE_SERVER;',
'    l_operation_url := ',
'        apex_string.format(l_base_url || ''/database/rdf/networks/%s,%s/models/%s/sparql/1.1'',',
'            :P1_NETWORK_OWNER, :P1_NETWORK_NAME, :P1_MODEL_NAME);',
'    apex_debug.info(''operation_url = %s'', l_operation_url);',
'    /*',
unistr('     * \6700\521D\306BREST\30EA\30AF\30A8\30B9\30C8\3092\767A\884C\3059\308B\6570\3092\78BA\8A8D\3059\308B\3002'),
'     */',
'    select max(n001) into l_total_part from apex_collections where collection_name = C_COLNAME;',
'    /*',
unistr('     * \9014\4E2D\304B\3089\5B9F\884C\3067\304D\308B\3088\3046\306B\3001P3_START_PART\306E\30E1\30F3\30D0\30FC\304B\3089REST API\306E'),
unistr('     * \547C\3073\51FA\3057\3092\884C\3046\3002'),
'     */',
'    for r in ',
'    (',
'        select n001, n002, clob001',
'        from apex_collections where collection_name = C_COLNAME and n001 >= :P3_START_PART',
'        order by n001 asc',
'    )',
'    loop',
'        l_sofar := r.n001;',
'        l_request := ''INSERT DATA {'' || CHR(10) || r.clob001 || CHR(10) || ''}'';',
'        apex_web_service.set_request_headers(''Content-Type'', ''application/sparql-update'', ''Accept'', ''application/sparql-results+json'');',
'        l_response := apex_web_service.make_rest_request(',
'            p_url          => l_operation_url',
'            ,p_http_method => ''POST''',
'            ,p_body        => l_request',
'            ,p_credential_static_id => :G_CREDENTIAL',
'        );',
'        l_status_code := apex_web_service.g_status_code;',
'        apex_debug.info(''status_code = %s'', l_status_code);',
'        if not l_status_code between 200 and 300 then',
'            raise e_call_api_failed;',
'        end if;',
'        apex_background_process.set_progress(',
'            p_totalwork => l_total_part',
'            ,p_sofar => l_sofar',
'        );',
'    end loop;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(9662210214384432)
,p_internal_uid=>9662328128384433
);
wwv_flow_imp.component_end;
end;
/
