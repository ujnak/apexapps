prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>104
,p_default_id_offset=>12237625690706392
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Map'
,p_alias=>'MAP'
,p_step_title=>'Map'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10441163426448737)
,p_plug_name=>'SPARQL Query'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10441213180448738)
,p_plug_name=>'LLM'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22677070625155112)
,p_plug_name=>'Map'
,p_region_name=>'sportsmap'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(22677150119155113)
,p_region_id=>wwv_flow_imp.id(22677070625155112)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(22677245106155114)
,p_map_region_id=>wwv_flow_imp.id(22677150119155113)
,p_name=>'Sports Facilities'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>'select c001 s_value, n001 geom_lon, n002 geom_lat, c002 label_value, c003 sport_value from apex_collections where collection_name = ''SPORTS_FACILITIES'''
,p_has_spatial_index=>false
,p_pk_column=>'S_VALUE'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'GEOM_LON'
,p_latitude_column=>'GEOM_LAT'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'LABEL_VALUE'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22677484445155116)
,p_plug_name=>'SPORTS_FACILITIES'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c001 s_value, c002 label_value, c003 sport_value, n001 geom_lon, n002 geom_lat',
'from apex_collections where collection_name = ''SPORTS_FACILITIES'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(22677607740155117)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>10439982049448725
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(22677635024155118)
,p_db_column_name=>'S_VALUE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'S Value'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(22677780408155119)
,p_db_column_name=>'LABEL_VALUE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Label Value'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(22677916762155120)
,p_db_column_name=>'SPORT_VALUE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Sport Value'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(22677989900155121)
,p_db_column_name=>'GEOM_LON'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Geom Lon'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(22678084339155122)
,p_db_column_name=>'GEOM_LAT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Geom Lat'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(23879949788161951)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'116424'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'S_VALUE:LABEL_VALUE:SPORT_VALUE:GEOM_LON:GEOM_LAT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23478191423983555)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(45013839238682832)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22676952357155111)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(10441163426448737)
,p_button_name=>'UPDATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Update'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10441492870448740)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(10441213180448738)
,p_button_name=>'GENERATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Generate'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(14059460095917509)
,p_branch_name=>'Fit Map'
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RR,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(22676952357155111)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10441314919448739)
,p_name=>'P4_USER_PROMPT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10441213180448738)
,p_prompt=>'User Prompt'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>10
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22676893370155110)
,p_name=>'P4_SPARQL_QUERY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10441163426448737)
,p_prompt=>'SPARQL Query'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>10
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10441533034448741)
,p_name=>'onClick GENERATE'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10441492870448740)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10441797494448743)
,p_event_id=>wwv_flow_imp.id(10441533034448741)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_GENERATE_TEXT_AI'
,p_attribute_01=>'ITEM'
,p_attribute_02=>'P4_USER_PROMPT'
,p_attribute_04=>'ITEM'
,p_attribute_05=>'P4_SPARQL_QUERY'
,p_attribute_07=>'N'
,p_wait_for_result=>'Y'
,p_ai_config_id=>wwv_flow_imp.id(13237645419527774)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22677407410155115)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SPARQL Query'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_COLNAME constant varchar2(20) := ''SPORTS_FACILITIES'';',
'    l_base_url apex_workspace_remote_servers.base_url%type;',
'    l_operation_url varchar2(400);',
'    l_request clob;',
'    l_response clob;',
'    e_call_api_failed exception;',
'    l_status_code number;',
unistr('    /* JSON\304B\3089\30B3\30EC\30AF\30B7\30E7\30F3\306B\6295\5165\3059\308B */'),
'    l_response_json json_object_t;',
'    l_results  json_object_t;',
'    l_bindings json_array_t;',
'    l_binding  json_object_t;',
'    l_s json_object_t;',
'    l_s_value varchar2(4000);',
'    l_sport json_object_t;',
'    l_sport_value varchar2(4000);',
'    l_label json_object_t;',
'    l_label_value varchar2(4000);',
'    l_geom  json_object_t;',
'    l_geom_value varchar2(4000);',
'    l_geom_lat   number;',
'    l_geom_lon   number;',
'    /* SPARQL query */',
'    l_sparql_start pls_integer;',
'    l_sparql_end   pls_integer;',
'    C_SPARQL_START constant varchar2(10) := ''```sparql'';',
'    C_SPARQL_END   constant varchar2(10) := ''```'';',
'begin',
'    /*',
unistr('     * \4EE5\4E0B\306F\30DA\30FC\30B8\FF11\306B\3042\308BSPARQL\30AF\30A8\30EA\306E\5B9F\884C\30B3\30FC\30C9\3068\540C\3058\3002'),
'     */',
'    select base_url into l_base_url from apex_workspace_remote_servers',
'    where remote_server_static_id = :G_REMOTE_SERVER;',
'    l_operation_url := ',
'        apex_string.format(l_base_url || ''/database/rdf/networks/%s,%s/models/%s/sparql/1.1'',',
'            :P1_NETWORK_OWNER, :P1_NETWORK_NAME, :P1_MODEL_NAME);',
'    apex_debug.info(''operation_url = %s'', l_operation_url);',
'    /* ',
unistr('     * P4_SPARQL_QUERY\306Fsparql\3067\306E\56F2\307F\304C\3042\308C\3070\3001\305D\306E\4E2D\306E\30AF\30A8\30EA\3092\53D6\308A\51FA\3059\3002'),
'     *',
'     * ```sparql',
unistr('     * \3053\3053\306B\30AF\30A8\30EA\304C\3042\308B\3002'),
'     * ....',
'     * ```',
'     */',
'    l_request := :P4_SPARQL_QUERY;',
'    l_sparql_start := instr(l_request, C_SPARQL_START);',
'    if l_sparql_start > 0 then',
unistr('        /* \56F2\307E\308C\3066\3044\308B */'),
'        l_sparql_end := instr(l_request, C_SPARQL_END, l_sparql_start + length(C_SPARQL_START));',
'        apex_debug.info(''start = %, end = %s'', l_sparql_start, l_sparql_end);',
'        l_request := substr(l_request, l_sparql_start + length(C_SPARQL_START), l_sparql_end - l_sparql_start - length(C_SPARQL_START));',
'    end if;',
'    apex_debug.info(''SPARQL Query = %s'', l_request);',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/sparql-query'', ''Accept'', ''application/sparql-results+json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_operation_url',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    l_status_code := apex_web_service.g_status_code;',
'    apex_debug.info(''status_code = %s'', l_status_code);',
'    if not l_status_code between 200 and 300 then',
'        raise e_call_api_failed;',
'    end if;',
'    /*',
unistr('     * \30D0\30C3\30AF\30AF\30A9\30FC\30C8\3092\30A8\30B9\30B1\30FC\30B9\3059\308B\3068\3044\3046\4E0D\5177\5408\306E\30EF\30FC\30AF\30A2\30E9\30A6\30F3\30C9'),
'     */',
'    l_response := replace(l_response, q''~\''~'',q''~''~'');',
'    /*',
unistr('     * JSON\3067\8FD4\3055\308C\308B\30EC\30B9\30DD\30F3\30B9\3092\30D1\30FC\30B9\3057\3066\3001\30DE\30C3\30D7\304C\53C2\7167\3059\308BAPEX\30B3\30EC\30AF\30B7\30E7\30F3\306B\6295\5165\3059\308B\3002'),
unistr('     * get_object\3067null\304C\8FD4\3055\308C\305F\5834\5408\306E\5BFE\5FDC\3092\30B5\30DC\3063\3066\3044\307E\3059\3002'),
'     */',
'    l_response_json := json_object_t(l_response);',
'    l_results := l_response_json.get_object(''results'');',
'    l_bindings := l_results.get_array(''bindings'');',
'    apex_collection.create_or_truncate_collection(C_COLNAME);',
'    for i in 0..(l_bindings.get_size()-1)',
'    loop',
'        l_binding := treat(l_bindings.get(i) as json_object_t);',
'        /* s */',
'        l_s := l_binding.get_object(''s'');',
'        l_s_value := l_s.get_string(''value'');',
'        /* sport */',
'        l_sport := l_binding.get_object(''sport'');',
'        l_sport_value := l_sport.get_string(''value'');',
'        /* label */',
'        l_label := l_binding.get_object(''label'');',
'        l_label_value := l_label.get_string(''value'');',
'        /* geom */',
'        l_geom  := l_binding.get_object(''geom'');',
'        l_geom_value := l_geom.get_string(''value'');',
'        select',
'            to_number(regexp_substr(l_geom_value, ''[-0-9\.]+'', 1, 1)),',
'            to_number(regexp_substr(l_geom_value, ''[-0-9\.]+'', 1, 2))',
'        into l_geom_lon, l_geom_lat from dual;',
'        apex_collection.add_member(',
'            p_collection_name => C_COLNAME',
'            ,p_n001 => l_geom_lon',
'            ,p_n002 => l_geom_lat',
'            ,p_c001 => l_s_value',
'            ,p_c002 => l_label_value',
'            ,p_c003 => l_sport_value',
'        );',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(22676952357155111)
,p_internal_uid=>10439781719448723
);
wwv_flow_imp.component_end;
end;
/
