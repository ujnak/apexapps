prompt --workspace/credentials/rdf_graph_cred
begin
--   Manifest
--     CREDENTIAL: RDF Graph Cred
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>104
,p_default_id_offset=>10037808022949004
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(32811887152063186)
,p_name=>'RDF Graph Cred'
,p_static_id=>'RDF_Graph_Cred'
,p_authentication_type=>'BASIC'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
