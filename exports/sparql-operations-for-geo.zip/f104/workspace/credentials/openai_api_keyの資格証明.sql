prompt --workspace/credentials/openai_api_keyの資格証明
begin
--   Manifest
--     CREDENTIAL: openai api keyの資格証明
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>104
,p_default_id_offset=>12237625690706392
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(13043384975520105)
,p_name=>unistr('openai api key\306E\8CC7\683C\8A3C\660E')
,p_static_id=>'openai_api_key_'
,p_authentication_type=>'HTTP_HEADER'
,p_valid_for_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://api.openai.com/v1',
''))
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
