prompt --workspace/remote_servers/openai_api_key
begin
--   Manifest
--     REMOTE SERVER: OpenAI API Key
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>104
,p_default_id_offset=>12237625690706392
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(13043658548520106)
,p_name=>'OpenAI API Key'
,p_static_id=>'OPENAI_API_KEY'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('OPENAI_API_KEY'),'https://api.openai.com/v1')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('OPENAI_API_KEY'),'')
,p_server_type=>'GENERATIVE_AI'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('OPENAI_API_KEY'),'')
,p_credential_id=>wwv_flow_imp.id(13043384975520105)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('OPENAI_API_KEY'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('OPENAI_API_KEY'),'')
,p_prompt_on_install=>true
,p_ai_provider_type=>'OPENAI'
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('OPENAI_API_KEY'),'gpt-4.1-2025-04-14')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('OPENAI_API_KEY'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('OPENAI_API_KEY'),'')
);
wwv_flow_imp.component_end;
end;
/
