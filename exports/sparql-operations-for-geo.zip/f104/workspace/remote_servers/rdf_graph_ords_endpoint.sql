prompt --workspace/remote_servers/rdf_graph_ords_endpoint
begin
--   Manifest
--     REMOTE SERVER: RDF Graph ORDS Endpoint
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>104
,p_default_id_offset=>10037808022949004
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(32811586117058080)
,p_name=>'RDF Graph ORDS Endpoint'
,p_static_id=>'RDF_Graph_ORDS_Endpoint'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('RDF_Graph_ORDS_Endpoint'),'https://myserver-apexdev.adb.us-ashburn-1.oraclecloudapps.com/ords/apexdev/_/db-api/stable')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('RDF_Graph_ORDS_Endpoint'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('RDF_Graph_ORDS_Endpoint'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('RDF_Graph_ORDS_Endpoint'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('RDF_Graph_ORDS_Endpoint'),'')
,p_prompt_on_install=>true
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('RDF_Graph_ORDS_Endpoint'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('RDF_Graph_ORDS_Endpoint'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('RDF_Graph_ORDS_Endpoint'),'')
);
wwv_flow_imp.component_end;
end;
/
