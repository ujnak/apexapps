prompt --application/shared_components/data_profiles/resas産業小分類
begin
--   Manifest
--     DATA PROFILE: RESAS産業小分類
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(11060956060655619)
,p_name=>unistr('RESAS\7523\696D\5C0F\5206\985E')
,p_format=>'JSON'
,p_row_selector=>'result'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11061143299655624)
,p_data_profile_id=>wwv_flow_imp.id(11060956060655619)
,p_name=>'SIMCCODE'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_has_time_zone=>false
,p_selector=>'simcCode'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11061478159655624)
,p_data_profile_id=>wwv_flow_imp.id(11060956060655619)
,p_name=>'SISCCODE'
,p_sequence=>2
,p_is_primary_key=>true
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_has_time_zone=>false
,p_selector=>'siscCode'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11061785486655625)
,p_data_profile_id=>wwv_flow_imp.id(11060956060655619)
,p_name=>'SISCNAME'
,p_sequence=>3
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'siscName'
);
wwv_flow_imp.component_end;
end;
/
