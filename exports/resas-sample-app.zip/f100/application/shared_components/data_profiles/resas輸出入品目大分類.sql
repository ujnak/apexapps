prompt --application/shared_components/data_profiles/resas輸出入品目大分類
begin
--   Manifest
--     DATA PROFILE: RESAS輸出入品目大分類
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(11151338766013352)
,p_name=>unistr('RESAS\8F38\51FA\5165\54C1\76EE\5927\5206\985E')
,p_format=>'JSON'
,p_row_selector=>'result'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11151574944013353)
,p_data_profile_id=>wwv_flow_imp.id(11151338766013352)
,p_name=>'ITEMCODE1'
,p_sequence=>1
,p_is_primary_key=>true
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_has_time_zone=>false
,p_selector=>'itemCode1'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11151883742013353)
,p_data_profile_id=>wwv_flow_imp.id(11151338766013352)
,p_name=>'ITEMNAME1'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'itemName1'
);
wwv_flow_imp.component_end;
end;
/
