prompt --application/shared_components/data_profiles/resas農業部門
begin
--   Manifest
--     DATA PROFILE: RESAS農業部門
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(11132139286951580)
,p_name=>unistr('RESAS\8FB2\696D\90E8\9580')
,p_format=>'JSON'
,p_row_selector=>'result'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11132307058951581)
,p_data_profile_id=>wwv_flow_imp.id(11132139286951580)
,p_name=>'SECTIONCODE'
,p_sequence=>1
,p_is_primary_key=>true
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>1
,p_has_time_zone=>false
,p_selector=>'sectionCode'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11132698963951581)
,p_data_profile_id=>wwv_flow_imp.id(11132139286951580)
,p_name=>'SECTIONNAME'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'sectionName'
);
wwv_flow_imp.component_end;
end;
/
