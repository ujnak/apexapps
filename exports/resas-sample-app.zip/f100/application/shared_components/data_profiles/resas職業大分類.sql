prompt --application/shared_components/data_profiles/resas職業大分類
begin
--   Manifest
--     DATA PROFILE: RESAS職業大分類
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(11085398087704185)
,p_name=>unistr('RESAS\8077\696D\5927\5206\985E')
,p_format=>'JSON'
,p_row_selector=>'result'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11085524609704186)
,p_data_profile_id=>wwv_flow_imp.id(11085398087704185)
,p_name=>'ISCOCODE'
,p_sequence=>1
,p_is_primary_key=>true
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>1
,p_has_time_zone=>false
,p_selector=>'iscoCode'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11085881191704186)
,p_data_profile_id=>wwv_flow_imp.id(11085398087704185)
,p_name=>'ISCONAME'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'iscoName'
);
wwv_flow_imp.component_end;
end;
/
