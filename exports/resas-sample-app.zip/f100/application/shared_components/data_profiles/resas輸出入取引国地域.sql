prompt --application/shared_components/data_profiles/resas輸出入取引国地域
begin
--   Manifest
--     DATA PROFILE: RESAS輸出入取引国地域
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(11122291589894371)
,p_name=>unistr('RESAS\8F38\51FA\5165\53D6\5F15\56FD\5730\57DF')
,p_format=>'JSON'
,p_row_selector=>'result'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11122489984894372)
,p_data_profile_id=>wwv_flow_imp.id(11122291589894371)
,p_name=>'REGIONCODE'
,p_sequence=>1
,p_is_primary_key=>true
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_has_time_zone=>false
,p_selector=>'regionCode'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11122763716894372)
,p_data_profile_id=>wwv_flow_imp.id(11122291589894371)
,p_name=>'REGIONNAME'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'regionName'
);
wwv_flow_imp.component_end;
end;
/
