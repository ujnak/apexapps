prompt --application/shared_components/data_profiles/resas特許技術分野
begin
--   Manifest
--     DATA PROFILE: RESAS特許技術分野
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(11096356942767843)
,p_name=>unistr('RESAS\7279\8A31\6280\8853\5206\91CE')
,p_format=>'JSON'
,p_row_selector=>'result'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11096566699767843)
,p_data_profile_id=>wwv_flow_imp.id(11096356942767843)
,p_name=>'TECCODE'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>1
,p_has_time_zone=>false
,p_selector=>'tecCode'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(11096866446767844)
,p_data_profile_id=>wwv_flow_imp.id(11096356942767843)
,p_name=>'TECNAME'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'tecName'
);
wwv_flow_imp.component_end;
end;
/
