prompt --application/shared_components/automations/resas特許権者の所在地
begin
--   Manifest
--     AUTOMATION: RESAS特許権者の所在地
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_automation(
 p_id=>wwv_flow_imp.id(11140062173991665)
,p_name=>unistr('RESAS\7279\8A31\6A29\8005\306E\6240\5728\5730')
,p_static_id=>'resas-patents-locations'
,p_trigger_type=>'API'
,p_polling_status=>'DISABLED'
,p_result_type=>'ROWS'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_type=>'SQL'
,p_query_source=>'select prefCode, ''-'' as cityCode from resas_prefectures'
,p_include_rowid_column=>false
,p_commit_each_row=>false
,p_error_handling_type=>'IGNORE'
);
wwv_flow_imp_shared.create_automation_action(
 p_id=>wwv_flow_imp.id(11140338637991665)
,p_automation_id=>wwv_flow_imp.id(11140062173991665)
,p_name=>unistr('\540C\671F')
,p_execution_sequence=>10
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_parameters apex_exec.t_parameters;',
'BEGIN',
'    apex_exec.add_parameter(',
'        p_parameters      => l_parameters,',
'        p_name            => ''prefCode'',',
'        p_value           => :PREFCODE );',
'    apex_exec.add_parameter(',
'        p_parameters      => l_parameters,',
'        p_name            => ''cityCode'',',
'        p_value           => :CITYCODE );',
'    apex_rest_source_sync.dynamic_synchronize_data(',
'        p_module_static_id      => ''RESAS_patents_locations'',',
'        p_sync_static_id        => ''resas-patents-locations'',',
'        p_sync_parameters       => l_parameters );',
'END;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp.component_end;
end;
/
