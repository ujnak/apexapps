prompt --application/shared_components/automations/resas産業小分類
begin
--   Manifest
--     AUTOMATION: RESAS産業小分類
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_automation(
 p_id=>wwv_flow_imp.id(11063450158672488)
,p_name=>unistr('RESAS\7523\696D\5C0F\5206\985E')
,p_static_id=>'resas-industries-narrow'
,p_trigger_type=>'API'
,p_polling_status=>'DISABLED'
,p_result_type=>'ROWS'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_type=>'SQL'
,p_query_source=>'select simcCode from resas_industries_middle'
,p_include_rowid_column=>false
,p_commit_each_row=>false
,p_error_handling_type=>'IGNORE'
);
wwv_flow_imp_shared.create_automation_action(
 p_id=>wwv_flow_imp.id(11063705960672489)
,p_automation_id=>wwv_flow_imp.id(11063450158672488)
,p_name=>unistr('\540C\671F')
,p_execution_sequence=>10
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_parameters apex_exec.t_parameters;',
'BEGIN',
'    apex_exec.add_parameter(',
'        p_parameters      => l_parameters,',
'        p_name            => ''simcCode'',',
'        p_value           => :SIMCCODE );',
'',
'    apex_rest_source_sync.dynamic_synchronize_data(',
'        p_module_static_id      => ''RESAS_industries_narrow'',',
'        p_sync_static_id        => ''RESAS-industries-narrow'',',
'        p_sync_parameters       => l_parameters );',
'END;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp.component_end;
end;
/
