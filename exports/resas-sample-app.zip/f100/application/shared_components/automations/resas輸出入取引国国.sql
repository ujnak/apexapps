prompt --application/shared_components/automations/resas輸出入取引国国
begin
--   Manifest
--     AUTOMATION: RESAS輸出入取引国国
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_automation(
 p_id=>wwv_flow_imp.id(11128973804927957)
,p_name=>unistr('RESAS\8F38\51FA\5165\53D6\5F15\56FD\56FD')
,p_static_id=>'resas-regions-middle'
,p_trigger_type=>'API'
,p_polling_status=>'DISABLED'
,p_result_type=>'ROWS'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_type=>'SQL'
,p_query_source=>'select regionCode from resas_regions_broad'
,p_include_rowid_column=>false
,p_commit_each_row=>false
,p_error_handling_type=>'IGNORE'
);
wwv_flow_imp_shared.create_automation_action(
 p_id=>wwv_flow_imp.id(11129242891927957)
,p_automation_id=>wwv_flow_imp.id(11128973804927957)
,p_name=>unistr('\540C\671F')
,p_execution_sequence=>10
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_parameters apex_exec.t_parameters;',
'BEGIN',
'    apex_exec.add_parameter(',
'        p_parameters      => l_parameters,',
'        p_name            => ''regionCode'',',
'        p_value           => :REGIONCODE );',
'    apex_rest_source_sync.dynamic_synchronize_data(',
'        p_module_static_id      => ''RESAS_regions_middle'',',
'        p_sync_static_id        => ''resas-regions-middle'',',
'        p_sync_parameters       => l_parameters );',
'END;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp.component_end;
end;
/
