prompt --application/shared_components/web_sources/resas特許技術分野
begin
--   Manifest
--     WEB SOURCE: RESAS特許技術分野
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(11097156083767844)
,p_name=>unistr('RESAS\7279\8A31\6280\8853\5206\91CE')
,p_static_id=>'RESAS_patents_broad'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(11096356942767843)
,p_remote_server_id=>wwv_flow_imp.id(8155477406380472)
,p_url_path_prefix=>'patents/broad'
,p_credential_id=>wwv_flow_imp.id(9849488510118319)
,p_sync_table_name=>'RESAS_PATENTS_BROAD'
,p_sync_type=>'APPEND'
,p_sync_max_http_requests=>1000
,p_catalog_internal_name=>'RESAS'
,p_catalog_service_name=>unistr('RESAS\7279\8A31\6280\8853\5206\91CE')
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(11097316913767844)
,p_web_src_module_id=>wwv_flow_imp.id(11097156083767844)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
