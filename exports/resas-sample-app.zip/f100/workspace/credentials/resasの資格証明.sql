prompt --workspace/credentials/resasの資格証明
begin
--   Manifest
--     CREDENTIAL: RESASの資格証明
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(9849488510118319)
,p_name=>unistr('RESAS\306E\8CC7\683C\8A3C\660E')
,p_static_id=>'RESAS_API_KEY'
,p_authentication_type=>'HTTP_HEADER'
,p_valid_for_urls=>'https://opendata.resas-portal.go.jp/api/v1/'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
