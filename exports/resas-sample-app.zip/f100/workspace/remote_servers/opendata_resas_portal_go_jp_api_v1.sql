prompt --workspace/remote_servers/opendata_resas_portal_go_jp_api_v1
begin
--   Manifest
--     REMOTE SERVER: opendata-resas-portal-go-jp-api-v1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329863223023940
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(8155477406380472)
,p_name=>'opendata-resas-portal-go-jp-api-v1'
,p_static_id=>'opendata_resas_portal_go_jp_api_v1'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('opendata_resas_portal_go_jp_api_v1'),'https://opendata.resas-portal.go.jp/api/v1/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('opendata_resas_portal_go_jp_api_v1'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('opendata_resas_portal_go_jp_api_v1'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('opendata_resas_portal_go_jp_api_v1'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('opendata_resas_portal_go_jp_api_v1'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
