prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>191
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\30C9\30FC\30CA\30C4\30C1\30E3\30FC\30C8\306E\771F\3093\4E2D\306E\30E9\30D9\30EB')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230512083323'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79066514805976343)
,p_plug_name=>'donut'
,p_region_name=>'donut'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(85014952166828822)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(79066672464976344)
,p_region_id=>wwv_flow_imp.id(79066514805976343)
,p_chart_type=>'donut'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
'    options.pieCenter = {',
'        label: apex.items.P1_DEPTNO.displayValueFor(',
'            apex.items.P1_DEPTNO.value',
'        )',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(79066737518976345)
,p_chart_id=>wwv_flow_imp.id(79066672464976344)
,p_seq=>10
,p_name=>'sal'
,p_data_source_type=>'TABLE'
,p_ajax_items_to_submit=>'P1_DEPTNO'
,p_query_table=>'EMP'
,p_query_where=>'deptno = :P1_DEPTNO'
,p_include_rowid_column=>false
,p_items_value_column_name=>'SAL'
,p_items_label_column_name=>'ENAME'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85123804045828897)
,p_plug_name=>unistr('\30C9\30FC\30CA\30C4\30C1\30E3\30FC\30C8\306E\771F\3093\4E2D\306E\30E9\30D9\30EB')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(84981997277828804)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79066461028976342)
,p_name=>'P1_DEPTNO'
,p_item_sequence=>10
,p_prompt=>'DEPT'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select dname d, deptno from dept'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(85085365522828864)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79067079058976348)
,p_name=>'onChange'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_DEPTNO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79067263767976350)
,p_event_id=>wwv_flow_imp.id(79067079058976348)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.region("donut").widget().ojChart(',
'    {',
'        pieCenter: {',
'            label: apex.items.P1_DEPTNO.displayValueFor(',
'                apex.items.P1_DEPTNO.value',
'            )',
'        }',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79067132340976349)
,p_event_id=>wwv_flow_imp.id(79067079058976348)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(79066514805976343)
);
wwv_flow_imp.component_end;
end;
/
