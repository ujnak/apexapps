prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>156
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Force-directed graph'
,p_alias=>'FORCE-DIRECTED-GRAPH'
,p_step_title=>'Force-directed graph'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "d3": "https://cdn.jsdelivr.net/npm/d3/+esm"',
'        }',
'    }',
'</script>'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77428011687884382)
,p_plug_name=>'D3'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(42103395290142684)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="myChart""></div>',
'<script type="module">',
'import * as d3 from ''d3'';',
'',
'/*',
unistr('\3000\3000* \4EE5\4E0B\306FD3\306EForce-directred graph\306EExamples\3088\308A'),
' * ',
unistr(' * \51FA\5178\5143\FF1A'),
' * https://observablehq.com/@d3/force-directed-graph/2',
' */',
unistr('// chart\306F\30D5\30A1\30F3\30AF\30B7\30E7\30F3\3068\3059\308B\305F\3081const chart = (data) => {\306B\5909\66F4'),
'const chart = (data) => {',
'  // Specify the dimensions of the chart.',
'  const width = 928;',
'  const height = 600;',
'',
'  // Specify the color scale.',
'  const color = d3.scaleOrdinal(d3.schemeCategory10);',
'',
'  // The force simulation mutates links and nodes, so create a copy',
'  // so that re-evaluating this cell produces the same result.',
'  const links = data.links.map(d => ({...d}));',
'  const nodes = data.nodes.map(d => ({...d}));',
'',
'  // Create a simulation with several forces.',
'  const simulation = d3.forceSimulation(nodes)',
'      .force("link", d3.forceLink(links).id(d => d.id))',
'      .force("charge", d3.forceManyBody())',
'      .force("center", d3.forceCenter(width / 2, height / 2))',
'      .on("tick", ticked);',
'',
'  // Create the SVG container.',
'  const svg = d3.create("svg")',
'      .attr("width", width)',
'      .attr("height", height)',
'      .attr("viewBox", [0, 0, width, height])',
'      .attr("style", "max-width: 100%; height: auto;");',
'',
'  // Add a line for each link, and a circle for each node.',
'  const link = svg.append("g")',
'      .attr("stroke", "#999")',
'      .attr("stroke-opacity", 0.6)',
'    .selectAll()',
'    .data(links)',
'    .join("line")',
'      .attr("stroke-width", d => Math.sqrt(d.value));',
'',
'  const node = svg.append("g")',
'      .attr("stroke", "#fff")',
'      .attr("stroke-width", 1.5)',
'    .selectAll()',
'    .data(nodes)',
'    .join("circle")',
'      .attr("r", 5)',
'      .attr("fill", d => color(d.group));',
'',
'  node.append("title")',
'      .text(d => d.id);',
'',
'  // Add a drag behavior.',
'  node.call(d3.drag()',
'        .on("start", dragstarted)',
'        .on("drag", dragged)',
'        .on("end", dragended));',
'',
'  // Set the position attributes of links and nodes each time the simulation ticks.',
'  function ticked() {',
'    link',
'        .attr("x1", d => d.source.x)',
'        .attr("y1", d => d.source.y)',
'        .attr("x2", d => d.target.x)',
'        .attr("y2", d => d.target.y);',
'',
'    node',
'        .attr("cx", d => d.x)',
'        .attr("cy", d => d.y);',
'  }',
'',
'  // Reheat the simulation when drag starts, and fix the subject position.',
'  function dragstarted(event) {',
'    if (!event.active) simulation.alphaTarget(0.3).restart();',
'    event.subject.fx = event.subject.x;',
'    event.subject.fy = event.subject.y;',
'  }',
'',
'  // Update the subject (dragged node) position during drag.',
'  function dragged(event) {',
'    event.subject.fx = event.x;',
'    event.subject.fy = event.y;',
'  }',
'',
'  // Restore the target alpha so the simulation cools after dragging ends.',
unistr('  // Unfix the subject position now that it\2019s no longer being dragged.'),
'  function dragended(event) {',
'    if (!event.active) simulation.alphaTarget(0);',
'    event.subject.fx = null;',
'    event.subject.fy = null;',
'  }',
'',
unistr('  // When this cell is re-run, stop the previous simulation. (This doesn\2019t'),
'  // really matter since the target alpha is zero and the simulation will',
unistr('  // stop naturally, but it\2019s a good practice.)'),
unistr('  // \4EE5\4E0B\306FOracle APEX\306E\30DA\30FC\30B8\306B\306F\5B9F\88C5\3055\308C\3066\3044\306A\3044\3002'),
'  // invalidation.then(() => simulation.stop());',
'',
'  return svg.node();',
'};',
'',
'/*',
unistr(' * D3\306EExamples\3088\308A\8EE2\8A18\3057\305F\30C1\30E3\30FC\30C8\306E\5B9F\88C5\306F\4EE5\4E0A\3067\7D42\4E86\3002'),
' * ',
unistr(' * \4EE5\4E0B\306FOracle APEX\3067\306E\30C1\30E3\30FC\30C8\8868\793A\3002'),
' */',
'apex.server.process(',
'    "GET_DATA",',
'    {',
unistr('        x01: ''miserable.json'' // apex_application.g_x01\306B\30D5\30A1\30A4\30EB\540D\3092\6E21\3059'),
'    },',
'    {',
'        success: function( response ) {',
unistr('            // \30C1\30E3\30FC\30C8\63CF\753B\306EJSON\3092response\3068\3057\3066\53D7\3051\53D6\308B\3002'),
'            document.getElementById("myChart").append(chart(response));',
'        }',
'    }',
');',
'</script>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84650037859762183)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(42115784405142710)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(42000045318142439)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(42178560174142853)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42328096929488952)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_name ebaj_d3_graphs.name%type;',
'    l_data clob;',
'    l_amount integer;',
'    l_offset integer;',
'begin',
'    l_name := apex_application.g_x01;',
'    select graph_data into l_data from ebaj_d3_graphs',
'    where name = l_name;',
'    l_amount := dbms_lob.getlength(l_data);',
'    l_offset := 1;',
'    apex_debug.info(''data found for %s, %s'', l_name, l_amount);',
'    while( l_amount > 0 )',
'    loop',
'        htp.p(dbms_lob.substr(l_data, 30000, l_offset));',
'        l_amount := l_amount - 30000;',
'        l_offset := l_offset + 30000;',
'    end loop;',
'exception',
'    when others then',
'        apex_debug.info(''no data found for %s, %s'', l_name, SQLERRM );',
'        htp.p(''{}'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>42328096929488952
);
wwv_flow_imp.component_end;
end;
/
