prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>156
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Hierarchical edge bundling II'
,p_alias=>'HIERARCHICAL-EDGE-BUNDLING-II'
,p_step_title=>'Hierarchical edge bundling II'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "d3": "https://cdn.jsdelivr.net/npm/d3/+esm"',
'        }',
'    }',
'</script>'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(35101841314395443)
,p_plug_name=>'D3'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(42103395290142684)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="myChart""></div>',
'<script type="module">',
'import * as d3 from ''d3'';',
'',
'/*',
unistr('\3000\3000* \4EE5\4E0B\306FD3\306EHierarchical edge bundling II\306EExamples\3088\308A'),
unistr(' * Observable Template\3067\306F\306A\304F\3001\7D20\306EJavaScript\3067\52D5\4F5C\3059\308B\3088\3046\306B'),
unistr(' * \30B3\30FC\30C9\306F\82E5\5E72\6539\5909\3057\3066\3044\308B\3002'),
' * ',
unistr(' * \51FA\5178\5143\FF1A'),
' * https://observablehq.com/@d3/hierarchical-edge-bundling/2',
' */',
unistr('// const\3092\52A0\3048\3066\30D5\30A1\30F3\30AF\30B7\30E7\30F3\5316'),
'const color = t => d3.interpolateRdBu(1 - t);',
'',
unistr('// BezierCurve \306F\5B9F\884C\5F62\5F0F\3067\306A\304Fclass\5B9A\7FA9\306B\5909\66F4'),
'// BezierCurbe = {',
'const l1 = [4 / 8, 4 / 8, 0 / 8, 0 / 8];',
'const l2 = [2 / 8, 4 / 8, 2 / 8, 0 / 8];',
'const l3 = [1 / 8, 3 / 8, 3 / 8, 1 / 8];',
'const r1 = [0 / 8, 2 / 8, 4 / 8, 2 / 8];',
'const r2 = [0 / 8, 0 / 8, 4 / 8, 4 / 8];',
'',
'function dot([ka, kb, kc, kd], {a, b, c, d}) {',
'    return [',
'        ka * a[0] + kb * b[0] + kc * c[0] + kd * d[0],',
'        ka * a[1] + kb * b[1] + kc * c[1] + kd * d[1]',
'    ];',
'}',
'',
unistr('// return\306F\4E0D\8981'),
'class BezierCurve {',
'    constructor(a, b, c, d) {',
'        this.a = a;',
'        this.b = b;',
'        this.c = c;',
'        this.d = d;',
'    }',
'    split() {',
'        const m = dot(l3, this);',
'        return [',
'            new BezierCurve(this.a, dot(l1, this), dot(l2, this), m),',
'            new BezierCurve(m, dot(r1, this), dot(r2, this), this.d)',
'        ];',
'    }',
'    toString() {',
'        return `M${this.a}C${this.b},${this.c},${this.d}`;',
'    }',
'};',
'',
unistr('// Line\306F\305D\306E\307E\307E'),
'class Line {',
'    constructor(a, b) {',
'        this.a = a;',
'        this.b = b;',
'    }',
'    split() {',
'        const {a, b} = this;',
'        const m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];',
'        return [new Line(a, m), new Line(m, b)];',
'    }',
'    toString() {',
'        return `M${this.a}L${this.b}`;',
'    }',
'};',
'',
unistr('// Path\3082\305D\306E\307E\307E'),
'class Path {',
'    constructor(_) {',
'        this._ = _;',
'        this._m = undefined;',
'    }',
'    moveTo(x, y) {',
'        this._ = [];',
'        this._m = [x, y];',
'    }',
'    lineTo(x, y) {',
'        this._.push(new Line(this._m, this._m = [x, y]));',
'    }',
'    bezierCurveTo(ax, ay, bx, by, x, y) {',
'        this._.push(new BezierCurve(this._m, [ax, ay], [bx, by], this._m = [x, y]));',
'    }',
'    *split(k = 0) {',
'        const n = this._.length;',
'        const i = Math.floor(n / 2);',
'        const j = Math.ceil(n / 2);',
'        const a = new Path(this._.slice(0, i));',
'        const b = new Path(this._.slice(j));',
'        if (i !== j) {',
'            const [ab, ba] = this._[i].split();',
'            a._.push(ab);',
'            b._.unshift(ba);',
'        }',
'        if (k > 1) {',
'            yield* a.split(k - 1);',
'            yield* b.split(k - 1);',
'        } else {',
'            yield a;',
'            yield b;',
'        }',
'    }',
'    toString() {',
'        return this._.join("");',
'    }',
'};',
'',
unistr('// id\3082\305D\306E\307E\307E'),
'function id(node) {',
'    return `${node.parent ? id(node.parent) + "." : ""}${node.data.name}`;',
'};',
'',
unistr('// bilink\3082\305D\306E\307E\307E'),
'function bilink(root) {',
'    const map = new Map(root.leaves().map(d => [id(d), d]));',
'    for (const d of root.leaves()) d.incoming = [], d.outgoing = d.data.imports.map(i => [d, map.get(i)]);',
'    for (const d of root.leaves()) for (const o of d.outgoing) o[1].incoming.push(o);',
'    return root;',
'};',
'',
unistr('// hierarchy\3082\305D\306E\307E\307E'),
'function hierarchy(data, delimiter = ".") {',
'    let root;',
'    const map = new Map;',
'    data.forEach(function find(data) {',
'        const {name} = data;',
'        if (map.has(name)) return map.get(name);',
'        const i = name.lastIndexOf(delimiter);',
'        map.set(name, data);',
'        if (i >= 0) {',
'            find({name: name.substring(0, i), children: []}).children.push(data);',
'            data.name = name.substring(i + 1);',
'        } else {',
'            root = data;',
'        }',
'        return data;',
'    });',
'    return root;',
'};',
'',
unistr('// chart\306F\30D5\30A1\30F3\30AF\30B7\30E7\30F3\3068\3059\308B\305F\3081const chart = (data) => {\306B\5909\66F4'),
'const chart = (data) => {',
'    const width = 954;',
'    const radius = width / 2;',
'    const k = 6; // 2^k colors segments per curve',
'',
'    const tree = d3.cluster()',
'        .size([2 * Math.PI, radius - 100]);',
'    const root = tree(bilink(d3.hierarchy(data)',
'        .sort((a, b) => d3.ascending(a.height, b.height) || d3.ascending(a.data.name, b.data.name))));',
'',
'    const svg = d3.create("svg")',
'        .attr("width", width)',
'        .attr("height", width)',
'        .attr("viewBox", [-width / 2, -width / 2, width, width])',
'        .attr("style", "max-width: 100%; height: auto; font: 10px sans-serif;");',
'',
'    const node = svg.append("g")',
'        .selectAll()',
'        .data(root.leaves())',
'        .join("g")',
'        .attr("transform", d => `rotate(${d.x * 180 / Math.PI - 90}) translate(${d.y},0)`)',
'        .append("text")',
'        .attr("dy", "0.31em")',
'        .attr("x", d => d.x < Math.PI ? 6 : -6)',
'        .attr("text-anchor", d => d.x < Math.PI ? "start" : "end")',
'        .attr("transform", d => d.x >= Math.PI ? "rotate(180)" : null)',
'        .text(d => d.data.name)',
'        .call(text => text.append("title").text(d => `${id(d)}',
'    ${d.outgoing.length} outgoing',
'    ${d.incoming.length} incoming`));',
'',
'    const line = d3.lineRadial()',
'        .curve(d3.curveBundle)',
'        .radius(d => d.y)',
'        .angle(d => d.x);',
'',
'    const path = ([source, target]) => {',
'        const p = new Path;',
'        line.context(p)(source.path(target));',
'        return p;',
'    };',
'',
'    svg.append("g")',
'        .attr("fill", "none")',
'        .selectAll()',
'        .data(d3.transpose(root.leaves()',
'        .flatMap(leaf => leaf.outgoing.map(path))',
'        .map(path => Array.from(path.split(k)))))',
'        .join("path")',
'        .style("mix-blend-mode", "darken")',
'        .attr("stroke", (d, i) => color(d3.easeQuad(i / ((1 << k) - 1))))',
'        .attr("d", d => d.join(""));',
'',
'    return svg.node();',
'};',
'',
'/*',
unistr(' * D3\306EExamples\3088\308A\8EE2\8A18\3057\305F\30C1\30E3\30FC\30C8\306E\5B9F\88C5\306F\4EE5\4E0A\3067\7D42\4E86\3002'),
' * ',
unistr(' * \4EE5\4E0B\306FOracle APEX\3067\306E\30C1\30E3\30FC\30C8\8868\793A\3002'),
' */',
'apex.server.process(',
'    "GET_DATA",',
'    {',
unistr('        x01: ''flare.json'' // apex_application.g_x01\306B\30D5\30A1\30A4\30EB\540D\3092\6E21\3059'),
'    },',
'    {',
'        success: function( response ) {',
unistr('            // \30C1\30E3\30FC\30C8\63CF\753B\306EJSON\3092response\3068\3057\3066\53D7\3051\53D6\308B\3002'),
'            let data = hierarchy(response);',
'            document.getElementById("myChart").append(chart(data));',
'        }',
'    }',
');',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42323867486273244)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(42115784405142710)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(42000045318142439)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(42178560174142853)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35101791068395442)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_name ebaj_d3_graphs.name%type;',
'    l_data clob;',
'    l_amount integer;',
'    l_offset integer;',
'begin',
'    l_name := apex_application.g_x01;',
'    select graph_data into l_data from ebaj_d3_graphs',
'    where name = l_name;',
'    l_amount := dbms_lob.getlength(l_data);',
'    l_offset := 1;',
'    apex_debug.info(''data found for %s, %s'', l_name, l_amount);',
'    while( l_amount > 0 )',
'    loop',
'        htp.p(dbms_lob.substr(l_data, 30000, l_offset));',
'        l_amount := l_amount - 30000;',
'        l_offset := l_offset + 30000;',
'    end loop;',
'exception',
'    when others then',
'        apex_debug.info(''no data found for %s, %s'', l_name, SQLERRM );',
'        htp.p(''{}'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>35101791068395442
);
wwv_flow_imp.component_end;
end;
/
