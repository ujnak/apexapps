prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>156
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'World tour'
,p_alias=>'WORLD-TOUR'
,p_step_title=>'World tour'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "d3": "https://cdn.jsdelivr.net/npm/d3/+esm",',
'            "topojson-client": "https://cdn.jsdelivr.net/npm/topojson-client/+esm"',
'        }',
'    }',
'</script>'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(120416163822707274)
,p_plug_name=>'D3'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(42103395290142684)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="myChart""></div>',
'<script type="module">',
'import * as d3 from ''d3'';',
'import * as topojson from ''topojson-client'';',
'',
'/*',
' * read countries-110m.json from the server ',
' */',
'var world;',
'',
'async function getData( fileName ) {',
'    return apex.server.process(',
'        "GET_DATA",',
'        {',
unistr('            x01: fileName // apex_application.g_x01\306B\30D5\30A1\30A4\30EB\540D\3092\6E21\3059'),
'        }',
'    ).done( ( response ) => {',
'        world = response;',
'    })',
'};',
'await getData ( ''countries-110m.json'' );',
'apex.debug.info( world );',
'',
'/*',
unistr('\3000\3000* \4EE5\4E0B\306FD3\306EWorld tour\306EExamples\3088\308A'),
' * ',
unistr(' * \51FA\5178\5143\FF1A'),
' * https://observablehq.com/@d3/world-tour',
' */',
'const land = topojson.feature(world, world.objects.land);',
'const borders = topojson.mesh(world, world.objects.countries, (a, b) => a !== b);',
'const countries = topojson.feature(world, world.objects.countries).features;',
'var name = null;',
'',
'class Versor {',
'  static fromAngles([l, p, g]) {',
'    l *= Math.PI / 360;',
'    p *= Math.PI / 360;',
'    g *= Math.PI / 360;',
'    const sl = Math.sin(l), cl = Math.cos(l);',
'    const sp = Math.sin(p), cp = Math.cos(p);',
'    const sg = Math.sin(g), cg = Math.cos(g);',
'    return [',
'      cl * cp * cg + sl * sp * sg,',
'      sl * cp * cg - cl * sp * sg,',
'      cl * sp * cg + sl * cp * sg,',
'      cl * cp * sg - sl * sp * cg',
'    ];',
'  }',
'  static toAngles([a, b, c, d]) {',
'    return [',
'      Math.atan2(2 * (a * b + c * d), 1 - 2 * (b * b + c * c)) * 180 / Math.PI,',
'      Math.asin(Math.max(-1, Math.min(1, 2 * (a * c - d * b)))) * 180 / Math.PI,',
'      Math.atan2(2 * (a * d + b * c), 1 - 2 * (c * c + d * d)) * 180 / Math.PI',
'    ];',
'  }',
'  static interpolateAngles(a, b) {',
'    const i = Versor.interpolate(Versor.fromAngles(a), Versor.fromAngles(b));',
'    return t => Versor.toAngles(i(t));',
'  }',
'  static interpolateLinear([a1, b1, c1, d1], [a2, b2, c2, d2]) {',
'    a2 -= a1, b2 -= b1, c2 -= c1, d2 -= d1;',
'    const x = new Array(4);',
'    return t => {',
'      const l = Math.hypot(x[0] = a1 + a2 * t, x[1] = b1 + b2 * t, x[2] = c1 + c2 * t, x[3] = d1 + d2 * t);',
'      x[0] /= l, x[1] /= l, x[2] /= l, x[3] /= l;',
'      return x;',
'    };',
'  }',
'  static interpolate([a1, b1, c1, d1], [a2, b2, c2, d2]) {',
'    let dot = a1 * a2 + b1 * b2 + c1 * c2 + d1 * d2;',
'    if (dot < 0) a2 = -a2, b2 = -b2, c2 = -c2, d2 = -d2, dot = -dot;',
'    if (dot > 0.9995) return Versor.interpolateLinear([a1, b1, c1, d1], [a2, b2, c2, d2]); ',
'    const theta0 = Math.acos(Math.max(-1, Math.min(1, dot)));',
'    const x = new Array(4);',
'    const l = Math.hypot(a2 -= a1 * dot, b2 -= b1 * dot, c2 -= c1 * dot, d2 -= d1 * dot);',
'    a2 /= l, b2 /= l, c2 /= l, d2 /= l;',
'    return t => {',
'      const theta = theta0 * t;',
'      const s = Math.sin(theta);',
'      const c = Math.cos(theta);',
'      x[0] = a1 * c + a2 * s;',
'      x[1] = b1 * c + b2 * s;',
'      x[2] = c1 * c + c2 * s;',
'      x[3] = d1 * c + d2 * s;',
'      return x;',
'    };',
'  }',
'}',
'',
'  /*',
'   * Adding code for APEX. -- start',
'   */',
'  const div = document.getElementById("myChart");',
'  const width = div.clientWidth;',
'  console.log(''width of myChart'', width);',
'  /*',
'   * Adding code for APEX. -- end',
'   */',
'',
unistr('  // Specify the chart\2019s dimensions.'),
'  const height = Math.min(width, 720); // Observable sets a responsive *width*',
'',
'  // Prepare a canvas.',
'  const dpr = window.devicePixelRatio ?? 1;',
'  const canvas = d3.create("canvas")',
'      .attr("width", dpr * width)',
'      .attr("height", dpr * height)',
'      .style("width", `${width}px`);',
'  const context = canvas.node().getContext("2d");',
'  context.scale(dpr, dpr);',
'',
'  // Create a projection and a path generator.',
'  const projection = d3.geoOrthographic().fitExtent([[10, 10], [width - 10, height - 10]], {type: "Sphere"});',
'  const path = d3.geoPath(projection, context);',
'  const tilt = 20;',
'',
'  function render(country, arc) {',
'    context.clearRect(0, 0, width, height);',
'    context.beginPath(), path(land), context.fillStyle = "#ccc", context.fill();',
'    context.beginPath(), path(country), context.fillStyle = "#f00", context.fill();',
'    context.beginPath(), path(borders), context.strokeStyle = "#fff", context.lineWidth = 0.5, context.stroke();',
'    context.beginPath(), path({type: "Sphere"}), context.strokeStyle = "#000", context.lineWidth = 1.5, context.stroke();',
'    context.beginPath(), path(arc), context.stroke();',
'    return context.canvas;',
'  }',
'',
'  let p1, p2 = [0, 0], r1, r2 = [0, 0, 0];',
'  for (const country of countries) {',
'    // mutable name = country.properties.name;',
'    name = country.properties.name;',
'    // yield render(country);',
'    render(country);',
'    ',
'    /*',
'     * Adding code for APEX -- start',
'     */',
'    div.appendChild(canvas.node());',
'    apex.item("P6_NAME").setValue(name);',
'    /*',
'     * Adding code for APEX -- end',
'     */',
'    ',
'    p1 = p2, p2 = d3.geoCentroid(country);',
'    r1 = r2, r2 = [-p2[0], tilt - p2[1], 0];',
'    const ip = d3.geoInterpolate(p1, p2);',
'    const iv = Versor.interpolateAngles(r1, r2);',
'',
'    await d3.transition()',
'        .duration(1250)',
'        .tween("render", () => t => {',
'          projection.rotate(iv(t));',
'          render(country, {type: "LineString", coordinates: [p1, ip(t)]});',
'        })',
'      .transition()',
'        .tween("render", () => t => {',
'          render(country, {type: "LineString", coordinates: [ip(t), p2]});',
'        })',
'      .end();',
'    }',
'    ',
'</script>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127638189994585075)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(42115784405142710)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(42000045318142439)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(42178560174142853)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35102023563395445)
,p_name=>'P6_NAME'
,p_item_sequence=>10
,p_prompt=>'Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(42174453828142843)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42989928996823002)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_name ebaj_d3_graphs.name%type;',
'    l_data clob;',
'    /* Generous number of characters that can be stored in l_buffer */',
'    l_amount integer := 4000;',
'    l_offset integer := 1;',
'    l_total  integer;',
'    l_buffer varchar2(32767);',
'begin',
'    l_name := apex_application.g_x01;',
'    select graph_data into l_data from ebaj_d3_graphs',
'    where name = l_name;',
'    l_total := dbms_lob.getlength( l_data );',
'    apex_debug.info(''data found for %s, %s'', l_name, l_total);',
'    while ( l_offset < l_total )',
'    loop',
'        dbms_lob.read( l_data, l_amount, l_offset, l_buffer );',
'        htp.prn( l_buffer );',
'        l_offset := l_offset + l_amount;',
'    end loop;',
'exception',
'    when others then',
'        apex_debug.info(''no data found for %s, %s'', l_name, SQLERRM );',
'        htp.prn(''{}'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>42989928996823002
);
wwv_flow_imp.component_end;
end;
/
