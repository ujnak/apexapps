prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9930343173359963
,p_default_application_id=>100
,p_default_id_offset=>16731726318329929
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>unistr('\30AF\30EA\30C7\30F3\30B7\30E3\30EB')
,p_alias=>unistr('\30AF\30EA\30C7\30F3\30B7\30E3\30EB')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\30AF\30EA\30C7\30F3\30B7\30E3\30EB')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41466507885613375)
,p_plug_name=>unistr('\30AF\30EA\30C7\30F3\30B7\30E3\30EB\306E\30C6\30B9\30C8')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P2_CREDENTIAL_NAME'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41682427525213413)
,p_plug_name=>unistr('\30AF\30EA\30C7\30F3\30B7\30E3\30EB')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'select credential_name, username from user_credentials'
,p_is_editable=>true
,p_edit_operations=>'i:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41684194569213418)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41686610666213425)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(41466507885613375)
,p_button_name=>'B_GET_NAMESPACE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Get Namespace'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P2_CREDENTIAL_NAME'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41684615671213419)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(41684194569213418)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41686216653213424)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(41684194569213418)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P2_CREDENTIAL_NAME'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41687023319213425)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(41684194569213418)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P2_CREDENTIAL_NAME'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41465587776613366)
,p_name=>'P2_TENANCY'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(41682427525213413)
,p_prompt=>'Tenancy OCID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41465724801613367)
,p_name=>'P2_FINGERPRINT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(41682427525213413)
,p_prompt=>'Fingerprint'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41465797877613368)
,p_name=>'P2_PRIVATE_KEY'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(41682427525213413)
,p_prompt=>'Private Key'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41466612112613376)
,p_name=>'P2_REGION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(41466507885613375)
,p_prompt=>'Region'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41466710381613377)
,p_name=>'P2_NAMESPACE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(41466507885613375)
,p_prompt=>'Namespace'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41682782251213414)
,p_name=>'P2_CREDENTIAL_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(41682427525213413)
,p_item_source_plug_id=>wwv_flow_imp.id(41682427525213413)
,p_prompt=>'Credential Name'
,p_source=>'CREDENTIAL_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when=>'P2_CREDENTIAL_NAME'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41683193946213415)
,p_name=>'P2_USERNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(41682427525213413)
,p_item_source_plug_id=>wwv_flow_imp.id(41682427525213413)
,p_prompt=>'User OCID'
,p_source=>'USERNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>128
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41684681757213419)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(41684615671213419)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41685504575213421)
,p_event_id=>wwv_flow_imp.id(41684681757213419)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41466786261613378)
,p_name=>unistr('\30CD\30FC\30E0\30B9\30DA\30FC\30B9\306E\53D6\5F97')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(41686610666213425)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41466891240613379)
,p_event_id=>wwv_flow_imp.id(41466786261613378)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'PL/SQL SDK'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    response dbms_cloud_oci_obs_object_storage_get_namespace_response_t;',
'begin',
'    response := dbms_cloud_oci_obs_object_storage.get_namespace(',
'        compartment_id => null',
'        , region => :P2_REGION',
'        , credential_name => :P2_CREDENTIAL_NAME',
'    );',
'    if response.status_code != 200 then',
'        :P2_NAMESPACE := to_char(response.status_code, ''9999'');',
'    else',
'        :P2_NAMESPACE := response.response_body;',
'    end if;',
'end;'))
,p_attribute_02=>'P2_CREDENTIAL_NAME,P2_REGION'
,p_attribute_03=>'P2_NAMESPACE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_build_option_id=>wwv_flow_imp.id(27716222211350875)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(27710992922347131)
,p_event_id=>wwv_flow_imp.id(41466786261613378)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'SEND_REQUEST'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_resp dbms_cloud_types.resp;',
'    l_uri varchar2(400);',
'begin',
'    l_uri := apex_string.format(''https://objectstorage.%s.oraclecloud.com/n/'', :P2_REGION);',
'    /*',
unistr('    * utl_http.set_wallet\306F\521D\671F\5316\30D1\30E9\30E1\30FC\30BF\306EWALLET_ROOT\304Csystem:\3067\3042\308C\3070\4E0D\8981\3002'),
'    */',
'    -- utl_http.set_wallet(''system:'');',
'    l_resp := dbms_cloud.send_request(',
'        credential_name => :P2_CREDENTIAL_NAME',
'        ,uri => l_uri',
'        ,method => DBMS_CLOUD.METHOD_GET',
'    );',
'    :P2_NAMESPACE := dbms_cloud.get_response_text(l_resp);',
'end;'))
,p_attribute_02=>'P2_CREDENTIAL_NAME,P2_REGION'
,p_attribute_03=>'P2_NAMESPACE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41687831600213426)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(41682427525213413)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0\30AF\30EA\30C7\30F3\30B7\30E3\30EB')
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_private_key varchar2(4000);',
'    l_end integer;',
'begin',
'    case',
'    when :APEX$ROW_STATUS = ''C'' then',
unistr('        -- \4EE5\4E0B\3088\308A\3001\79D8\5BC6\9375\3092\4E00\884C\306B\3059\308B\3002'),
'        l_private_key := :P2_PRIVATE_KEY;',
unistr('        -- MII\3088\308A\524D\306E\6587\5B57\3092\524A\9664\3059\308B\3002'),
'        l_private_key := substr(l_private_key, instr(l_private_key, ''MII''));',
unistr('        -- ''-----END''\4EE5\964D\306E\6587\5B57\3092\524A\9664\3059\308B\3002\898B\3064\304B\3089\306A\3044\5834\5408\306F\5909\66F4\306A\3057\3002'),
'        l_end := instr(l_private_key, ''-----END'');',
'        if l_end > 0 then',
'            l_private_key := substr(l_private_key, 1, (l_end-1));',
'        end if;',
unistr('        -- \6587\5B57\5217\304B\3089 CR(13) \3068 LF(10) \3092\53D6\308A\9664\304F\3002'),
'        l_private_key := replace(l_private_key, CHR(10));',
'        l_private_key := replace(l_private_key, CHR(13));',
unistr('        -- \30AF\30EA\30C7\30F3\30B7\30E3\30EB\3092\767B\9332\3059\308B\3002'),
'        dbms_cloud.create_credential(',
'            credential_name => :P2_CREDENTIAL_NAME',
'            , user_ocid     => :P2_USERNAME',
'            , tenancy_ocid  => :P2_TENANCY',
'            , private_key   => :P2_PRIVATE_KEY',
'            , fingerprint   => :P2_FINGERPRINT',
'        );',
'    when :APEX$ROW_STATUS = ''D'' then',
unistr('        -- \30AF\30EA\30C7\30F3\30B7\30E3\30EB\3092\524A\9664\3059\308B\3002'),
'        dbms_cloud.drop_credential(',
'            credential_name => :P2_CREDENTIAL_NAME',
'        );',
'    end case;',
'end;'))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>24956105281883497
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41688237004213426)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>24956510685883497
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41687413958213426)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(41682427525213413)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0\30AF\30EA\30C7\30F3\30B7\30E3\30EB')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>24955687639883497
);
wwv_flow_imp.component_end;
end;
/
