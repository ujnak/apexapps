prompt --application/shared_components/user_interface/lovs/login_remember_username
begin
--   Manifest
--     LOGIN_REMEMBER_USERNAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>4558970047759359
,p_default_application_id=>100
,p_default_id_offset=>4955450716908812
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(53381436882761355)
,p_lov_name=>'LOGIN_REMEMBER_USERNAME'
,p_lov_query=>'.'||wwv_flow_imp.id(53381436882761355)||'.'
,p_location=>'STATIC'
,p_version_scn=>44427512555591
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(53381868764761357)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>unistr('\30E6\30FC\30B6\30FC\540D\3092\8A18\61B6')
,p_lov_return_value=>'Y'
);
wwv_flow_imp.component_end;
end;
/
