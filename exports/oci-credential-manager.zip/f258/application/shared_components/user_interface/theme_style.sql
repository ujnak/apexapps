prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 258
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>258
,p_default_id_offset=>10676612165908724
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(24914814859709799)
,p_theme_id=>42
,p_name=>'Vista'
,p_css_file_urls=>'#THEME_IMAGES#css/Vista#MIN#.css?v=#APEX_VERSION#'
,p_is_public=>false
,p_is_accessible=>false
,p_theme_roller_read_only=>true
,p_reference_id=>4007676303523989775
);
wwv_flow_imp.component_end;
end;
/
