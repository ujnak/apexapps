prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>246
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Motion'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[module,defer]#APP_FILES#js/quick-start-motion#MIN#.js'
,p_css_file_urls=>'#APP_FILES#css/quick-start-motion#MIN#.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(132167812330799537)
,p_plug_name=>'Create an animation - Rotate'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div class="box"></div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(132168131940799540)
,p_plug_name=>'What can be animated? - Three.js'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div id="three-container"></div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(132168347817799542)
,p_plug_name=>'Customizing animations - Basic animation'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div class="box2"></div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(132168525050799544)
,p_plug_name=>'Customizing animations - Spring'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div class="box3"></div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(132168759404799546)
,p_plug_name=>'Customizing animations - Stagger'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <ul class="example">',
'        <li></li>',
'        <li></li>',
'        <li></li>',
'        <li></li>',
'    </ul>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133148537923747896)
,p_plug_name=>'Sample Motion'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(132917446213747218)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132167962032799538)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(132167812330799537)
,p_button_name=>'ANIMATE_ROTATE'
,p_button_static_id=>'ANIMATE_ROTATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Rotate'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132168256119799541)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(132168131940799540)
,p_button_name=>'ANIMATE_THREE'
,p_button_static_id=>'ANIMATE_THREE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Three'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132168444230799543)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(132168347817799542)
,p_button_name=>'ANIMATE_BASIC'
,p_button_static_id=>'ANIMATE_BASIC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Basic'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132168654754799545)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(132168525050799544)
,p_button_name=>'ANIMATE_SPRING'
,p_button_static_id=>'ANIMATE_SPRING'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Spring'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132168857010799547)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(132168759404799546)
,p_button_name=>'ANIMATE_STAGGER'
,p_button_static_id=>'ANIMATE_STAGGER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Stagger'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132169113572799550)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(132168131940799540)
,p_button_name=>'STOP_THREE'
,p_button_static_id=>'STOP_THREE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Three'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133167402747806001)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(132168347817799542)
,p_button_name=>'STOP_BASIC'
,p_button_static_id=>'STOP_BASIC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Basic'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133167545708806002)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(132168525050799544)
,p_button_name=>'STOP-SPRING'
,p_button_static_id=>'STOP_SPRING'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Spring'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133167608956806003)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(132168759404799546)
,p_button_name=>'STOP_STAGGER'
,p_button_static_id=>'STOP_STAGGER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Stagger'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132169058236799549)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(132167812330799537)
,p_button_name=>'STOP_ROTATE'
,p_button_static_id=>'STOP_ROTATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop-Rotate'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
);
wwv_flow_imp.component_end;
end;
/
