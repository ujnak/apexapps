prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>246
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Dynamic Actions'
,p_alias=>'DYNAMIC-ACTIONS'
,p_step_title=>'Dynamic Actions'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "three": "https://cdn.jsdelivr.net/npm/three@0.172.0/build/three.module.min.js",',
'            "three/webgpu": "https://cdn.jsdelivr.net/npm/three@0.172.0/build/three.webgpu.min.js"',
'        }',
'    }',
'</script>'))
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/motion@11.16.0/dist/motion.min.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var animateRotate = null;',
'var animateThree = null;',
'var animateBasic = null;',
'var animateSpring = null;',
'var animateStagger = null;',
'',
'var cube;',
'',
'function rad(degrees) {',
'    return degrees * (Math.PI / 180)',
'};'))
,p_css_file_urls=>'#APP_FILES#css/quick-start-motion#MIN#.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(398531953844004028)
,p_plug_name=>'Create an animation - Rotate'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div class="box"></div>',
'</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(398532273454004031)
,p_plug_name=>'What can be animated? - Three.js'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div id="three-container"></div>',
'</div>',
'',
'<script type="module">',
'import * as THREE from ''three'';',
'',
'var scene = new THREE.Scene({ alpha: true });',
'const main = document.getElementById("three-container");',
'var camera = new THREE.PerspectiveCamera(',
'    25,',
'    main.offsetWidth / main.offsetHeight,',
'    0.1,',
'    1000',
');',
'var renderer = new THREE.WebGLRenderer({ antialias: true });',
'renderer.setSize(main.offsetWidth, main.offsetHeight);',
'main.appendChild(renderer.domElement);',
'',
'var geometry = new THREE.BoxGeometry();',
'var material = new THREE.MeshPhongMaterial({ color: 0x4ff0b7 });',
'// cube is defined in page property.',
'cube = new THREE.Mesh(geometry, material);',
'renderer.setClearColor(0xffffff, 0);',
'const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);',
'directionalLight.position.set(2, 2, 2);',
'const light = new THREE.AmbientLight(0x404040); // soft white light',
'scene.add(light);',
'scene.add(directionalLight);',
'scene.add(cube);',
'',
'camera.position.z = 5;',
'',
'/**',
' * Create Three.js render loop using Motion''s frameloop',
' */',
'Motion.frame.render(() => renderer.render(scene, camera), true);',
'</script>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(398532489331004033)
,p_plug_name=>'Customizing animations - Basic animation'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div class="box2"></div>',
'</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(398532666564004035)
,p_plug_name=>'Customizing animations - Spring'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div class="box3"></div>',
'</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(398532900918004037)
,p_plug_name=>'Customizing animations - Stagger'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <ul class="example">',
'        <li></li>',
'        <li></li>',
'        <li></li>',
'        <li></li>',
'    </ul>',
'</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(399512679436952387)
,p_plug_name=>'Sample Motion'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(132917446213747218)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133192199174237233)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(398531953844004028)
,p_button_name=>'ANIMATE_ROTATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Rotate'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133193740183237237)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(398532273454004031)
,p_button_name=>'ANIMATE_THREE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Three'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133194982872237240)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(398532489331004033)
,p_button_name=>'ANIMATE_BASIC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Basic'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133196172470237243)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(398532900918004037)
,p_button_name=>'ANIMATE_STAGGER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Stagger'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133197349315237246)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(398532666564004035)
,p_button_name=>'ANIMATE_SPRING'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Spring'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133193344851237236)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(398532273454004031)
,p_button_name=>'STOP_THREE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Three'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133194529752237239)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(398532489331004033)
,p_button_name=>'STOP_BASIC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Basic'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133195738115237242)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(398532900918004037)
,p_button_name=>'STOP_STAGGER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Stagger'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133196999441237245)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(398532666564004035)
,p_button_name=>'STOP_SPRING'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Spring'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133192548804237234)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(398531953844004028)
,p_button_name=>'STOP_ROTATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop-Rotate'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133167711398806004)
,p_name=>'onClick ANIMATE_ROTATE'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133192199174237233)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133167801408806005)
,p_event_id=>wwv_flow_imp.id(133167711398806004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'animateRotate = Motion.animate(',
'    ".box",',
'    { ',
'        rotate: [ 0, 360 ]',
'    },',
'    {',
'        duration: 1,',
'        repeat: 3',
'    }',
');',
'animateRotate.then(() => {',
'    apex.debug.info(''rotate is completed.'');',
'});',
'apex.debug.info(''rotate is started.'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133167915991806006)
,p_name=>'onClick STOP_ROTATE'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133192548804237234)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133168065748806007)
,p_event_id=>wwv_flow_imp.id(133167915991806006)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ( animateRotate !== null ) {',
'    animateRotate.stop();',
'    apex.debug.info(''rotate is stopped.'');',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133168168483806008)
,p_name=>'onClick ANIMATE_ BASIC'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133194982872237240)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133168297285806009)
,p_event_id=>wwv_flow_imp.id(133168168483806008)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'animateBasic = Motion.animate(',
'    ".box2",',
'    {',
'        scale: [0.4, 1]',
'    },',
'    {',
'        ease: "circInOut",',
'        duration: 1,',
'        repeat: 3',
'    }',
');',
'animateBasic.then(() => {',
'    apex.debug.info(''basic is completed.'');',
'});',
'apex.debug.info(''basic is started.'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133168362480806010)
,p_name=>'onClick STOP_BASIC'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133194529752237239)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133168427300806011)
,p_event_id=>wwv_flow_imp.id(133168362480806010)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ( animateBasic !== null ) {',
'    animateBasic.stop();',
'    apex.debug.info(''basic is stopped.'');',
'};'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133168599017806012)
,p_name=>'onClick ANIMATE_SPRING'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133197349315237246)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133168609612806013)
,p_event_id=>wwv_flow_imp.id(133168599017806012)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'animateSpring = Motion.animate(',
'    ".box3",',
'    {',
'        rotate: [ 0, 90 ]',
'    },',
'    {',
'        type: "spring",',
'        repeat: Infinity,',
'        repeatDelay: 0.2',
'    }',
');',
'animateSpring.then(() => {',
'    apex.debug.info(''spring is completed.'');',
'});',
'apex.debug.info(''spring is started.'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133168706056806014)
,p_name=>'onClick STOP_SPRING'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133196999441237245)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133168893378806015)
,p_event_id=>wwv_flow_imp.id(133168706056806014)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ( animateSpring !== null ) {',
'    animateSpring.stop();',
'    apex.debug.info(''spring is stopped.'');',
'};'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133168989872806016)
,p_name=>'onClick ANIMATE_STAGGER'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133196172470237243)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133169093530806017)
,p_event_id=>wwv_flow_imp.id(133168989872806016)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'animateStagger = Motion.animate(',
'    ".example li",',
'    {',
'        opacity: 1, y: [50, 0]',
'    },',
'    {',
'        delay: Motion.stagger(0.05),',
'        repeat: 3',
'    }',
');',
'animateStagger.then(() => {',
'    apex.debug.info(''stagger is completed.'');',
'});',
'apex.debug.info(''stagger is started.'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133169125689806018)
,p_name=>'onClick STOP_STAGGER'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133195738115237242)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133169262571806019)
,p_event_id=>wwv_flow_imp.id(133169125689806018)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ( animateStagger !== null ) {',
'    animateStagger.stop();',
'    apex.debug.info(''stagger is stopped.'');',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133584251871783029)
,p_name=>'onClick ANIMATE_THREE'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133193740183237237)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133584381438783030)
,p_event_id=>wwv_flow_imp.id(133584251871783029)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'animateThree = Motion.animate(',
'    cube.rotation,',
'    { ',
'        y: rad(360), z: rad(360) ',
'    },',
'    { ',
'        duration: 10, ',
'        repeat: Motion.Infinity,',
'        ease: "linear"',
'    }',
');',
'animateThree.then(() => {',
'    apex.debug.info(''three is completed.'');',
'});',
'apex.debug.info(''three is started.'');',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133584492065783031)
,p_name=>'onClick STOP_THREE'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133193344851237236)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133584584328783032)
,p_event_id=>wwv_flow_imp.id(133584492065783031)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ( animateThree !== null ) {',
'    animateThree.stop();',
'    apex.debug.info(''three is stopped.'');',
'}'))
);
wwv_flow_imp.component_end;
end;
/
