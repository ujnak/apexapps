prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>246
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'APEX Actions'
,p_alias=>'APEX-ACTIONS'
,p_step_title=>'APEX Actions'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[module,defer]#APP_FILES#js/quick-start-motion-actions#MIN#.js'
,p_css_file_urls=>'#APP_FILES#css/quick-start-motion#MIN#.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(265341196006766803)
,p_plug_name=>'Create an animation - Rotate'
,p_region_name=>'ROTATE'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div class="box"></div>',
'</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(265341515616766806)
,p_plug_name=>'What can be animated? - Three.js'
,p_region_name=>'THREE'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div id="three-container"></div>',
'</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(265341731493766808)
,p_plug_name=>'Customizing animations - Basic animation'
,p_region_name=>'BASIC'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div class="box2"></div>',
'</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(265341908726766810)
,p_plug_name=>'Customizing animations - Spring'
,p_region_name=>'SPRING'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <div class="box3"></div>',
'</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(265342143080766812)
,p_plug_name=>'Customizing animations - Stagger'
,p_region_name=>'STAGGER'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(132950772874747287)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="h400 u-flex u-justify-content-center u-align-items-center">',
'    <ul class="example">',
'        <li></li>',
'        <li></li>',
'        <li></li>',
'        <li></li>',
'    </ul>',
'</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(266321921599715162)
,p_plug_name=>'Sample Motion'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(132917446213747218)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133174638011967293)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(265341196006766803)
,p_button_name=>'ANIMATE_ROTATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Rotate'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
,p_button_cattributes=>'data-action="ANIMATE"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133176294242967298)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(265341515616766806)
,p_button_name=>'ANIMATE_THREE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Three'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
,p_button_cattributes=>'data-action="ANIMATE"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133177454024967301)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(265341731493766808)
,p_button_name=>'ANIMATE_BASIC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Basic'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
,p_button_cattributes=>'data-action="ANIMATE"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133178656375967304)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(265342143080766812)
,p_button_name=>'ANIMATE_STAGGER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Stagger'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
,p_button_cattributes=>'data-action="ANIMATE"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133179892852967307)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(265341908726766810)
,p_button_name=>'ANIMATE_SPRING'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Animate Spring'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-play'
,p_button_cattributes=>'data-action="ANIMATE"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133175834992967297)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(265341515616766806)
,p_button_name=>'STOP_THREE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Three'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
,p_button_cattributes=>'data-action="STOP"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133177074902967300)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(265341731493766808)
,p_button_name=>'STOP_BASIC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Basic'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
,p_button_cattributes=>'data-action="STOP"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133178214938967303)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(265342143080766812)
,p_button_name=>'STOP_STAGGER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Stagger'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
,p_button_cattributes=>'data-action="STOP"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133179406697967306)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(265341908726766810)
,p_button_name=>'STOP_SPRING'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop Spring'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
,p_button_cattributes=>'data-action="STOP"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133175020058967295)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(265341196006766803)
,p_button_name=>'STOP_ROTATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133023653721747454)
,p_button_image_alt=>'Stop-Rotate'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-stop'
,p_button_cattributes=>'data-action="STOP"'
);
wwv_flow_imp.component_end;
end;
/
