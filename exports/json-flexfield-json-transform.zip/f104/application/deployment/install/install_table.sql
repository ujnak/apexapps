prompt --application/deployment/install/install_table
begin
--   Manifest
--     INSTALL: INSTALL-table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.1'
,p_default_workspace_id=>14753839747585513
,p_default_application_id=>104
,p_default_id_offset=>22569991066471786
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(43277745235176857)
,p_install_id=>wwv_flow_imp.id(43277130843170068)
,p_name=>'table'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "FF_EMP" ',
'   (	"EMPNO" NUMBER(4,0) NOT NULL ENABLE, ',
'	"ENAME" VARCHAR2(50 CHAR), ',
'	"JOB" VARCHAR2(50 CHAR), ',
'	"HIREDATE" DATE, ',
'	"SAL" NUMBER, ',
'	"FLEX" BLOB, ',
'	 CHECK (flex is json format oson) ENABLE, ',
'	 CONSTRAINT "FF_EMP_EMPNO_PK" PRIMARY KEY ("EMPNO")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(43277834830176859)
,p_script_id=>wwv_flow_imp.id(43277745235176857)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FF_EMP'
,p_last_updated_by=>'APEXDEV'
,p_last_updated_on=>to_date('20220719054103','YYYYMMDDHH24MISS')
,p_created_by=>'APEXDEV'
,p_created_on=>to_date('20220719054103','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
