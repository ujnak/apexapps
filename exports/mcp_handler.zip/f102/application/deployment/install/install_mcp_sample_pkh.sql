prompt --application/deployment/install/install_mcp_sample_pkh
begin
--   Manifest
--     INSTALL: INSTALL-mcp_sample.pkh
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>19556557699208374
,p_default_application_id=>102
,p_default_id_offset=>19569790177235364
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(46345080368103112)
,p_install_id=>wwv_flow_imp.id(46343254095135741)
,p_name=>'mcp_sample.pkh'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package mcp_sample as',
'/**',
unistr(' * 2025\5E7411\670827\65E5'),
unistr(' * \30E1\30C3\30BB\30FC\30B8logging/setlevel\306B\5BFE\5FDC\3057\305F\30D7\30ED\30B7\30FC\30B8\30E3'),
unistr(' * logging_setlevel\3092\8FFD\52A0\3002'),
' */',
'procedure initialize(',
'    p_username     in varchar2',
'    ,p_params      in clob',
'    ,p_context     in varchar2',
'    ,p_result      out clob',
'    ,p_error       out clob',
'    ,p_status_code out number',
');',
'',
'procedure notifications_initialized(',
'    p_username     in varchar2',
'    ,p_params      in clob',
'    ,p_context     in varchar2',
'    ,p_result      out clob',
'    ,p_error       out clob',
'    ,p_status_code out number',
');',
'',
'procedure logging_setlevel(',
'    p_username     in varchar2',
'    ,p_params      in clob',
'    ,p_context     in varchar2',
'    ,p_result      out clob',
'    ,p_error       out clob',
'    ,p_status_code out number',
');',
'',
'procedure tools_list(',
'    p_username     in varchar2',
'    ,p_params      in clob',
'    ,p_context     in varchar2',
'    ,p_result      out clob',
'    ,p_error       out clob',
'    ,p_status_code out number',
');',
'',
'procedure tools_call(',
'    p_username     in varchar2',
'    ,p_params      in clob',
'    ,p_context     in varchar2',
'    ,p_result      out clob',
'    ,p_error       out clob',
'    ,p_status_code out number',
');',
'',
'end mcp_sample;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
