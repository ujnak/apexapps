prompt --application/deployment/install/install_mcp_http_server_pkg_pkh
begin
--   Manifest
--     INSTALL: INSTALL-mcp_http_server_pkg.pkh
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>19556557699208374
,p_default_application_id=>102
,p_default_id_offset=>19569790177235364
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(46344510602110463)
,p_install_id=>wwv_flow_imp.id(46343254095135741)
,p_name=>'mcp_http_server_pkg.pkh'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package mcp_http_server_pkg',
'as',
'/**',
unistr(' * JSON-RPC\6A19\6E96\30A8\30E9\30FC\30FB\30B3\30FC\30C9'),
' */',
'C_PARSE_ERROR      constant number := -32700;',
'C_INVALID_REQUEST  constant number := -32600;',
'C_METHOD_NOT_FOUND constant number := -32601;',
'C_INVALID_PARAMS   constant number := -32602;',
'C_INTERNAL_ERROR   constant number := -32603;',
'',
'/**',
unistr(' * ORDS\306EPOST\30CF\30F3\30C9\30E9\306B\8A2D\5B9A\3057\3066MCP Server\306E\51E6\7406\3092\547C\3073\51FA\3059\3002'),
' *',
unistr(' * @param p_script_name owa_util.get_cgi_env(''SCRIPT_NAME'')\3067\53D6\5F97\3055\308C\308B\30B9\30AF\30EA\30D7\30C8\540D\3002'),
unistr(' * @param p_username    ORDS REST\30CF\30F3\30C9\30E9\5185\306E:current_user\3067\53D6\5F97\3055\308C\308B\30E6\30FC\30B6\540D\3002'),
unistr(' * @param p_request     :body\3067\53D6\5F97\3055\308C\308B\30EA\30AF\30A8\30B9\30C8\30DC\30C7\30A3\3002\5B9F\614B\306FJSONRPC\306E\30EA\30AF\30A8\30B9\30C8\3002'),
unistr(' * @param p_response    \30EC\30B9\30DD\30F3\30B9\3068\306A\308BBLOB\3002\5B9F\614B\306FJSONRPC\306E\30EC\30B9\30DD\30F3\30B9\3002notification\306E\5834\5408\306Fnull\3002'),
unistr(' * @param p_session_id  apex_session.create_session\3067\4F5C\6210\3057\305F\30BB\30C3\30B7\30E7\30F3ID\3002'),
unistr(' * @param p_status_code \30EC\30B9\30DD\30F3\30B9\306EHTTP\30B9\30C6\30FC\30BF\30B9\30B3\30FC\30C9\3002\901A\5E38\306F200\3002'),
' */',
'procedure ords_handler(',
'    p_script_name   in  varchar2',
'    ,p_username     in  varchar2',
'    ,p_request      in  blob',
'    ,p_response     out blob',
'    ,p_session_id   out varchar2',
'    ,p_status_code  out number',
');',
'',
'end mcp_http_server_pkg;'))
);
wwv_flow_imp.component_end;
end;
/
