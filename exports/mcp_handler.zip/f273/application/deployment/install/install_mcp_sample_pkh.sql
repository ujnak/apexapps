prompt --application/deployment/install/install_mcp_sample_pkh
begin
--   Manifest
--     INSTALL: INSTALL-mcp_sample.pkh
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>273
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(26775290190867748)
,p_install_id=>wwv_flow_imp.id(26773463917900377)
,p_name=>'mcp_sample.pkh'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package mcp_sample as',
'',
'procedure initialize(',
'    p_username     in varchar2',
'    ,p_params      in clob',
'    ,p_context     in varchar2',
'    ,p_result      out clob',
'    ,p_error       out clob',
'    ,p_status_code out number',
');',
'',
'procedure notifications_initialized(',
'    p_username     in varchar2',
'    ,p_params      in clob',
'    ,p_context     in varchar2',
'    ,p_result      out clob',
'    ,p_error       out clob',
'    ,p_status_code out number',
');',
'',
'procedure tools_list(',
'    p_username     in varchar2',
'    ,p_params      in clob',
'    ,p_context     in varchar2',
'    ,p_result      out clob',
'    ,p_error       out clob',
'    ,p_status_code out number',
');',
'',
'procedure tools_call(',
'    p_username     in varchar2',
'    ,p_params      in clob',
'    ,p_context     in varchar2',
'    ,p_result      out clob',
'    ,p_error       out clob',
'    ,p_status_code out number',
');',
'',
'end mcp_sample;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
