prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 273
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>273
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000E1494441545847637C191DF29F610001E3A8034643603404864C08FC565062605456C559623C3FB88F81EDF36706714E0E924A';
wwv_flow_imp.g_varchar2_table(2) := '15A2CB813FCEEE0CA2BE7E380D7FD8D90696FB7EEF2E498EA0AA03C4D4D5195EDDBC499223A8E6802FC78E32BC3D7C101C0AF7AF5E61D01712242A2AA8E60064DB5E6FDEC4C0B27727ED1DF0E3D62D060E35350C8BE8E200902520004A983036AFBA06D8';
wwv_flow_imp.g_varchar2_table(3) := '41347500CC3298E5201A5D8CA60E0059882BE86171417307104A5D7473C068228415CDA389103D51D2241112AA8E911DF176CB46A26B44A2EB0242598F5CF951078C86C068080C78080000F1D1DE014BA118980000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(26720332640829162)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
