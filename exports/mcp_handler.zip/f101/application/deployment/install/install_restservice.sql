prompt --application/deployment/install/install_restservice
begin
--   Manifest
--     INSTALL: INSTALL-RESTSERVICE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.13'
,p_default_workspace_id=>9770943118767672
,p_default_application_id=>101
,p_default_id_offset=>12799726869403705
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(12807318212193145)
,p_install_id=>wwv_flow_imp.id(113374488885109790)
,p_name=>'RESTSERVICE'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_ords_uri mcp_http_servers.ords_uri%type;',
'    l_application_id number;',
'begin',
'    select ''/ords/'' || s.pattern || ''/sampleserver'' into l_ords_uri ',
'    from user_ords_schemas s join user_ords_modules m on s.id = m.schema_id',
'    where m.name = ''sampleserver'';',
'    select application_id into l_application_id',
'    from apex_applications where application_name = ''MCP Handler'';',
'    merge into mcp_http_servers t',
'    using (',
'        select',
'            l_ords_uri ords_uri,',
'            l_application_id apex_app_id,',
'            1 apex_page_id,',
'            ''MCP_SAMPLE'' package_name,',
'            ''Countries'' tool_set,',
'            4 log_level',
'        from dual',
'    ) s',
'    on (t.ords_uri = s.ords_uri) ',
'    when matched then',
'        update set',
'            t.apex_app_id = s.apex_app_id,',
'            t.apex_page_id = s.apex_page_id,',
'            t.package_name = s.package_name,',
'            t.tool_set     = s.tool_set,',
'            t.log_level    = s.log_level',
'    when not matched then',
'        insert (ords_uri, apex_app_id, apex_page_id, package_name, tool_set, log_level)',
'        values (s.ords_uri, s.apex_app_id, s.apex_page_id, s.package_name, s.tool_set, s.log_level)',
'    ;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
