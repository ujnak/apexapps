prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.13'
,p_default_workspace_id=>9770943118767672
,p_default_application_id=>101
,p_default_id_offset=>12799726869403705
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(113374488885109790)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    execute immediate ''drop package mcp_sample'';',
'exception',
'    when others then',
'        null;',
'end;',
'/',
'begin',
'    execute immediate ''drop package mcp_http_server_pkg'';',
'exception',
'    when others then',
'        null;',
'end;',
'/',
'begin',
'    execute immediate ''drop table mcp_http_servers'';',
'exception',
'    when others then',
'        null;',
'end;',
'/',
'begin',
'    ords.delete_privilege(',
'        p_name => ''oracle.example.mcp''',
'    );',
'    ords.delete_role(',
'        p_role_name => ''MCP Server Role''',
'    );',
'    ords.delete_module(',
'        p_module_name => ''sampleserver''',
'    );',
'exception',
'    when others then',
'        null;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
