prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>7739405930131605
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Talk to Agent'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24562274154642408)
,p_plug_name=>'Talk to Agent'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10944296395491531)
,p_button_sequence=>20
,p_button_name=>'SEND_A_TASK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Send a Task'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10944437200491533)
,p_button_sequence=>40
,p_button_name=>'AGENT_CARD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Agent Card'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10944163030491530)
,p_name=>'P1_TASK'
,p_item_sequence=>10
,p_prompt=>'Task'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10944326522491532)
,p_name=>'P1_RESPONSE'
,p_item_sequence=>30
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10944687881491535)
,p_name=>'P1_AGENT_CARD'
,p_item_sequence=>50
,p_prompt=>'Agent Card'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10944578941491534)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Agent Card'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'* Agent Card',
'* https://google.github.io/A2A/#/documentation?id=agent-card-1',
'*/',
'declare',
'    l_url varchar2(200);',
'    l_response clob;',
'    e_api_call_failed exception;',
'begin',
unistr('    -- Agent Card\306EURL'),
'    l_url := :G_ENDPOINT || ''/.well-known/agent.json'';',
'    apex_debug.info(''endpoint = %s'', l_url);',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_url',
'        ,p_http_method => ''GET''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_api_call_failed;',
'    end if;',
'    select json_serialize(l_response returning clob pretty) into :P1_AGENT_CARD;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10944437200491533)
,p_internal_uid=>10944578941491534
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10944714570491536)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Send a Task'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url varchar2(200);',
'    /*',
'    * tasks/send',
'    */',
'    l_request    clob;',
'    l_task       json_object_t;',
'    l_id         number;',
'    l_params     json_object_t;',
'    l_params_id  varchar2(32);',
'    l_guid       varchar2(36);',
'    l_message    json_object_t;',
'    l_parts      json_array_t;',
'    l_part       json_object_t;',
'    e_api_call_failed exception;',
'    /*',
'    * response',
'    */',
'    l_response      clob;',
'    l_response_json json_object_t;',
'    l_result        json_object_t;',
'    l_artifacts     json_array_t;',
'    l_artifact      json_object_t;',
'    /*',
unistr('    * GUID\30923262b5fd-c7fa-faa8-e063-0200590aca0e\306E\5F62\5F0F\3067\53D6\5F97\3059\308B\3002'),
'    */',
'    function get_guid return varchar2',
'    as',
'        l_guid varchar2(32);',
'        l_formatted_guid varchar2(36);',
'    begin',
'        l_guid := lower(rawtohex(sys_guid()));',
'        l_formatted_guid := apex_string.format(',
'            ''%s-%s-%s-%s-%s''',
'            ,substr(l_guid,  1, 8)',
'            ,substr(l_guid,  9, 4)',
'            ,substr(l_guid, 13, 4)',
'            ,substr(l_guid, 17, 4)',
'            ,substr(l_guid, 21)',
'        );',
'        return l_formatted_guid;',
'    end get_guid;',
'begin',
'    l_url := :G_ENDPOINT;',
'    apex_debug.info(''endpoint = %s'', l_url);',
'    /*',
'    * Send a Task',
'    * https://google.github.io/A2A/#/documentation?id=send-a-task',
'    */',
'    l_task := json_object_t();',
'    l_id := 1;',
'    l_task.put(''jsonrpc'',''2.0'');',
'    l_task.put(''id'', l_id);',
'    l_task.put(''method'', ''tasks/send'');',
'    l_params := json_object_t();',
'    l_guid := get_guid();',
'    l_params.put(''id'', l_guid);',
'    l_message := json_object_t();',
'    l_message.put(''role'', ''user'');',
'    l_parts := json_array_t();',
'    l_part  := json_object_t();',
'    l_part.put(''type'', ''text'');',
'    l_part.put(''text'', :P1_TASK);',
'    l_parts.append(l_part);',
unistr('    l_message.put(''parts'', l_parts); -- Send a Task\306E\4F8B\306B\306Fdata\3068\306A\3063\3066\3044\308B\304Cparts\304C\6B63\3057\3044\3002'),
'    l_params.put(''message'', l_message);',
'    l_params.put(''metadata'', json_object_t()); -- empty object',
'    l_task.put(''params'', l_params);',
'    l_request := l_task.to_clob();',
'    apex_debug.info(l_request);',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_url',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_api_call_failed;',
'    end if;',
'    /*',
unistr('    * response\304B\3089artifact\3092\53D6\308A\51FA\3059\3002'),
'    */',
'    l_response_json := json_object_t(l_response);',
'    l_result := l_response_json.get_object(''result'');',
'    l_artifacts := l_result.get_array(''artifacts'');',
'    apex_debug.info(''artfifacts = %s'', l_artifacts.to_clob());',
unistr('    -- \4ECA\306F\6700\521D\306Eartifact\3060\3051\3092\53D6\308A\51FA\3059\3002'),
'    l_artifact := treat(l_artifacts.get(0) as json_object_t);',
'    l_parts := l_artifact.get_array(''parts'');',
'    apex_debug.info(''parts in first artifact = %s'', l_parts.to_clob());',
unistr('    -- \6700\521D\306Epart\3092\53D6\308A\51FA\3059\3002'),
'    l_part := treat(l_parts.get(0) as json_object_t);',
'    apex_debug.info(''first part in first artifact = %s'', l_part.to_clob());',
unistr('    -- part\306Ftext\6C7A\3081\6253\3061\3067\53D6\308A\51FA\3059\3002'),
'    :P1_RESPONSE := l_part.get_string(''text'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10944296395491531)
,p_internal_uid=>10944714570491536
);
wwv_flow_imp.component_end;
end;
/
