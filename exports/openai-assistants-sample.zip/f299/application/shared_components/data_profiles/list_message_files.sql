prompt --application/shared_components/data_profiles/list_message_files
begin
--   Manifest
--     DATA PROFILE: List message files
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>299
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(129642489432204358)
,p_name=>'List message files'
,p_format=>'JSON'
,p_has_header_row=>false
,p_row_selector=>'data'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(129648717668212554)
,p_data_profile_id=>wwv_flow_imp.id(129642489432204358)
,p_name=>'ID'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'id'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(129649264119212554)
,p_data_profile_id=>wwv_flow_imp.id(129642489432204358)
,p_name=>'OBJECT'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'object'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(129649742342212554)
,p_data_profile_id=>wwv_flow_imp.id(129642489432204358)
,p_name=>'CREATED_AT'
,p_sequence=>3
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_has_time_zone=>false
,p_selector=>'created_at'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(129650278860212555)
,p_data_profile_id=>wwv_flow_imp.id(129642489432204358)
,p_name=>'MESSAGE_ID'
,p_sequence=>4
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'message_id'
);
wwv_flow_imp.component_end;
end;
/
