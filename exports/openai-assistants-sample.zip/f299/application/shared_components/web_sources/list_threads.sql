prompt --application/shared_components/web_sources/list_threads
begin
--   Manifest
--     WEB SOURCE: List threads
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>299
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(129433629758591660)
,p_name=>'List threads'
,p_static_id=>'list_threads'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(129432540471591659)
,p_remote_server_id=>wwv_flow_imp.id(128679627188677162)
,p_url_path_prefix=>'v1/threads'
,p_credential_id=>wwv_flow_imp.id(59103911961121450)
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(129436055929617495)
,p_web_src_module_id=>wwv_flow_imp.id(129433629758591660)
,p_name=>'OpenAI-Beta'
,p_param_type=>'HEADER'
,p_is_required=>false
,p_value=>'assistants=v1'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(129664003231406492)
,p_web_src_module_id=>wwv_flow_imp.id(129433629758591660)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(129433806539591660)
,p_web_src_module_id=>wwv_flow_imp.id(129433629758591660)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
