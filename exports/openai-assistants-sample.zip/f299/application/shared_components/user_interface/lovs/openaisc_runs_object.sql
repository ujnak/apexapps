prompt --application/shared_components/user_interface/lovs/openaisc_runs_object
begin
--   Manifest
--     OPENAISC_RUNS.OBJECT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>299
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(129245343595608605)
,p_lov_name=>'OPENAISC_RUNS.OBJECT'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'OPENAISC_RUNS'
,p_return_column_name=>'ID'
,p_display_column_name=>'OBJECT'
,p_default_sort_column_name=>'OBJECT'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
