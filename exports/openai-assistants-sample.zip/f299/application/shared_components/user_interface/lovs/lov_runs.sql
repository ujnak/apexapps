prompt --application/shared_components/user_interface/lovs/lov_runs
begin
--   Manifest
--     LOV_RUNS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>299
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(129579984770630820)
,p_lov_name=>'LOV_RUNS'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(129545139876551638)
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'ID'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'ID'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(129580624615635109)
,p_query_column_name=>'ID'
,p_heading=>'Run Id'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(129580919449635110)
,p_query_column_name=>'THREAD_ID'
,p_heading=>'Thread Id'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(129580247385630823)
,p_web_src_param_id=>wwv_flow_imp.id(129546930766551647)
,p_shared_lov_id=>wwv_flow_imp.id(129579984770630820)
,p_value_type=>'DEFAULT'
);
wwv_flow_imp.component_end;
end;
/
