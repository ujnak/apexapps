prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>254
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'pay'
,p_alias=>'PAY'
,p_page_mode=>'MODAL'
,p_step_title=>'pay'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://multipay.komoju.com/fields.js'
,p_step_template=>wwv_flow_imp.id(69307752055721237)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230823040403'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65573503790802144)
,p_plug_name=>'KOMOJU Host Fields'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(69345049919721284)
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<komoju-fields',
'  session-id=&P2_SESSION_ID.',
'  publishable-key=&KOMOJU_PUBLISHABLE_KEY.',
'></komoju-fields>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65573693787802145)
,p_button_sequence=>40
,p_button_name=>'PAY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(69483487528721382)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Pay'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65573339435802142)
,p_name=>'P2_SESSION_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(65573757929802146)
,p_name=>'onClick Pay'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(65573693787802145)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(65573866564802147)
,p_event_id=>wwv_flow_imp.id(65573757929802146)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.querySelector(''komoju-fields'').submit();',
'apex.navigation.dialog.close(true);'))
);
wwv_flow_imp.component_end;
end;
/
