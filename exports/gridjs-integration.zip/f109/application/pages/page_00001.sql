prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(19858153901004312)
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Grid.js'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/gridjs/dist/gridjs.umd.js'
,p_javascript_code=>'let apexSession = apex.env.APP_ID + '','' + apex.env.APP_SESSION;'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const grid = new gridjs.Grid({',
'  columns: [',
'  {',
'    id: "EMPNO",',
unistr('    name: "\5F93\696D\54E1\756A\53F7"'),
'  },',
'  {',
'    id: "ENAME",',
unistr('    name: "\5F93\696D\54E1\540D"'),
'  },',
'  {',
'    id: "JOB",',
unistr('    name: "\30B8\30E7\30D6"'),
'  },',
'  {',
'    id: "SAL",',
unistr('    name: "\7D66\4E0E"'),
'  },',
'  {',
'    id: "COMM",',
unistr('    name: "\624B\5F53"'),
'  },',
'  {',
'    id: "HIREDATE",',
unistr('    name: "\63A1\7528\65E5"'),
'  }',
'  ],',
'  server: {',
'    url: "&G_DATA_SOURCE_URL.",',
'    data: (opts) => {',
'      return new Promise((resolve, reject) => {',
'        // let''s implement our own HTTP client',
'        const xhttp = new XMLHttpRequest();',
'        xhttp.onreadystatechange = function() {',
'          if (this.readyState === 4) {',
'            if (this.status === 200) {',
'              const resp = JSON.parse(this.response); ',
'              // make sure the output conforms to StorageResponse format: ',
'              // https://github.com/grid-js/gridjs/blob/master/src/storage/storage.ts#L21-L24',
'              resolve({',
'                data: resp.data.map(emp => [emp.EMPNO, emp.ENAME, emp.JOB, emp.SAL, emp.COMM, emp.HIREDATE]),',
'                total: resp.total,',
'              });',
'            } else {',
'              reject();',
'            }',
'          }',
'        };',
'        xhttp.open("GET", opts.url, true);',
'        xhttp.setRequestHeader("Apex-Session", apexSession);',
'        xhttp.send();',
'      });',
'    }',
'  }',
'  /* ,',
'  pagination: {',
'    limit: 5',
'  }',
'*/',
'}).render(document.getElementById("grid"));',
'',
unistr('// \30B0\30EA\30C3\30C9\3092\30EA\30D5\30EC\30C3\30B7\30E5\3059\308B\3002'),
'apex.actions.add([',
'{',
'    name: "force-render",',
'    action: function ( event, element, args ) {',
'        grid.forceRender();',
'    }',
'}',
']);'))
,p_css_file_urls=>'https://cdn.jsdelivr.net/npm/gridjs/dist/theme/mermaid.min.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20220830045733'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15859519782947322)
,p_plug_name=>'Grid'
,p_region_name=>'grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19701322062004206)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19866657201004361)
,p_plug_name=>'Grid.js'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(19732542765004221)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15859913659947326)
,p_button_sequence=>20
,p_button_name=>'B_REFRESH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19833200926004280)
,p_button_image_alt=>unistr('\30EA\30D5\30EC\30C3\30B7\30E5')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$force-render"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp.component_end;
end;
/
