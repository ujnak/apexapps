prompt --application/shared_components/plugins/template_component/chartist_js_bar_chart
begin
--   Manifest
--     PLUGIN: CHARTIST_JS_BAR_CHART
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>137
,p_default_id_offset=>35416869915407458
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(35424984624617787)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '')
,p_name=>'CHARTIST_JS_BAR_CHART'
,p_display_name=>'Chartist.js Bar Chart'
,p_supported_component_types=>'PARTIAL'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','CHARTIST_JS_BAR_CHART'),'')
,p_css_file_urls=>'https://cdn.jsdelivr.net/chartist.js/latest/chartist.min.css'
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if ?VALUE/}',
'<div id="#APEX$DOM_ID#" class="#CSS#"></div>',
'<script type="module">',
'    import { BarChart } from ''https://cdn.jsdelivr.net/npm/chartist@1.3.0/+esm'';',
'',
'    const div = document.createElement("div");',
'    const chartCss = ''#CHART_CSS#'';',
'    if ( chartCss ) {',
'        const cssArr = chartCss.split(/\s+/);',
'        cssArr.forEach( (cls) => {',
'            if (cls) {',
'                div.classList.add(cls.trim());',
'            }',
'        })',
'    };',
'    document.getElementById(''#APEX$DOM_ID#'').appendChild(div);',
'',
'    const groups = ''#GROUPS#'';',
'    const value  = ''#VALUE#'';',
'',
'    let data = {',
'        labels: JSON.parse(groups),',
'        series: [',
'            JSON.parse(value)',
'        ]',
'    };',
'',
'    let config = {',
'        horizontalBars: true,',
'        axisY: {',
'            offset: 70',
'        }',
'    };',
'',
'    if (''#ORIENTATION#'' === ''false'') {',
'        config.horizontalBars = false;',
'    };',
'',
'    new BarChart(div, data, config);',
'</script>',
'{endif/}'))
,p_default_escape_mode=>'ATTR'
,p_translate_this_template=>false
,p_api_version=>1
,p_standard_attributes=>'REGION_TEMPLATE'
,p_substitute_attributes=>true
,p_version_scn=>41128940141205
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_files_version=>23
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35425649753617814)
,p_plugin_id=>wwv_flow_imp.id(35424984624617787)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>10
,p_static_id=>'GROUPS'
,p_prompt=>'Groups'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>true
,p_escape_mode=>'RAW'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35426024208617815)
,p_plugin_id=>wwv_flow_imp.id(35424984624617787)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_static_id=>'ORIENTATION'
,p_prompt=>'Orientation'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35427751219630286)
,p_plugin_attribute_id=>wwv_flow_imp.id(35426024208617815)
,p_display_sequence=>10
,p_display_value=>'horizontal'
,p_return_value=>'true'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35428193332631005)
,p_plugin_attribute_id=>wwv_flow_imp.id(35426024208617815)
,p_display_sequence=>20
,p_display_value=>'vertical'
,p_return_value=>'false'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35426427174617816)
,p_plugin_id=>wwv_flow_imp.id(35424984624617787)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>20
,p_static_id=>'VALUE'
,p_prompt=>'Value'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>true
,p_escape_mode=>'RAW'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35436917800739861)
,p_plugin_id=>wwv_flow_imp.id(35424984624617787)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>40
,p_static_id=>'CHART_CSS'
,p_prompt=>'Chart Css'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_escape_mode=>'RAW'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(37087449942978929)
,p_plugin_id=>wwv_flow_imp.id(35424984624617787)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>6
,p_display_sequence=>60
,p_static_id=>'CSS'
,p_prompt=>'Css'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_escape_mode=>'RAW'
,p_is_translatable=>false
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
