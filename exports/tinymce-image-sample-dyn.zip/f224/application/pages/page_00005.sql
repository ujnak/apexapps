prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>224
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>unistr('\52D5\7684\30B3\30F3\30C6\30F3\30C4')
,p_alias=>unistr('\52D5\7684\30B3\30F3\30C6\30F3\30C4')
,p_step_title=>unistr('\52D5\7684\30B3\30F3\30C6\30F3\30C4')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#mydoc img {',
'    width: 80%;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230705054435'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33300192494100018)
,p_plug_name=>unistr('\30C9\30AD\30E5\30E1\30F3\30C8')
,p_region_name=>'mydoc'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(33880096972435266)
,p_plug_display_sequence=>20
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob clob;',
'begin',
unistr('    -- \8868\793A\3059\308B\6587\66F8\3092\53D6\308A\51FA\3059\3002'),
'    select content into l_clob from rte_documents where id = :P5_DOCUMENT_ID;',
unistr('    -- \753B\50CFURL\3092\4E8B\524D\627F\8A8D\30EA\30AF\30A8\30B9\30C8\3067\7F6E\304D\63DB\3048\308B\3002'),
'    l_clob := replace(l_clob, :G_OBJECT_STORAGE_URL, :G_PREAUTH_URL);',
unistr('    -- \30DE\30FC\30AF\30C0\30A6\30F3\3092HTML\306B\5909\63DB\3059\308B\3002'),
'    l_clob := apex_markdown.to_html(l_clob);',
'    return l_clob;',
'exception',
'    when no_data_found then',
'        return null;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P5_DOCUMENT_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(35141343670475433)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(33892416201435274)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(33787329338435210)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(33965437131435320)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33300051669100017)
,p_name=>'P5_DOCUMENT_ID'
,p_item_sequence=>10
,p_prompt=>unistr('\8868\793A\3059\308B\6587\7AE0')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select title d, id r from rte_documents',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- \6587\7AE0\3092\9078\629E --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(33961393253435316)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33300225715100019)
,p_name=>unistr('\6587\66F8\306E\5207\308A\66FF\3048')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_DOCUMENT_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33300313758100020)
,p_event_id=>wwv_flow_imp.id(33300225715100019)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('\6587\66F8\306E\518D\8868\793A')
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33300192494100018)
);
wwv_flow_imp.component_end;
end;
/
