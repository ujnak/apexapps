prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>220
,p_default_id_offset=>35159054231821370
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Document'
,p_alias=>'DOCUMENT'
,p_page_mode=>'MODAL'
,p_step_title=>'Document'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const apexSession = apex.env.APP_ID + '','' + apex.env.APP_SESSION;',
'const imageUrl = "&G_IMAGE_URL.";',
'',
'const image_upload_handler = (blobInfo, progress) => new Promise((resolve, reject) => {',
'    const xhr = new XMLHttpRequest();',
'    xhr.withCredentials = false;',
'    xhr.open(''POST'', imageUrl);',
unistr('    xhr.setRequestHeader("Apex-Session", apexSession);    // APEX\30BB\30C3\30B7\30E7\30F3\3067\306E\8A8D\8A3C\3092\4ED8\52A0'),
'',
'    xhr.upload.onprogress = (e) => {',
'        progress(e.loaded / e.total * 100);',
'    };',
'',
'    xhr.onload = () => {',
'        if (xhr.status === 403) {',
'            reject({ message: ''HTTP Error: '' + xhr.status, remove: true });',
'            return;',
'        }',
'',
'        if (xhr.status < 200 || xhr.status >= 300) {',
'            reject(''HTTP Error: '' + xhr.status);',
'            return;',
'        }',
'',
'        const json = JSON.parse(xhr.responseText);',
'',
'        if (!json || typeof json.location != ''string'') {',
'            reject(''Invalid JSON: '' + xhr.responseText);',
'            return;',
'        }',
'        ',
unistr('        /* \4E8B\524D\627F\8A8D\6E08\307FURL\306B\7F6E\304D\63DB\3048\308B\3002\3000 */'),
'        resolve(json.location.replace(''&G_OBJECT_STORAGE_URL!RAW.'',''&G_PREAUTH_URL!RAW.'')); ',
'    };',
'',
'    xhr.onerror = () => {',
'        reject(''Image upload failed due to a XHR Transport error. Code: '' + xhr.status);',
'    };',
'',
'    const formData = new FormData();',
'    formData.append(''file'', blobInfo.blob(), blobInfo.filename());',
'',
'    xhr.send(formData);',
'});'))
,p_step_template=>wwv_flow_imp.id(68967815738256595)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230705053331'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(69243678544256923)
,p_plug_name=>'Document'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(68983141322256605)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'RTE_DOCUMENTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(69250344987256928)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(68985944806256607)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69250710986256929)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(69250344987256928)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(69122936461256689)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69252057036256930)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(69250344987256928)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(69122936461256689)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P2_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69252548211256930)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(69250344987256928)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(69122936461256689)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_position=>'NEXT'
,p_button_condition=>'P2_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69252873289256930)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(69250344987256928)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(69122936461256689)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'NEXT'
,p_button_condition=>'P2_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69243983137256923)
,p_name=>'P2_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_item_source_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69244437495256924)
,p_name=>'P2_TITLE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_item_source_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_prompt=>'Title'
,p_source=>'TITLE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(69120447485256686)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69244789898256924)
,p_name=>'P2_CONTENT'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_item_source_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_prompt=>'Content'
,p_source=>'CONTENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>wwv_flow_imp.id(69120447485256686)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'    // Add the plugin and the toolbar option',
'    options.editorOptions.plugins += " image";',
'    options.editorOptions.toolbar += " image";',
'',
'    // Use the custom upload handler',
'    options.editorOptions.images_upload_handler = image_upload_handler; ',
'',
'    // Disable relative url',
'    options.editorOptions.relative_urls = false;',
'',
'    // Replace the editor content',
'    options.editorOptions.init_instance_callback = (editor) => {',
'        editor.setContent(editor.getContent());',
'    }',
'',
'    // Define the URL converter and enable it',
'    options.editorOptions.convert_urls = true;',
'    options.editorOptions.urlconverter_callback = function(url, node, on_save, name) {',
'        if (node === "img" && name === "src" ){    ',
'            url = url.replace(''&G_OBJECT_STORAGE_URL!RAW.'',''&G_PREAUTH_URL!RAW.'');',
'        }',
'        return url;',
'    }',
'',
'    return options;',
'}'))
,p_attribute_01=>'MARKDOWN'
,p_attribute_04=>'180'
,p_attribute_25=>'TINYMCE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69245218844256925)
,p_name=>'P2_AUTHOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_item_source_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_prompt=>'Author'
,p_source=>'AUTHOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(69120447485256686)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69245652778256925)
,p_name=>'P2_PUBLISHED'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_item_source_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_prompt=>'Published'
,p_source=>'PUBLISHED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(69120447485256686)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69246020415256925)
,p_name=>'P2_CREATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_item_source_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_source=>'CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(68945774618256579)
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69246413520256926)
,p_name=>'P2_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_item_source_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(68945774618256579)
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69246849116256926)
,p_name=>'P2_UPDATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_item_source_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_source=>'UPDATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(68945774618256579)
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69247233318256926)
,p_name=>'P2_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_item_source_plug_id=>wwv_flow_imp.id(69243678544256923)
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(68945774618256579)
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(69250831724256929)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(69250710986256929)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(69251612996256929)
,p_event_id=>wwv_flow_imp.id(69250831724256929)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(68459006634921386)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\4E8B\524D\627F\8A8DURL\306E\524A\9664')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :P2_CONTENT := replace(:P2_CONTENT, :G_PREAUTH_URL, :G_OBJECT_STORAGE_URL);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>33299952403100016
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(69253702460256931)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(69243678544256923)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0Document')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>34094648228435561
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(68458023944921376)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\753B\50CF\306E\7D10\4ED8\3051')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_link varchar2(32767);',
'    l_id varchar2(80);',
'    i pls_integer;',
'    l_images apex_t_varchar2;',
'begin',
'    /*',
unistr('     * \30A2\30C3\30D7\30ED\30FC\30C9\3055\308C\305FCLOB\306B\542B\307E\308C\3066\3044\308B\753B\50CFURL\3092\898B\3064\3051\3001'),
unistr('     * \8868RTE_IMAGES\306EDOCUMENT_ID\306B\3001\73FE\5728\7DE8\96C6\4E2D\306E\30C9\30AD\30E5\30E1\30F3\30C8ID\3092\8A2D\5B9A\3059\308B\3002'),
'     */',
'    i := 1;',
'    while true',
'    loop',
unistr('        -- \753B\50CFURL\3092\898B\3064\3051\308B\3002'),
'        l_link := regexp_substr(:P2_CONTENT, :G_OBJECT_STORAGE_URL || ''([0-9]+)'',1,i);',
'        if l_link is null then',
unistr('            -- \306A\3051\308C\3070\7D42\4E86\3002'),
'            exit;',
'        else',
unistr('            -- \3042\308C\3070\753B\50CFURL\3088\308AID\90E8\5206\3092\53D6\308A\51FA\3059\3002'),
'            i := i + 1;',
'            l_id := regexp_replace(l_link, :G_OBJECT_STORAGE_URL || ''([0-9]+)'', ''\1'');',
'            apex_string.push(l_images,l_id);',
'        end if;',
'    end loop;',
unistr('    -- \30A4\30F3\30B5\30FC\30C8\306E\5834\5408\306F\8868CKE_IMAGES\306B\6307\5B9A\3057\305F\30C9\30AD\30E5\30E1\30F3\30C8ID\306E\5217\306F\306A\3044\3002\306A\306E\3067\3001\52B9\679C\304C\3042\308B\306E\306F\30A2\30C3\30D7\30C7\30FC\30C8\6642\306E\307F\3002'),
'    update rte_images set document_id = null where document_id = :P2_ID;',
unistr('    -- CLOB\30C7\30FC\30BF\306B\542B\307E\308C\3066\3044\308B\753B\50CFID\306EDOCUMENT_ID\3092\3001\73FE\5728\4F5C\6210\307E\305F\306F\66F4\65B0\4E2D\306E\8868RTE_DOCUMENTS\306EID\306B\3059\308B\3002'),
unistr('    -- \30A2\30C3\30D7\30ED\30FC\30C9\3055\308C\305F\753B\50CF\306F\30C9\30AD\30E5\30E1\30F3\30C8\9593\3067\5171\6709\3055\308C\308B\3053\3068\306F\306A\3044\305F\3081\3001\3053\308C\3067\554F\984C\306A\3044\3002'),
'    update rte_images set document_id = :P2_ID where id in (select column_value from table(l_images));',
'    /*',
unistr('     * \6587\7AE0\3092\8A18\8FF0\4E2D\306B\753B\50CF\3092\8CBC\308A\4ED8\3051\305F\5F8C\306B\524A\9664\3057\305F\5834\5408\3001\305D\306E\753B\50CF\306F\8868RTE_IMAGES\306B'),
unistr('     * DOCUMENT_ID\304CNULL\306E\72B6\614B\3067\6B8B\308B\3002\3053\306E\753B\50CF\306B\3064\3044\3066\306F\3001\5B9A\671F\7684\306B\5B9F\884C\3059\308B\30D0\30C3\30C1\306A\3069\3067\6D88\53BB\3059\308B'),
unistr('     * \5FC5\8981\304C\3042\308B\3002'),
'     */',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>33298969713100006
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(69254084545256931)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>34095030313435561
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(69253338189256931)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(69243678544256923)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0Document')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>34094283957435561
);
wwv_flow_imp.component_end;
end;
/
