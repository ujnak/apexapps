prompt --application/shared_components/user_interface/map_backgrounds/tokyo_digital_twin
begin
--   Manifest
--     MAP BACKGROUND: Tokyo Digital Twin
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>118
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_map_background(
 p_id=>wwv_flow_imp.id(21998202727427968)
,p_name=>'Tokyo Digital Twin'
,p_type=>'RASTER'
,p_url=>'http://localhost:8080/tiles/{z}/{x}/{y}.png'
,p_version_scn=>12807527
);
wwv_flow_imp.component_end;
end;
/
