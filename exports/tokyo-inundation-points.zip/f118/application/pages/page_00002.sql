prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>118
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>unistr('\6D78\6C34\4E88\60F3\533A\57DF\56F3')
,p_alias=>unistr('\6D78\6C34\4E88\60F3\533A\57DF\56F3')
,p_step_title=>unistr('\6D78\6C34\4E88\60F3\533A\57DF\56F3')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'19'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21991552287063741)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(21975665481993005)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21992257141063743)
,p_plug_name=>unistr('\6D78\6C34\4E88\60F3\533A\57DF\56F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>10
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(21992630326063743)
,p_region_id=>wwv_flow_imp.id(21992257141063743)
,p_height=>1000
,p_tilelayer_type=>'SHARED'
,p_default_shared_tilelayer_id=>wwv_flow_imp.id(21998202727427968)
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(21993183114063744)
,p_map_region_id=>wwv_flow_imp.id(21992630326063743)
,p_name=>unistr('\6D78\6C34\4E88\60F3\533A\57DF\56F3')
,p_layer_type=>'HEATMAP'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    flood_depth,',
'    geom',
'FROM tokyo_inundation_points t',
'WHERE SDO_RELATE(',
'    t.geom,',
'    SDO_GEOMETRY(',
unistr('        2003,  -- 2\6B21\5143\30DD\30EA\30B4\30F3'),
'        4326,  -- WGS84',
'        NULL,',
'        SDO_ELEM_INFO_ARRAY(1, 1003, 3),',
'        SDO_ORDINATE_ARRAY(',
unistr('            139.64759444, 35.72404722,  -- \5DE6\4E0B'),
unistr('            139.67415833, 35.74030833   -- \53F3\4E0A'),
'        )',
'    ),',
unistr('    ''mask=INSIDE''  -- \77E9\5F62\5185\306B\5B8C\5168\306B\542B\307E\308C\308B\3082\306E\306E\307F'),
') = ''TRUE''',
'AND flood_depth > 0'))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_fill_color_spectr_name=>'DarkMint'
,p_fill_color_spectr_type=>'SEQUENTIAL'
,p_fill_value_column=>'FLOOD_DEPTH'
,p_allow_hide=>true
);
wwv_flow_imp.component_end;
end;
/
