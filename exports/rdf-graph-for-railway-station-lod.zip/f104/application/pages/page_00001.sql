prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>5050556754310867
,p_default_application_id=>104
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\9244\9053\99C5')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9835789418841713)
,p_plug_name=>unistr('\9244\9053\99C5')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22413259266708644)
,p_plug_name=>unistr('\9244\9053\99C5')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(22413318994708645)
,p_region_id=>wwv_flow_imp.id(22413259266708644)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
,p_copyright_notice=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="https://uedayou.net/">&copy; uedayou</a>&nbsp;',
'<a href="https://www.maptiler.com/copyright">&copy; MapTiler</a>&nbsp;',
'<a href="https://www.openstreetmap.org/copyright">&copy; OpenStreetMap contributors</a>'))
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(22413411581708646)
,p_map_region_id=>wwv_flow_imp.id(22413318994708645)
,p_name=>unistr('\8DEF\7DDA')
,p_layer_type=>'LINE'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.s$rdfterm name, sdo_util.from_wktgeometry(t.o$rdfclob) geom',
'from table(sem_match(',
'    query => q''[',
'        SELECT ?s ?o',
'        WHERE',
'        { ?s gsp:asWKT ?o }',
'    ]''',
'    , models => SEM_MODELS(''RAILWAYS'')',
'    , rulebases => null',
'    , aliases => SEM_ALIASES(',
'        SEM_ALIAS(''gsp'',''http://www.opengis.net/ont/geosparql#'')',
'    )',
'    , filter => null',
'    , options =>'' PLUS_RDFT=VC ''',
'    , network_owner => ''WKSP_APEXDEV''',
'    , network_name => ''LOCALNET''',
')) t',
unistr('where t.s$rdfterm = ''<https://uedayou.net/jrslod/\6771\6D77\65C5\5BA2\9244\9053/\6771\6D77\9053\65B0\5E79\7DDA>'';')))
,p_has_spatial_index=>false
,p_pk_column=>'NAME'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOM'
,p_stroke_color=>'#101010'
,p_stroke_style=>'SOLID'
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp.component_end;
end;
/
