prompt --application/shared_components/files/model_onnx
begin
--   Manifest
--     APP STATIC FILES: 204
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>204
,p_default_id_offset=>106648380594802041
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '0803120C6261636B656E642D746573743A620A110A01610A016212016322064D61744D756C120E746573745F6D61746D756C5F32645A130A0161120E0A0C080112080A0208030A0208045A130A0162120E0A0C080112080A0208040A02080362130A0163';
wwv_flow_imp.g_varchar2_table(2) := '120E0A0C080112080A0208030A02080342021009';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(213293765561481199)
,p_file_name=>'model.onnx'
,p_mime_type=>'application/octet-stream'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
