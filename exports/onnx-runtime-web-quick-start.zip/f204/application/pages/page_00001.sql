prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>204
,p_default_id_offset=>106648380594802041
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'ONNX Runtime Web'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "onnxruntime-web": "https://cdn.jsdelivr.net/npm/onnxruntime-web/dist/esm/ort.min.js",',
'            "onnxruntime-web/wasm": "https://cdn.jsdelivr.net/npm/onnxruntime-web/dist/esm/ort.wasm.min.js"',
'        }',
'    }',
'</script>'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105697695787803740)
,p_plug_name=>'Output'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(213069812427021445)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="output"></div>',
'<script type="module" defer>',
'// see also advanced usage of importing ONNX Runtime Web:',
'// https://github.com/microsoft/onnxruntime-inference-examples/tree/main/js/importing_onnxruntime-web',
'',
'// import ONNXRuntime Web from CDN',
'import * as ort from "onnxruntime-web";',
'// set wasm path override',
'ort.env.wasm.wasmPaths = "https://cdn.jsdelivr.net/npm/onnxruntime-web/dist/";',
'',
'// use an async context to call onnxruntime functions.',
'async function main() {',
'    try {',
'        // create a new session and load the specific model.',
'        //',
'        // the model in this example contains a single MatMul node',
'        // it has 2 inputs: ''a''(float32, 3x4) and ''b''(float32, 4x3)',
'        // it has 1 output: ''c''(float32, 3x3)',
'        const session = await ort.InferenceSession.create(''#APP_FILES#model.onnx'');',
'',
'        // prepare inputs. a tensor need its corresponding TypedArray as data',
'        const dataA = Float32Array.from([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]);',
'        const dataB = Float32Array.from([10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120]);',
'        const tensorA = new ort.Tensor(''float32'', dataA, [3, 4]);',
'        const tensorB = new ort.Tensor(''float32'', dataB, [4, 3]);',
'',
'        // prepare feeds. use model input names as keys.',
'        const feeds = { a: tensorA, b: tensorB };',
'',
'        // feed inputs and run',
'        const results = await session.run(feeds);',
'',
'        // read from results',
'        const dataC = results.c.data;',
'',
'        // document.write(`data of result tensor ''c'': ${dataC}`);',
'        document.getElementById("output").textContent = `data of result tensor ''c'': ${dataC}`;',
'',
'    } catch (e) {',
'        // document.write(`failed to inference ONNX model: ${e}.`);',
'        document.getElementById("output").textContent = `failed to inference ONNX model: ${e}.`;',
'    }',
'}',
'',
'main();',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213267612982022348)
,p_plug_name=>'ONNX Runtime Web'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(213046557083021393)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
