prompt --application/plugin_settings
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>204
,p_default_id_offset=>106648380594802041
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212962030800021090)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'include_slider', 'Y')).to_clob
,p_version_scn=>41793761387192
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212962329629021093)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attribute_01=>'FULL'
,p_attribute_02=>'POPUP'
,p_version_scn=>41793761387194
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212962646355021094)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SELECT_MANY'
,p_attribute_01=>'separated'
,p_version_scn=>41793761387194
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212962923160021095)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_MAP_REGION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_vector_tile_layers', 'Y')).to_clob
,p_version_scn=>41793761387194
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212963262857021095)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attribute_01=>'fa-star'
,p_attribute_04=>'#VALUE#'
,p_version_scn=>41793761387194
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212963563755021096)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_ADFBC'
,p_version_scn=>41793761387194
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212963876315021097)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'actions_menu_structure', 'IG')).to_clob
,p_version_scn=>41793761387194
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212964135598021097)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attribute_01=>'Y'
,p_attribute_03=>'N'
,p_attribute_05=>'SWITCH_CB'
,p_version_scn=>41793761387194
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212964449935021098)
,p_plugin_type=>'DYNAMIC ACTION'
,p_plugin=>'NATIVE_OPEN_AI_ASSISTANT'
,p_version_scn=>41793761387195
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212964768273021099)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_APEX'
,p_attribute_01=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_02=>'VISIBLE'
,p_attribute_03=>'15'
,p_attribute_04=>'FOCUS'
,p_version_scn=>41793761387228
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212965040210021100)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_GEOCODED_ADDRESS'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_attribute_02=>'N'
,p_attribute_03=>'POPUP:ITEM'
,p_attribute_04=>'default'
,p_attribute_06=>'LIST'
,p_version_scn=>41793761387256
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212965296557021101)
,p_plugin_type=>'PROCESS TYPE'
,p_plugin=>'NATIVE_GEOCODING'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_version_scn=>41793761387288
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(212965584837021101)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_version_scn=>41793761387324
);
wwv_flow_imp.component_end;
end;
/
