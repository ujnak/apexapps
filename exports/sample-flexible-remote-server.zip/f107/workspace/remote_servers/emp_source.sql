prompt --workspace/remote_servers/emp_source
begin
--   Manifest
--     REMOTE SERVER: EMP Source
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(21216357356080774)
,p_name=>'EMP Source'
,p_static_id=>'EMP_Source'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('EMP_Source'),'#proto#://#host#:#port#/ords/#workspace#/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('EMP_Source'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('EMP_Source'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('EMP_Source'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('EMP_Source'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('EMP_Source'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('EMP_Source'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('EMP_Source'),'')
,p_configuration_procedure=>'config_remote_server'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure config_remote_server( ',
'    p_info    in  apex_plugin.t_remote_server_info',
'    ,p_config out apex_plugin.t_remote_server_config',
')',
'is',
'begin',
'    p_config.base_url := ''#proto#://#host#:#port#/ords/#workspace#/'';',
'    p_config.substitutions := apex_t_varchar2();',
'    apex_string.plist_put(p_config.substitutions, ''proto'',     nvl(v(''P1_PROTO''),''http''));',
'    apex_string.plist_put(p_config.substitutions, ''host'',      nvl(v(''P1_HOST''),''localhost''));',
'    apex_string.plist_put(p_config.substitutions, ''port'',      nvl(v(''P1_PORT''),''8181''));',
'    apex_string.plist_put(p_config.substitutions, ''workspace'', nvl(v(''P1_WORKSPACE''),''rest1''));',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
