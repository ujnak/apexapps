prompt --application/shared_components/user_interface/lovs/voices
begin
--   Manifest
--     VOICES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(24116566848961551)
,p_lov_name=>'VOICES'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(24087460192708119)
,p_use_local_sync_table=>true
,p_return_column_name=>'VOICE_ID'
,p_display_column_name=>'NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15642636
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24118814653027581)
,p_query_column_name=>'VOICE_ID'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24116925592027581)
,p_query_column_name=>'NAME'
,p_heading=>'Name'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24117259406027581)
,p_query_column_name=>'LABELS_AGE'
,p_heading=>'Labels Age'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24118452179027581)
,p_query_column_name=>'LABELS_ACCENT'
,p_heading=>'Labels Accent'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24118058877027581)
,p_query_column_name=>'LABELS_GENDER'
,p_heading=>'Labels Gender'
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24119681388027581)
,p_query_column_name=>'LABELS_LANGUAGE'
,p_heading=>'Labels Language'
,p_display_sequence=>60
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24120039936027581)
,p_query_column_name=>'LABELS_USE_CASE'
,p_heading=>'Labels Use Case'
,p_display_sequence=>70
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24119298888027581)
,p_query_column_name=>'LABELS_DESCRIPTIVE'
,p_heading=>'Labels Descriptive'
,p_display_sequence=>80
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24117697862027581)
,p_query_column_name=>'DESCRIPTION'
,p_heading=>'Description'
,p_display_sequence=>90
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
