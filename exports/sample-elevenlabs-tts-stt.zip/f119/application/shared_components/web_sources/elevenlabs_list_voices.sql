prompt --application/shared_components/web_sources/elevenlabs_list_voices
begin
--   Manifest
--     WEB SOURCE: ElevenLabs List voices
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(24087460192708119)
,p_name=>'ElevenLabs List voices'
,p_static_id=>'elevenlabs_list_voices'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(24064712857708113)
,p_remote_server_id=>wwv_flow_imp.id(23956922792114595)
,p_url_path_prefix=>'v2/voices'
,p_credential_id=>wwv_flow_imp.id(23940405554592329)
,p_sync_table_name=>'ELEVENLABS_VOICES'
,p_sync_type=>'REPLACE'
,p_sync_max_http_requests=>1000
,p_attribute_01=>'PAGE_TOKEN_FLEXIBLE_SIZE'
,p_attribute_02=>'page_size'
,p_attribute_03=>'100'
,p_attribute_09=>'has_more'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
,p_attribute_12=>'total_count'
,p_attribute_13=>'next_page_token'
,p_attribute_14=>'next_page_token'
,p_version_scn=>15618804
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(24087667115708120)
,p_web_src_module_id=>wwv_flow_imp.id(24087460192708119)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
