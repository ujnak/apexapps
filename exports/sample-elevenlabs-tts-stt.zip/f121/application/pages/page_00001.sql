prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>121
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'ElevenLabs'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- [module]#APP_FILES#app#MIN#.js',
'[module]#APP_FILES#improved_voice_recorder#MIN#.js'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23319105227054944)
,p_plug_name=>'Voice Recorder'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23319404640054947)
,p_plug_name=>'Recorder'
,p_parent_plug_id=>wwv_flow_imp.id(23319105227054944)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_source=>'<audio id="recorder" controls></audio>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23942555334952404)
,p_plug_name=>'Button Container'
,p_parent_plug_id=>wwv_flow_imp.id(23319105227054944)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23913094814419555)
,p_plug_name=>'ElevenLabs'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23942719305952406)
,p_plug_name=>'Transcribe'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23942842326952407)
,p_plug_name=>'Speech'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23319260184054945)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(23942555334952404)
,p_button_name=>'START'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Start'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="start-voice-recording"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23319320562054946)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(23942555334952404)
,p_button_name=>'STOP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Stop'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="stop-voice-recording"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23319616305054949)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(23942719305952406)
,p_button_name=>'TRANSCRIBE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Transcribe'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="transcribe"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23942443214952403)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(23942719305952406)
,p_button_name=>'CREATE_VOICE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Create Voice'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="create-voice"'
,p_required_patch=>wwv_flow_imp.id(23899238481419529)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23943146882952410)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(23942842326952407)
,p_button_name=>'CREATE_SPEECH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Create Speech'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="create-speech"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23319790128054950)
,p_name=>'P1_LANGUAGE_CODE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(23942719305952406)
,p_prompt=>'language_code'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23942288679952401)
,p_name=>'P1_LANGUAGE_PROBABILITY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(23942719305952406)
,p_prompt=>'language_probability'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23942315079952402)
,p_name=>'P1_TEXT'
,p_item_sequence=>20
,p_prompt=>'text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23942996263952408)
,p_name=>'P1_VOICE_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(23942842326952407)
,p_prompt=>'Voice Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(23899238481419529)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23943057617952409)
,p_name=>'P1_VOICE_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(23942842326952407)
,p_prompt=>'Voice ID'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'AVAILABLE_VOICES'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(23319526844054948)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'TRANSCRIBE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    /*',
'     * ElevenLabs / Create transcript',
'     * https://elevenlabs.io/docs/api-reference/speech-to-text/convert',
'     */',
'    l_voice blob;',
'    l_mime_type varchar2(80);',
'    l_multipart apex_web_service.t_multipart_parts;',
'    l_multipart_request blob; ',
'    l_response_clob clob;',
'    l_response      json_object_t;',
'    l_response_blob blob;',
'    e_call_api_failed exception;',
'begin',
'    /*',
unistr('     * \97F3\58F0\30C7\30FC\30BF\306Fbase64\3067\30A8\30F3\30B3\30FC\30C9\3055\308C\305FCLOB\3068\3057\3066\30D6\30E9\30A6\30B6\304B\3089\53D7\4FE1\3059\308B\3002'),
'     */',
'    l_voice := apex_web_service.clobbase642blob(apex_application.g_clob_01);',
'    l_mime_type := apex_application.g_x01;',
'    /*',
unistr('     * model_id\306Fscribe_v1\307E\305F\306Fscribe_v1_experimental\306E\3069\3061\3089\304B\306A\306E\3067\3001'),
unistr('     * scribe_v1\306B\56FA\5B9A\3057\3066\3044\308B\3002'),
'     */',
'    apex_web_service.append_to_multipart(',
'        p_multipart     => l_multipart',
'        ,p_name         => ''model_id''',
'        ,p_content_type => ''text/plain''',
'        ,p_body         => ''scribe_v1''',
'    );',
'    /*',
unistr('     * \30D6\30E9\30A6\30B6\3067\9332\97F3\3055\308C\305F\30C7\30FC\30BF\3092\542B\3081\308B\3002'),
'     */',
'    apex_web_service.append_to_multipart(',
'        p_multipart     => l_multipart',
'        ,p_name         => ''file''',
unistr('        ,p_filename     => ''voice.wav'' -- \30D5\30A1\30A4\30EB\540D\306F\5FC5\9808\3002'),
'        ,p_content_type => l_mime_type',
'        ,p_body_blob    => l_voice',
'    );',
'    l_multipart_request := apex_web_service.generate_request_body(l_multipart);',
'    l_response_clob := apex_web_service.make_rest_request(   ',
'        p_url => ''https://api.elevenlabs.io/v1/speech-to-text'' ',
'        ,p_http_method => ''POST'' ',
'        ,p_body_blob => l_multipart_request ',
'        ,p_credential_static_id => ''ELEVENLABS_API_KEY''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_call_api_failed;',
'    end if;',
unistr('    -- \6587\5B57\6570\5236\9650\306E\7121\3044\65B9\6CD5\3067\30EC\30B9\30DD\30F3\30B9\3092\8FD4\3059\3002'),
'    l_response := json_object_t(l_response_clob);',
'    l_response_blob := l_response.to_blob();',
'    sys.htp.init;',
'    sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_response_blob));',
'    sys.htp.p(''Content-Type: application/json'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_response_blob);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>23319526844054948
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(23942650677952405)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CREATE_VOICE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    /*',
'     * ElevenLabs / Create IVC voice',
'     * https://elevenlabs.io/docs/api-reference/voices/ivc/create',
'     *',
unistr('     * \30DC\30A4\30B9\30FB\30AF\30ED\30FC\30F3\3092\5229\7528\3059\308B\306B\306F\30A2\30AB\30A6\30F3\30C8\306E\30A2\30C3\30D7\30B0\30EC\30FC\30C9\3092\3059\308B\5FC5\8981\304C\3042\308B\3002'),
unistr('     * \4EE5\4E0B\306E\30B3\30FC\30C9\306F\672A\78BA\8A8D\3002'),
'     */',
'    l_voice blob;',
'    l_mime_type varchar2(80);',
'    l_multipart apex_web_service.t_multipart_parts;',
'    l_multipart_request blob; ',
'    l_response clob;',
'    e_call_api_failed exception;',
'begin',
'    l_voice := apex_web_service.clobbase642blob(apex_application.g_clob_01);',
'    l_mime_type := apex_application.g_x01;',
'    apex_web_service.append_to_multipart(',
'        p_multipart     => l_multipart',
'        ,p_name         => ''name''',
'        ,p_content_type => ''text/plain''',
'        ,p_body         => :P1_VOICE_NAME',
'    );',
'    apex_web_service.append_to_multipart(',
'        p_multipart     => l_multipart',
'        ,p_name         => ''file''',
'        ,p_filename     => ''voice.wav''',
'        ,p_content_type => l_mime_type',
'        ,p_body_blob    => l_voice       ',
'    );',
'    l_multipart_request := apex_web_service.generate_request_body(l_multipart);',
'    l_response := apex_web_service.make_rest_request(   ',
'        p_url => ''https://api.elevenlabs.io/v1/voices/add'' ',
'        ,p_http_method => ''POST'' ',
'        ,p_body_blob => l_multipart_request ',
'        ,p_credential_static_id => ''ELEVENLABS_API_KEY''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_call_api_failed;',
'    end if;',
unistr('    -- \30EC\30B9\30DD\30F3\30B9\306F\305D\306E\307E\307E\30D6\30E9\30A6\30B6\306B\8FD4\3059\3002'),
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>23942650677952405
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(23943213192952411)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CREATE_SPEECH'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    /*',
'     * ElevenLabs / Create speech',
'     * https://elevenlabs.io/docs/api-reference/text-to-speech/convert',
'     */',
'    C_AUDIO_FORMAT constant varchar2(20) := ''mp3_44100_128''; -- MP3, Sampling 44.1kHZ, bitrate 128kbps',
'    C_MIME_TYPE    constant varchar2(20) := ''audio/mpeg'';',
'    C_MODEL_ID     constant varchar2(30) := ''eleven_multilingual_v2'';    ',
'    l_voice blob;',
'    l_voice_clob clob;',
'    l_text  clob;',
'    l_url varchar2(4000);',
'    l_response json_object_t;',
'    l_response_blob blob;',
'    l_voice_id varchar2(255);',
'    l_request json_object_t;',
'    l_request_clob clob;',
'    e_call_api_failed exception;',
'begin',
'    l_voice_id := :P1_VOICE_ID;',
'    l_url := apex_string.format(''https://api.elevenlabs.io/v1/text-to-speech/%s?output_format=%s'', l_voice_id, C_AUDIO_FORMAT);',
'    l_request := json_object_t();',
'    l_text := apex_application.g_clob_01;',
'    l_request.put(''text'', l_text);',
'    l_request.put(''model_id'', C_MODEL_ID);',
'    l_request_clob := l_request.to_clob();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'');',
'    l_voice := apex_web_service.make_rest_request_b(   ',
'        p_url => l_url',
'        ,p_http_method => ''POST'' ',
'        ,p_body => l_request_clob',
'        ,p_credential_static_id => ''ELEVENLABS_API_KEY''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_call_api_failed;',
'    end if;',
'    l_response := json_object_t();',
'    l_voice_clob := apex_web_service.blob2clobbase64(l_voice);',
'    l_response.put(''type'', C_MIME_TYPE);',
'    l_response.put(''content'', l_voice_clob);',
'    l_response_blob := l_response.to_blob();',
unistr('    -- type\3068content\3092\542B\3080JSON\3068\3057\3066\30D6\30E9\30A6\30B6\306B\97F3\58F0\3092\623B\3059\3002'),
'    sys.htp.init;',
'    sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_response_blob));',
'    sys.htp.p(''Content-Type: application/json'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_response_blob);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>23943213192952411
);
wwv_flow_imp.component_end;
end;
/
