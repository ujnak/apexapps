prompt --application/shared_components/user_interface/lovs/available_voices
begin
--   Manifest
--     AVAILABLE_VOICES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>121
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(24008078229139294)
,p_lov_name=>'AVAILABLE_VOICES'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(23979518689114601)
,p_use_local_sync_table=>true
,p_return_column_name=>'VOICE_ID'
,p_display_column_name=>'NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15462850
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24010524244152922)
,p_query_column_name=>'VOICE_ID'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24008566645152921)
,p_query_column_name=>'NAME'
,p_heading=>'Name'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24008947153152921)
,p_query_column_name=>'LABELS_AGE'
,p_heading=>'Labels Age'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24010186230152922)
,p_query_column_name=>'LABELS_ACCENT'
,p_heading=>'Labels Accent'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24009753717152922)
,p_query_column_name=>'LABELS_GENDER'
,p_heading=>'Labels Gender'
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24011379922152922)
,p_query_column_name=>'LABELS_LANGUAGE'
,p_heading=>'Labels Language'
,p_display_sequence=>60
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24011713559152922)
,p_query_column_name=>'LABELS_USE_CASE'
,p_heading=>'Labels Use Case'
,p_display_sequence=>70
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24009371632152921)
,p_query_column_name=>'LABELS_DESCRIPTION'
,p_heading=>'Labels Description'
,p_display_sequence=>80
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(24010957631152922)
,p_query_column_name=>'LABELS_DESCRIPTIVE'
,p_heading=>'Labels Descriptive'
,p_display_sequence=>90
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
