prompt --workspace/remote_servers/api_elevenlabs_io
begin
--   Manifest
--     REMOTE SERVER: api-elevenlabs-io
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>121
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(23956922792114595)
,p_name=>'api-elevenlabs-io'
,p_static_id=>'api_elevenlabs_io'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('api_elevenlabs_io'),'https://api.elevenlabs.io/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('api_elevenlabs_io'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('api_elevenlabs_io'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('api_elevenlabs_io'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('api_elevenlabs_io'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('api_elevenlabs_io'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('api_elevenlabs_io'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('api_elevenlabs_io'),'')
);
wwv_flow_imp.component_end;
end;
/
