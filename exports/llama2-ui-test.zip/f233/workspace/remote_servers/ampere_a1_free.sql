prompt --workspace/remote_servers/ampere_a1_free
begin
--   Manifest
--     REMOTE SERVER: Ampere A1 Free
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>233
,p_default_id_offset=>45493224565663106
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(90602090431493026)
,p_name=>'Ampere A1 Free'
,p_static_id=>'Ampere_A1_Free'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('Ampere_A1_Free'),'https://your.llama2.server/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('Ampere_A1_Free'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('Ampere_A1_Free'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('Ampere_A1_Free'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('Ampere_A1_Free'),'')
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
