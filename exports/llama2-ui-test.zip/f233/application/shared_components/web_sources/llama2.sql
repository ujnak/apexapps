prompt --application/shared_components/web_sources/llama2
begin
--   Manifest
--     WEB SOURCE: Llama2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>233
,p_default_id_offset=>45493224565663106
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(90960506199466674)
,p_name=>'Llama2'
,p_static_id=>'llama2'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(90959416002466673)
,p_remote_server_id=>wwv_flow_imp.id(90602090431493026)
,p_url_path_prefix=>'chat'
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(90960715704466675)
,p_web_src_module_id=>wwv_flow_imp.id(90960506199466674)
,p_operation=>'POST'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'"max_tokens": #MAX_TOKENS#,',
'"query": "#PROMPT#"',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(90966115396545464)
,p_web_src_module_id=>wwv_flow_imp.id(90960506199466674)
,p_web_src_operation_id=>wwv_flow_imp.id(90960715704466675)
,p_name=>'MAX_TOKENS'
,p_param_type=>'BODY'
,p_value=>'64'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(90966593336545464)
,p_web_src_module_id=>wwv_flow_imp.id(90960506199466674)
,p_web_src_operation_id=>wwv_flow_imp.id(90960715704466675)
,p_name=>'PROMPT'
,p_param_type=>'BODY'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(90967645239614321)
,p_web_src_module_id=>wwv_flow_imp.id(90960506199466674)
,p_web_src_operation_id=>wwv_flow_imp.id(90960715704466675)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(90968112555616173)
,p_web_src_module_id=>wwv_flow_imp.id(90960506199466674)
,p_web_src_operation_id=>wwv_flow_imp.id(90960715704466675)
,p_name=>'Accept'
,p_param_type=>'HEADER'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp.component_end;
end;
/
