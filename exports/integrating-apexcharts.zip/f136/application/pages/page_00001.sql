prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>136
,p_default_id_offset=>35401153623220381
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Integrating ApexCharts'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/apexcharts/dist/apexcharts.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var options = {',
'  chart: {',
'    type: ''bar''',
'  },',
'  plotOptions: {',
'    bar: {',
'        horizontal: true',
'    }',
'  },',
'  series: [{',
'    color: "#309fdb",',
'    data: JSON.parse(apex.items.P1_VALUE.value)',
'  }],',
'  xaxis: {',
'    categories: JSON.parse(apex.items.P1_GROUPS.value)',
'  }',
'}',
'',
'var chart = new ApexCharts(document.querySelector("#myChart"), options);',
'',
'chart.render();'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/apexcharts/dist/apexcharts.min.css',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134132384494764283)
,p_plug_name=>'ApexCharts'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(134845750382893626)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<div id="myChart"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(135043768806894327)
,p_plug_name=>'Integrating ApexCharts'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(134822483241893577)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134131957864764279)
,p_name=>'P1_GROUPS'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134132060874764280)
,p_name=>'P1_VALUE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(134132128056764281)
,p_computation_sequence=>10
,p_computation_item=>'P1_GROUPS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        ename',
'    order by empno asc )',
'from emp where deptno = 10'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(134132244434764282)
,p_computation_sequence=>20
,p_computation_item=>'P1_VALUE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        sal',
'    order by empno asc )',
'from emp where deptno = 10'))
);
wwv_flow_imp.component_end;
end;
/
