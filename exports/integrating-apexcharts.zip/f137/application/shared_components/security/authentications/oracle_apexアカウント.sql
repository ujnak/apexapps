prompt --application/shared_components/security/authentications/oracle_apexアカウント
begin
--   Manifest
--     AUTHENTICATION: Oracle APEXアカウント
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>137
,p_default_id_offset=>33935222283398220
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(99340942974672994)
,p_name=>unistr('Oracle APEX\30A2\30AB\30A6\30F3\30C8')
,p_scheme_type=>'NATIVE_APEX_ACCOUNTS'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>41128222108764
);
wwv_flow_imp.component_end;
end;
/
