prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 108
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>108
,p_default_id_offset=>17623117624195435
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(60124585606665011)
,p_prompt_sub_string_02=>'Y'
,p_install_prompt_02=>unistr('Pinecone\306E\30A4\30F3\30C7\30C3\30AF\30B9URL')
,p_prompt_sub_string_03=>'Y'
,p_install_prompt_03=>unistr('\30D9\30AF\30C8\30EB\57CB\3081\8FBC\307F\3092\751F\6210\3059\308B\30D9\30FC\30B9URL')
,p_prompt_sub_string_04=>'Y'
,p_install_prompt_04=>unistr('\30AA\30D6\30B8\30A7\30AF\30C8\30FB\30B9\30C8\30EC\30FC\30B8\306E\30CD\30FC\30E0\30B9\30DA\30FC\30B9')
,p_prompt_sub_string_05=>'Y'
,p_install_prompt_05=>unistr('\30A4\30E1\30FC\30B8\3092\4FDD\5B58\3059\308B\30D0\30B1\30C3\30C8\540D')
);
wwv_flow_imp.component_end;
end;
/
