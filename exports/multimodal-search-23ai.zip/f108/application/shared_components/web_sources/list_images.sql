prompt --application/shared_components/web_sources/list_images
begin
--   Manifest
--     WEB SOURCE: List Images
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>108
,p_default_id_offset=>20411754277158639
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(61743566752144391)
,p_name=>'List Images'
,p_static_id=>'list_images'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(61743125506144384)
,p_remote_server_id=>wwv_flow_imp.id(59780984571897928)
,p_url_path_prefix=>'n/:namespace/b/:bucket/o/'
,p_credential_id=>wwv_flow_imp.id(27528134761269476)
,p_sync_table_name=>'VEC_IMAGES'
,p_sync_type=>'REPLACE'
,p_sync_max_http_requests=>1000
,p_version_scn=>7283869
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(61758508200811894)
,p_web_src_module_id=>wwv_flow_imp.id(61743566752144391)
,p_name=>'namespace'
,p_param_type=>'URL_PATTERN'
,p_data_type=>'VARCHAR2'
,p_value=>'&G_NAMESPACE.'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(61758847300813087)
,p_web_src_module_id=>wwv_flow_imp.id(61743566752144391)
,p_name=>'bucket'
,p_param_type=>'URL_PATTERN'
,p_data_type=>'VARCHAR2'
,p_value=>'&G_BUCKET.'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(61743782594144393)
,p_web_src_module_id=>wwv_flow_imp.id(61743566752144391)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
