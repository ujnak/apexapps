prompt --application/shared_components/logic/application_items/g_preauth_url
begin
--   Manifest
--     APPLICATION ITEM: G_PREAUTH_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>108
,p_default_id_offset=>17623117624195435
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(58952806960957280)
,p_name=>'G_PREAUTH_URL'
,p_protection_level=>'I'
,p_version_scn=>6986321
);
wwv_flow_imp.component_end;
end;
/
