prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 108
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>108
,p_default_id_offset=>20411754277158639
,p_default_owner=>'WKSP_APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
