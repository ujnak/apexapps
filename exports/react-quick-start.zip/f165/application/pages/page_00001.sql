prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>165
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'React Quick Start'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "react": "https://cdn.jsdelivr.net/npm/react@18.3.1/+esm",',
'            "react-dom": "https://cdn.jsdelivr.net/npm/react-dom@18.3.1/+esm"',
'        }',
'    }',
'</script>'))
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/@babel/standalone/babel.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * React\306E\30AB\30B9\30BF\30E0\8981\7D20\306B\542B\307E\308C\308B\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3057\305F\3068\304D\306B\3001'),
unistr(' * APEX\304C\30DA\30FC\30B8\3092\9001\4FE1\3059\308B\306E\3092\6291\5236\3059\308B\3002'),
' */',
'document.addEventListener(''click'', (event) => {',
'    const buttons = document.querySelectorAll("#container button");',
'    buttons.forEach( (button) => {',
'        if (button === event.target) {',
'            console.log(''click on button within React component is ignored to prevent page submittion.'', event.target);',
'            event.preventDefault();',
'        }',
'    });',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'@scope(#container) {',
'    .avatar {',
'        border-radius: 50%;',
'    }',
'}',
'',
'/* Game */',
'@scope(#container) {',
'    ',
'* {',
'  box-sizing: border-box;',
'}',
'',
'body {',
'  font-family: sans-serif;',
'  margin: 20px;',
'  padding: 0;',
'}',
'',
'h1 {',
'  margin-top: 0;',
'  font-size: 22px;',
'}',
'',
'h2 {',
'  margin-top: 0;',
'  font-size: 20px;',
'}',
'',
'h3 {',
'  margin-top: 0;',
'  font-size: 18px;',
'}',
'',
'h4 {',
'  margin-top: 0;',
'  font-size: 16px;',
'}',
'',
'h5 {',
'  margin-top: 0;',
'  font-size: 14px;',
'}',
'',
'h6 {',
'  margin-top: 0;',
'  font-size: 12px;',
'}',
'',
'code {',
'  font-size: 1.2em;',
'}',
'',
'ul {',
'  padding-inline-start: 20px;',
'}',
'',
'.square {',
'  background: #fff;',
'  border: 1px solid #999;',
'  float: left;',
'  font-size: 24px;',
'  font-weight: bold;',
'  line-height: 34px;',
'  height: 34px;',
'  margin-right: -1px;',
'  margin-top: -1px;',
'  padding: 0;',
'  text-align: center;',
'  width: 34px;',
'}',
'',
'.board-row:after {',
'  clear: both;',
'  content: '''';',
'  display: table;',
'}',
'',
'.status {',
'  margin-bottom: 10px;',
'}',
'',
'.game {',
'  display: flex;',
'  flex-direction: row;',
'}',
'',
'.game-info {',
'  margin-left: 20px;',
'}',
'',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58200969804115618)
,p_plug_name=>'MyButton'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(59844841632818735)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="container"></div>',
'<script type="text/babel" data-presets="react" data-type="module">',
'import React from ''react'';',
'import ReactDOM from ''react-dom'';',
'',
'function MyButton() {',
'  return (',
'    <button>I''m a button</button>',
'  );',
'}',
'',
'class App extends React.Component {',
'    render() {',
'        return (',
'<>',
'<div>',
'    <h1>Welcome to my app</h1>',
'    <MyButton />',
'</div>',
'</>',
'        );',
'    }',
'}',
'',
'/* render React component within an APEX region */',
'const container = document.getElementById("container");',
'const root = ReactDOM.createRoot( container );',
'root.render( <App /> );',
'</script>'))
,p_required_patch=>wwv_flow_imp.id(59740914111818514)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58201077690115619)
,p_plug_name=>'App'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(59844841632818735)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="container"></div>',
'<script type="text/babel" data-presets="react" data-type="module">',
'import React from ''react'';',
'import ReactDOM from ''react-dom'';',
'import App from "#APP_FILES#App.js";',
'',
'/* render React component within an APEX region */',
'const container = document.getElementById("container");',
'const root = ReactDOM.createRoot( container );',
'root.render( <App /> );',
'</script>'))
,p_required_patch=>wwv_flow_imp.id(59740914111818514)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58201108286115620)
,p_plug_name=>'Profile'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(59844841632818735)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="container"></div>',
'<script type="text/babel" data-presets="react" data-type="module">',
'import React from ''react'';',
'import ReactDOM from ''react-dom'';',
'import Profile from "#APP_FILES#Profile.js";',
'',
'/* render React component within an APEX region */',
'const container = document.getElementById("container");',
'const root = ReactDOM.createRoot( container );',
'root.render( <Profile /> );',
'</script>'))
,p_required_patch=>wwv_flow_imp.id(59740914111818514)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58201272836115621)
,p_plug_name=>'ShoppingList'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(59844841632818735)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="container"></div>',
'<script type="text/babel" data-presets="react" data-type="module">',
'import React from ''react'';',
'import ReactDOM from ''react-dom'';',
'import ShoppingList from "#APP_FILES#ShoppingList.js";',
'',
'/* render React component within an APEX region */',
'const container = document.getElementById("container");',
'const root = ReactDOM.createRoot( container );',
'root.render( <ShoppingList /> );',
'</script>'))
,p_required_patch=>wwv_flow_imp.id(59740914111818514)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58201388727115622)
,p_plug_name=>'MyApp'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(59844841632818735)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="container"></div>',
'<script type="text/babel" data-presets="react" data-type="module">',
'import React from ''react'';',
'import ReactDOM from ''react-dom'';',
'import MyApp from "#APP_FILES#MyApp.js";',
'',
'/* render React component within an APEX region */',
'const container = document.getElementById("container");',
'const root = ReactDOM.createRoot( container );',
'root.render( <MyApp /> );',
'</script>'))
,p_required_patch=>wwv_flow_imp.id(59740914111818514)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58201456393115623)
,p_plug_name=>'MyApp2'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(59844841632818735)
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="container"></div>',
'<script type="text/babel" data-presets="react" data-type="module">',
'import React, { useState } from ''react'';',
'import ReactDOM from ''react-dom'';',
'import MyApp from "#APP_FILES#MyApp2.js";',
'',
'/* render React component within an APEX region */',
'const container = document.getElementById("container");',
'const root = ReactDOM.createRoot( container );',
'root.render( <MyApp /> );',
'</script>'))
,p_required_patch=>wwv_flow_imp.id(59740914111818514)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58201574619115624)
,p_plug_name=>'Game'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(59844841632818735)
,p_plug_display_sequence=>70
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="container"></div>',
'<script type="text/babel" data-presets="react" data-type="module">',
'import React from ''react'';',
'import ReactDOM from ''react-dom'';',
'import Game from "#APP_FILES#Game.js";',
'',
'/* render React component within an APEX region */',
'const container = document.getElementById("container");',
'const root = ReactDOM.createRoot( container );',
'root.render( <Game /> );',
'</script>'))
,p_required_patch=>wwv_flow_imp.id(59740914111818514)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58201625776115625)
,p_plug_name=>'App3'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(59844841632818735)
,p_plug_display_sequence=>80
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="container"></div>',
'<script type="text/babel" data-presets="react" data-type="module">',
'import React from ''react'';',
'import ReactDOM from ''react-dom'';',
'import App from ''#APP_FILES#App3.js'';',
'',
'/* render React component within an APEX region */',
'const container = document.getElementById("container");',
'const root = ReactDOM.createRoot( container );',
'root.render( <App /> );',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60042715747819363)
,p_plug_name=>'React Quick Start'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(59811545400818665)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
