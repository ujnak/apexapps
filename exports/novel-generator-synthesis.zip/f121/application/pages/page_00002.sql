prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>121
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>unistr('\5C0F\8AAC\3092\8AAD\3080')
,p_alias=>'READ-STORY'
,p_step_title=>unistr('\5C0F\8AAC\3092\8AAD\3080')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[module,defer]#APP_FILES#js/readout#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28629688539763815)
,p_plug_name=>'Item Container'
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--alignCenter'
,p_plug_template=>1569994581593435632
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28630143750763820)
,p_plug_name=>unistr('\5C0F\8AAC')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_end    integer;',
'    l_length integer;',
'    l_story  clob;',
'begin',
'    if :P2_STORY is not null then',
'        select story into l_story from ebaj_stories where id = :P2_STORY;',
'        if :P2_EXCLUDE_THINK = ''Y'' then',
unistr('            -- DeepSeek-R1\306E\51FA\529B\306F\304B\306A\3089\305A<think>\3067\59CB\307E\308B\3053\3068\3092\60F3\5B9A\3002'),
'            l_length := dbms_lob.getlength(l_story);',
'            l_end    := instr(l_story, ''</think>'') + length(''</think>'');',
unistr('            -- \51FA\529B\306E\5148\982D\306F\3064\306D\306B<think>\304B\3089\59CB\307E\308B\304B\3089\3001\3064\306D\306B</think>\4EE5\964D\3092\8FD4\3059\3002'),
'            l_story := dbms_lob.substr(l_story, (l_length - l_end + 1), l_end);',
'        end if;',
'        l_story := ''<div id="STORY">'' || apex_markdown.to_html(l_story) || ''</div>'';',
'        return l_story;',
'    end if;',
'    return '''';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28630913616763828)
,p_plug_name=>'Readout Container'
,p_region_name=>'READOUT'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>50
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28630653011763825)
,p_plug_name=>'Audio'
,p_parent_plug_id=>wwv_flow_imp.id(28630913616763828)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>'<audio controls id="story-audio"></audio>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30335043007178309)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(30311752687455324)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28630831256763827)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(28630913616763828)
,p_button_name=>'READOUT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\8AAD\307F\4E0A\3052\308B')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="READOUT"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28629888813763817)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(28629688539763815)
,p_button_name=>'READ'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\8AAD\3080')
,p_button_position=>'BUTTON_END'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28629985039763818)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(28629688539763815)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'BUTTON_END'
,p_confirm_message=>unistr('\672C\5F53\306B\524A\9664\3057\307E\3059\304B\FF1F')
,p_confirm_style=>'danger'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28629781073763816)
,p_name=>'P2_STORY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(28629688539763815)
,p_prompt=>unistr('\5C0F\8AAC')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select title d, id r from ebaj_stories'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- \8AAD\307F\305F\3044\5C0F\8AAC\3092\9078\3093\3067 -')
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28630508529763824)
,p_name=>'P2_EXCLUDE_THINK'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(28630913616763828)
,p_item_default=>'N'
,p_prompt=>unistr('Think\3092\9664\304F')
,p_display_as=>'NATIVE_YES_NO'
,p_grid_row_css_classes=>'u-flex u-align-items-center'
,p_colspan=>2
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28631168410763830)
,p_name=>'P2_BASE_URL'
,p_item_sequence=>10
,p_source=>'G_VOICEVOX_BASE_URL'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28631262245763831)
,p_name=>'P2_SPEAKER'
,p_item_sequence=>20
,p_source=>'G_SPEAKER'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28631444980763833)
,p_name=>'P2_PROXY_URL'
,p_item_sequence=>30
,p_source=>'G_VOICEVOX_PROXY_URL'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28630038298763819)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE'
,p_process_sql_clob=>'delete from ebaj_stories where id = :P2_STORY;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28629985039763818)
,p_internal_uid=>28630038298763819
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28630283037763821)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>unistr('P2_STORY\306E\30AF\30EA\30A2')
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P2_STORY'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28629985039763818)
,p_internal_uid=>28630283037763821
);
wwv_flow_imp.component_end;
end;
/
