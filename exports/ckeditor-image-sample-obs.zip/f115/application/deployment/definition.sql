prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 115
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495801124689411
,p_default_application_id=>115
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(15334312689763971)
,p_prompt_sub_string_02=>'Y'
,p_install_prompt_02=>unistr('\753B\50CF\30A2\30C3\30D7\30ED\30FC\30C9URL')
,p_prompt_sub_string_03=>'Y'
,p_prompt_sub_string_04=>'Y'
,p_prompt_sub_string_05=>'Y'
,p_prompt_sub_string_06=>'Y'
,p_prompt_sub_string_07=>'Y'
);
wwv_flow_imp.component_end;
end;
/
