prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>5498096389773725
,p_default_application_id=>104
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\6771\4EAC\90FD\518D\958B\767A')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require requirejs]https://localhost:9443/spatialstudio/api/v1/embeddable.js?ex=kobinding'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const studioProjectElement = document.getElementById(''spatial-studio-project-1'');',
'const region = apex.region("TABLEREGION");',
'const grid   = region.call("getViews").grid;',
'const model  = grid.model;',
'',
'studioProjectElement.addEventListener(''features_selected'', (event) => {			',
'    const selectionObjects = event.detail.value;',
'    if (selectionObjects && selectionObjects.length > 0) {',
'        const selectedFeatures = selectionObjects[0].featureKeys;',
'        apex.debug.info("selected features:", selectedFeatures);',
'        /*',
unistr('         * \5BFE\8A71\30B0\30EA\30C3\30C9\3067getRecord\3067\304D\308B\306E\306F\3001\3059\3067\306B\8AAD\307F\8FBC\307F\6E08\307F\306E\30EC\30B3\30FC\30C9\306B'),
unistr('         * \9650\5B9A\3055\308C\308B\3002\305D\306E\305F\3081\3001\30DE\30C3\30D7\4E0A\3067\9078\629E\3057\305F\9818\57DF\306F\5FC5\305A\5B58\5728\3059\308B\306E\306B\3001'),
unistr('         * record\3068\3057\3066\306Fnull\304C\8FD4\3055\308C\308B\3053\3068\304C\3042\308B\3002'),
'         */',
'        const records = selectedFeatures',
'            .map(id => model.getRecord(id))',
'            .filter(rec => rec !== null && rec !== undefined);',
'        /*',
unistr('         * \30DE\30C3\30D7\4E0A\3067\9078\629E\3055\308C\305F\30EC\30B3\30FC\30C9\3067\5BFE\8A71\30B0\30EA\30C3\30C9\306E\9078\629E\3092\66F4\65B0\3059\308B\3002'),
unistr('         * \3053\306E\5834\5408\3001\9078\629E\306E\5909\66F4\30A4\30D9\30F3\30C8\304C\767A\751F\3059\308B\306E\3067\3001\5730\56F3\3082\66F4\65B0\3055\308C\308B\3002'),
unistr('         * \30DE\30C3\30D7\4E0A\3067\9818\57DF\3092\9078\629E\3057\3066\3082\5BFE\8A71\30B0\30EA\30C3\30C9\306B\30EC\30B3\30FC\30C9\304C\8AAD\307F\8FBC\307E\308C\3066\3044\306A\3044\3068\3001'),
unistr('         * \5BFE\8A71\30B0\30EA\30C3\30C9\3068\3057\3066\306F\9078\629E\3055\308C\305F\30EC\30B3\30FC\30C9\304C\5B58\5728\3057\306A\3044\3002'),
unistr('         * \305D\306E\5834\5408\3001\30DE\30C3\30D7\4E0A\306E\9818\57DF\306F\9078\629E\3055\308C\3066\3044\308B\304C\5BFE\8A71\30B0\30EA\30C3\30C9\306F\66F4\65B0\3055\308C\306A\3044\3001'),
unistr('         * \3068\3044\3046\7D50\679C\306B\306A\308B\3002'),
'         * ',
unistr('         * \5BFE\8A71\30B0\30EA\30C3\30C9\3068\3057\3066\306F\4ED5\69D8\901A\308A\306E\52D5\4F5C\3060\304C\3001\4F7F\3044\52DD\624B\306F\826F\304F\306A\3044\3002'),
'         */',
'        if (records && records.length > 0) {',
'            grid.setSelectedRecords(records);',
'        }',
'    }',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'body {',
'    --sgtech-bg: var(--rbr-blue);',
'    --oj-heading-text-color: white;',
'',
'    --ut-region-header-text-color: white;',
'    --ut-region-border-color: white;',
'    --ut-footer-text-color: white;',
'',
'    max-width: 100%;',
'',
'    --oj-core-spacing-3x: 0px;',
'    --ut-region-body-padding-y: 0px;',
'    --ut-region-body-padding-x: 0px;',
'}',
'',
'div.sgtech-home-container {',
'    max-height: 100%;',
'}',
'*/'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9716324987779985)
,p_plug_name=>unistr('\6771\4EAC\90FD\518D\958B\767A')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9718695641812901)
,p_plug_name=>'Spatial Studio'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="width:100%; height: 400px;">',
'    <spatial-studio-project ',
'        id="spatial-studio-project-1"',
'        server-url="https://localhost:9443/spatialstudio/"',
'        project-id="edc92249bfb9a70092d694056a813215"',
'        token="eyJ0eXAiOiJzZ3RlY2hfand0IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI3YTYzMGU2ODhkZDQ0Y2YzYjhjYzgxNTQ3NzRhODJkYSIsInN0dWRpb190ZW5hbnRfaWRlbnRpZmllciI6IkdMT0JBTDpAZGF0YWJhc2VAOkBkZWZhdWx0QCIsIm5iZiI6MTc2MjQ5NjA1MCwic2NvcGUiOiJyZXNvdXJjZS5yZWFkX3dy'
||'aXRlOnJlc291cmNlLnR5cGUuYWxsIiwiaXNzIjoiT3JhY2xlU3BhdGlhbFN0dWRpbyIsImV4cCI6MTc2MzA5NTk5MCwiaWF0IjoxNzYyNDk2MDUwLCJqdGkiOiIwNjMxYzQ4NS02YjNiLTRiZGQtOWRkYy0xNjMzNTU1OWUzZDEiLCJzdHVkaW9fb2lkIjoiYmUxYWFmNTFhY2RmNDgyYWI3NTVkZTYxMTVmNzg1NDAifQ.qfNoxEto7Sy'
||'vUijKDbyDYAz5G3hVWhPV047ys9XRqkUCBLkDgwvM62PiATW7UpZ7igbHC64bOomeywQ-2yMgSxQWvx6fdkxbpE9ihkUS5dUq3iJPSRODLJDKa7AWk1BC5ot2j6n1MkvAuqf6qb9sx0VuGc4fwO6sqi9lEe04DhZf_aVsShzHUYHwPrJnsMYL-9DbNfdoW6q9Mi4O9rtUZa5nreXuDiuMFx2SmluLL7jFzerpXPzy20mzw64GPUzs2s6Ri'
||'mH6elrWBSNpBRKLrScxqtSCyKpfiRLJ2UZJ-n4wvQdbkxJcQ4cXvYkvRx-hkdQQqWOBcnbd2Y77PzU-tg"',
'        project-header="off"',
'        layers-list="on">',
'    </spatial-studio-project>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10103627498011501)
,p_plug_name=>unistr('\533A\57DF')
,p_region_name=>'TABLEREGION'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'GIS_SAIKAIHATSU'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10113615541013201)
,p_name=>'OGR_FID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OGR_FID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10113774579013202)
,p_name=>'GEOM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GEOM'
,p_data_type=>'SDO_GEOMETRY'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Geom'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_enable_filter=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10113802137013203)
,p_name=>'AREA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AREA'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Area'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10113954440013204)
,p_name=>unistr('\5730\533A\540D')
,p_source_type=>'DB_COLUMN'
,p_source_expression=>unistr('\5730\533A\540D')
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('\5730\533A\540D')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10114071835013205)
,p_name=>unistr('\8A08\753B\9762\7A4D')
,p_source_type=>'DB_COLUMN'
,p_source_expression=>unistr('\8A08\753B\9762\7A4D')
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('\8A08\753B\9762\7A4D')
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10114129563013206)
,p_name=>unistr('\5F53\521D\6C7A\5B9A')
,p_source_type=>'DB_COLUMN'
,p_source_expression=>unistr('\5F53\521D\6C7A\5B9A')
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('\5F53\521D\6C7A\5B9A')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10114269465013207)
,p_name=>unistr('\6700\7D42\6C7A\5B9A')
,p_source_type=>'DB_COLUMN'
,p_source_expression=>unistr('\6700\7D42\6C7A\5B9A')
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('\6700\7D42\6C7A\5B9A')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10114367934013208)
,p_name=>unistr('\7167\4F1A\5148')
,p_source_type=>'DB_COLUMN'
,p_source_expression=>unistr('\7167\4F1A\5148')
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('\7167\4F1A\5148')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10118624860014501)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10118737590014502)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(10108696349012801)
,p_internal_uid=>10108696349012801
,p_is_editable=>true
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>400
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(10124509807030496)
,p_interactive_grid_id=>wwv_flow_imp.id(10108696349012801)
,p_static_id=>'101246'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(10124718634030497)
,p_report_id=>wwv_flow_imp.id(10124509807030496)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10125227981030499)
,p_view_id=>wwv_flow_imp.id(10124718634030497)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(10113615541013201)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10126199525030500)
,p_view_id=>wwv_flow_imp.id(10124718634030497)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(10113774579013202)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10127087892030501)
,p_view_id=>wwv_flow_imp.id(10124718634030497)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(10113802137013203)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10127950453030501)
,p_view_id=>wwv_flow_imp.id(10124718634030497)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(10113954440013204)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10128848442030502)
,p_view_id=>wwv_flow_imp.id(10124718634030497)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(10114071835013205)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10129721474030502)
,p_view_id=>wwv_flow_imp.id(10124718634030497)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(10114129563013206)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10130697569030503)
,p_view_id=>wwv_flow_imp.id(10124718634030497)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(10114269465013207)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10131593606030503)
,p_view_id=>wwv_flow_imp.id(10124718634030497)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(10114367934013208)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(10132420219030504)
,p_view_id=>wwv_flow_imp.id(10124718634030497)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(10118624860014501)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10135647056101301)
,p_name=>'Selection Change'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(10103627498011501)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10135758803101302)
,p_event_id=>wwv_flow_imp.id(10135647056101301)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const spatialStudioProjectElement = document.getElementById(''spatial-studio-project-1'');',
'',
'const currentSelectedRecords = this.data.selectedRecords;',
'const model = this.data.model;',
'const COLUMN_NAME = "OGR_FID";',
'const LAYER_ID = "17fed1cae714f726c6ce28c67413be20";',
'',
'if ( currentSelectedRecords.length > 0 ) {',
'    const selectedAreas = currentSelectedRecords.map(currentSelectedRecord => {',
'        return model.getValue(currentSelectedRecord, COLUMN_NAME);',
'    });',
'    apex.debug.info(selectedAreas);',
'    spatialStudioProjectElement.filterFeatures(LAYER_ID, COLUMN_NAME, selectedAreas);',
'} else {',
'    apex.debug.info("clear Filters");',
'    spatialStudioProjectElement.clearFilters && spatialStudioProjectElement.clearFilters(LAYER_ID);',
'}'))
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'document.querySelector(''#spatial-studio-project-1 studio-application'')'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10118848860014503)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(10103627498011501)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('\533A\57DF - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10118848860014503
);
wwv_flow_imp.component_end;
end;
/
