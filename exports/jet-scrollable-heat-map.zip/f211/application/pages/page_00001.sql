prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>211
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'JET Scrollable Heat Map'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'requirejs.config({',
'   paths: {',
'        ''dataProvider'': "&APEX_PATH!RAW.#APP_FILES#dataProvider",',
'    }',
'});',
'',
'require(["require", "exports", "knockout", "ojs/ojbootstrap", "dataProvider/DemoArrayDataGridProvider", "ojs/ojknockout", "ojs/ojdatagrid"], function (require, exports, ko, ojbootstrap_1, DemoArrayDataGridProvider_1) {',
'    "use strict";',
'      ',
'    class ViewModel {',
'        constructor(data) {',
'            // this.jsonData = JSON.parse(jsonData);',
'            this.jsonData = data;',
'            this.rowHeaderProperties = [''Region''];',
'            this.rowHeaders = this.rowHeaderProperties.map((prop) => {',
'                return this.jsonData.map((item) => {',
'                    return item[prop];',
'                });',
'            });',
'            this.columnHeaders = [',
'                Object.keys(this.jsonData[0]).filter((key) => {',
'                    return this.rowHeaderProperties.indexOf(key) === -1;',
'                })',
'            ];',
'            this.data = this.jsonData.map((item) => {',
'                return this.columnHeaders[0].map((header) => {',
'                    return { data: item[header] };',
'                });',
'            });',
'            this.dataGridProvider = ko.observable(new DemoArrayDataGridProvider_1.DemoArrayDataGridProvider({',
'                data: this.data,',
'                rowHeader: this.rowHeaders,',
'                columnHeader: this.columnHeaders',
'            }));',
'            this.columnHeaderRenderer = (headerContext) => {',
'                // container div to rotate the text',
'                var container = document.createElement(''div'');',
'                container.className = ''demo-content-container'';',
'                container.appendChild(document.createTextNode(headerContext.data));',
'                return { insert: container };',
'            };',
'            this.cellRenderer = (cellContext) => {',
'                // set the value as aria-label for screen reader on the cell',
'                var cell = cellContext.parentElement;',
'                cell.setAttribute(''aria-label'', cellContext.data);',
'            };',
'            this.setCellClass = (cellContext) => {',
'                const cell = cellContext.cell;',
'                const data = cell.data;',
'                if (data < -1.25) {',
'                    return ''oj-bg-success-30'';',
'                }',
'                // -1% > data >= -1.25%',
'                if (data < -1) {',
'                    return ''oj-bg-brand-30'';',
'                }',
'                // -0.75% > data >= -1%',
'                if (data < -0.75) {',
'                    return ''oj-bg-warning-30'';',
'                }',
'                // -0.5% > data >= -0.75%',
'                if (data < -0.5) {',
'                    return ''oj-bg-warning-20'';',
'                }',
'                // -0.25% > data >= -0.5%',
'                if (data < -0.25) {',
'                    return ''oj-bg-warning-10'';',
'                }',
'                // data > 2.25%',
'                if (data > 2.25) {',
'                    return ''oj-bg-neutral-200'';',
'                }',
'                // 2% < data <= 2.25%',
'                if (data > 2) {',
'                    return ''oj-bg-neutral-170'';',
'                }',
'                // 1.75% < data <= 2%',
'                if (data > 1.75) {',
'                    return ''oj-bg-success-20'';',
'                }',
'                // 1.5% < data <= 1.75%',
'                if (data > 1.5) {',
'                    return ''oj-bg-brand-20'';',
'                }',
'                // 1.25% < data <= 1.5%',
'                if (data > 1.25) {',
'                    return ''oj-bg-info-30'';',
'                }',
'                // 1% < data <= 1.25%',
'                if (data > 1) {',
'                    return ''oj-bg-info-20'';',
'                }',
'                // 0.75% < data <= 1%',
'                if (data > 0.75) {',
'                    return ''oj-bg-info-10'';',
'                }',
'                // 0.5% < data <= 0.75%',
'                if (data > 0.5) {',
'                    return ''oj-bg-neutral-20'';',
'                }',
'                // 0.25% < data <= 0.5%',
'                if (data > 0.25) {',
'                    return ''oj-bg-neutral-10'';',
'                }',
'                // between -0.25 and 0.25',
'                return ''oj-bg-neutral-0'';',
'            };',
'          ',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
unistr('        /* \30C7\30FC\30BF\30D9\30FC\30B9\304B\3089JSON\3067\30C7\30FC\30BF\3092\53D6\5F97\3059\308B\3002 */'),
'        apex.server.process( "GET_DATA", {}, ',
'            {',
'                success: (data) => {',
unistr('                    /* datagrid\306EviewModel\3092\30D0\30A4\30F3\30C9 */'),
'                    ko.applyBindings(new ViewModel(data), document.getElementById(''datagrid''));',
'                }',
'            }',
'        );',
'    });',
'});'))
,p_css_file_urls=>'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.demo-data-grid {',
'    width: 100%;',
'    height: 27.75rem;',
'    max-width: 48.875rem;',
'}',
'  ',
'.demo-cell-alignment {',
'    align-items: stretch;',
'}',
'  ',
'.demo-content-container {',
'    position: relative;',
'    transform: rotate(180deg);',
'    writing-mode: vertical-lr;',
'    width: 9.625rem;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121429614295580204)
,p_plug_name=>'Scrollable Heat Map'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(121484738930113288)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<oj-data-grid',
'    id="datagrid"',
'    aria-label="Data Grid Heatmap Demo"',
'    class="demo-data-grid"',
'    data="[[dataGridProvider]]"',
'    header.row.style="width:16em;"',
'    header.column.class-name="demo-cell-alignment"',
'    header.column.style="height:13em;width:2.5em"',
'    cell.renderer="[[cellRenderer]]"',
'    cell.class-name="[[setCellClass]]">',
'    <template slot="columnHeaderTemplate" data-oj-as="header">',
'        <div class="demo-content-container oj-helper-text-align-left">',
'            <oj-bind-text value="[[header.item.data]]"></oj-bind-text>',
'        </div>',
'    </template>',
'</oj-data-grid>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(121747782828114126)
,p_plug_name=>'JET Scrollable Heat Map'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(121516608417113362)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(121429757928580205)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'begin',
'    select json_arrayagg(nobj returning clob) into l_response from',
'    (',
'        select json_mergepatch(obj, ''{"Region": "'' || rgn || ''"}'') nobj',
'        from (',
'            select p.region rgn, json_objectagg(p.period value p.price) obj ',
'            from ebaj_demo_house_price p group by p.region',
'        )',
'    );',
'    htp.p(l_response);',
'end;   '))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>121429757928580205
);
wwv_flow_imp.component_end;
end;
/
