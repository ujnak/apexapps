prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>296
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\718A\76EE\6483\5831\544A')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \73FE\5728\4F4D\7F6E\3092\53D6\5F97\3057\3001\30DA\30FC\30B8\FF13\306E\718A\51FA\6CA1\5831\544A\3078\6E21\3059\3002'),
' */',
'navigator.geolocation.getCurrentPosition(',
'    (position) => {',
'        const lat = position.coords.latitude;',
'        const lon = position.coords.longitude;',
'        let url = "";',
'        url = url.concat(',
'            "/ords/r/apexdev/bear2-report/report?session="',
'            ,apex.env.APP_SESSION',
'            ,"&p3_latitude="',
'            ,lat',
'            ,"&p3_longitude="',
'            ,lon',
'        );',
'        console.log(url);',
'        apex.navigation.redirect(url);',
'    }',
');'))
,p_step_template=>wwv_flow_imp.id(122687407783754532)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231102045147'
);
wwv_flow_imp.component_end;
end;
/
