prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>296
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>unistr('\718A\76EE\6483\5831\544A')
,p_alias=>'REPORT'
,p_step_title=>unistr('\718A\76EE\6483\5831\544A')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var mediaRecorder = null;',
'var mimeType = '''';',
'var chunks = [];',
unistr('var recording = null; // \9332\97F3\306EBlob\30C7\30FC\30BF'),
'var audioContext;',
'var audioSampleRate;',
'var scriptProcessor;',
'var destinationNode;',
'',
'const CONSTRAINTS = {"video": false, "audio": true};',
'',
'/*',
unistr(' * \9332\97F3\3092\958B\59CB\3059\308B\3002'),
' */',
'const START_AUDIO_RECORDING = {',
'    name: "start-audio-recording",',
'    action: function(event, element, args) {',
'        if (mediaRecorder.state == "inactive") {',
'            console.log("start audio recording");',
'            mediaRecorder.start();',
'        }',
'    }',
'};',
'',
'/*',
unistr(' * \9332\97F3\3092\505C\6B62\3059\308B\3002'),
' */',
'const STOP_AUDIO_RECORDING = {',
'    name: "stop-audio-recording",',
'    action: function(event, element, args) {',
'        if (mediaRecorder.state == "recording") {',
'            console.log("stop audio recording");',
'            mediaRecorder.stop();',
'        }',
'    }',
'};',
'',
'/*',
unistr(' * \30DA\30FC\30B8\30FB\30ED\30FC\30C9\6642\306B\5B9F\884C\3059\308B\3002 '),
' */',
'window.onload = () => {',
'',
unistr('/* \30A2\30AF\30B7\30E7\30F3\306E\521D\671F\5316 */'),
'apex.actions.add([START_AUDIO_RECORDING,STOP_AUDIO_RECORDING]);',
'',
'/*',
unistr(' * \97F3\58F0\30EC\30B3\30FC\30C0\30FC\306E\521D\671F\5316\3002'),
' */',
'navigator.mediaDevices',
'    .getUserMedia(CONSTRAINTS)',
'    .then((stream) => {',
'        mediaRecorder = new MediaRecorder(stream);',
unistr('        /* \518D\751F\306E\6E96\5099\304C\3067\304D\305F\3068\304D\306B\547C\3070\308C\308B */'),
'        mediaRecorder.ondataavailable = (e) => {',
'            mimeType = e.data.type;',
'            chunks.push(e.data);',
'            console.log("data available", e.data);',
'        };',
unistr('        /* \9332\97F3\3092\505C\6B62\3057\305F\3068\304D\306B\547C\3070\308C\308B\3002 */'),
'        mediaRecorder.onstop = () => {',
'            recording = new Blob(chunks, {''type'': mimeType});',
unistr('            chunks = []; // \4ECA\307E\3067\306E\9332\97F3\306F\524A\9664\3002'),
'            player.src = window.URL.createObjectURL(recording);',
'            console.log("audio recorder stopped.");',
'        };',
'    })',
'    .catch(function (e) {',
'        alert(e);',
'    }',
');',
unistr('/* onload\7D42\4E86 */'),
'}'))
,p_step_template=>wwv_flow_imp.id(122687407783754532)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'02'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231102045426'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(122974902300777315)
,p_plug_name=>unistr('\718A\76EE\6483\5831\544A')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(122706117376754546)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'BEAR2_SIGHTINGS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(122562300421328824)
,p_plug_name=>unistr('\5730\56F3')
,p_region_name=>'map'
,p_parent_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(122706117376754546)
,p_plug_display_sequence=>70
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(122562464552328825)
,p_region_id=>wwv_flow_imp.id(122562300421328824)
,p_height=>240
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'SQL'
,p_init_position_zoom_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    to_number(:P3_LATITUDE) as lat',
'    ,to_number(:P3_LONGITUDE) as lon',
'    ,12 zoom',
'from dual'))
,p_init_position_geometry_type=>'LONLAT_COLUMNS'
,p_init_position_lon_column=>'LON'
,p_init_position_lat_column=>'LAT'
,p_init_zoomlevel_column=>'ZOOM'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(122562553586328826)
,p_map_region_id=>wwv_flow_imp.id(122562464552328825)
,p_name=>unistr('\73FE\5728\4F4D\7F6E')
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    to_number(:P3_LATITUDE) as lat',
'    ,to_number(:P3_LONGITUDE) as lon',
'from dual'))
,p_items_to_submit=>'P3_LONGITUDE,P3_LATITUDE'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LON'
,p_latitude_column=>'LAT'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(122563021107328831)
,p_plug_name=>unistr('\9332\97F3')
,p_parent_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(122706117376754546)
,p_plug_display_sequence=>90
,p_plug_source=>'<audio id="player" controls></audio>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(122985045308777331)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_button_name=>'CREATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(122845971733754644)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5831\544A')
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(122563202155328833)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(122563021107328831)
,p_button_name=>'STOP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(122845971733754644)
,p_button_image_alt=>unistr('\9332\97F3\7D42\4E86')
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$stop-audio-recording"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(122563135804328832)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(122563021107328831)
,p_button_name=>'START'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(122845971733754644)
,p_button_image_alt=>unistr('\9332\97F3\958B\59CB')
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$start-audio-recording"'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(122985300610777331)
,p_branch_name=>unistr('\30DA\30FC\30B8\306B\79FB\52D5 2')
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::P2_ID:&P3_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122562652734328827)
,p_name=>'P3_PHOTOS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_prompt=>unistr('\5199\771F')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(122843471724754640)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'Y'
,p_attribute_11=>'image/*'
,p_attribute_12=>'NATIVE'
,p_attribute_15=>'10000'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122975282884777315)
,p_name=>'P3_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122975639424777316)
,p_name=>'P3_VOICE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_source=>'VOICE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122976093715777317)
,p_name=>'P3_REPORT_DATE'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_default=>'to_char(current_timestamp,''YYYY-MM-DD HH24:MI:SS'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('\76EE\6483\65E5\6642')
,p_format_mask=>'YYYY-MM-DD HH24:MI:SS'
,p_source=>'REPORT_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(122844767855754642)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122976449055777318)
,p_name=>'P3_LATITUDE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_source=>'LATITUDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122976843254777318)
,p_name=>'P3_LONGITUDE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_source=>'LONGITUDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122977295512777319)
,p_name=>'P3_ADDRESS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_prompt=>unistr('\76EE\6483\3057\305F\5834\6240')
,p_source=>'ADDRESS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select address d, address r',
'from (',
'    select region || '' '' || municipality || '' '' || street || '' '' || sec_unit address',
'    from table(do_reverse_geocoding(',
'        p_latitude => to_number(:P3_LATITUDE)',
'        ,p_longitude => to_number(:P3_LONGITUDE)',
'        ,p_count => 5',
'    ))',
')'))
,p_lov_cascade_parent_items=>'P3_LATITUDE,P3_LONGITUDE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(122843471724754640)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122977600966777319)
,p_name=>'P3_REPORT_TEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_prompt=>'Report Text'
,p_source=>'REPORT_TEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(122843471724754640)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(122668879748754503)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122978002405777319)
,p_name=>'P3_ATTRIBUTES'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_prompt=>'Attributes'
,p_source=>'ATTRIBUTES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(122843471724754640)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(122668879748754503)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122978463433777320)
,p_name=>'P3_CREATED'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_prompt=>'Created'
,p_source=>'CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(122844767855754642)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(122668879748754503)
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122978843135777320)
,p_name=>'P3_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_prompt=>'Created By'
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(122844767855754642)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(122668879748754503)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122979288353777321)
,p_name=>'P3_UPDATED'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_prompt=>'Updated'
,p_source=>'UPDATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(122844767855754642)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(122668879748754503)
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122979674485777321)
,p_name=>'P3_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_item_source_plug_id=>wwv_flow_imp.id(122974902300777315)
,p_prompt=>'Updated By'
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(122844767855754642)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(122668879748754503)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(122562816324328829)
,p_name=>unistr('\5730\56F3\4E0A\3092\30AF\30EA\30C3\30AF')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(122562300421328824)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(122562944950328830)
,p_event_id=>wwv_flow_imp.id(122562816324328829)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.items.P3_LATITUDE.setValue(this.data.lat);',
'apex.items.P3_LONGITUDE.setValue(this.data.lng);',
'apex.region("map").refresh();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(122563346179328834)
,p_name=>unistr('\9332\97F3\3092\4FDD\5B58\3057\3066\304B\3089\9001\4FE1')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(122985045308777331)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(122563407010328835)
,p_event_id=>wwv_flow_imp.id(122563346179328834)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// \97F3\58F0\3092\9001\4FE1\3057\3066P3_VOICE_ID\306B\4E3B\30AD\30FC\3092\4FDD\5B58\3059\308B\3002'),
'if (recording !== null) {',
'    let formData = new FormData();',
'    formData.append("file", recording);',
'    let request = new XMLHttpRequest();',
'',
'    request.onreadystatechange = () => {',
'        if (request.readyState ===  XMLHttpRequest.DONE) {',
'            const status = request.status;',
'            if (status === 0 || (status >= 200 && status < 400)) {',
'                console.log("send success");',
'                let response_json = JSON.parse(request.response);',
'                $s("P3_VOICE_ID", response_json.id);',
'                apex.page.submit( "CREATE" );',
'            }',
'            else ',
'            {',
'                console.log("status = ", status);',
'            };',
'        }',
'    };',
'',
'    request.open("POST", "/ords/apexdev/upload/voice");',
'    request.send(formData);',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(122986230603777335)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(122974902300777315)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0\718A\76EE\6483\5831\544A')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('\76EE\6483\5831\544A\304C\9001\4FE1\3055\308C\307E\3057\305F\3002')
,p_internal_uid=>122986230603777335
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(122563641933328837)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\5199\771F\3092\4FDD\5B58')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    for c in (select column_value from apex_string.split(:P3_PHOTOS,'':''))',
'    loop',
'        for bc in (',
'            select * from apex_application_temp_files',
'            where name = c.column_value',
'        )',
'        loop',
'            insert into bear2_photos(sighting_id, filename, mime_type, photo)',
'                values(:P3_ID, bc.filename, bc.mime_type, bc.blob_content);',
'        end loop;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(122985045308777331)
,p_internal_uid=>122563641933328837
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(122563890011328839)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Whisper\3068ChatGPT\547C\3073\51FA\3057')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_text clob;',
'    l_attributes clob;',
'    l_json json_object_t;',
'    l_array json_array_t;',
'    l_array_clob clob;',
'begin',
'    /*',
unistr('     * OpenAI Whisper\306B\3088\308B\6587\5B57\8D77\3053\3057\3002'),
'     */',
'    utl_bear_openai.transcribe(',
'        p_voice_id => :P3_VOICE_ID',
'        ,p_text => l_text',
unistr('        ,p_prompt => ''\91CE\6BDB\5C71 \30C4\30AD\30CE\30EF\30B0\30DE'''),
'    );',
'    update bear2_sightings set report_text = l_text where id = :P3_ID;',
'    /*',
unistr('     * ChatGPT\306B\3088\308B\5358\8A9E\62BD\51FA'),
'     */',
'    utl_bear_openai.get_attributes(',
'        p_text => l_text',
'        ,p_attributes => l_attributes',
'    );',
'    l_json := json_object_t(l_attributes);',
'    l_array := l_json.get_array(''words'');',
'    l_array_clob := l_array.to_clob();',
'    update bear2_sightings set attributes = l_array_clob where id = :P3_ID;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(122985045308777331)
,p_internal_uid=>122563890011328839
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(122562767748328828)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\65E5\672C\6642\9593\306B\5F37\5236')
,p_process_sql_clob=>'apex_util.set_session_time_zone(''Asia/Tokyo'');'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>122562767748328828
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(122985841810777333)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(122974902300777315)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0\718A\76EE\6483\5831\544A')
,p_internal_uid=>122985841810777333
);
wwv_flow_imp.component_end;
end;
/
