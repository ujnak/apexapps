prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>137
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>unistr('\30D0\30B9\505C\306E\4F4D\7F6E')
,p_alias=>unistr('\30D0\30B9\505C\306E\4F4D\7F6E')
,p_step_title=>unistr('\30D0\30B9\505C\306E\4F4D\7F6E')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2526643373347724467
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40118993432943099)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(39983675268243149)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40119645802943099)
,p_plug_name=>unistr('\30DE\30C3\30D7')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>20
,p_location=>'JSON_COLLECTION'
,p_document_source_id=>wwv_flow_imp.id(40001962002514656)
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select C_ID2,',
'       C_ID,',
'       C_TYPE,',
'       TITLE_EN,',
'       TITLE_JA,',
'       TITLE_JA_HRKT,',
'       DC_DATE,',
'       GEO_LAT,',
'       C_CONTEXT,',
'       DC_TITLE,',
'       GEO_LONG,',
'       C_METADATA_ETAG,',
'       ODPT_KANA,',
'       ODPT_NOTE,',
'       OWL_SAMEAS,',
'       replace(replace(replace(replace(json_serialize(ODPT_OPERATOR returning clob),''[''),'']''),''odpt.Operator:''),''"'') ODPT_OPERATOR,',
'       ODPT_PLATFORMNUMBER,',
'       replace(replace(replace(replace(json_serialize(ODPT_BUSROUTEPATTERN returning clob),''[''),'']''),''odpt.BusroutePattern:''),''"'') ODPT_BUSROUTEPATTERN,',
'       ODPT_BUSSTOPPOLENUMBER,',
'       replace(replace(replace(replace(json_serialize(ODPT_BUSSTOPPOLETIMETABLE returning clob),''[''),'']''),''odpt.BusstopPoleTimetable:''),''"'') ODPT_BUSSTOPPOLETIMETABLE',
'  from #APEX$SOURCE_DATA#'))
,p_source_post_processing=>'SQL'
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(40121619237943100)
,p_region_id=>wwv_flow_imp.id(40119645802943099)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(40122106638943100)
,p_map_region_id=>wwv_flow_imp.id(40121619237943100)
,p_name=>unistr('\30D0\30B9\505C\306E\4F4D\7F6E')
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'GEO_LONG'
,p_latitude_column=>'GEO_LAT'
,p_fill_color_is_spectrum=>false
,p_extrude_unit=>'M'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'TITLE_JA'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40119778547943099)
,p_plug_name=>unistr('\691C\7D22')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(40119645802943099)
,p_landmark_label=>unistr('\30D5\30A3\30EB\30BF')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40120590677943100)
,p_plug_name=>unistr('\30DC\30BF\30F3\30FB\30D0\30FC')
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(40121006009943100)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(40120590677943100)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>unistr('\30EA\30BB\30C3\30C8')
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:RR,4::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39959381998550328)
,p_name=>'P4_C_ID2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'C_ID2'
,p_source=>'C_ID2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39959407618550329)
,p_name=>'P4_C_ID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'C_ID'
,p_source=>'C_ID'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39959571343550330)
,p_name=>'P4_C_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'C_TYPE'
,p_source=>'C_TYPE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39959622379550331)
,p_name=>'P4_TITLE_EN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'TITLE_EN'
,p_source=>'TITLE_EN'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39959714984550332)
,p_name=>'P4_TITLE_JA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'TITLE_JA'
,p_source=>'TITLE_JA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39959849584550333)
,p_name=>'P4_TITLE_JA_HRKT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'TITLE_JA_HRKT'
,p_source=>'TITLE_JA_HRKT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39959950112550334)
,p_name=>'P4_DC_DATE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'DC_DATE'
,p_source=>'DC_DATE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39960035217550335)
,p_name=>'P4_GEO_LAT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'GEO_LAT'
,p_source=>'GEO_LAT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39960129041550336)
,p_name=>'P4_C_CONTEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'C_CONTEXT'
,p_source=>'C_CONTEXT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39960273883550337)
,p_name=>'P4_DC_TITLE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'DC_TITLE'
,p_source=>'DC_TITLE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39960392974550338)
,p_name=>'P4_GEO_LONG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'GEO_LONG'
,p_source=>'GEO_LONG'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39960477007550339)
,p_name=>'P4_C_METADATA_ETAG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'C_METADATA_ETAG'
,p_source=>'C_METADATA_ETAG'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39960555692550340)
,p_name=>'P4_ODPT_KANA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'ODPT_KANA'
,p_source=>'ODPT_KANA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39960609925550341)
,p_name=>'P4_ODPT_NOTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'ODPT_NOTE'
,p_source=>'ODPT_NOTE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39960734890550342)
,p_name=>'P4_OWL_SAMEAS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'OWL_SAMEAS'
,p_source=>'OWL_SAMEAS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39960876936550343)
,p_name=>'P4_ODPT_OPERATOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'ODPT_OPERATOR'
,p_source=>'ODPT_OPERATOR'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39960929534550344)
,p_name=>'P4_ODPT_PLATFORMNUMBER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'ODPT_PLATFORMNUMBER'
,p_source=>'ODPT_PLATFORMNUMBER'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39961015718550345)
,p_name=>'P4_ODPT_BUSROUTEPATTERN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>unistr('\904B\884C\7D4C\8DEF')
,p_source=>'ODPT_BUSROUTEPATTERN'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_multi_value_trim_space=>false
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39961181427550346)
,p_name=>'P4_ODPT_BUSSTOPPOLENUMBER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'ODPT_BUSSTOPPOLENUMBER'
,p_source=>'ODPT_BUSSTOPPOLENUMBER'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39961275897550347)
,p_name=>'P4_ODPT_BUSSTOPPOLETIMETABLE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>'ODPT_BUSSTOPPOLETIMETABLE'
,p_source=>'ODPT_BUSSTOPPOLETIMETABLE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_INPUT'
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(39983044692243149)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'comparison_operator', 'EQUALS',
  'user_can_choose_operator', 'Y')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40120204970943100)
,p_name=>'P4_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(40119778547943099)
,p_prompt=>unistr('\691C\7D22')
,p_source=>'TITLE_EN,TITLE_JA,TITLE_JA_HRKT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
);
wwv_flow_imp.component_end;
end;
/
