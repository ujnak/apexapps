prompt --application/shared_components/json_source/東京都バス停
begin
--   Manifest
--     DOCUMENT SOURCE: 東京都バス停
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>137
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_document_source(
 p_id=>wwv_flow_imp.id(40001962002514656)
,p_name=>unistr('\6771\4EAC\90FD\30D0\30B9\505C')
,p_static_id=>'c40001962002514656'
,p_document_source_type=>'JSON_COLLECTION'
,p_location=>'LOCAL'
,p_object_name=>'TOKYO_BUS_STOPS'
,p_data_profile_id=>wwv_flow_imp.id(40002085856514656)
,p_version_scn=>16883054
);
wwv_flow_imp.component_end;
end;
/
