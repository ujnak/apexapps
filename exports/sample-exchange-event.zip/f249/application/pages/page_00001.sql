prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>249
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Event Exchange'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[module]#APP_FILES#js/main#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133586121526783048)
,p_plug_name=>'Controls'
,p_region_name=>'CONTROLS'
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--alignCenter'
,p_plug_template=>wwv_flow_imp.id(134545510503204333)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134751251331205046)
,p_plug_name=>'Sample Event Exchange'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(134529915074204300)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(134760943231363902)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(133586121526783048)
,p_button_name=>'CLEAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(134626876316204535)
,p_button_image_alt=>'Clear'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="CLEAR"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133586294367783049)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(133586121526783048)
,p_button_name=>'OPEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(134626876316204535)
,p_button_image_alt=>'Open'
,p_button_position=>'BUTTON_START'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="OPEN"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133586320498783050)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(133586121526783048)
,p_button_name=>'SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(134626876316204535)
,p_button_image_alt=>'Search'
,p_button_position=>'BUTTON_START'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="SEARCH"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134760864315363901)
,p_name=>'P1_ENAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(133586121526783048)
,p_prompt=>'Ename'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(134624367417204525)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134761009770363903)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ADD_FILTER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_REPORT_COLUMN constant varchar2(5) := ''ENAME'';',
'    C_PAGE_ID       constant number := 2;',
'    C_REGION_ID     constant number := :G_REPORT_REGION_ID;',
'begin',
'    apex_ir.add_filter(',
'        p_page_id        => C_PAGE_ID',
'        ,p_region_id     => C_REGION_ID',
'        ,p_report_column => C_REPORT_COLUMN',
'        ,p_filter_value  => :P1_ENAME',
'        ,p_operator_abbr => ''EQ''',
'        ,p_report_id     => null',
'    );',
'    /*',
unistr('     * \30D5\30A3\30EB\30BF\3092\9069\7528\3057\305F\30EC\30DD\30FC\30C8\306E\9759\7684ID\3092\5C5E\6027report\3068\3057\3066\8FD4\3059\3002'),
'     */',
'    htp.p(''{ "success": true, "report": "EMP" }'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>134761009770363903
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134761162222363904)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CLEAR_REPORT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_REPORT_COLUMN constant varchar2(5) := ''ENAME'';',
'    C_PAGE_ID       constant number := 2;',
'    C_REGION_ID     constant number := :G_REPORT_REGION_ID;',
'begin',
'    apex_ir.clear_report(',
'        p_page_id        => C_PAGE_ID',
'        ,p_region_id     => C_REGION_ID',
'        ,p_report_id     => null',
'    );',
'    /*',
unistr('     * \30EA\30BB\30C3\30C8\3057\305F\30EC\30DD\30FC\30C8\306E\9759\7684ID\3092\5C5E\6027report\3068\3057\3066\8FD4\3059\3002'),
'     */',
'    htp.p(''{ "success": true, "report": "EMP" }'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>134761162222363904
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134761203586363905)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_URL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url varchar2(400);',
'    l_response clob;',
'begin',
'    l_url := apex_page.get_url(',
'        p_page => 2',
'    );',
'    l_response := apex_string.format(''{ "url": "%s" }'', l_url );',
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>134761203586363905
);
wwv_flow_imp.component_end;
end;
/
