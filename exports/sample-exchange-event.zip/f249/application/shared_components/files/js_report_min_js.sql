prompt --application/shared_components/files/js_report_min_js
begin
--   Manifest
--     APP STATIC FILES: 249
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>249
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '636F6E7374206368616E6E656C3D6E65772042726F6164636173744368616E6E656C282265786368616E67652D6576656E7422293B617065782E64656275672E696E666F28226368616E6E656C3A20222C6368616E6E656C292C6368616E6E656C2E6164';
wwv_flow_imp.g_varchar2_table(2) := '644576656E744C697374656E657228226D657373616765222C28653D3E7B617065782E64656275672E696E666F28226576656E743A20222C65292C2272656672657368223D3D3D652E646174612E747970652626617065782E726567696F6E2822454D50';
wwv_flow_imp.g_varchar2_table(3) := '22292E7265667265736828297D29293B';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(134804152142140162)
,p_file_name=>'js/report.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
