prompt --application/shared_components/logic/application_computations/g_report_region_id
begin
--   Manifest
--     APPLICATION COMPUTATION: G_REPORT_REGION_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>249
,p_default_id_offset=>136113106533354226
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(270883881857840401)
,p_computation_sequence=>10
,p_computation_item=>'G_REPORT_REGION_ID'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select region_id from apex_application_page_regions',
'where application_id = :APP_ID and page_id = 2 and static_id = ''EMP''',
''))
,p_version_scn=>41800138356032
);
wwv_flow_imp.component_end;
end;
/
