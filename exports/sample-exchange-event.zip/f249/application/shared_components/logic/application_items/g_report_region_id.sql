prompt --application/shared_components/logic/application_items/g_report_region_id
begin
--   Manifest
--     APPLICATION ITEM: G_REPORT_REGION_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>249
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(134770342597480543)
,p_name=>'G_REPORT_REGION_ID'
,p_protection_level=>'I'
,p_version_scn=>41800138356033
);
wwv_flow_imp.component_end;
end;
/
