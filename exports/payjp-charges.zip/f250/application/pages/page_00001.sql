prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>250
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'PAY.JP Charges'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://js.pay.jp/v2/pay.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.getElementById("pay-button").disabled = "disabled";',
'',
'const payjp = Payjp(''&PAYJP_PUBLIC_KEY.'');',
'const elements = payjp.elements();',
'const cardElement = elements.create(''card'', {style: {base: {color: ''black''}}});',
'cardElement.mount(''#card-element'');',
'cardElement.on(''change'', (event) => {',
'    console.log(event);',
'    if (event.complete === true) {',
'        document.getElementById("pay-button").disabled = null; ',
'    } else {',
'        document.getElementById("pay-button").disabled = "disabled";',
'    }',
'    if (event.error !== null) {',
'        apex.message.clearErrors();',
'        apex.message.showErrors(',
'            {',
'                type:       "error",',
'                location:   "inline",',
'                pageItem:   "card-element",',
'                message:    event.error.message,',
'                unsafe:     false',
'            }        ',
'        );',
'    } else {',
'        let elem = document.getElementById("card-element_error_placeholder");',
'        if (elem !== null) {',
'            elem.remove();',
'        }',
'        // apex.message.clearErrors();',
'    };',
'  /*',
'  {',
'    brand: ''Visa'',',
'    complete: false,',
'    elementType: ''card'',',
'    empty: false,',
'    error: {',
unistr('      message: ''\5165\529B\304C\5B8C\4E86\3057\3066\3044\307E\305B\3093\3002'','),
'      type: ''validation_error'',',
'      code: ''incomplete_error''',
'    }',
'  }',
'  */',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230822082333'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65570712301802116)
,p_plug_name=>'Card Element'
,p_region_name=>'card-element'
,p_region_template_options=>'#DEFAULT#:margin-top-lg:margin-bottom-lg'
,p_plug_template=>wwv_flow_imp.id(67449509082811937)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65571060977802119)
,p_button_sequence=>30
,p_button_name=>'PAY'
,p_button_static_id=>'pay-button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(67587956535812025)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Pay'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65571350293802122)
,p_name=>'P1_AMOUNT'
,p_item_sequence=>10
,p_prompt=>'Amount'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(67585495670812021)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65571808378802127)
,p_name=>'P1_RESPONSE'
,p_item_sequence=>40
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(67585495670812021)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(65571455244802123)
,p_name=>'onClick Pay'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(65571060977802119)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(65571584850802124)
,p_event_id=>wwv_flow_imp.id(65571455244802123)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'payjp.createToken(cardElement).then(',
'    (response) => {',
'        if (response.error) {',
'            apex.message.showErrors(',
'                {',
'                    type:       "error",',
'                    location:   "page",',
'                    message:    "Page error has occurred!",',
'                    unsafe:     false',
'                }',
'            );',
'        } else {',
'            apex.server.process(',
'                "CHARGE",',
'                {',
'                    x01: response.id,',
'                    pageItems: [ "P1_AMOUNT" ],',
'                },',
'                {',
'                    success: (data) => {',
'                        $s("P1_RESPONSE", JSON.stringify(data));',
'                    },',
'                    error: (jqXHR, textStatus, errorThrown) => {',
'                        console.log(textStatus);',
'                    }',
'                }',
'            )',
'        }',
'    }',
');'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(65571774558802126)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CHARGE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_card varchar2(128);',
'    l_response clob;',
'    e_charges_failed exception;',
'begin',
'    l_card := apex_application.g_x01;',
'    apex_web_service.set_request_headers(''Content-Type'',''application/x-www-form-urlencoded'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => :PAYJP_ENDPOINT || ''/v1/charges''',
'        ,p_http_method => ''POST''',
'        ,p_parm_name => apex_string.string_to_table(''card:amount:currency'')',
'        ,p_parm_value => apex_string.string_to_table(l_card || '':'' || :P1_AMOUNT || '':jpy'')',
'        ,p_credential_static_id => ''PAYJP_TEST_CRED''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        apex_debug.info(l_response);',
'        raise e_charges_failed;',
'    end if;',
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>65571774558802126
);
wwv_flow_imp.component_end;
end;
/
