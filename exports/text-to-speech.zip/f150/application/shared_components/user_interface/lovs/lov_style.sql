prompt --application/shared_components/user_interface/lovs/lov_style
begin
--   Manifest
--     LOV_STYLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>150
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(60503452991770206)
,p_lov_name=>'LOV_STYLE'
,p_lov_query=>'.'||wwv_flow_imp.id(60503452991770206)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(60503741679770210)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'talk'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(60504122437770212)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'happy'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(60504581495770212)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'sad'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(60504940184770212)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'angry'
,p_lov_return_value=>'5'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(60505341686770213)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'fear'
,p_lov_return_value=>'6'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(60505706513770213)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'surprised'
,p_lov_return_value=>'7'
);
wwv_flow_imp.component_end;
end;
/
