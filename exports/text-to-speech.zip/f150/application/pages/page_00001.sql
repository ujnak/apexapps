prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>150
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Text to Speech'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230306045759'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59447310399968331)
,p_plug_name=>unistr('\8AAD\307F\4E0A\3052')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(60306635359459427)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<audio controls src="/ords/apexdev/rinna/speech?id=&P1_ID."></audio>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P1_ID'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60482615446459546)
,p_plug_name=>'Text to Speech'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(60339619921459448)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59447130157968329)
,p_button_sequence=>60
,p_button_name=>'TEXT_TO_SPEECH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(60445529123459510)
,p_button_image_alt=>'Text To Speech'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59446639276968324)
,p_name=>'P1_SID'
,p_is_required=>true
,p_item_sequence=>10
,p_item_default=>'27'
,p_prompt=>unistr('\30DC\30A4\30B9ID')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(60443060351459508)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'27'
,p_attribute_02=>'47'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59446761839968325)
,p_name=>'P1_TID'
,p_is_required=>true
,p_item_sequence=>20
,p_item_default=>'1'
,p_prompt=>unistr('\30B9\30BF\30A4\30EB')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_STYLE'
,p_lov=>'.'||wwv_flow_imp.id(60503452991770206)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(60443060351459508)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59446851737968326)
,p_name=>'P1_SPEED'
,p_is_required=>true
,p_item_sequence=>30
,p_item_default=>'1.0'
,p_prompt=>unistr('\8A71\901F')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(60443060351459508)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0.1'
,p_attribute_02=>'10.0'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59446995133968327)
,p_name=>'P1_VOLUME'
,p_is_required=>true
,p_item_sequence=>40
,p_item_default=>'1.0'
,p_prompt=>unistr('\97F3\91CF')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(60443060351459508)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0.1'
,p_attribute_02=>'10.0'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59447067399968328)
,p_name=>'P1_TEXT'
,p_is_required=>true
,p_item_sequence=>50
,p_prompt=>unistr('\30C6\30AD\30B9\30C8')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(60443060351459508)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59447239912968330)
,p_name=>'P1_ID'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59447444216968332)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Text to Speech'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request json_object_t;',
'    l_request_clob clob;',
'    l_response json_object_t;',
'    l_response_clob clob;',
'    l_media_content_url varchar2(32767);',
'    l_blob blob;',
'begin',
'    /*',
unistr('     * Text To Speech V2\306E\30EA\30AF\30A8\30B9\30C8\3092\4F5C\6210\3059\308B\3002'),
'     *',
unistr('     * \53C2\7167: https://developers.rinna.co.jp/api-details#api=TextToSpeech-v2'),
'     */',
'    l_request := json_object_t();',
'    l_request.put(''sid'',   to_number(:P1_SID));',
'    l_request.put(''tid'',   to_number(:P1_TID));',
'    l_request.put(''speed'', to_number(:P1_SPEED));',
'    l_request.put(''text'',   :P1_TEXT);',
'    l_request.put(''volume'', to_number(:P1_VOLUME));',
'    l_request.put(''format'', ''wav'');',
'    l_request_clob := l_request.to_clob();',
'    -- apex_debug.info(l_request_clob);',
'    /*',
unistr('     * Text To Speech \306E\547C\3073\51FA\3057\3002'),
'     */',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'', p_reset => false);',
'    apex_web_service.set_request_headers(''Cache-Control'',''no-cache'', p_reset => false);',
'    l_response_clob := apex_web_service.make_rest_request(',
'        p_url => ''https://api.rinna.co.jp/models/cttse/v2''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'        ,p_credential_static_id => ''RINNA_DEVELOPER_KEY''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise_application_error(-20001, ''Text To Speech = '' || apex_web_service.g_status_code);',
'    end if;',
'    /*',
unistr('     * \30EC\30B9\30DD\30F3\30B9\304B\3089\751F\6210\3055\308C\305FWAV\30D5\30A1\30A4\30EB\306EURL\3092\53D6\5F97\3059\308B\3002'),
'     */',
'    l_response := json_object_t(l_response_clob);',
'    l_media_content_url := l_response.get_string(''mediaContentUrl'');',
'    if l_media_content_url is null then',
'        raise_application_error(-20001, ''No MediaContentUrl'');',
'    end if;',
'    /*',
unistr('     * WAV\30D5\30A1\30A4\30EB\3092\53D6\5F97\3057\3001BLOB\3068\3057\3066\4FDD\5B58\3059\308B\3002'),
'     */',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Content-Type'',''audio/wav'', p_reset => false);',
'    l_blob := apex_web_service.make_rest_request_b(',
'        p_url => l_media_content_url',
'        ,p_http_method => ''GET''',
'        ,p_credential_static_id => ''RINNA_DEVELOPER_KEY''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise_application_error(-20001, ''Get Speecg = '' || apex_web_service.g_status_code);',
'    end if;',
'    /*',
unistr('     * \30C6\30AD\30B9\30C8\3068\97F3\58F0\306E\4E21\65B9\3092\4FDD\5B58\3059\308B\3002'),
'     */',
'    insert into rinna_text_to_speeches(text, speech, sid, tid, speed, volume) ',
'    values(:P1_TEXT, l_blob, :P1_SID, :P1_TID, :P1_SPEED, :P1_VOLUME)',
'    returning id into :P1_ID;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(59447130157968329)
);
wwv_flow_imp.component_end;
end;
/
