prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>325
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Secrets'
,p_alias=>'SECRETS'
,p_step_title=>'Secrets'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add([',
'{',
'    name: "install-web-credential",',
'    action: function( event, element, args) {',
unistr('        /* \78BA\8A8D\306E\305F\3081\306E\30C0\30A4\30A2\30ED\30B0\3092\8868\793A\3059\308B */'),
'        apex.message.confirm(',
'            "Are you sure?", function( okPressed ) {',
unistr('                /* OCI Vault\306E\30B7\30FC\30AF\30EC\30C3\30C8\304B\3089Web\8CC7\683C\8A3C\660E\3092\4F5C\6210/\66F4\65B0\3059\308B\3002 */'),
'                apex.server.process(',
'                    "INSTALL_WEB_CREDENTIAL",',
'                    {',
'                        x01: args.secretId',
'                    }',
'                    ,{',
'                        success: function( data ) {',
'                            if (data.success) {',
unistr('                                /* \6210\529F\30E1\30C3\30BB\30FC\30B8\306E\8868\793A */'),
'                                apex.message.showPageSuccess( "Web Credential Created or Updated!" );',
'                            } ',
'                            else',
'                            {',
unistr('                                /* \5931\6557\30E1\30C3\30BB\30FC\30B8\306E\8868\793A */'),
'                                apex.message.showErrors([',
'                                    {',
'                                        type:       "error",',
'                                        location:   "page",',
'                                        message:    "Web Credential Creation or Update Failed!",',
'                                        unsafe:     false',
'                                    }',
'                                ]);',
'                            }',
'                        }',
'                    }',
'                );',
'            }',
'        );',
'    }',
'}',
']);'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240206091433'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46032262021805127)
,p_plug_name=>'Secrets'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(45772441792704193)
,p_plug_display_sequence=>10
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(45987793098723301)
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       KEY_ID,',
'       VAULT_ID,',
'       SECRET_NAME,',
'       CREATED_BY,',
'       CREATED_ON,',
'       DESCRIPTION,',
'       TIME_CREATED,',
'       COMPARTMENT_ID,',
'       LIFECYCLE_STATE,',
'       ROTATION_CONFIG,',
'       TIME_OF_DELETION,',
'       LIFECYCLE_DETAILS,',
'       IS_AUTO_GENERATION_ENABLED,',
'       SECRET_GENERATION_CONTEXT,',
'       TIME_OF_CURRENT_VERSION_EXPIRY,',
'       ''INSTALL'' as INSTALL',
'from #APEX$SOURCE_DATA#',
'where KEY_ID = :G_KEY_ID',
'  and VAULT_ID = :G_VAULT_ID',
'  and COMPARTMENT_ID = :G_COMPARTMENT_ID'))
,p_source_post_processing=>'SQL'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Secrets'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(46032326289805127)
,p_name=>'Secrets'
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,:P3_ID,P3_COMPARTMENT_ID:\#ID#\,\#COMPARTMENT_ID#\'
,p_detail_link_text=>'<span role="img" aria-label="&#x7DE8;&#x96C6;" class="fa fa-edit" title="&#x7DE8;&#x96C6;"></span>'
,p_owner=>'APEXDEV'
,p_internal_uid=>46032326289805127
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46032766654805130)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46033115541805132)
,p_db_column_name=>'KEY_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Key Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46033524214805133)
,p_db_column_name=>'VAULT_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Vault Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46033958766805133)
,p_db_column_name=>'SECRET_NAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Secret Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46034302546805133)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46034730626805134)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46035105621805134)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46035562732805134)
,p_db_column_name=>'TIME_CREATED'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Time Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46035977019805134)
,p_db_column_name=>'COMPARTMENT_ID'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Compartment Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46036332067805135)
,p_db_column_name=>'LIFECYCLE_STATE'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Lifecycle State'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46036725553805135)
,p_db_column_name=>'ROTATION_CONFIG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Rotation Config'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46037147170805135)
,p_db_column_name=>'TIME_OF_DELETION'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Time Of Deletion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46037562427805136)
,p_db_column_name=>'LIFECYCLE_DETAILS'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Lifecycle Details'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46037918582805136)
,p_db_column_name=>'IS_AUTO_GENERATION_ENABLED'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Is Auto Generation Enabled'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46038392155805136)
,p_db_column_name=>'SECRET_GENERATION_CONTEXT'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Secret Generation Context'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46038784606805137)
,p_db_column_name=>'TIME_OF_CURRENT_VERSION_EXPIRY'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Time Of Current Version Expiry'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46474715064232423)
,p_db_column_name=>'INSTALL'
,p_display_order=>26
,p_column_identifier=>'Q'
,p_column_label=>'Install'
,p_column_html_expression=>'<button type="button" class="t-Button" data-action="install-web-credential?secretId=#ID#">Install</button>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(46042468789810379)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'460425'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:KEY_ID:VAULT_ID:SECRET_NAME:CREATED_BY:CREATED_ON:DESCRIPTION:TIME_CREATED:COMPARTMENT_ID:LIFECYCLE_STATE:ROTATION_CONFIG:TIME_OF_DELETION:LIFECYCLE_DETAILS:IS_AUTO_GENERATION_ENABLED:SECRET_GENERATION_CONTEXT:TIME_OF_CURRENT_VERSION_EXPIRY'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(46039266292805138)
,p_page_id=>2
,p_web_src_param_id=>wwv_flow_imp.id(45989192132730621)
,p_page_plug_id=>wwv_flow_imp.id(46032262021805127)
,p_value_type=>'STATIC'
,p_value=>'&G_COMPARTMENT_ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46041344170805141)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(45794638911704207)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(45678970696704109)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(45857058431704256)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46039769089805138)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(46032262021805127)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(45855408123704255)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3:P3_COMPARTMENT_ID,P3_VAULT_ID,P3_KEY_ID:\&G_COMPARTMENT_ID.\,\&G_VAULT_ID.\,\&G_KEY_ID.\'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46040043272805139)
,p_name=>unistr('\30EC\30DD\30FC\30C8\306E\7DE8\96C6 - \30C0\30A4\30A2\30ED\30B0\306E\30AF\30ED\30FC\30BA')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(46032262021805127)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46040518142805139)
,p_event_id=>wwv_flow_imp.id(46040043272805139)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46032262021805127)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46474818061232424)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'INSTALL_WEB_CREDENTIAL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_key_id varchar2(255);',
'    l_params apex_exec.t_parameters;',
'    l_secret varchar2(4000);',
'begin',
'    apex_exec.add_parameter( l_params, ''secretId'', apex_application.g_x01 );',
'    apex_exec.execute_rest_source(',
'        p_static_id        => ''vault_secret_retrieval'',',
'        p_operation        => ''GET'',',
'        p_parameters       => l_params );',
'    l_secret := apex_exec.get_parameter_varchar2( l_params, ''CONTENT'');',
'    -- apex_debug.info(''secret %s'', l_secret);',
'    utl_apex_web_credential_manager.create_credential_from_secret(',
'        p_secret => l_secret',
'    );',
'    htp.p(''{ "success": true }'');',
'exception',
'    when others then',
'        htp.p(''{ "success": false }'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>46474818061232424
);
wwv_flow_imp.component_end;
end;
/
