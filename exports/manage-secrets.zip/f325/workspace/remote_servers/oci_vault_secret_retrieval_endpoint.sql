prompt --workspace/remote_servers/oci_vault_secret_retrieval_endpoint
begin
--   Manifest
--     REMOTE SERVER: OCI Vault Secret Retrieval Endpoint
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>325
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(25223089934281631)
,p_name=>'OCI Vault Secret Retrieval Endpoint'
,p_static_id=>'OCI_Vault_Secret_Retrieval_Endpoint'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('OCI_Vault_Secret_Retrieval_Endpoint'),'https://secrets.vaults.us-ashburn-1.oci.oraclecloud.com/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('OCI_Vault_Secret_Retrieval_Endpoint'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('OCI_Vault_Secret_Retrieval_Endpoint'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('OCI_Vault_Secret_Retrieval_Endpoint'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('OCI_Vault_Secret_Retrieval_Endpoint'),'')
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
