prompt --application/shared_components/files/gemini_nano_min_js
begin
--   Manifest
--     APP STATIC FILES: 183
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>183
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '7661722067656D696E6953657373696F6E3B6173796E632066756E6374696F6E2073656E6450726F6D707428652C6E297B67656D696E6953657373696F6E7C7C28636F6E736F6C652E6C6F6728226E6F2073657373696F6E2063726561746564202D2063';
wwv_flow_imp.g_varchar2_table(2) := '726561746522292C67656D696E6953657373696F6E3D61776169742061692E617373697374616E742E6372656174652829293B636F6E737420733D652E67657456616C756528292C693D67656D696E6953657373696F6E2E70726F6D707453747265616D';
wwv_flow_imp.g_varchar2_table(3) := '696E672873293B666F7220617761697428636F6E73742065206F662069296E2E73657456616C75652865297D66756E6374696F6E20726573657453657373696F6E28297B67656D696E6953657373696F6E3D6E756C6C7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(71620805327515969)
,p_file_name=>'gemini-nano.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
