prompt --application/shared_components/user_interface/map_backgrounds/stamen_terrain
begin
--   Manifest
--     MAP BACKGROUND: Stamen Terrain
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>6703897220469736
,p_default_application_id=>104
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_map_background(
 p_id=>wwv_flow_imp.id(11907329188115381)
,p_name=>'Stamen Terrain'
,p_type=>'RASTER'
,p_url=>'https://tiles.stadiamaps.com/tiles/stamen_terrain/{z}/{x}/{y}.png?api_key={api_key}'
,p_attribution=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&copy; <a href="https://stadiamaps.com/" target="_blank">Stadia Maps</a> <a href="https://stamen.com/" target="_blank">&copy; Stamen Design</a>',
'&copy; <a href="https://openmaptiles.org/" target="_blank">OpenMapTiles</a>',
'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a>'))
,p_api_key=>'<API key>'
,p_version_scn=>3444792
);
wwv_flow_imp.component_end;
end;
/
