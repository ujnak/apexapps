prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>112
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Image Resize'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14874574683128193)
,p_plug_name=>'Image Resize'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(14643401013127532)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13562634186151921)
,p_button_sequence=>30
,p_button_name=>'RESIZE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(14750378045127764)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Resize'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13562399767151918)
,p_name=>'P1_ID'
,p_item_sequence=>10
,p_prompt=>'Image'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select title d, id r from ebmj_images'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Image -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(14747839837127757)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'REDIRECT_SET_VALUE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13562585771151920)
,p_name=>'P1_SCALE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_default=>'10'
,p_prompt=>'Scale'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14749182158127761)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13562710860151922)
,p_name=>'P1_IMAGE'
,p_item_sequence=>40
,p_prompt=>'Original'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(14747839837127757)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'SQL'
,p_attribute_06=>'select image from ebmj_images where id = :P1_ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13562854220151923)
,p_name=>'P1_IMAGE2'
,p_item_sequence=>50
,p_prompt=>'Resized'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(14747839837127757)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'SQL'
,p_attribute_06=>'select image2 from ebmj_images where id = :P1_ID'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13562938539151924)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Resize JPEG'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const jpeg = await import(''/npm/jpeg-js@0.4.4/+esm'');',
'const { Buffer } = await import(''/npm/buffer@6.0.3/+esm'');',
'const { default:Resize } = await import(''resize'');',
'',
'const id = Number(apex.env.P1_ID);',
'const scale = Number(apex.env.P1_SCALE);',
'',
'/*',
' * Extract original image as Oracle BLOB - blobImageOrg',
' */',
'const query = ''select image, image_mimetype from ebmj_images where id = :id'';',
'const res = session.execute(query,',
'    {',
'        id: { type: oracledb.NUMBER, dir: oracledb.BIND_IND, val: id }',
'    },',
'    { ',
'        fetchInfo: {',
'            "IMAGE": { type: oracledb.ORACLE_BLOB },',
'            "IMAGE_MIMETYPE": { type: oracledb.DB_TYPE_VARCHAR }',
'        },',
'        outFormat: oracledb.OUT_FORMAT_OBJECT',
'    }',
');',
'if ( res.rows.length === 0 ) {',
'    console.log("no rows selected.");',
'    // do nothing.',
'    return;',
'};',
'const row = res.rows[0];',
'const blobImageOrg = row.IMAGE;',
'let   mimeType     = row.IMAGE_MIMETYPE;',
'const blobImageOrgLen = blobImageOrg.length();',
'console.log("Lenght of BLOB Image Original = ", blobImageOrgLen);',
'',
'/*',
' * Read JPEG image from BLOB into Uint8Array then convert it into Buffer - jpegImageOrg',
' */',
'blobImageOrg.open(OracleBlob.LOB_READONLY);',
'let u8a = blobImageOrg.read(blobImageOrgLen, 1);',
'blobImageOrg.close();',
'console.log("Length of Uint8Array read from BLOB = ", u8a.length);',
'const bufImageOrg = Buffer.from(u8a);',
'',
'/*',
' * Decode JPEG image into RAW image - rawImageOrg',
' */',
'let rawImageOrg = null;',
'switch( mimeType ) {',
'    case "image/jpeg":',
'        rawImageOrg = jpeg.decode(bufImageOrg);',
'        break;',
'    default:',
'        // do nothing.',
'        return;',
'};',
'',
'/*',
' * Resize rawImageOrg into rawImageResized.',
' */',
'const originalWidth  = rawImageOrg.width;',
'const originalHeight = rawImageOrg.height;',
'const targetWidth    = Math.ceil( originalWidth / scale );',
'const targetHeight   = Math.ceil( originalHeight / scale );',
'',
'const resize = new Resize(',
'    originalWidth,',
'    originalHeight,',
'    targetWidth,',
'    targetHeight,',
'    true, ',
'    true,',
'    null,',
');',
'',
'const buf = resize.resizeHeight(resize.resizeWidth(rawImageOrg.data));',
'const rawImageResized = { width: targetWidth, height: targetHeight, data: buf };',
'',
'/*',
' * Encode RAW image that is resized into JPEG image.',
' */',
'let bufImageResized = null;',
'switch( mimeType ) {',
'    case "image/jpeg":',
'        bufImageResized = jpeg.encode(rawImageResized, 10);',
'        u8a = Uint8Array.from(bufImageResized.data);',
'        break;',
'    default:',
'        // do nothing.',
'        return;',
'};',
'console.log("Lenth of u8a written to BLOB = ", u8a.length); ',
'',
'/*',
' * Write Uint8Array to Blob',
' */',
'const blobImageResized = OracleBlob.createTemporary(false);',
'blobImageResized.open(OracleBlob.LOB_READWRITE);',
'blobImageResized.write(1, u8a);',
'blobImageResized.close();',
'console.log("Lenght of BLOB Image Resized = ", blobImageResized.length());',
'',
'/*',
' * Update Resized Image',
' */',
'const update = ''update ebmj_images set image2 = :blob, image2_mimetype = :mimeType where id = :id'';',
'const result = session.execute(update,',
'    {',
'        id: {',
'            type: oracledb.NUMBER, dir: oracledb.BIND_IND, val: id',
'        },',
'        mimeType: {',
'            type: oracledb.DB_TYPE_VARCHAR, dir: oracledb.BIND_IND, val: mimeType',
'        },',
'        blob: {',
'            type: oracledb.ORACLE_BLOB, dir: oracledb.BIND_IND, val: blobImageResized',
'        }',
'    }',
');',
'blobImageResized.freeTemporary();'))
,p_process_clob_language=>'JAVASCRIPT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13562634186151921)
,p_internal_uid=>13562938539151924
);
wwv_flow_imp.component_end;
end;
/
