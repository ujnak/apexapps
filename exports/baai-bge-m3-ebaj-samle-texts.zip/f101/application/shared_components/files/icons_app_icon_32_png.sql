prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000E1494441545847638CCA58FB9F610001E3A8034643603404864C0828CA7231282B08E02C310E1EBEC6F0E9DB7F064E2E41924A';
wwv_flow_imp.g_varchar2_table(2) := '15A2CB01175B29063F776D9C86B74FDA0B96BBF7E02D498EA0AA03345465196EDC7E4C9223A8E680A3A71F321C3A7E071C0A57AFDE66101255262A2AA8E60064DB36EDBCCAB0E7F033DA3BE0D6BD370C6A4A221816D1C501204B40009430616C0D5571B0';
wwv_flow_imp.g_varchar2_table(3) := '8368EA00986530CB4134BA184D1D00B21057D0C3E282E60E2094BAE8E680D144082B9A4713217AA2A4492224541D233B62F3CEAB44D78844D70584B21EB9F2A30E180D81D11018F0100000390AD4E17A2D5ABB0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(9633194268228196)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
