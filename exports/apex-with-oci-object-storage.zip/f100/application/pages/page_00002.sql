prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'File Upload'
,p_alias=>'FILE-UPLOAD'
,p_page_mode=>'MODAL'
,p_step_title=>'File Upload'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221201072842'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8725409400920409)
,p_plug_name=>'File Upload'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(8570314415634619)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8725538824920410)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8587943648634628)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8725810938920413)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8725538824920410)
,p_button_name=>'UPLOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(8676967781634731)
,p_button_image_alt=>'Upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8725944214920414)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8725538824920410)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(8676967781634731)
,p_button_image_alt=>'Cancel'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8725632985920411)
,p_name=>'P2_BUCKET_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8725409400920409)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8725706914920412)
,p_name=>'P2_FILE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8725409400920409)
,p_prompt=>'File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(8674469112634718)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8726001935920415)
,p_name=>'Click CANCEL'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8725944214920414)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8726198070920416)
,p_event_id=>wwv_flow_imp.id(8726001935920415)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr(' \30C0\30A4\30A2\30ED\30B0\3092\53D6\308A\6D88\3059')
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8726259610920417)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'uploadFile'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_request_url varchar2(32767);',
'  l_content_length number;',
'',
'  l_response clob;',
'    ',
'  upload_failed_exception exception;',
'begin',
'  for file in (',
'    select * from apex_application_temp_files',
'    where name = :P2_FILE',
'  ) loop',
'    l_request_url := :G_BASE_URL || ''b/'' || :P2_BUCKET_NAME ',
'     || ''/o/'' || utl_url.escape(file.filename, false, ''AL32UTF8'');',
'',
'    apex_web_service.g_request_headers(1).name := ',
'      ''Content-Type'';',
'    apex_web_service.g_request_headers(1).value :=',
'      file.mime_type;',
'    l_response := apex_web_service.make_rest_request(',
'      p_url => l_request_url',
'      , p_http_method => ''PUT''',
'      , p_body_blob => file.blob_content',
'      , p_credential_static_id => :G_OCI_WEB_CREDENTIAL',
'    );',
'',
'    if apex_web_service.g_status_code != 200 then',
'      raise upload_failed_exception;',
'    end if;',
'  end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8726322625920418)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'closeDialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
