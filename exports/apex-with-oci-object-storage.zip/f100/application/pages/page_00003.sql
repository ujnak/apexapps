prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Download Object'
,p_alias=>'DOWNLOAD-OBJECT'
,p_step_title=>'Download Object'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221201074721'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8726773521920422)
,p_name=>'P3_BUCKET_NAME'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8726845775920423)
,p_name=>'P3_OBJECT_NAME'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8726936433920424)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'downloadObject'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_request_url varchar2(32767);',
'  l_content_type varchar2(32767);',
'  l_content_length varchar2(32767);',
'',
'  l_response blob;',
'',
'  download_failed_exception exception;',
'begin',
'  l_request_url := :G_BASE_URL || ''b/'' ',
'    || :P3_BUCKET_NAME || ''/o/'' ',
'    || utl_url.escape(:P3_OBJECT_NAME, false, ''AL32UTF8'');',
'',
'  l_response := apex_web_service.make_rest_request_b(',
'    p_url => l_request_url',
'    , p_http_method => ''GET''',
'    , p_credential_static_id => :G_OCI_WEB_CREDENTIAL',
'  );',
'',
'  if apex_web_service.g_status_code != 200 then',
'    raise download_failed_exception;',
'  end if;',
'',
'  for i in 1..apex_web_service.g_headers.count',
'  loop',
'    if apex_web_service.g_headers(i).name = ',
'      ''Content-Length'' ',
'    then',
'      l_content_length := ',
'        apex_web_service.g_headers(i).value;',
'    end if;',
'',
'    if apex_web_service.g_headers(i).name = ',
'      ''Content-Type''',
'    then',
'      l_content_type :=',
'        apex_web_service.g_headers(i).value;',
'    end if;',
'  end loop;',
'',
'  sys.htp.init;',
'  if l_content_type is not null then',
'    sys.owa_util.mime_header(trim(l_content_type), false);',
'  end if;',
'  sys.htp.p(''Content-length: '' || l_content_length);',
'  sys.htp.p(''Content-Disposition: attachment; filename="''',
'    || utl_url.escape(:P3_OBJECT_NAME, false, ''AL32UTF8'') || ''"'' );',
'  sys.htp.p(''Cache-Control: max-age=3600''); -- if desired',
'  sys.owa_util.http_header_close;',
'  sys.wpg_docload.download_file(l_response);',
'',
'  apex_application.stop_apex_engine;',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
