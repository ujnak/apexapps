prompt --application/shared_components/web_sources/list_objects_in_bucket
begin
--   Manifest
--     WEB SOURCE: list_objects_in_bucket
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(8722659630861775)
,p_name=>'list_objects_in_bucket'
,p_static_id=>'list_objects_in_bucket'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(8721204607861768)
,p_remote_server_id=>wwv_flow_imp.id(8716839044834703)
,p_url_path_prefix=>'b/:bucket_name/o/'
,p_credential_id=>wwv_flow_imp.id(8715697685729597)
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(8723271292861775)
,p_web_src_module_id=>wwv_flow_imp.id(8722659630861775)
,p_name=>'bucket_name'
,p_param_type=>'URL_PATTERN'
,p_is_required=>false
,p_value=>'apex_file_storage'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(8723682127861775)
,p_web_src_module_id=>wwv_flow_imp.id(8722659630861775)
,p_name=>'fields'
,p_param_type=>'QUERY_STRING'
,p_is_required=>false
,p_value=>'name,size,timeCreated,md5'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(8722888648861775)
,p_web_src_module_id=>wwv_flow_imp.id(8722659630861775)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
