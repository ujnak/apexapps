prompt --application/shared_components/web_sources/list_buckets
begin
--   Manifest
--     WEB SOURCE: list_buckets
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(8719642947834728)
,p_name=>'list_buckets'
,p_static_id=>'list_buckets'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(8717083895834709)
,p_remote_server_id=>wwv_flow_imp.id(8716839044834703)
,p_url_path_prefix=>'/b/'
,p_credential_id=>wwv_flow_imp.id(8715697685729597)
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(8720276211834737)
,p_web_src_module_id=>wwv_flow_imp.id(8719642947834728)
,p_name=>'compartmentId'
,p_param_type=>'QUERY_STRING'
,p_is_required=>false
,p_value=>'ocid1.compartment.oc1..aaaaaaaaavuhimwvhaa7d7uo4ygllne24osdlh7xnsmedk4ppm5h7fkxohiq'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(8719853045834732)
,p_web_src_module_id=>wwv_flow_imp.id(8719642947834728)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
