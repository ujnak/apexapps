prompt --application/shared_components/web_sources/cohere_connector_api
begin
--   Manifest
--     WEB SOURCE: Cohere Connector API
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>291
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(86419409656640521)
,p_name=>'Cohere Connector API'
,p_static_id=>'cohere_connector_api'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(86416278992640505)
,p_remote_server_id=>wwv_flow_imp.id(85976097640881593)
,p_url_path_prefix=>'v1/connectors'
,p_credential_id=>wwv_flow_imp.id(85628553491852971)
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(86419697406640523)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(86420089888680493)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_operation=>'POST'
,p_database_operation=>'INSERT'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{  ',
'  "name":"#NAME#",  ',
'  "description":"#DESCRIPTION#",  ',
'  "url":"#URL!RAW#",  ',
'  "service_auth": {  ',
'    "type": "#TYPE#",',
'    "token": "#TOKEN!RAW#"',
'  }',
'}'))
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86420397894689244)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86420089888680493)
,p_name=>'NAME'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86420767867689245)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86420089888680493)
,p_name=>'DESCRIPTION'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86421229430689245)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86420089888680493)
,p_name=>'URL'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86421783903689246)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86420089888680493)
,p_name=>'TYPE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86422275146689246)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86420089888680493)
,p_name=>'TOKEN'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86422712175712581)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86420089888680493)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(86423157377726471)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_operation=>'PATCH'
,p_database_operation=>'UPDATE'
,p_url_pattern=>'/:id'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{  ',
'  "service_auth": {  ',
'    "type": "#TYPE#",',
'    "token": "#TOKEN!RAW#"',
'  }',
'}'))
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86423479253728481)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86423157377726471)
,p_name=>'TYPE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86423821509728482)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86423157377726471)
,p_name=>'TOKEN'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86424369722730162)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86423157377726471)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86424797481734033)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86423157377726471)
,p_name=>'id'
,p_param_type=>'URL_PATTERN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(86425123103770905)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_operation=>'DELETE'
,p_database_operation=>'DELETE'
,p_url_pattern=>'/:id'
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(86425422985772083)
,p_web_src_module_id=>wwv_flow_imp.id(86419409656640521)
,p_web_src_operation_id=>wwv_flow_imp.id(86425123103770905)
,p_name=>'id'
,p_param_type=>'URL_PATTERN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp.component_end;
end;
/
