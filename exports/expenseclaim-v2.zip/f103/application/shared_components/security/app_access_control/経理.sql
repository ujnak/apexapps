prompt --application/shared_components/security/app_access_control/経理
begin
--   Manifest
--     ACL ROLE: 経理
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>103
,p_default_id_offset=>26567742131370767
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(52507917010206078)
,p_static_id=>'ACCOUNTANT'
,p_name=>unistr('\7D4C\7406')
);
wwv_flow_imp.component_end;
end;
/
