prompt --application/shared_components/workflow/task_definitions/部門長による申請のレビュー
begin
--   Manifest
--     TASK_DEF: 部門長による申請のレビュー
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>103
,p_default_id_offset=>26567742131370767
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(26572058441515652)
,p_name=>unistr('\90E8\9580\9577\306B\3088\308B\7533\8ACB\306E\30EC\30D3\30E5\30FC')
,p_static_id=>'REVIEW_BY_VP'
,p_subject=>unistr('\7D4C\8CBB\7CBE\7B97\7533\8ACB &PROCESS_ID. &SUBFLOW_ID. &STEP_KEY.')
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP,10:P10_TASK_ID:&TASK_ID.'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(26621177601595782)
,p_task_def_id=>wwv_flow_imp.id(26572058441515652)
,p_name=>unistr('F4A:\7533\8ACB\306E\30EC\30D3\30E5\30FC')
,p_execution_sequence=>10
,p_outcome=>'APPROVED'
,p_on_event=>'COMPLETE'
,p_action_type=>'PLUGIN_COM.FLOWS4APEX.RETURN.TO.FLOWS.PROCESS'
,p_attribute_01=>'PROCESS_ID'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(26572378745515653)
,p_task_def_id=>wwv_flow_imp.id(26572058441515652)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'APEXDEV'
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(26572720180515653)
,p_task_def_id=>wwv_flow_imp.id(26572058441515652)
,p_participant_type=>'BUSINESS_ADMIN'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'APEXDEV'
);
wwv_flow_imp.component_end;
end;
/
