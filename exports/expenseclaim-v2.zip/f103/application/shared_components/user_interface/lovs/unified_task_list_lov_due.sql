prompt --application/shared_components/user_interface/lovs/unified_task_list_lov_due
begin
--   Manifest
--     UNIFIED_TASK_LIST.LOV.DUE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>103
,p_default_id_offset=>26567742131370767
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(26624015441657909)
,p_lov_name=>'UNIFIED_TASK_LIST.LOV.DUE'
,p_lov_query=>'.'||wwv_flow_imp.id(26624015441657909)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26624346157657910)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('\671F\9650\8D85\904E')
,p_lov_return_value=>'|0'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26624780194657910)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('\6B21\306E1\6642\9593')
,p_lov_return_value=>'0|1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26625115441657910)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('24\6642\9593\5F8C')
,p_lov_return_value=>'1|24'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26625528522657911)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('\6B21\306E7\65E5\9593')
,p_lov_return_value=>'24|168'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26625938233657911)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>unistr('\6B21\306E30\65E5\9593')
,p_lov_return_value=>'168|720'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26626311337657911)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>unistr('30\65E5\3092\8D85\3048\308B')
,p_lov_return_value=>'720|'
);
wwv_flow_imp.component_end;
end;
/
