prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>7739405930131605
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\30FB\30A8\30AF\30B9\30DD\30FC\30C8')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10358223579428074)
,p_plug_name=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\30FB\30A8\30AF\30B9\30DD\30FC\30C8')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48511081514016242)
,p_button_sequence=>60
,p_button_name=>'EXPORT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\30A8\30AF\30B9\30DD\30FC\30C8')
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10942653994491515)
,p_branch_name=>unistr('\30DA\30FC\30B8\306B\79FB\52D5 1')
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\30D6\30E9\30F3\30C1\304C\306A\3044\3068\4F55\6545\304B\4EE5\4E0B\306E\30A8\30E9\30FC\304C\767A\751F\3059\308B\3002'),
unistr('dbms_cloud_repo\304C\51FA\529B\30D0\30C3\30D5\30A1\306B\4F55\304B\66F8\304D\8FBC\3093\3067\3044\308B\306E\3067\306F\306A\3044\304B\3068\601D\3046\3002'),
'Error: SyntaxError: Unexpected end of JSON input'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48510508931016237)
,p_name=>'P1_APPLICATION_ID'
,p_item_sequence=>10
,p_prompt=>unistr('\30A8\30AF\30B9\30DD\30FC\30C8\3059\308B\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_APPLICATION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select application_id, application_name, lower(alias) alias from apex_applications',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\9078\629E --')
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_outputs', 'ALIAS:P1_ALIAS',
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48510643753016238)
,p_name=>'P1_ALIAS'
,p_item_sequence=>20
,p_prompt=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\5225\540D')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48510780916016239)
,p_name=>'P1_ALLOW_OVERWRITE'
,p_item_sequence=>30
,p_prompt=>unistr('\4E0A\66F8\304D\8A31\53EF')
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48510836671016240)
,p_name=>'P1_COMMIT_MESSAGE'
,p_item_sequence=>40
,p_prompt=>unistr('\30B3\30DF\30C3\30C8\306E\30E1\30C3\30BB\30FC\30B8')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48510975960016241)
,p_name=>'P1_COMMIT_AUTHOR_NAME'
,p_item_sequence=>50
,p_prompt=>unistr('\30B3\30DF\30C3\30BF\30FC')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(48511143523016243)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\30A8\30AF\30B9\30DD\30FC\30C8')
,p_attribute_01=>'PLSQL_PROCEDURE_FUNCTION'
,p_attribute_05=>'EXPORT_APEX_APP_TO_GITHUB'
,p_process_error_message=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\30A8\30AF\30B9\30DD\30FC\30C8\306B\5931\6557\3057\307E\3057\305F\3002')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(48511081514016242)
,p_process_success_message=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\304C\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\307E\3057\305F\3002')
,p_internal_uid=>48511143523016243
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10941241311491501)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_is_zip_export_only'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>80
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10941338021491502)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_alias'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>90
,p_value_type=>'ITEM'
,p_value=>'P1_ALIAS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10941477150491503)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_application_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P1_APPLICATION_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10941525077491504)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_with_date'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>110
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10941674425491505)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_with_ir_public_reports'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>120
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10941797746491506)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_with_ir_private_reports'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>130
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10941831997491507)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_with_ir_notifications'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>140
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10941927888491508)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_with_translations'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>150
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10942021124491509)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_with_original_ids'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>160
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10942125952491510)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_with_no_subscriptions'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>170
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10942223710491511)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_with_comments'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>180
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10942391583491512)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_with_supporting_objects'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>190
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10942434301491513)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_with_acl_assignments'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>200
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(48511269917016244)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_repo_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'G_REPO_NAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(48511362824016245)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_credential_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'G_CREDENTIAL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(48511401471016246)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_owner'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'G_OWNER'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(48511589490016247)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_directory'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'G_DIRECTORY'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(48511668495016248)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_branch_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(48511766029016249)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_commit_details'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_commit_details_in_json clob;',
'    l_author_in_json varchar2(4000);',
'begin',
unistr('    -- \30E1\30C3\30BB\30FC\30B8\304C\306A\3051\308C\3070\3001\30C7\30D5\30A9\30EB\30C8\306E\30E1\30C3\30BB\30FC\30B8\3092\4F7F\7528\3059\308B\3002'),
'    if :P1_COMMIT_MESSAGE is null then',
'        return null;',
'    end if;',
unistr('    -- \30B3\30DF\30C3\30BF\30FC\306B\30C7\30D5\30A9\30EB\30C8\306FAPEX\306E\958B\767A\8005\30A2\30AB\30A6\30F3\30C8\3068\3059\308B\3002'),
'    l_author_in_json := json_object(',
'        key ''name''',
'        value',
'            case',
'            when :P1_COMMIT_AUTHOR_NAME is not null then',
'                :P1_COMMIT_AUTHOR_NAME',
'            else',
'                :APP_USER',
'            end',
'    );',
'    l_commit_details_in_json := json_object(',
'        key ''message'' value :P1_COMMIT_MESSAGE,',
'        key ''author'' value l_author_in_json format json',
'    );',
'    apex_debug.info(l_commit_details_in_json);',
'    return l_commit_details_in_json;',
'end;'))
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(48511823192016250)
,p_page_process_id=>wwv_flow_imp.id(48511143523016243)
,p_page_id=>1
,p_name=>'p_allow_overwrite'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P1_ALLOW_OVERWRITE'
);
wwv_flow_imp.component_end;
end;
/
