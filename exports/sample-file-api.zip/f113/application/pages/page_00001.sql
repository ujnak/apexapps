prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>7601775501100353
,p_default_application_id=>113
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'File API'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23633842566022294)
,p_plug_name=>'File API'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22411118775708623)
,p_name=>'P1_FILE'
,p_item_sequence=>10
,p_prompt=>unistr('\30D5\30A1\30A4\30EB')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'display_as', 'INLINE',
  'purge_file_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22411288435708624)
,p_name=>'P1_CONTENT'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22411541884708627)
,p_name=>'onChange P1_FILE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_FILE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22411602596708628)
,p_event_id=>wwv_flow_imp.id(22411541884708627)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_CONTENT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * this.triggeringElement\306F\3001\52D5\7684\30A2\30AF\30B7\30E7\30F3\3092\30C8\30EA\30AC\30FC\3057\305F\8981\7D20\3067\3001'),
unistr(' * \4ECA\56DE\306E\5B9F\88C5\3067\306F\4EE5\4E0B\306B\306A\308B\3002'),
' * docuemnt.getElementById("P1_FILE")',
' */',
'apex.debug.info(this.triggeringElement);',
'/*',
unistr(' * this.affectedElements[0]\306F\3001\5F71\97FF\3092\53D7\3051\308B\8981\7D20\3068\3057\3066'),
unistr(' * \8A2D\5B9A\3057\305F\8981\7D20\3002\8907\6570\6307\5B9A\304C\53EF\80FD\3060\304C\3001\6700\521D\306E\8981\7D20\3092\9078\3093\3067\3044\308B\3002'),
unistr(' * \4ECA\56DE\306E\4F8B\3067\306F\3002\4EE5\4E0B\3092\5F71\97FF\3092\53D7\3051\308B\8981\7D20\3068\3057\3066\8A2D\5B9A\3057\3066\3044\308B\3002'),
' * document.getElementById("P1_CONTENT")',
' */',
'const affectedItem = apex.item(this.affectedElements[0]);',
unistr('// \9078\629E\3055\308C\305F\30D5\30A1\30A4\30EB\3092\53D6\308A\51FA\3059\3002'),
'const file = this.triggeringElement.files[0];',
'if (!file) {',
unistr('    // \30D5\30A1\30A4\30EB\304C\672A\9078\629E\306E\5834\5408\3001\8981\7D20\3092\30AF\30EA\30A2\3059\308B\3002'),
'    affectedItem.setValue("");',
'    return; ',
'}',
'const reader = new FileReader();',
'/*',
unistr(' * \9078\629E\3057\305F\30D5\30A1\30A4\30EB\306E\5185\5BB9\3092\30C6\30AD\30B9\30C8\3068\3057\3066\8AAD\307F\51FA\3059\3002'),
' */',
'reader.readAsText(file);',
'',
'/*',
unistr(' * \30D5\30A1\30A4\30EB\306E\5185\5BB9\306E\8AAD\307F\51FA\3057\304C\5B8C\4E86\3057\305F\3002'),
' */',
'reader.onload = (e) => {',
'    const content = e.target.result;',
'    affectedItem.setValue(content);',
'}'))
);
wwv_flow_imp.component_end;
end;
/
