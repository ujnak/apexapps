prompt --application/shared_components/navigation/search_config/e_gov法令ベクトル検索
begin
--   Manifest
--     SEARCH CONFIG: E-Gov法令ベクトル検索
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>160
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(47458674103125658)
,p_label=>unistr('E-Gov\6CD5\4EE4\30D9\30AF\30C8\30EB\691C\7D22')
,p_static_id=>'LAW_VECTOR'
,p_search_type=>'VECTOR'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'JLAW_LAW_SENTENCES'
,p_oratext_index_column_name=>'SENTENCE_VECTOR'
,p_vector_provider_id =>wwv_flow_imp.id(47433837811914208)
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'COSINE'
,p_return_max_results=>100
,p_pk_column_name=>'SID'
,p_title_column_name=>'LawTitle'
,p_description_column_name=>'Sentence'
,p_custom_01_column_name=>'SectionTitle'
,p_custom_02_column_name=>'SubsectionTitle'
,p_custom_03_column_name=>'ArticleTitle'
,p_icon_source_type=>'INITIALS'
,p_version_scn=>26491314
);
wwv_flow_imp.component_end;
end;
/
