prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>148
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Text to Image'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230310025910'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(63025465977083747)
,p_plug_name=>'Text to Image'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(62882366567083655)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61409997306313122)
,p_button_sequence=>30
,p_button_name=>'TEXT_TO_IMAGE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(62988203450083712)
,p_button_image_alt=>'Text To Image'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61409762567313120)
,p_name=>'P1_TEXT'
,p_is_required=>true
,p_item_sequence=>10
,p_prompt=>unistr('\30C6\30AD\30B9\30C8')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(62985716935083710)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61409845525313121)
,p_name=>'P1_SCALE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_default=>'7.5'
,p_prompt=>'scale'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(62985716935083710)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_02=>'20'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61410084799313123)
,p_name=>'P1_IMAGE'
,p_item_sequence=>40
,p_prompt=>unistr('\753B\50CF')
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(62985716935083710)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61410129034313124)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Text to Image'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request json_object_t;',
'    l_request_clob clob;',
'    l_response json_object_t;',
'    l_response_clob clob;',
'    l_id rinna_text_to_images.id%type;',
'    l_image clob;',
'    l_image_blob blob;',
'    l_nsfwContentDetected rinna_text_to_images.nsfwContentDetected%type;',
'    l_type rinna_text_to_images.type%type;',
'begin',
'    /*',
unistr('     * Text To Image V2\306E\30EA\30AF\30A8\30B9\30C8\3092\4F5C\6210\3059\308B\3002'),
'     *',
unistr('     * \53C2\7167: https://developers.rinna.co.jp/api-details#api=z05-text2image-jsd'),
'     */',
'    l_request := json_object_t();',
'    l_request.put(''prompts'',   :P1_TEXT);',
'    l_request.put(''scale'', to_number(:P1_SCALE));',
'    l_request_clob := l_request.to_clob();',
'    -- apex_debug.info(l_request_clob);',
'    /*',
unistr('     * Text To Image \306E\547C\3073\51FA\3057\3002'),
'     */',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'', p_reset => false);',
'    apex_web_service.set_request_headers(''Cache-Control'',''no-cache'', p_reset => false);',
'    l_response_clob := apex_web_service.make_rest_request(',
'        p_url => ''https://api.rinna.co.jp/models/tti/v2''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'        ,p_credential_static_id => ''RINNA_DEVELOPER_KEY''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        apex_debug.info(''REST API Failed, %s, %s'', apex_web_service.g_status_code, l_response_clob);',
'        raise_application_error(-20001, ''Text To Image = '' || apex_web_service.g_status_code);',
'    end if;',
'    /*',
unistr('     * \30EC\30B9\30DD\30F3\30B9\304B\3089\751F\6210\3055\308C\305F\753B\50CF\3092\53D6\5F97\3059\308B\3002'),
'     */',
'    l_response := json_object_t(l_response_clob);',
'    l_image := l_response.get_clob(''image'');',
'    l_image_blob := null;',
'    if instr(l_image, ''data:image/png;base64,'') <> 1 then',
unistr('        -- image/png\3067\306F\306A\3044\FF1F \8A18\9332\3057\3066\7121\8996\3059\308B\3002'),
'        apex_debug.info(l_response_clob);',
'    else',
unistr('        /* API\304C\751F\6210\3059\308B\753B\50CF\306Fimage/png\3067\3042\308B\3053\3068\3092\5E38\306B\671F\5F85\3057\3066\3044\308B\3002 */'),
'        l_image := substr(l_image, length(''data:image/png;base64,'')+1);',
'        l_image_blob := apex_web_service.clobbase642blob(l_image);',
'    end if;',
'    l_nsfwContentDetected := ''N'';',
'    if l_response.get_boolean(''nsfwContentDetected'') then',
'        l_nsfwContentDetected := ''Y'';',
'    end if;',
'    l_type := l_response.get_string(''type'');',
'    /*',
unistr('     * \30C6\30AD\30B9\30C8\3068\753B\50CF\306E\4E21\65B9\3092\4FDD\5B58\3059\308B\3002'),
'     */',
'    insert into rinna_text_to_images(text, scale, image, content_type, nsfwContentDetected, type) ',
'    values(:P1_TEXT, :P1_SCALE, l_image_blob, ''image/png'', l_nsfwContentDetected, l_type)',
'    returning id into l_id;',
unistr('    /* \30EF\30FC\30AF\30B9\30DA\30FC\30B9\540D\306Fapexdev\3067\3042\308B\3068\4EEE\5B9A\3002\9055\3046\5834\5408\306F\5909\66F4\3059\308B\3002 */'),
'    :P1_IMAGE := apex_util.host_url() || ''/ords/apexdev/rinna/image?id='' || l_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(61409997306313122)
);
wwv_flow_imp.component_end;
end;
/
