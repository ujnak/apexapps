prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>151
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Drawing on Map'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-draw/v1.4.0/mapbox-gl-draw.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var map, draw;',
'',
'/*',
unistr(' * Mapbox\306EDraw\30D7\30E9\30B0\30A4\30F3\306E\521D\671F\5316\3002'),
' */',
'const DRAW_INIT = {',
'    name: "draw-init",',
'    action: (event, element, args) => {',
'        //Get MapLibre GL JS map object',
'        map = apex.region(element.id).getMapObject();',
'        //Add Draw plug-in.',
'        draw = new MapboxDraw({',
'            displayControlsDefault: false,',
'            controls: {',
'                point: true,',
'                line_string: true,',
'                polygon: true,',
'                trash: true',
'            }',
'        });',
'        //Add Control to map',
'        map.addControl(draw, ''top-left'');',
'        //Fix Mapbox - MapLibre issue',
'        $(''.mapboxgl-ctrl-group.mapboxgl-ctrl'').addClass(''maplibregl-ctrl maplibregl-ctrl-group'');',
'',
unistr('        // \56F3\5F62\304C\4F5C\6210\3055\308C\305F\3068\304D\306B\547C\3073\51FA\3055\308C\308B\3002'),
'        map.on("draw.create", (e) => {',
'            apex.items.P1_COORDINATE.setValue(',
'                JSON.stringify(e.features[0].geometry)',
'            );',
'        });',
'    }',
'};',
'',
'/*',
unistr(' * \30A2\30AF\30B7\30E7\30F3\306E\521D\671F\5316\3002'),
' */',
'apex.jQuery(window).on(''theme42ready'', () => {',
'    apex.actions.add([DRAW_INIT]);',
'});'))
,p_css_file_urls=>'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-draw/v1.4.0/mapbox-gl-draw.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230213053542'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43038309807984844)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(46346017918268893)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>'select 35.6769883 lat, 139.7588499 lon from dual'
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(43038485609984845)
,p_region_id=>wwv_flow_imp.id(43038309807984844)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(43038544447984846)
,p_map_region_id=>wwv_flow_imp.id(43038485609984845)
,p_name=>'Sample'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LON'
,p_latitude_column=>'LAT'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46455013185268965)
,p_plug_name=>'Drawing on Map'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(46313037148268875)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43038600014984847)
,p_name=>'P1_COORDINATE'
,p_item_sequence=>20
,p_prompt=>'Coordinate'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(46416409717268932)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43038778647984848)
,p_name=>'Init Mapbox GL Draw'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(43038309807984844)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_MAP_REGION|REGION TYPE|spatialmapinitialized'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43038856062984849)
,p_event_id=>wwv_flow_imp.id(43038778647984848)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.invoke("draw-init", null, this.triggeringElement);'
);
wwv_flow_imp.component_end;
end;
/
