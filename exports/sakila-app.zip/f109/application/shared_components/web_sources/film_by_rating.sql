prompt --application/shared_components/web_sources/film_by_rating
begin
--   Manifest
--     WEB SOURCE: film by rating
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7324704527453303
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(16076426725697202)
,p_name=>'film by rating'
,p_static_id=>'film_by_rating'
,p_web_source_type=>'NATIVE_REST_ENABLED_SQL_QUERY'
,p_data_profile_id=>wwv_flow_imp.id(16072355270697200)
,p_remote_server_id=>wwv_flow_imp.id(12848911301766037)
,p_url_path_prefix=>'/_/sql'
,p_credential_id=>wwv_flow_imp.id(12843917942485175)
,p_attribute_01=>'select * from film where rating = :RATING or :RATING is null'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(16077057503697202)
,p_web_src_module_id=>wwv_flow_imp.id(16076426725697202)
,p_name=>'RATING'
,p_param_type=>'BODY'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(16076691036697202)
,p_web_src_module_id=>wwv_flow_imp.id(16076426725697202)
,p_operation=>'POST'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
