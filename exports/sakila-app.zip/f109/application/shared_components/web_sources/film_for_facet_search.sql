prompt --application/shared_components/web_sources/film_for_facet_search
begin
--   Manifest
--     WEB SOURCE: film for facet search
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7324704527453303
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(16097715384009565)
,p_name=>'film for facet search'
,p_static_id=>'film_for_facet_search'
,p_web_source_type=>'NATIVE_REST_ENABLED_SQL_QUERY'
,p_data_profile_id=>wwv_flow_imp.id(16093385027009559)
,p_remote_server_id=>wwv_flow_imp.id(12848911301766037)
,p_url_path_prefix=>'/_/sql'
,p_credential_id=>wwv_flow_imp.id(12843917942485175)
,p_sync_table_name=>'FILM_FOR_FACET_SEARCH'
,p_sync_type=>'MERGE'
,p_sync_max_http_requests=>1000
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    f.film_id',
'    , f.title',
'    , f.description',
'    , f.release_year',
'    , l.name language',
'    , f.rental_duration',
'    , f.rental_rate',
'    , f.length',
'    , f.replacement_cost',
'    , f.rating',
'    , f.special_features',
'    , f.last_update',
'    , c.name category',
'    , ga.actors',
'from film f ',
'        join language l on f.language_id = l.language_id',
'        left join film_category fc on f.film_id = fc.film_id',
'        join category c on fc.category_id = c.category_id',
'        left join (',
'            select ',
'                fa.film_id',
'                , group_concat(concat(a.first_name,'' '',a.last_name) order by a.actor_id) actors',
'            from film_actor fa join actor a on fa.actor_id = a.actor_id',
'            group by fa.film_id',
'        ) ga on f.film_id = ga.film_id'))
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(16097959757009565)
,p_web_src_module_id=>wwv_flow_imp.id(16097715384009565)
,p_operation=>'POST'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
