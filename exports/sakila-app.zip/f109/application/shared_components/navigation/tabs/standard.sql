prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7324704527453303
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
