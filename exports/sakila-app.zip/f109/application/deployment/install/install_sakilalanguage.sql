prompt --application/deployment/install/install_sakilalanguage
begin
--   Manifest
--     INSTALL: INSTALL-sakilalanguage
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7324704527453303
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16123532617395667)
,p_install_id=>wwv_flow_imp.id(16123160945391406)
,p_name=>'sakilalanguage'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table language (language_id number primary key, name varchar2(20) not null);',
'insert into language values(1, ''English'');',
'insert into language values(2, ''Italian'');',
'insert into language values(3, ''Japanese'');',
'insert into language values(4, ''Mandarin'');',
'insert into language values(5, ''French'');',
'insert into language values(6, ''German'');',
'commit;'))
);
wwv_flow_imp.component_end;
end;
/
