prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7324704527453303
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_imp.id(16024085713023533)
,p_name=>'film by rating'
,p_alias=>'FILM-BY-RATING'
,p_step_title=>'film by rating'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20220810084849'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16078070892727666)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15938694653023472)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(15829114121023408)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(16000702166023509)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16078661781727668)
,p_plug_name=>'film by rating'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15921695211023463)
,p_plug_display_sequence=>10
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(16076426725697202)
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select FILM_ID,',
'       TITLE,',
'       DESCRIPTION,',
'       RELEASE_YEAR,',
'       -- LANGUAGE_ID,',
'       l.name LANGUAGE,',
'       ORIGINAL_LANGUAGE_ID,',
'       RENTAL_DURATION,',
'       RENTAL_RATE,',
'       LENGTH,',
'       REPLACEMENT_COST,',
'       RATING,',
'       SPECIAL_FEATURES,',
'       LAST_UPDATE',
'  from #APEX$SOURCE_DATA# a join LANGUAGE l on a.language_id = l.language_id'))
,p_source_post_processing=>'SQL'
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_RATING'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'film by rating'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(16078753837727668)
,p_name=>'film by rating'
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>16078753837727668
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16079106684727668)
,p_db_column_name=>'FILM_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Film Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16079584999727669)
,p_db_column_name=>'TITLE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16079991927727669)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Description'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16080306624727669)
,p_db_column_name=>'RELEASE_YEAR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Release Year'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16081154823727670)
,p_db_column_name=>'ORIGINAL_LANGUAGE_ID'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Original Language Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16081549867727670)
,p_db_column_name=>'RENTAL_DURATION'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Rental Duration'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16081930936727671)
,p_db_column_name=>'RENTAL_RATE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Rental Rate'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16082303887727671)
,p_db_column_name=>'LENGTH'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Length'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16082769788727671)
,p_db_column_name=>'REPLACEMENT_COST'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Replacement Cost'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16083122076727671)
,p_db_column_name=>'RATING'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Rating'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16083509798727672)
,p_db_column_name=>'SPECIAL_FEATURES'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Special Features'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16083912008727672)
,p_db_column_name=>'LAST_UPDATE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Last Update'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14484044787008445)
,p_db_column_name=>'LANGUAGE'
,p_display_order=>23
,p_column_identifier=>'N'
,p_column_label=>'Language'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(16086645712803779)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'160867'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FILM_ID:TITLE:DESCRIPTION:RELEASE_YEAR:ORIGINAL_LANGUAGE_ID:RENTAL_DURATION:RENTAL_RATE:LENGTH:REPLACEMENT_COST:RATING:SPECIAL_FEATURES:LAST_UPDATE'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(16084414094727672)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(16077057503697202)
,p_page_plug_id=>wwv_flow_imp.id(16078661781727668)
,p_value_type=>'ITEM'
,p_value=>'P3_RATING'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14483702356008442)
,p_name=>'P3_RATING'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16078661781727668)
,p_prompt=>'Rating'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:PG;PG,G;G,NC-17;NC-17,PG-13;PG-13,R;R'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-- Rating\306E\9078\629E --')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(15996636813023506)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14483845639008443)
,p_name=>'onChange P3_RATING'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_RATING'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14483976281008444)
,p_event_id=>wwv_flow_imp.id(14483845639008443)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16078661781727668)
);
wwv_flow_imp.component_end;
end;
/
