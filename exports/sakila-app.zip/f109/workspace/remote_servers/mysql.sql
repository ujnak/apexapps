prompt --workspace/remote_servers/mysql
begin
--   Manifest
--     REMOTE SERVER: MySQL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7324704527453303
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(12848911301766037)
,p_name=>'MySQL'
,p_static_id=>'MySQL'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('MySQL'),'https://sql.dbtools.us-ashburn-1.oci.oraclecloud.com/20201005/ords/ocid1.databasetoolsconnection.oc1.iad.amaaaaaay3txaayamxzfwrmifzplttocnckyjcnxamf4pbjbjam3tbl3tula')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('MySQL'),'')
,p_server_type=>'REMOTE_SQL'
,p_ords_version=>'22.2.0.r1721758'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('MySQL'),'UTC')
,p_credential_id=>wwv_flow_imp.id(12843917942485175)
,p_remote_sql_database_type=>'MYSQL'
,p_remote_sql_database_info=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "database_product_name":"MySQL"',
'   ,"database_product_version":"8.0.26"',
'   ,"database_major_version":8',
'   ,"database_minor_version":0',
'   ,"env":{',
'        "defaultTimeZone":"UTC"',
'       ,"ordsVersion":"22.2.0.r1721758"',
'    }',
'}',
''))
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('MySQL'),'sakila')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('MySQL'),'')
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
