prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>112
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'AMeDAS'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20352205251173446)
,p_plug_name=>'AMeDAS'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(20352378808173447)
,p_region_id=>wwv_flow_imp.id(20352205251173446)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'139.6917'
,p_init_position_lat_static=>'35.6895'
,p_init_zoomlevel_static=>'4'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(20352461938173448)
,p_map_region_id=>wwv_flow_imp.id(20352378808173447)
,p_name=>unistr('\964D\6C34\91CF')
,p_layer_type=>'POLYGON_3D'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    p.station_number,',
'    p.station_name,',
'    p.pref_name,',
'    s.geometry_precipitation,',
'    p.curr_value_mm,',
'    p.curr_value_mm * to_number(:P1_SCALE) as curr_value,',
'    r.curr_time,',
'    r.duration',
'from amedas_precipitation p ',
'    join amedas_records r on p.record_id = r.record_id',
'    join amedas_stations s on p.station_number = s.station_number',
'where p.record_id = :P1_RECORD_ID',
'  and p.curr_value_mm > 0'))
,p_has_spatial_index=>true
,p_pk_column=>'STATION_NUMBER'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'GEOMETRY_PRECIPITATION'
,p_fill_color=>'#0000ff, #2020df, #4040bf, #60609f, #804080, #9f6060, #bf4040, #df2020, #ff0000'
,p_fill_color_is_spectrum=>true
,p_fill_value_column=>'CURR_VALUE_MM'
,p_fill_opacity=>.7
,p_extrude_value_column=>'CURR_VALUE'
,p_extrude_unit=>'M'
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Time: &P1_TIME.<br>',
'Station Name: &STATION_NAME.<br>',
'Pref Name: &PREF_NAME.<br>',
'Value: &CURR_VALUE_MM. (mm)<br>',
'Duration: &P1_DURATION.'))
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20755354074342485)
,p_plug_name=>'AMeDAS'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20352052371173444)
,p_button_sequence=>50
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20351690319173440)
,p_name=>'P1_TIME'
,p_is_required=>true
,p_item_sequence=>10
,p_prompt=>unistr('\89B3\6E2C\6642\523B')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(time_point,''YYYY-MM-DD HH24:MI'') d, to_char(time_point,''YYYYMMDDHH24MI'') r from (',
'    select',
'        t0 - numtodsinterval((level - 1) * 10, ''MINUTE'') as time_point',
'    from (',
unistr('        -- \73FE\5728\6642\523B\3092\76F4\8FD1\306E10\5206\306B\5207\308A\4E0B\3052'),
'        select (trunc(t1, ''MI'')',
'            - numtodsinterval(mod(to_number(to_char(t1,''MI'')), 10), ''MINUTE'')) AS t0',
'        from (',
unistr('            -- sysdate\304CUTC\306A\306E\30679\6642\9593\52A0\3048\308B\3001\305D\308C\304B\3089\964D\6C34\91CF\306F\89B3\6E2C\306E30\5206\5F8C\304B\3089\66F4\65B0\3055\308C\308B\306E\3067\30010.5\5F15\304F\3002'),
'            select sysdate + 8.5/24 as t1',
'        )',
'    )',
unistr('    connect by level <= 24 * 6 -- 144\884C (24\6642\9593 \00D7 6\5206\5272)'),
')',
'order by time_point desc'))
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20351703434173441)
,p_name=>'P1_DURATION'
,p_is_required=>true
,p_item_sequence=>20
,p_prompt=>unistr('\671F\9593')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:1h00;1h00,3h00;3h00,6h00;6h00,12h00;12h00,48h00;48h00,72h00;72h00'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20351817838173442)
,p_name=>'P1_RECORD_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20351966610173443)
,p_name=>'P1_SCALE'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(20352175734173445)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load PRECIPITATION from AMeDAS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_AMEDAS_URL constant varchar2(80) := ''https://www.data.jma.go.jp/stats/data/mdrr/pre_rct/alltable/pre%s_%s.csv'';',
'    l_url varchar2(120);',
'    l_data blob;',
'    e_rest_request_failed exception;',
'    l_record_id number;',
'    l_load_result apex_data_loading.t_data_load_result;',
'    l_curr_time date;',
'    l_duration  varchar2(16);',
'begin',
'    l_curr_time := to_date(:P1_TIME,''YYYYMMDDHH24MI'');',
'    l_duration  := :P1_DURATION;',
'    /*',
unistr('     * \671F\9593\306B\5408\308F\305B\3066\62BC\3057\51FA\3057\91CF\3092\8ABF\6574\3059\308B\3002'),
'     */',
'    if :P1_DURATION = ''72h00'' then',
'        :P1_SCALE := 50;',
'    elsif :P1_DURATION = ''48h00'' then',
'        :P1_SCALE := 75;',
'    elsif :P1_DURATION = ''24h00'' then',
'        :P1_SCALE := 150;',
'    elsif :P1_DURATION = ''12h00'' then',
'        :P1_SCALE := 300;',
'    elsif :P1_DURATION = ''6h00'' then',
'        :P1_SCALE := 600;',
'    elsif :P1_DURATION = ''3h00'' then',
'        :P1_SCALE := 1200;',
'    elsif :P1_DURATION = ''1h00'' then',
'        :P1_SCALE := 3600;',
'    end if;',
'    /*',
unistr('     * \89B3\6E2C\6642\523B\3068\671F\9593\3088\308A\3001\3059\3067\306BAMeDAS\3088\308A\30C7\30FC\30BF\3092\53D6\5F97\3057\3066\3044\306A\3044\304B\78BA\8A8D\3059\308B\3002'),
'     */',
'    begin',
'        select record_id into l_record_id from amedas_records',
'        where curr_time = l_curr_time and duration = l_duration;',
unistr('        /* \3059\3067\306B\30C7\30FC\30BF\304C\53D6\5F97\6E08\307F\3067\3042\308C\3070RECORD_ID\3092\8A2D\5B9A\3057\3066\7D42\4E86\3059\308B\3002 */'),
'        apex_debug.info(''Record found: %s'', l_record_id);',
'        :P1_RECORD_ID := l_record_id;',
'        return;',
'    exception',
'        when no_data_found then',
unistr('            /* \51E6\7406\3092\7D99\7D9A\3059\308B\3002 */'),
'            null;',
'    end;',
'    /*',
unistr('     * \89B3\6E2C\6642\523B\3068\671F\9593\3092\6307\5B9A\3057\3066AMeDAS\304B\3089\964D\6C34\91CF\306E\30C7\30FC\30BF\3092\53D6\5F97\3059\308B\3002'),
'     */',
'    l_url := apex_string.format(C_AMEDAS_URL, :P1_DURATION, :P1_TIME);',
'    apex_debug.info(''AMeDAS URL: %s'', l_url);',
'    apex_web_service.set_request_headers(''Content-Type'',''text/csv'');',
'    l_data := apex_web_service.make_rest_request_b(',
'        p_url => l_url,',
'        p_http_method => ''GET''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_rest_request_failed;',
'    end if;',
'    /*',
unistr('     * \53D6\5F97\3057\305F\89B3\6E2C\7D50\679C\3092\8868AMEDAS_RECORDS\306B\767B\9332\3059\308B\3002'),
'     */',
'    insert into amedas_records(curr_time, duration) values(to_date(:P1_TIME,''YYYYMMDDHH24MI''), :P1_DURATION)',
'    returning record_id into l_record_id;',
'    /*',
unistr('     * CSV\306E\30C7\30FC\30BF\3092\8868AMEDAS_RECIPITATION\306B\30ED\30FC\30C9\3059\308B\3002'),
'     */',
'    apex_session_state.set_value(''G_RECORD_ID'', l_record_id);',
'    l_load_result := apex_data_loading.load_data(',
'        p_static_id => ''precipitation'',',
'        p_data_to_load => l_data',
'    );',
'    apex_debug.info(''Processed %s'', l_load_result.processed_rows);',
'    :P1_RECORD_ID := l_record_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(20352052371173444)
,p_internal_uid=>20352175734173445
);
wwv_flow_imp.component_end;
end;
/
