prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Additional Fonts'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'https://fonts.googleapis.com/css2?family=Pacifico&display=swap'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14971192064131222)
,p_plug_name=>'Additional Fonts'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10749368908374627)
,p_name=>'P1_TEXT'
,p_item_sequence=>10
,p_prompt=>'Text'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'    options.editorOptions.fontFamily = {',
'        options: [',
'         	''default'',',
' 	        ''Arial, Helvetica, sans-serif'',',
' 	        ''Courier New, Courier, monospace'',',
' 	        ''Georgia, serif'',',
' 	        ''Lucida Sans Unicode, Lucida Grande, sans-serif'',',
' 	        ''Tahoma, Geneva, sans-serif'',',
' 	        ''Times New Roman, Times, serif'',',
' 	        ''Trebuchet MS, Helvetica, sans-serif'',',
' 	        ''Verdana, Geneva, sans-serif'',',
unistr('            ''Pacifico'' // Pacifico\30D5\30A9\30F3\30C8\3092\8FFD\52A0\3002'),
'        ],',
'        // supportAllValues: true',
'    };',
'    return options;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_custom_html', 'N',
  'format', 'HTML',
  'min_height', '180',
  'toolbar', 'FULL',
  'toolbar_style', 'OVERFLOW')).to_clob
);
wwv_flow_imp.component_end;
end;
/
