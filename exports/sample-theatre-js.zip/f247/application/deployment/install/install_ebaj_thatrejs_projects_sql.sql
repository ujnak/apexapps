prompt --application/deployment/install/install_ebaj_thatrejs_projects_sql
begin
--   Manifest
--     INSTALL: INSTALL-ebaj_thatrejs_projects.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>247
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(134861889593872783)
,p_install_id=>wwv_flow_imp.id(134861423736837375)
,p_name=>'ebaj_thatrejs_projects.sql'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>'select 1 from user_tables where table_name = ''EBAJ_THEATREJS_PROJECTS'''
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table ebaj_theatrejs_projects (',
'    project_id       varchar2(200 char) not null',
'                     constraint ebaj_theatrejs_projects_project_id_pk primary key,',
'    project_state    clob check (project_state is json)',
');'))
);
wwv_flow_imp.component_end;
end;
/
