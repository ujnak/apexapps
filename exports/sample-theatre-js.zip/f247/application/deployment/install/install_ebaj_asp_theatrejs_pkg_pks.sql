prompt --application/deployment/install/install_ebaj_asp_theatrejs_pkg_pks
begin
--   Manifest
--     INSTALL: INSTALL-ebaj_asp_theatrejs_pkg.pks
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>247
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(134862293844884103)
,p_install_id=>wwv_flow_imp.id(134861423736837375)
,p_name=>'ebaj_asp_theatrejs_pkg.pks'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package ebaj_asp_theatrejs_pkg as',
'/**',
unistr('* \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3Sample Theatre.js\306B\7D44\307F\8FBC\3080\30B9\30AF\30EA\30D7\30C8\3002'),
'* ',
unistr('* \4EE5\4E0B\306EDDL\3067\4F5C\6210\3055\308C\308B\8868EBAJ_THEATREJS_PROJECTS\304C\64CD\4F5C\306E\5BFE\8C61\3002'),
'---',
'create table ebaj_theatrejs_projects (',
'    project_id       varchar2(200 char) not null',
'                     constraint ebaj_theatrejs_projects_project_id_pk primary key,',
'    project_state    clob check (project_state is json)',
');',
'---',
'*/',
'',
'/**',
unistr('* \6307\5B9A\3057\305FProject ID\306E\30A2\30CB\30E1\30FC\30B7\30E7\30F3\3092JSON\30C9\30AD\30E5\30E1\30F3\30C8\3068\3057\3066'),
unistr('* HTTP\30D0\30C3\30D5\30A1\306B\51FA\529B\3059\308B\3002'),
'*/',
'procedure ajax_restore_project_state(',
'    p_project_id in varchar2',
');',
'',
'/**',
unistr('* Theatre.js\306E\30A2\30CB\30E1\30FC\30B7\30E7\30F3\3092JSON\30C9\30AD\30E5\30E1\30F3\30C8\3068\3057\3066\4FDD\5B58\3059\308B\3002'),
'*/',
'procedure ajax_save_project_state(',
'    p_project_id     in varchar2',
'    ,p_project_state in clob',
');',
'',
'end ebaj_asp_theatrejs_pkg;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
