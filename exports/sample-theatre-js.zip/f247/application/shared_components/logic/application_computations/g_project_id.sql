prompt --application/shared_components/logic/application_computations/g_project_id
begin
--   Manifest
--     APPLICATION COMPUTATION: G_PROJECT_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>247
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(134824418565733492)
,p_computation_sequence=>10
,p_computation_item=>'G_PROJECT_ID'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'HTML Animation Tutorial'
,p_version_scn=>41800175153804
);
wwv_flow_imp.component_end;
end;
/
