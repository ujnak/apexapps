prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>247
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Theatre.js'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[module]#APP_FILES#js/production-animation-tutorial#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133169381076806020)
,p_plug_name=>'Theatre.js'
,p_region_template_options=>'#DEFAULT#:i-h320:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(133320147544261766)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>'<h1 id="article-heading" style="text-align: center">Welcome</h1>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133518098826262609)
,p_plug_name=>'Sample Theatre.js'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(133286847957261673)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134761387602363906)
,p_plug_name=>'Controls'
,p_region_name=>'CONTROLS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(133256382613261586)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(134761400999363907)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(134761387602363906)
,p_button_name=>'EXPORT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133393799124262001)
,p_button_image_alt=>'Export'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="EXPORT"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(134762492038363917)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(134761387602363906)
,p_button_name=>'RELOAD'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133393799124262001)
,p_button_image_alt=>'Reload'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="RELOAD"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(134761837570363911)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(134761387602363906)
,p_button_name=>'IMPORT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(133393799124262001)
,p_button_image_alt=>'Import'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="IMPORT"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134762145323363914)
,p_name=>'P1_PROJECT_ID'
,p_item_sequence=>30
,p_source=>'G_PROJECT_ID'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134762369965363916)
,p_name=>'P1_STATUS'
,p_item_sequence=>40
,p_prompt=>'Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(133391212400261992)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134762038384363913)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RESTORE_PROJECT_STATE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ebaj_asp_theatrejs_pkg.ajax_restore_project_state(',
'    p_project_id => :P1_PROJECT_ID',
');'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>134762038384363913
);
wwv_flow_imp.component_end;
end;
/
