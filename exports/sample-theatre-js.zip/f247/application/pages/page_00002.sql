prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>247
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Theatre.js Studio'
,p_alias=>'THEATRE-JS-STUDIO'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Theatre.js Studio'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[module]#APP_FILES#js/theatre-studio#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133169480690806021)
,p_plug_name=>'Theatre.js'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(133254925802261582)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1 id="article-heading" style="text-align: center">Welcome</h1>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134761672338363909)
,p_name=>'P2_PROJECT_ID'
,p_item_sequence=>20
,p_source=>'G_PROJECT_ID'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134761703894363910)
,p_name=>'P2_PROJECT_STATE'
,p_data_type=>'CLOB'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134761549308363908)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_PROJECT_STATE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ebaj_asp_theatrejs_pkg.ajax_save_project_state(',
'    p_project_id => :P2_PROJECT_ID',
'    ,p_project_state => :P2_PROJECT_STATE',
');'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>134761549308363908
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134863228360209212)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RESTORE_PROJECT_STATE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ebaj_asp_theatrejs_pkg.ajax_restore_project_state(',
'    p_project_id => :P2_PROJECT_ID',
');'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>134863228360209212
);
wwv_flow_imp.component_end;
end;
/
