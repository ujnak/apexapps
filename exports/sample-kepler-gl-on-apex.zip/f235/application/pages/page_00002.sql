prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>235
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'kepler.gl embeded map'
,p_alias=>'KEPLER-GL-EMBEDED-MAP'
,p_step_title=>'kepler.gl embeded map'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://unpkg.com/react@18.3.1/umd/react.production.min.js',
'https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js',
'https://unpkg.com/redux@4.2.1/dist/redux.js',
'https://unpkg.com/react-redux@8.1.3/dist/react-redux.min.js',
'https://unpkg.com/styled-components@6.1.13/dist/styled-components.min.js',
'https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.js',
'https://unpkg.com/kepler.gl@3.1.0-alpha.1/umd/keplergl.min.js'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('/* LOAD\3068SAVE\6642\306B\753B\9762\64CD\4F5C\3092\30D6\30ED\30C3\30AF\3059\308B\3002 */'),
'var spinner;',
'',
'/*',
' * Original: https://github.com/keplergl/kepler.gl/blob/master/examples/umd-client/index.html',
unistr(' * KeplerGl 3.0\4EE5\964D\306FMapLibre\304C\30C7\30D5\30A9\30EB\30C8\306A\306E\3067\3001MapBox\95A2\9023\306E\30B3\30FC\30C9\306F\524A\9664\3057\305F\3002'),
' */',
'',
'/** STORE **/',
'const reducers = (function createReducers(redux, keplerGl) {',
'    return redux.combineReducers({',
'        // mount keplerGl reducer',
'        keplerGl: keplerGl.keplerGlReducer',
'    });',
'})(Redux, KeplerGl);',
'',
'const middleWares = (function createMiddlewares(keplerGl) {',
'    return keplerGl.enhanceReduxMiddleware([',
'        // Add other middlewares here',
'    ]);',
'})(KeplerGl);',
'',
'const enhancers = (function craeteEnhancers(redux, middles) {',
'    return redux.applyMiddleware(...middles);',
'})(Redux, middleWares);',
'',
'const store = (function createStore(redux, enhancers) {',
'    const initialState = {};',
'',
'    return redux.createStore(reducers, initialState, redux.compose(enhancers));',
'})(Redux, enhancers);',
'/** END STORE **/',
'',
'/** COMPONENTS **/',
'const KeplerElement = (function (react, keplerGl) {',
'    return function () {',
'        const element = document.getElementById(''app'');',
'        /*',
unistr('         * KeplerGl\306E\9AD8\3055\306F\3001\73FE\6642\70B9\3067\306F\30B3\30F3\30C6\30F3\30C4\304C\306A\3044\305F\3081height\304C0\306B\306A\308B\3002'),
unistr('         * \305D\306E\305F\3081\3001\30D8\30C3\30C0\30FC\3001\30D5\30C3\30BF\30FC\3001\30A2\30A4\30C6\30E0\30FB\30B3\30F3\30C6\30CA\306E\9AD8\3055\3092'),
unistr('         * 180px\3068\3057\3066\3001innerHeight\304B\3089\6E1B\3089\3057\305F\5024\3092\9AD8\3055\3068\3057\3066\3044\308B\3002'),
'         */',
'        const props = element.getBoundingClientRect();',
'        if ( props.height === 0 ) {',
'            props.height =  window.innerHeight - 180;',
'        }',
'        return react.createElement(',
'            ''div'',',
'            props,',
'            react.createElement(keplerGl.KeplerGl, {',
'                id: ''map'',',
'                width: props.width,',
'                height: props.height',
'            })',
'        );',
'    };',
'})(React, KeplerGl);',
'',
'',
'const app = (function createReactReduxProvider(react, reactRedux, KeplerElement) {',
'    return react.createElement(',
'        reactRedux.Provider,',
'        { store },',
'        react.createElement(KeplerElement, null)',
'    );',
'})(React, ReactRedux, KeplerElement);',
'/** END COMPONENTS **/'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' * Original: https://github.com/keplergl/kepler.gl/blob/master/examples/umd-client/index.html',
' */',
'',
'/** Render **/',
'(function render(react, reactDOM, app) {',
'    const container = document.getElementById(''app'');',
'    const root = reactDOM.createRoot(container);',
'    root.render(app);',
'})(React, ReactDOM, app);',
'',
'/*',
unistr(' * \4EE5\4E0B\306E\30AB\30B9\30BF\30DE\30A4\30BA\7528\306E\30B3\30FC\30C9\306F\672A\4F7F\7528\3002'),
' */',
'',
'/**',
' * Customize map.',
' * Interact with map store to customize data and behavior',
' */',
'(function customize(keplerGl, store) {',
'    // store.dispatch(keplerGl.toggleSplitMap());',
'})(KeplerGl, store);'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://d1a3f4spazzrp4.cloudfront.net/kepler.gl/uber-fonts/4.0.0/superfine.css',
'https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.css',
'https://unpkg.com/kepler.gl@3.1.0-alpha.1/umd/keplergl.min.css'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123378201727885210)
,p_plug_name=>'kepler.gl'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(124691983144107387)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>'<div id="app"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123378384755885211)
,p_plug_name=>'Controls'
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--alignCenter'
,p_plug_template=>wwv_flow_imp.id(124749438671107513)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(123378589954885213)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(123378384755885211)
,p_button_name=>'SAVE'
,p_button_static_id=>'B_SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(124830797306107719)
,p_button_image_alt=>'Save'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>unistr('\672C\5F53\306B\4FDD\5B58\3057\307E\3059\304B\FF1F')
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(123379836186885226)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(123378384755885211)
,p_button_name=>'DELETE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(124830797306107719)
,p_button_image_alt=>'Delete'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>unistr('\672C\5F53\306B\524A\9664\3057\307E\3059\304B\FF1F')
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(123379217850885220)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(123378384755885211)
,p_button_name=>'LOAD'
,p_button_static_id=>'B_LOAD'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(124830797306107719)
,p_button_image_alt=>'Load'
,p_button_position=>'BUTTON_START'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123378430551885212)
,p_name=>'P2_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(123378384755885211)
,p_prompt=>'Name'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select name d, name r from kepler_datasets order by name asc'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(124828239812107711)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'Y'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123378935861885217)
,p_name=>'P2_CONFIG'
,p_data_type=>'CLOB'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123379003165885218)
,p_name=>'P2_DATASET'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(123378602935885214)
,p_name=>'onClick Save'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(123378589954885213)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123378783135885215)
,p_event_id=>wwv_flow_imp.id(123378602935885214)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \30B9\30D4\30CA\30FC\3092\958B\59CB\3057\3001\753B\9762\64CD\4F5C\3092\30D6\30ED\30C3\30AF\3059\308B\3002'),
' */',
'spinner = apex.widget.waitPopup();',
'',
'/*',
unistr(' * \30DC\30BF\30F3SAVE\3092\7121\52B9\5316\3059\308B\3002'),
' */',
'const saveButton = document.getElementById("B_SAVE");',
'saveButton.disabled = true;',
'',
'/*',
unistr(' * KeplerGl\304B\3089\30DE\30C3\30D7\306Econfig\3068datasets\3092\53D6\308A\51FA\3059\3002'),
unistr(' * \30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0'),
' */',
'const KeplerGlSchema = KeplerGl.KeplerGlSchema;',
'const state = store.getState().keplerGl.map;',
'const dataToSave = JSON.stringify(KeplerGlSchema.getDatasetToSave(state));',
'const configToSave = JSON.stringify(KeplerGlSchema.getConfigToSave(state));',
'',
'/*',
unistr(' * \30B5\30FC\30D0\30FC\306B\9001\4FE1\3059\308B\305F\3081\3001\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306B\4FDD\5B58\3059\308B\3002'),
' */',
'apex.item("P2_DATASET").setValue(dataToSave);',
'apex.item("P2_CONFIG").setValue(configToSave);',
'',
'/*',
unistr(' * name, config, datasets\3092\30B5\30FC\30D0\30FC\306B\9001\4FE1\3057\3001\30C7\30FC\30BF\30D9\30FC\30B9\306B\4FDD\5B58\3059\308B\3002'),
' */',
'apex.server.process( "UPSERT_DATASET", {',
'    pageItems: ["P2_NAME","P2_CONFIG","P2_DATASET"]',
'}, {',
'    success: function(data) {',
'        if ( data.success ) {',
unistr('            apex.message.showPageSuccess("\30DE\30C3\30D7\304C\4FDD\5B58\3055\308C\307E\3057\305F\3002");'),
'            apex.item("P2_NAME").refresh();',
'        } else {',
'            apex.message.clearErrors();',
'            apex.message.showErrors([',
'                {',
'                    type: "error",',
'                    location: "page",',
unistr('                    message: "\30DE\30C3\30D7\306E\4FDD\5B58\306B\5931\6557\3057\307E\3057\305F\3002",'),
'                    unsafe: false',
'                }',
'            ]);',
'        };',
'        saveButton.disabled = false;',
unistr('        /* \30B9\30D4\30CA\30FC\306E\524A\9664 */'),
'        spinner.remove();',
'    },',
'    error: function( jqXHR, textStatus, errorThrown ) {',
'        apex.message.clearErrors();',
'        apex.message.showErrors([',
'            {',
'                type: "error",',
'                location: "page",',
unistr('                message: "\30DE\30C3\30D7\306E\4FDD\5B58\306B\5931\6557\3057\307E\3057\305F\3002",'),
'                unsafe: false',
'            }',
'        ]);',
'        saveButton.disabled = false;',
unistr('        /* \30B9\30D4\30CA\30FC\306E\524A\9664 */'),
'        spinner.remove();',
'    }',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(123379311867885221)
,p_name=>'onClick LOAD'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(123379217850885220)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123380341647885231)
,p_event_id=>wwv_flow_imp.id(123379311867885221)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('/* \30B9\30D4\30CA\30FC\3092\958B\59CB\3057\3001\753B\9762\64CD\4F5C\3092\30D6\30ED\30C3\30AF\3059\308B */'),
'spinner = apex.widget.waitPopup();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123379682161885224)
,p_event_id=>wwv_flow_imp.id(123379311867885221)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>unistr('\30DC\30BF\30F3LOAD\306E\7121\52B9\5316')
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(123379217850885220)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123379485504885222)
,p_event_id=>wwv_flow_imp.id(123379311867885221)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select config, dataset into :P2_CONFIG, :P2_DATASET',
'from kepler_datasets where name = :P2_NAME;'))
,p_attribute_02=>'P2_NAME'
,p_attribute_03=>'P2_CONFIG,P2_DATASET'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123379586262885223)
,p_event_id=>wwv_flow_imp.id(123379311867885221)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \30C7\30FC\30BF\30D9\30FC\30B9\304B\3089\53D6\308A\51FA\3057\305Fconfig\3068datasets\3092KeplerGl\306B\9069\7528\3059\308B\3002'),
' */',
'const KeplerGlSchema = KeplerGl.KeplerGlSchema;',
'const savedDatasets = JSON.parse(apex.item("P2_DATASET").getValue());',
'const savedConfig   = JSON.parse(apex.item("P2_CONFIG").getValue());',
'const mapToLoad = KeplerGlSchema.load(savedDatasets, savedConfig);',
'const data = KeplerGl.addDataToMap(mapToLoad);',
'store.dispatch(data);',
'',
'/*',
unistr(' * \30DC\30BF\30F3LOAD\3092\6709\52B9\5316\3059\308B\3002'),
unistr(' * \52D5\7684\30A2\30AF\30B7\30E7\30F3\3067\7121\52B9\5316\3057\3066\3044\308B\306E\3067\3001CSS\30AF\30E9\30B9\3092\524A\9664\3059\308B\5FC5\8981\304C\3042\308B\3002'),
' */',
'const loadButton = document.getElementById("B_LOAD");',
'loadButton.classList.remove("is-disabled","apex_disabled");',
'loadButton.disabled = false;',
'',
unistr('/* \30B9\30D4\30CA\30FC\3092\524A\9664 */'),
'spinner.remove();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(123380438234885232)
,p_name=>'onClick DELETE'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(123379836186885226)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123380536470885233)
,p_event_id=>wwv_flow_imp.id(123380438234885232)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'delete from kepler_datasets where name = :P2_NAME;'
,p_attribute_02=>'P2_NAME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(123380786924885235)
,p_event_id=>wwv_flow_imp.id(123380438234885232)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const thisPage = ''f?p='' + apex.env.APP_ID + '':'' + apex.env.APP_PAGE_ID + '':'' + apex.env.APP_SESSION + '':::::'';',
'apex.navigation.redirect(thisPage, true);'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(123379189494885219)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPSERT_DATASET'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    merge into kepler_datasets t',
'    using ',
'    (',
'        select :P2_NAME as name, :P2_CONFIG as config, :P2_DATASET as dataset from dual',
'    ) s',
'    on ( t.name = s.name )',
'    when matched then',
'        update set',
'            t.config = s.config',
'            ,t.dataset = s.dataset',
'    when not matched then',
'        insert (name, config, dataset)',
'        values (s.name, s.config, s.dataset);',
'    htp.p(''{ "success": true }'');',
'exception',
'    when others then',
'        htp.p(apex_string.format(''{ "success": false, "error": "%s" }'', SQLERRM ));',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>123379189494885219
);
wwv_flow_imp.component_end;
end;
/
