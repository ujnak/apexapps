prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>182
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Adding more behavior'
,p_alias=>'ADDING-MORE-BEHAVIOR'
,p_step_title=>'Adding more behavior'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#JET_BASE_DIRECTORY#js/libs/knockout/knockout-3.5.1.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function AppViewModel() {',
'    this.firstName = ko.observable("Bert");',
'    this.lastName = ko.observable("Bertington");',
'',
'    this.fullName = ko.computed(function() {',
'        return this.firstName() + " " + this.lastName();    ',
'    }, this);',
'',
'    this.capitalizeLastName = function() {',
'        var currentVal = this.lastName();        // Read the current value',
'        this.lastName(currentVal.toUpperCase()); // Write back a modified value',
'    };    ',
'}'))
,p_javascript_code_onload=>'ko.applyBindings(new AppViewModel());'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230509025632'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(333392651832632578)
,p_plug_name=>'Learn knockoutjs'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(83201297590871122)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79065261876976330)
,p_button_sequence=>80
,p_button_name=>'GO_CAPS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(83307106571871183)
,p_button_image_alt=>'Go Caps'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-bind="click: capitalizeLastName"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83353876890946252)
,p_name=>'P4_FIRST_NAME'
,p_item_sequence=>10
,p_item_default=>'todo'
,p_prompt=>'First name:'
,p_pre_element_text=>'<strong>'
,p_post_element_text=>'</strong>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'data-bind="text: firstName"'
,p_field_template=>wwv_flow_imp.id(83304402676871181)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83354263772946253)
,p_name=>'P4_LAST_NAME'
,p_item_sequence=>30
,p_item_default=>'todo'
,p_prompt=>'Last name:'
,p_pre_element_text=>'<strong>'
,p_post_element_text=>'</strong>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'data-bind="text: lastName"'
,p_field_template=>wwv_flow_imp.id(83304402676871181)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83354655762946253)
,p_name=>'P4_FIRST_NAME_VALUE'
,p_item_sequence=>50
,p_item_default=>'todo'
,p_prompt=>'First name:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'data-bind="value: firstName"'
,p_field_template=>wwv_flow_imp.id(83304402676871181)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83355014801946253)
,p_name=>'P4_LAST_NAME_VALUE'
,p_item_sequence=>60
,p_item_default=>'todo'
,p_prompt=>'Last name:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'data-bind="value: lastName"'
,p_field_template=>wwv_flow_imp.id(83304402676871181)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83355422601946254)
,p_name=>'P4_FULL_NAME'
,p_item_sequence=>70
,p_prompt=>'Full name:'
,p_pre_element_text=>'<strong>'
,p_post_element_text=>'</strong>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'data-bind="text: fullName"'
,p_field_template=>wwv_flow_imp.id(83304402676871181)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
