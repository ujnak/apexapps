prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>182
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Welcome!'
,p_alias=>'HOME'
,p_step_title=>'Learn knockoutjs'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#JET_BASE_DIRECTORY#js/libs/knockout/knockout-3.5.1.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function AppViewModel() {',
'    this.firstName = "Bert";',
'    this.lastName = "Bertington";',
'}'))
,p_javascript_code_onload=>'ko.applyBindings(new AppViewModel());'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230509024530'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(83343116762871213)
,p_plug_name=>'Learn knockoutjs'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(83201297590871122)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79064644999976324)
,p_name=>'P1_FIRST_NAME'
,p_item_sequence=>10
,p_item_default=>'todo'
,p_prompt=>'First name:'
,p_pre_element_text=>'<strong>'
,p_post_element_text=>'</strong>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'data-bind="text: firstName"'
,p_field_template=>wwv_flow_imp.id(83304402676871181)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79064732174976325)
,p_name=>'P1_LAST_NAME'
,p_item_sequence=>20
,p_item_default=>'todo'
,p_prompt=>'Last name:'
,p_pre_element_text=>'<strong>'
,p_post_element_text=>'</strong>'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'data-bind="text: lastName"'
,p_field_template=>wwv_flow_imp.id(83304402676871181)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
