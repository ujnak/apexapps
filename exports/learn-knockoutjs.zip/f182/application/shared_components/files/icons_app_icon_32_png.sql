prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 182
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>182
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE90000010E49444154584763D4DBBFE73FC30002C651078C86C068088C86003121A0C7CEC1A0C7CD032FAECE3D7BCA20C88BE083242E3F';
wwv_flow_imp.g_varchar2_table(2) := '7FC1202E28005773EDC3070656616182451C5105518C900843828606DCB005376E30280809A218BEF2E60D065D6919B8D8E5A74F186E33338F3A803A21A0F5E327839194344969E0E5FB0F0C9F44A89406AC5959191CE515E00ED8FFF00183B8B0088AEF';
wwv_flow_imp.g_varchar2_table(3) := 'B87EFDC648274BDEBDA14E088C3A60C04380EFCD5B94420694C0FCD4D451E277EFBD7B0C4AA2884477EFF55B86E7027CD44903AA7FFF621432D36DED510CAF3F7D1223A11EFDFD7BD401D40901E1BFFF188418108D6762D2C081172FA8571911F406050A';
wwv_flow_imp.g_varchar2_table(4) := '88AA0D29309FA0D651078C86C068080C780800006D6CF621C26768D80000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(83333372619871200)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
