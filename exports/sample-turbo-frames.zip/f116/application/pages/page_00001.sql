prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7216617235130697
,p_default_application_id=>116
,p_default_id_offset=>10135707799809057
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Turbo Frames'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[module]https://unpkg.com/@hotwired/turbo@8.0.4/dist/turbo.es2017-esm.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.getElementById("action_1").addEventListener("turbo:before-fetch-request", (event) => {',
'    event.detail.fetchOptions.headers["Apex-Session"] = apex.env.APP_ID + "," + apex.env.APP_SESSION;',
'    console.log(event);',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'img {',
'  max-width:100%;',
'  max-height: 100%;',
'  width: auto;',
'  height: auto;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8288437379090114)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:margin-bottom-lg'
,p_plug_template=>wwv_flow_imp.id(18516866663777035)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<turbo-frame id="action_1">',
unistr('    <a class="t-Button" href="apexdev/turbo/image/\305F\306C\304D/image_1" data-turbo-frame="image_1">\305F\306C\304D</a>'),
unistr('    <a class="t-Button" href="apexdev/turbo/image/\30B7\30DE\30A6\30DE/image_1" data-turbo-frame="image_1">\30B7\30DE\30A6\30DE</a>'),
unistr('    <a class="t-Button" href="apexdev/turbo/image/\30EC\30C3\30B5\30FC\30D1\30F3\30C0/image_1" data-turbo-frame="image_1">\30EC\30C3\30B5\30FC\30D1\30F3\30C0</a>'),
'</turbo-frame>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18423639726899166)
,p_plug_name=>'Image'
,p_region_css_classes=>'w800 h800 margin-auto'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(18518245393777041)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<turbo-frame id="image_1"></turbo-frame>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18782249927777967)
,p_plug_name=>'Sample Turbo Frames'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(18550182706777109)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
