prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(24443113768874586)
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'CKEditor5 mention feature'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function getUserItems( queryText ) {',
'    return new Promise( resolve => {',
'        apex.server.process (',
'            "GET_USERS",',
'            {',
'                x01: queryText,',
'                pageItems: "#P1_LIMIT"',
'            },',
'            {',
'                // dataType: "text",',
'                success: function( pData ) {',
'                    let users = [];',
'                    if ( pData.matchFound ) {',
'                        users = JSON.parse(pData.users);',
'                    }',
'                    resolve(users);',
'                }',
'            }',
'        );',
'    })',
'}',
'',
'function userItemRenderer( item ) {',
'    const itemElement = document.createElement( ''div'' );',
'    itemElement.id = ''mention-list-item-id-${ item.id }'';',
'',
'    const usernameElement = document.createElement( ''span'' );',
'    usernameElement.classList.add( ''padding-right-sm'');',
'    usernameElement.textContent = item.text;',
'    itemElement.appendChild( usernameElement );',
'',
'    const emailElement = document.createElement( ''span'' );',
'    emailElement.classList.add( ''u-italics'' );',
'    emailElement.textContent = item.email;',
'    itemElement.appendChild( emailElement );',
'',
'    return itemElement;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20220902071806'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24451659184874641)
,p_plug_name=>'CKEditor5 mention feature'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(24317538430874487)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24454305692954801)
,p_button_sequence=>20
,p_button_name=>'B_SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(24418217469874559)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15862376384947350)
,p_name=>'P1_TEXT'
,p_item_sequence=>10
,p_prompt=>'Text'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(24415742896874553)
,p_item_template_options=>'#DEFAULT#'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'    options.editorOptions.extraPlugins.push(CKEditor5.mention.Mention);',
'    options.editorOptions.mention = {',
'        dropdownLimit: apex.items.P1_LIMIT.value,',
'        feeds: [',
'            {',
'                marker: ''@'',',
'                feed: getUserItems,',
'                minimumCharacters: 1,',
'                itemRenderer: userItemRenderer',
'            }',
'        ]',
'    };',
'    return options;',
'}'))
,p_attribute_02=>'Intermediate'
,p_attribute_07=>'180'
,p_attribute_09=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24454470919954802)
,p_name=>'P1_LIMIT'
,p_item_sequence=>30
,p_source=>'5'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(24454555807954803)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_USERS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_regexp varchar2(4000);',
'    l_users clob;',
'begin',
'    l_regexp := apex_escape.regexp(apex_application.g_x01);',
'    select',
'        json_arrayagg(',
'            json_object(',
'                key ''id'' value ''@'' || shortname,',
'                key ''text'' value first_name || '' '' || last_name,',
'                key ''email'' value email_address',
'            )',
'        returning clob)',
'        into l_users',
'    from cke_users',
'    where regexp_like(first_name, l_regexp, ''i'') or regexp_like(last_name, l_regexp, ''i'')',
'    fetch first :P1_LIMIT rows only;',
'',
'    apex_json.open_object;',
'    apex_json.write(''success'', true);',
'    apex_json.write(''matchFound'', (l_users is not null));',
'    apex_json.write(''users'', l_users);',
'    apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
