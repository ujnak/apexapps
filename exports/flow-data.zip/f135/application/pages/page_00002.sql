prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>135
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Page 2'
,p_alias=>'PAGE-2'
,p_step_title=>'Page 2'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79104711370195364)
,p_plug_name=>'Session State'
,p_title=>unistr('\30BB\30C3\30B7\30E7\30F3\30FB\30B9\30C6\30FC\30C8\306E\8868\793A')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:margin-top-md'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<b>\30DA\30FC\30B81\306EVARCHAR2:</b> &P1_TEXT.'),
'<br>',
unistr('<b>\30DA\30FC\30B81\306ECLOB:</b> &P1_CLOB.'),
'<br>',
unistr('<b>\30DA\30FC\30B82\306EVARCHAR2:</b> &P2_TEXT.'),
'<br>',
unistr('<b>\30DA\30FC\30B82\306ECLOB:</b> &P2_CLOB.')))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39444249963517237)
,p_button_sequence=>50
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\9001\4FE1 - \30BB\30C3\30B7\30E7\30F3\30FB\30B9\30C6\30FC\30C8\3078\306E\4FDD\5B58')
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39515910693676301)
,p_button_sequence=>70
,p_button_name=>'AJAX_CALLBACK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('Ajax\30B3\30FC\30EB\30D0\30C3\30AF\306E\547C\3073\51FA\3057')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39444174346517236)
,p_name=>'P2_TEXT'
,p_item_sequence=>20
,p_prompt=>'VARCHAR2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39444886122517243)
,p_name=>'P2_CLOB'
,p_data_type=>'CLOB'
,p_item_sequence=>30
,p_prompt=>'CLOB'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39515752927671418)
,p_name=>'P2_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>80
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39520324752676345)
,p_name=>'P2_SESSION_ID'
,p_item_sequence=>10
,p_prompt=>'Session ID = Flow Instance'
,p_source=>'APP_SESSION'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39516081201676302)
,p_name=>'onClick AJAX_CALLBACK'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(39515910693676301)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39516107825676303)
,p_event_id=>wwv_flow_imp.id(39516081201676302)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'begin',
unistr('    l_response := l_response || ''\30DA\30FC\30B81\306EVARCHAR2: '' || :P1_TEXT || apex_application.LF;'),
unistr('    l_response := l_response || ''\30DA\30FC\30B81\306ECLOB: '' || :P1_CLOB || apex_application.LF;'),
unistr('    l_response := l_response || ''\30DA\30FC\30B82\306EVARCHAR2: '' || :P2_TEXT || apex_application.LF;'),
unistr('    l_response := l_response || ''\30DA\30FC\30B82\306ECLOB: '' || :P2_CLOB || apex_application.LF;'),
'    :P2_RESPONSE := l_response;',
'end;'))
,p_attribute_03=>'P2_RESPONSE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
