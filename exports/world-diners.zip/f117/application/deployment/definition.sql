prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 117
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>14753839747585513
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(25872981422672222)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table wr_orders;',
'drop view wr_menus_vl;',
'drop table wr_menus_tl;',
'drop table wr_menus;'))
);
wwv_flow_imp.component_end;
end;
/
