prompt --application/deployment/install/install_wrmenustl
begin
--   Manifest
--     INSTALL: INSTALL-wrmenustl
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>14753839747585513
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(25873829377680524)
,p_install_id=>wwv_flow_imp.id(25872981422672222)
,p_name=>'wrmenustl'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table WR_MENUS_TL',
'(',
'    ID              number          primary key,',
'    MENU_ID         number          not null,',
'    LOCAL_MENU_NAME varchar2(80)    not null,',
'    LANGUAGE        varchar2(3)     not null',
');',
unistr('insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(1,1,''\725B\4E3C'',''JA'');'),
'insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(2,1,''beef bowl'',''US'');',
unistr('insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(3,1,''\725B\8089\7897'',''ZHS'');'),
unistr('insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(4,1,''\C18C\ACE0\AE30\B36E\BC25'',''KO'');'),
unistr('insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(5,2,''\30B8\30E3\30FC\30B8\30E3\30FC\9EBA'',''JA'');'),
'insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(6,2,''Fried Source Noodles'',''US'');',
unistr('insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(7,2,''\70B8\91AC\9EB5'',''ZHS'');'),
unistr('insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(8,2,''\C9DC\C7A5\BA74'',''KO'');'),
unistr('insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(9,3,''\30CF\30F3\30D0\30FC\30AC\30FC'',''JA'');'),
'insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(10,3,''hamburger'',''US'');',
unistr('insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(11,3,''\6C49\5821\5305'',''ZHS'');'),
unistr('insert into wr_menus_tl(id, menu_id, local_menu_name, language) values(12,3,''\D584\BC84\AC70'',''KO'');'),
'commit;'))
);
wwv_flow_imp.component_end;
end;
/
