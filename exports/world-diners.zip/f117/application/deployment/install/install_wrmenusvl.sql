prompt --application/deployment/install/install_wrmenusvl
begin
--   Manifest
--     INSTALL: INSTALL-wrmenusvl
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>14753839747585513
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(25874010609681965)
,p_install_id=>wwv_flow_imp.id(25872981422672222)
,p_name=>'wrmenusvl'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE FORCE VIEW "WR_MENUS_VL" ("ID", "MENU_NAME", "VOLUME", "PRICE")',
'AS',
'SELECT O.ID, L.LOCAL_MENU_NAME as MENU_NAME, APEX_LANG.LANG(O.VOLUME) as VOLUME, O.PRICE',
'FROM WR_MENUS O JOIN WR_MENUS_TL L ON O.ID = L.MENU_ID',
'WHERE L.LANGUAGE = SYS_CONTEXT(''USERENV'', ''LANG'')',
'/'))
);
wwv_flow_imp.component_end;
end;
/
