prompt --application/deployment/install/install_wrmenus
begin
--   Manifest
--     INSTALL: INSTALL-wrmenus
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>14753839747585513
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(25873621054679048)
,p_install_id=>wwv_flow_imp.id(25872981422672222)
,p_name=>'wrmenus'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table WR_MENUS',
'(',
'    ID          number          primary key,',
'    MENU_NAME   varchar2(80)    not null,',
'    VOLUME      varchar2(16)    not null,',
'    PRICE       number          not null',
')',
'/',
unistr('insert into wr_menus(id, menu_name, volume, price) values(1,''\725B\4E3C'',''\30DF\30CB\76DB'',350);'),
unistr('insert into wr_menus(id, menu_name, volume, price) values(2,''\30B8\30E3\30FC\30B8\30E3\30FC\9EBA'',''\4E26\76DB'',650);'),
unistr('insert into wr_menus(id, menu_name, volume, price) values(3,''\30CF\30F3\30D0\30FC\30AC\30FC'',''\5927\76DB'',700);'),
'commit;'))
);
wwv_flow_imp.component_end;
end;
/
