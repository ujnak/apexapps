prompt --application/shared_components/user_interface/lovs/wr_menus_menu_name
begin
--   Manifest
--     WR_MENUS.MENU_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>14753839747585513
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(25756902750309817)
,p_lov_name=>'WR_MENUS.MENU_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'WR_MENUS_VL'
,p_return_column_name=>'ID'
,p_display_column_name=>'MENU_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'MENU_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
