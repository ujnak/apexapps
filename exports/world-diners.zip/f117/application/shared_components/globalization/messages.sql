prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 117
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>14753839747585513
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>14753839747585513
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(25871921263654382)
,p_name=>'T_GREETING'
,p_message_text=>'Welcome, %0'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(25635937521171158)
,p_name=>'T_GREETING'
,p_message_language=>'ja'
,p_message_text=>unistr('\3088\3046\3053\305D, %0')
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(25871793919654373)
,p_name=>'T_GREETING'
,p_message_language=>'ko'
,p_message_text=>unistr('\C5B4\C11C\C624\C138\C694, %0')
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(25871828090654377)
,p_name=>'T_GREETING'
,p_message_language=>'zh-cn'
,p_message_text=>unistr('\6B22\8FCE\5149\4E34, %0')
);
wwv_flow_imp.component_end;
end;
/
