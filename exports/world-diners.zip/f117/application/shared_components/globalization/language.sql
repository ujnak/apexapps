prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 117
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>14753839747585513
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_language_map(
 p_id=>wwv_flow_imp.id(25576352659937272)
,p_translation_flow_id=>1171
,p_translation_flow_language_cd=>'en'
,p_direction_right_to_left=>'N'
);
wwv_flow_imp_shared.create_language_map(
 p_id=>wwv_flow_imp.id(25576414121938389)
,p_translation_flow_id=>1172
,p_translation_flow_language_cd=>'zh-cn'
,p_direction_right_to_left=>'N'
);
wwv_flow_imp_shared.create_language_map(
 p_id=>wwv_flow_imp.id(25576597913939718)
,p_translation_flow_id=>1173
,p_translation_flow_language_cd=>'ko'
,p_direction_right_to_left=>'N'
);
wwv_flow_imp.component_end;
end;
/
