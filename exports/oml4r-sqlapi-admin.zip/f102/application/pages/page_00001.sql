prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880811687992427
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'OML4R SQLAPI Admin'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8911041205793625)
,p_plug_name=>'OML4R SQLAPI Admin'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8925422260818114)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>80
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9025291186478030)
,p_plug_name=>'RQ_E16'
,p_parent_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>200
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9026421135478042)
,p_plug_name=>'RQ_E17'
,p_parent_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>210
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8925873488818118)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E01'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-32: RandomRedDots2 - JSON'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9025462867478032)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9025291186478030)
,p_button_name=>'RQ_E16_SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'RandomRedDots2 - PNG - submit'
,p_grid_new_row=>'Y'
,p_grid_row_css_classes=>'u-flex u-align-items-center'
,p_grid_column_span=>3
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9026548875478043)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9026421135478042)
,p_button_name=>'RQ_E17_SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'RandomRedDots2 - XML - submit'
,p_grid_new_row=>'Y'
,p_grid_row_css_classes=>'u-flex u-align-items-center'
,p_grid_column_span=>3
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8926153403818121)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E02'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-33: RandomRedDots2 - PNG '
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9026704020478045)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9026421135478042)
,p_button_name=>'RQ_E17_STATUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'RandomRedDots2 - XML - status'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>3
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8924939552818109)
,p_button_sequence=>50
,p_button_name=>'GET_TOKEN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Get Token / Set Aiuth Token'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8926405512818124)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E03'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9:34: RandomRedDots2 - XML'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9025557528478033)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(9025291186478030)
,p_button_name=>'RQ_E16_STATUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'RandomRedDots2 - PNG - status'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>3
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9026927139478047)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(9026421135478042)
,p_button_name=>'RQ_E17_RESULT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'RandomRedDots2 - XML - result'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>3
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8925025744818110)
,p_button_sequence=>60
,p_button_name=>'UNSET_TOKEN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Unset Token'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8927086180818130)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E03_01'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-35: RandomRedDots2 - XML - ore_graphics_flag: true'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8927412067818134)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E04'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9:36: RandomRedDots2 - Relational'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8927897621818138)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E03_02'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-37: RandomRedDots2 - XML - arguments'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8928250210818142)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E05'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'test_ggplot2_noinp - PNG'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9025696861478034)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(9025291186478030)
,p_button_name=>'RQ_E16_RESULT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'RandomRedDots2 - PNG - result'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>3
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8928611323818146)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E06'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-39: buildLM - JSON'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9022352644478001)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E07'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-40: buildLM - PNG'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9022774013478005)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E08'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-41: buildLM - Relational'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9023051812478008)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E09'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-43: scoreLM - JSON'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9023303980478011)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E10'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-44: scoreLM - Relational'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9023600760478014)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E11'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-46: groupCount - JSON'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9023996836478017)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E12'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-47: groupCount - XML'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9024273065478020)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E13'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-48: groupCount - Relational'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9024505256478023)
,p_button_sequence=>180
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E14'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-49: computeMean - JSON'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9024968170478027)
,p_button_sequence=>190
,p_button_plug_id=>wwv_flow_imp.id(8925422260818114)
,p_button_name=>'RQ_E15'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'9-50: computeMean - XML'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8926007003818120)
,p_branch_name=>'RQ_E01'
,p_branch_action=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8925873488818118)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8926347315818123)
,p_branch_name=>'RQ_E02'
,p_branch_action=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8926153403818121)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8926873981818128)
,p_branch_name=>'RQ_E03'
,p_branch_action=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8926405512818124)
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8927284594818132)
,p_branch_name=>'RQ_E03_01'
,p_branch_action=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8927086180818130)
,p_branch_sequence=>50
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8927771065818137)
,p_branch_name=>'RQ_E04'
,p_branch_action=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8927412067818134)
,p_branch_sequence=>60
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8928032317818140)
,p_branch_name=>'RQ_E03_02'
,p_branch_action=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8927897621818138)
,p_branch_sequence=>70
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8928412891818144)
,p_branch_name=>'RQ_E05'
,p_branch_action=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8928250210818142)
,p_branch_sequence=>80
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8929041115818150)
,p_branch_name=>'RQ_E06'
,p_branch_action=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8928611323818146)
,p_branch_sequence=>90
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9022616620478004)
,p_branch_name=>'RQ_E07'
,p_branch_action=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9022352644478001)
,p_branch_sequence=>100
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9022998814478007)
,p_branch_name=>'RQ_E08'
,p_branch_action=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9022774013478005)
,p_branch_sequence=>110
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9023203162478010)
,p_branch_name=>'RQ_E09'
,p_branch_action=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9023051812478008)
,p_branch_sequence=>120
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9023594317478013)
,p_branch_name=>'RQ_E10'
,p_branch_action=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9023303980478011)
,p_branch_sequence=>130
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9023859065478016)
,p_branch_name=>'RQ_E11'
,p_branch_action=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9023600760478014)
,p_branch_sequence=>140
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9024194405478019)
,p_branch_name=>'RQ_E12'
,p_branch_action=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9023996836478017)
,p_branch_sequence=>150
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9024459444478022)
,p_branch_name=>'RQ_E13'
,p_branch_action=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9024273065478020)
,p_branch_sequence=>160
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9024802833478026)
,p_branch_name=>'RQ_E14'
,p_branch_action=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9024505256478023)
,p_branch_sequence=>170
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9025139143478029)
,p_branch_name=>'RQ_E15'
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9024968170478027)
,p_branch_sequence=>180
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9026352236478041)
,p_branch_name=>'RQ_E16'
,p_branch_action=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9025696861478034)
,p_branch_sequence=>190
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9108093253914101)
,p_branch_name=>'RQ_E17'
,p_branch_action=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(9026927139478047)
,p_branch_sequence=>200
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8924545588818105)
,p_name=>'P1_IS_TOKEN_SET'
,p_item_sequence=>10
,p_prompt=>'Is Token Set'
,p_source=>'to_char(sys.rqIsTokenSet())'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8924696450818106)
,p_name=>'P1_HOST'
,p_item_sequence=>20
,p_item_default=>'owa_util.get_cgi_env(''HTTP_HOST'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'SQL'
,p_prompt=>'Host'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8924776450818107)
,p_name=>'P1_USERNAME'
,p_item_sequence=>30
,p_item_default=>'SYS_CONTEXT(''USERENV'', ''CURRENT_USER'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'SQL'
,p_prompt=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8924800394818108)
,p_name=>'P1_PASSWORD'
,p_item_sequence=>40
,p_prompt=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8925186185818111)
,p_name=>'P1_ACCESS_TOKEN'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9025742860478035)
,p_name=>'P1_E16_JOB_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9025291186478030)
,p_prompt=>'Job Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9025833109478036)
,p_name=>'P1_E16_STATUS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9025291186478030)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9026642522478044)
,p_name=>'P1_E17_JOB_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9026421135478042)
,p_prompt=>'Job Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9026809429478046)
,p_name=>'P1_E17_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9026421135478042)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8925231263818112)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Token'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_token_url     varchar2(4000);',
'    l_request       clob;',
'    l_request_json  json_object_t;',
'    l_response      clob;',
'    l_response_json json_object_t;',
'    e_get_token_failed exception;',
'begin',
'    /* construct the token url for OML4Py */',
'    l_token_url := apex_string.format(''https://%s/omlusers/api/oauth2/v1/token'', :P1_HOST);',
'    apex_debug.info(''toekn url = %s'', l_token_url);',
'    /* prepare request body */',
'    l_request_json := json_object_t();',
'    l_request_json.put(''grant_type'', ''password'');',
'    l_request_json.put(''username'', :P1_USERNAME);',
'    l_request_json.put(''password'', :P1_PASSWORD);',
'    l_request := l_request_json.to_clob();',
'    /* get token */',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', ''Accept'', ''application/json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_token_url',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'    );',
'    if not apex_web_service.g_status_code between 200 and 300 then',
'        raise e_get_token_failed;',
'    end if;',
'    /* get token from the response */',
'    apex_debug.info(l_response);',
'    l_response_json := json_object_t.parse(l_response);',
'    /* tokenType is always Bearer and expiresIn is always in 3600 */',
'    :P1_ACCESS_TOKEN := l_response_json.get_string(''accessToken'');',
'    /* once access token is taken, set it to token store */',
'    if :P1_ACCESS_TOKEN is not null then',
'        apex_debug.info(''Set Access Token: %s'', substr(:P1_ACCESS_TOKEN,1,10));',
'        sys.rqSetAuthToken(:P1_ACCESS_TOKEN);',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8924939552818109)
,p_internal_uid=>8925231263818112
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8925338723818113)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Unset Token'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :P1_ACCESS_TOKEN := '''';',
'    sys.rqSetAuthToken(NULL);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8925025744818110)
,p_internal_uid=>8925338723818113
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8925984189818119)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E01'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e01;',
'    /* copy SQL API result into the table */',
'    insert into rq_e01(name, value)',
'    select name, value from table(',
'        rqEval2(',
'            par_lst => ''{"ore_service_level":"LOW"}'',',
'            out_fmt => ''JSON'',',
'            scr_name => ''RandomRedDots2''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8925873488818118)
,p_internal_uid=>8925984189818119
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8926257327818122)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E02'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e02;',
'    /* copy SQL API result into the table */',
'    insert into rq_e02("RID","ID","NAME","VALUE","IMAGE")',
'    select rownum "RID","ID","NAME","VALUE","IMAGE" from table(',
'        rqEval2(',
'            par_lst => ''{"ore_graphics_flag":true, "ore_service_level":"LOW"}'',',
'            out_fmt => ''PNG'',',
'            scr_name => ''RandomRedDots2''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8926153403818121)
,p_internal_uid=>8926257327818122
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8926712168818127)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E03'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e03;',
'    /* copy SQL API result into the table */',
'    insert into rq_e03(name, value)',
'    select name, value from table(',
'        rqEval2(',
'            par_lst => ''{"ore_service_level":"LOW"}'',',
'            out_fmt => ''XML'',',
'            scr_name => ''RandomRedDots2''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8926405512818124)
,p_internal_uid=>8926712168818127
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8927136110818131)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E03_01'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e03;',
'    /* copy SQL API result into the table */',
'    insert into rq_e03(name, value)',
'    select name, value from table(',
'        rqEval2(',
'            par_lst => ''{"ore_graphics_flag":true, "ore_service_level":"LOW"}'',',
'            out_fmt => ''XML'',',
'            scr_name => ''RandomRedDots2''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8927086180818130)
,p_internal_uid=>8927136110818131
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8927562567818135)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E04'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e04;',
'    /* copy SQL API result into the table */',
'    insert into rq_e04("val","id")',
'    select "val", "id" from table(',
'        rqEval2(',
'            par_lst => ''{"ore_service_level":"LOW"}'',',
'            out_fmt => ''{"val":"NUMBER","id":"NUMBER"}'',',
'            scr_name => ''RandomRedDots2''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8927412067818134)
,p_internal_uid=>8927562567818135
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8927941922818139)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E03_02'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e03;',
'    /* copy SQL API result into the table */',
'    insert into rq_e03(name, value)',
'    select name, value from table(',
'        rqEval2(',
'            par_lst => ''{"ore_service_level":"LOW", "divisor":50, "numDots":500}'',',
'            out_fmt => ''XML'',',
'            scr_name => ''RandomRedDots2''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8927897621818138)
,p_internal_uid=>8927941922818139
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8928359500818143)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E05'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e05;',
'    /* copy SQL API result into the table */',
'    insert into rq_e05("RID","ID","NAME","VALUE","IMAGE")',
'    select rownum "RID","ID","NAME","VALUE","IMAGE" from table(',
'        rqEval2(',
'            par_lst => ''{"ore_graphics_flag":true}'',',
'            out_fmt => ''PNG'',',
'            scr_name => ''test_ggplot2_noinp'',',
'            -- scr_owner => ''RQSYS'',',
'            env_name => ''myrenv''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8928250210818142)
,p_internal_uid=>8928359500818143
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8928919898818149)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E06'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e06;',
'    /* copy SQL API result into the table */',
'    insert into rq_e06(name, value)',
'    select name, value from table(',
'        rqTableEval2(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"dsname":"ds-1", "ore_service_level":"LOW"}'',',
'            out_fmt => ''JSON'',',
'            scr_name => ''buildLM''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8928611323818146)
,p_internal_uid=>8928919898818149
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9022532063478003)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E07'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e07;',
'    /* copy SQL API result into the table */',
'    insert into rq_e07("RID","ID","NAME","VALUE","IMAGE")',
'    select rownum "RID","ID","NAME","VALUE","IMAGE" from table(',
'        rqTableEval2( ',
'            inp_nam => ''IRIS'', ',
'            par_lst => ''{"dsname":"ds-1", "ore_graphics_flag":true, "ore_service_level":"LOW"}'', ',
'            out_fmt => ''PNG'', ',
'            scr_name => ''buildLM''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9022352644478001)
,p_internal_uid=>9022532063478003
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9022892132478006)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E08'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e08;',
'    /* copy SQL API result into the table */',
'    insert into rq_e08("Coef")',
'    select "Coef" from table(',
'        rqTableEval2( ',
'            inp_nam => ''IRIS'', ',
'            par_lst => ''{"dsname":"ds-1", "ore_service_level":"LOW"}'', ',
'            out_fmt => ''{"Coef":"number"}'', ',
'            scr_name => ''buildLM''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9022774013478005)
,p_internal_uid=>9022892132478006
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9023189875478009)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E09'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e09;',
'    /* copy SQL API result into the table */',
'    insert into rq_e09(name, value)',
'    select name, value from table(',
'        rqRowEval2(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"dsname":"ds-1", "ore_parallel_flag":true, "ore_service_level":"MEDIUM"}'',',
'            out_fmt => ''JSON'',',
'            row_num => 5,',
'            scr_name => ''scoreLM''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9023051812478008)
,p_internal_uid=>9023189875478009
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9023492496478012)
,p_process_sequence=>150
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E10'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e10;',
'    /* copy SQL API result into the table */',
'    insert into rq_e10("Petal.Length_pred","Petal.Length","Species")',
'    select "Petal.Length_pred","Petal.Length","Species" from table(',
'        rqRowEval2(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"dsname":"ds-1", "ore_parallel_flag":true, "ore_service_level":"MEDIUM"}'',',
'            out_fmt => ''{"Petal.Length_pred":"NUMBER", "Petal.Length":"NUMBER", "Species":"VARCHAR2(10)"}'',',
'            row_num => 5,',
'            scr_name => ''scoreLM''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9023303980478011)
,p_internal_uid=>9023492496478012
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9023748734478015)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E11'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e11;',
'    /* copy SQL API result into the table */',
'    insert into rq_e11(name, value)',
'    select name, value from table(',
'        rqGroupEval2(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"ore_service_level":"MEDIUM", "ore_parallel_flag":true}'',',
'            out_fmt => ''JSON'',',
'            grp_col => ''Species'',',
'            scr_name => ''groupCount''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9023600760478014)
,p_internal_uid=>9023748734478015
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9024031598478018)
,p_process_sequence=>170
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E12'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e12;',
'    /* copy SQL API result into the table */',
'    insert into rq_e12(name, value)',
'    select name, value from table(',
'        rqGroupEval2(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"ore_service_level":"MEDIUM", "ore_parallel_flag":true}'',',
'            out_fmt => ''XML'',',
'            grp_col => ''Species'',',
'            scr_name => ''groupCount''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9023996836478017)
,p_internal_uid=>9024031598478018
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9024361982478021)
,p_process_sequence=>180
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E13'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e13;',
'    /* copy SQL API result into the table */',
'    insert into rq_e13("Species","Count")',
'    select "Species","Count" from table(',
'        rqGroupEval2(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"ore_service_level":"MEDIUM", "ore_parallel_flag":true}'',',
'            out_fmt => ''{"Species":"VARCHAR2(10)", "Count":"NUMBER"}'',',
'            grp_col => ''Species'',',
'            scr_name => ''groupCount''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9024273065478020)
,p_internal_uid=>9024361982478021
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9024704047478025)
,p_process_sequence=>190
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E14'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e14;',
'    /* copy SQL API result into the table */',
'    insert into rq_e14(name, value)',
'    select name, value from table(',
'        rqIndexEval2(',
'            par_lst => ''{"rseed":99, "ore_parallel_flag":true, "ore_service_level":"MEDIUM"}'',',
'            out_fmt => ''JSON'',',
'            times_num => 5,',
'            scr_name => ''computeMean''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9024505256478023)
,p_internal_uid=>9024704047478025
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9025014874478028)
,p_process_sequence=>200
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E15'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e15;',
'    /* copy SQL API result into the table */',
'    insert into rq_e15(name, value)',
'    select name, value from table(',
'        rqIndexEval2(',
'            par_lst => ''{"rseed":99, "ore_parallel_flag":true, "ore_service_level":"MEDIUM"}'',',
'            out_fmt => ''XML'',',
'            times_num => 5,',
'            scr_name => ''computeMean''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9024968170478027)
,p_internal_uid=>9025014874478028
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9026035318478038)
,p_process_sequence=>210
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E16_SUBMIT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_LOCATOR constant varchar2(40) := ''/oml/api/r-scripts/v1/jobs/'';',
'    l_url varchar2(400);',
'    l_idx pls_integer;',
'begin',
'    <<submit_job>>',
'    for r in (',
'        /* call SQL API for job_id */',
'        select "NAME", "VALUE" from table(',
'            rqEval2(',
'                par_lst => ''{"ore_async_flag":true, "ore_graphics_flag":true, "ore_service_level":"LOW"}'',',
'                out_fmt => NULL,',
'                scr_name => ''RandomRedDots2''',
'            )',
'        )',
'    )',
'    loop',
'        l_idx := instr(r.value, C_LOCATOR) + length(C_LOCATOR);',
'        :P1_E16_JOB_ID := substr(r.value, l_idx);',
'        exit submit_job;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9025462867478032)
,p_internal_uid=>9026035318478038
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9026103779478039)
,p_process_sequence=>230
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E16_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_set RQSYS.rqClobSet;',
'begin',
'    <<status_loop>>',
'    for r in (',
'        select * from rqJobStatus(',
'            job_id => :P1_E16_JOB_ID',
'        )',
'    )',
'    loop',
'        :P1_E16_STATUS := r.value;',
'        exit status_loop;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9025557528478033)
,p_internal_uid=>9026103779478039
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9026297391478040)
,p_process_sequence=>250
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E16_RESULT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e16;',
'    /* copy SQL API result into the table */',
'    insert into rq_e16("RID","ID","NAME","VALUE","IMAGE")',
'    select rownum "RID","ID","NAME","VALUE","IMAGE" from rqJobResult(',
'        job_id => :P1_E16_JOB_ID,',
'        out_fmt => ''PNG''',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9025696861478034)
,p_internal_uid=>9026297391478040
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9027031088478048)
,p_process_sequence=>270
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E17_SUBMIT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_LOCATOR constant varchar2(40) := ''/oml/api/r-scripts/v1/jobs/'';',
'    l_url varchar2(400);',
'    l_idx pls_integer;',
'begin',
'    <<submit_job>>',
'    for r in (',
'        /* call SQL API for job_id */',
'        select "NAME", "VALUE" from table(',
'            rqEval2(',
'                par_lst => ''{"ore_async_flag":true, "ore_graphics_flag":true, "ore_service_level":"LOW"}'',',
'                out_fmt => ''XML'',',
'                scr_name => ''RandomRedDots2''',
'            )',
'        )',
'    )',
'    loop',
'        l_idx := instr(r.value, C_LOCATOR) + length(C_LOCATOR);',
'        :P1_E17_JOB_ID := substr(r.value, l_idx);',
'        exit submit_job;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9026548875478043)
,p_internal_uid=>9027031088478048
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9027166854478049)
,p_process_sequence=>280
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E17_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_set RQSYS.rqClobSet;',
'begin',
'    <<status_loop>>',
'    for r in (',
'        select * from rqJobStatus(',
'            job_id => :P1_E17_JOB_ID',
'        )',
'    )',
'    loop',
'        :P1_E17_STATUS := r.value;',
'        exit status_loop;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9026704020478045)
,p_internal_uid=>9027166854478049
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9027269605478050)
,p_process_sequence=>290
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RQ_E17_RESULT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from rq_e17;',
'    /* copy SQL API result into the table */',
'    insert into rq_e17("NAME","VALUE")',
'    select "NAME",substr("VALUE",1,2000) from rqJobResult(',
'        job_id => :P1_E17_JOB_ID,',
'        out_fmt => ''XML''',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9026927139478047)
,p_internal_uid=>9027269605478050
);
wwv_flow_imp.component_end;
end;
/
