prompt --application/deployment/install/install_scripts
begin
--   Manifest
--     INSTALL: INSTALL-scripts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880811687992427
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9162919108540846)
,p_install_id=>wwv_flow_imp.id(9157440242338447)
,p_name=>'scripts'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    -- RandomRedDots2',
'    sys.rqScriptCreate(''RandomRedDots2'',q''~function(divisor = 100, numDots = 100) {',
'  id <- 1:10',
'  ',
'  plot(1:numDots, rnorm(numDots), pch = 21, bg = "red", cex = 2)',
'  ',
'  data.frame(id = id, val = id / divisor)',
'}~'',true,true);',
'    -- buildLM',
'    sys.rqScriptCreate(''buildLM'',q''~function(dat, dsname) {',
'  mod <- lm(Petal.Length ~ Petal.Width, dat)',
'  ',
'  ore.save(mod, name = dsname, overwrite = TRUE)',
'  ',
'  plot(predict(mod), dat$Petal.Length, ',
'       pch = 21, bg = c("red", "blue"),  ',
'       xlab = "Predicted Values", ylab = "Observed Values")',
'  ',
'  abline(a = 0, b = 1, lwd = 2, col = "green")',
'  ',
'  return(data.frame(Coef = mod$coef))',
'}~'',true,true);',
'    -- computeMean',
'    sys.rqScriptCreate(''computeMean'',q''~function(idx, rseed) {',
'  set.seed(rseed)',
'  ',
'  x <- round(runif(100, 2, 10), 4)',
'  ',
'  return(mean(x))',
'}~'',true,true);',
'    -- groupCount',
'    sys.rqScriptCreate(''groupCount'',q''~function(dat) {',
'  x <- data.frame(table(dat$Species))',
'  names(x) <- c("Species", "Count")',
'  x',
'}~'',true,true);',
'    -- scoreLM',
'    sys.rqScriptCreate(''scoreLM'',q''~function(dat, dsname) {',
'  ore.load(dsname)',
'  ',
'  dat$Petal.Length_pred <- predict(mod, newdata = dat)',
'  ',
'  dat[, c("Petal.Length_pred", "Petal.Length", "Species")]',
'}~'',true,true);',
'    -- test_ggplot2_idx',
'    sys.rqScriptCreate(''test_ggplot2_idx'',q''~function(idx) {',
'  library(ggplot2)',
'  ',
'  row <- iris[idx, ]',
'  ',
'  histogram <- ggplot(data = row, aes(x = Sepal.Width)) +',
'    geom_histogram(binwidth = 0.2, color = "black", aes(fill = Species)) +',
'    xlab("Sepal Width") + ',
'    ylab("Frequency") + ',
'    ggtitle("Histogram of Sepal Width")',
'  ',
'  plot(histogram)',
'  ',
'  res <- "hello world"',
'  res',
'}~'',true,true);',
'    -- test_ggplot2_inp',
'    sys.rqScriptCreate(''test_ggplot2_inp'',q''~function(dat) {',
'  library(ggplot2)',
'  ',
'  histogram <- ggplot(data = dat, aes(x = Sepal.Width)) +',
'    geom_histogram(binwidth = 0.2, color = "black", aes(fill = Species)) +',
'    xlab("Sepal Width") + ',
'    ylab("Frequency") + ',
'    ggtitle("Histogram of Sepal Width")',
'  ',
'  plot(histogram)',
'  ',
'  res <- "hello world"',
'  res',
'}~'',true,true);',
'    -- test_ggplot2_noinp',
'    sys.rqScriptCreate(''test_ggplot2_noinp'',q''~function() {',
'  library(ggplot2)',
'  ',
'  mtcars$gear <- factor(mtcars$gear, ',
'                        levels = c(3, 4, 5),',
'                        labels = c("3gears", "4gears", "5gears"))',
'  ',
'  gf <- qplot(mpg, data = mtcars, geom = "density",',
'              fill = gear, alpha = I(.5), ',
'              main = "Distribution of Gas Milage",',
'              xlab = "Miles Per Gallon", ylab = "Density")',
'  ',
'  plot(gf)',
'  ',
'  res <- "hello world"',
'  res',
'}~'',true,true);',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
