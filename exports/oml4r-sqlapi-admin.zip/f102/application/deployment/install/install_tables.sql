prompt --application/deployment/install/install_tables
begin
--   Manifest
--     INSTALL: INSTALL-tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880811687992427
,p_default_application_id=>102
,p_default_id_offset=>9163584753571451
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(18321597952990231)
,p_install_id=>wwv_flow_imp.id(18321024995909898)
,p_name=>'tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table if exists rq_e01;',
'drop table if exists rq_e02;',
'drop table if exists rq_e03;',
'drop table if exists rq_e04;',
'drop table if exists rq_e05;',
'drop table if exists rq_e06;',
'drop table if exists rq_e07;',
'drop table if exists rq_e08;',
'drop table if exists rq_e09;',
'drop table if exists rq_e10;',
'drop table if exists rq_e11;',
'drop table if exists rq_e12;',
'drop table if exists rq_e13;',
'drop table if exists rq_e14;',
'drop table if exists rq_e15;',
'drop table if exists rq_e16;',
'drop table if exists rq_e17;',
'drop table if exists rq_e18;',
'drop table if exists rq_e19;',
'drop table if exists rq_e20;',
'drop table if exists rq_e21;',
'CREATE TABLE "RQ_E01"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E02"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E03"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E04"("id" NUMBER,"val" NUMBER);',
'CREATE TABLE "RQ_E05"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E06"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E07"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E08"("Coef" NUMBER);',
'CREATE TABLE "RQ_E09"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E10"("Petal.Length_pred" NUMBER,"Petal.Length" NUMBER,"Species" VARCHAR2(10));',
'CREATE TABLE "RQ_E11"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E12"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E13"("Species" VARCHAR2(10),"Count" NUMBER); ',
'CREATE TABLE "RQ_E14"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E15"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E16"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E17"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E18"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E19"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E20"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E21"("NAME" VARCHAR2(128),"VALUE" CLOB);'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18321731357990244)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E01'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18321921267990246)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E02'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18321985022990247)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E03'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18322198150990248)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E04'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18322396023990249)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E05'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18322641541990249)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E06'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18322807742990250)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E07'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18323043551990251)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E08'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18323274148990252)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E09'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18323466570990252)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E10'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18323645473990253)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E11'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18323795126990254)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E12'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18324082187990254)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E13'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18324274137990255)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E14'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18324405732990256)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E15'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18324661736990257)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E16'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18324788416990257)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E17'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18325011894990258)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E18'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(18325279283990259)
,p_script_id=>wwv_flow_imp.id(18321597952990231)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E19'
);
wwv_flow_imp.component_end;
end;
/
