prompt --application/deployment/install/install_tables
begin
--   Manifest
--     INSTALL: INSTALL-tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880811687992427
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9158013199418780)
,p_install_id=>wwv_flow_imp.id(9157440242338447)
,p_name=>'tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table if exists rq_e01;',
'drop table if exists rq_e02;',
'drop table if exists rq_e03;',
'drop table if exists rq_e04;',
'drop table if exists rq_e05;',
'drop table if exists rq_e06;',
'drop table if exists rq_e07;',
'drop table if exists rq_e08;',
'drop table if exists rq_e09;',
'drop table if exists rq_e10;',
'drop table if exists rq_e11;',
'drop table if exists rq_e12;',
'drop table if exists rq_e13;',
'drop table if exists rq_e14;',
'drop table if exists rq_e15;',
'drop table if exists rq_e16;',
'drop table if exists rq_e17;',
'drop table if exists rq_e18;',
'drop table if exists rq_e19;',
'CREATE TABLE "RQ_E01"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E02"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E03"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E04"("id" NUMBER,"val" NUMBER);',
'CREATE TABLE "RQ_E05"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E06"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E07"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E08"("Coef" NUMBER);',
'CREATE TABLE "RQ_E09"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E10"("Petal.Length_pred" NUMBER,"Petal.Length" NUMBER,"Species" VARCHAR2(10));',
'CREATE TABLE "RQ_E11"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E12"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E13"("Species" VARCHAR2(10),"Count" NUMBER); ',
'CREATE TABLE "RQ_E14"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E15"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E16"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E17"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "RQ_E18"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);',
'CREATE TABLE "RQ_E19"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"VALUE" VARCHAR2(4000),"IMAGE" BLOB);'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9158146604418793)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E01'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9158336514418795)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E02'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9158400269418796)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E03'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9158613397418797)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E04'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9158811270418798)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E05'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9159056788418798)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E06'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9159222989418799)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E07'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9159458798418800)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E08'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9159689395418801)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E09'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9159881817418801)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E10'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9160060720418802)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E11'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9160210373418803)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E12'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9160497434418803)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E13'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9160689384418804)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E14'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9160820979418805)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E15'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9161076983418806)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E16'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9161203663418806)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E17'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9161427141418807)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E18'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9161694530418808)
,p_script_id=>wwv_flow_imp.id(9158013199418780)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'RQ_E19'
);
wwv_flow_imp.component_end;
end;
/
