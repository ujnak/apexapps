prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880811687992427
,p_default_application_id=>102
,p_default_id_offset=>9250029695529037
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(36781655742774363)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    -- RandomRedDots2',
'    begin sys.rqScriptDrop(''RandomRedDots2'',true,true);',
'    exception when others then null; end;',
'    -- buildLM',
'    begin sys.rqScriptDrop(''buildLM'',true,true);',
'    exception when others then null; end;',
'    -- computeMean',
'    begin sys.rqScriptDrop(''computeMean'',true,true);',
'    exception when others then null; end;',
'    -- groupCount',
'    begin sys.rqScriptDrop(''groupCount'',true,true);',
'    exception when others then null; end;',
'    -- scoreLM',
'    begin sys.rqScriptDrop(''scoreLM'',true,true);',
'    exception when others then null; end;',
'    -- test_ggplot2_idx',
'    begin sys.rqScriptDrop(''test_ggplot2_idx'',true,true);',
'    exception when others then null; end;',
'    -- test_ggplot2_inp',
'    begin sys.rqScriptDrop(''test_ggplot2_inp'',true,true);',
'    exception when others then null; end;',
'    -- test_ggplot2_noinp',
'    begin sys.rqScriptDrop(''test_ggplot2_noinp'',true,true);',
'    exception when others then null; end;',
'end;',
'/',
'drop table if exists rq_e01;',
'drop table if exists rq_e02;',
'drop table if exists rq_e03;',
'drop table if exists rq_e04;',
'drop table if exists rq_e05;',
'drop table if exists rq_e06;',
'drop table if exists rq_e07;',
'drop table if exists rq_e08;',
'drop table if exists rq_e09;',
'drop table if exists rq_e10;',
'drop table if exists rq_e11;',
'drop table if exists rq_e12;',
'drop table if exists rq_e13;',
'drop table if exists rq_e14;',
'drop table if exists rq_e15;',
'drop table if exists rq_e16;',
'drop table if exists rq_e17;',
'drop table if exists rq_e18;',
'drop table if exists rq_e19;',
'drop table if exists rq_e20;',
'drop table if exists rq_e21;',
'drop table if exists iris;'))
);
wwv_flow_imp.component_end;
end;
/
