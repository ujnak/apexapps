prompt --application/shared_components/logic/application_computations/cnt_e15
begin
--   Manifest
--     APPLICATION COMPUTATION: CNT_E15
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880811687992427
,p_default_application_id=>102
,p_default_id_offset=>9210601051335428
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(18398635227093538)
,p_computation_sequence=>10
,p_computation_item=>'CNT_E15'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'select count(*) from rq_e15'
,p_version_scn=>45045669481509
);
wwv_flow_imp.component_end;
end;
/
