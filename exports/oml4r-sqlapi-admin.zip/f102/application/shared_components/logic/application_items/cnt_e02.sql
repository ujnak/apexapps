prompt --application/shared_components/logic/application_items/cnt_e02
begin
--   Manifest
--     APPLICATION ITEM: CNT_E02
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880811687992427
,p_default_application_id=>102
,p_default_id_offset=>9250029695529037
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(27630247909481909)
,p_name=>'CNT_E02'
,p_protection_level=>'I'
,p_version_scn=>45045666905287
);
wwv_flow_imp.component_end;
end;
/
