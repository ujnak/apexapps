prompt --application/shared_components/navigation/lists/ページ・ナビゲーション
begin
--   Manifest
--     LIST: ページ・ナビゲーション
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>30040104978234657984
,p_default_application_id=>63416
,p_default_id_offset=>67776734671150896252
,p_default_owner=>'WKSP_JAPANCOMMUNITY'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(101654584481828604311)
,p_name=>unistr('\30DA\30FC\30B8\30FB\30CA\30D3\30B2\30FC\30B7\30E7\30F3')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(101654584969457604313)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('\30AB\30B9\30BF\30E0\30FB\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\7BA1\7406')
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:'
,p_list_item_icon=>'fa-layout-header-sidebar-left'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
