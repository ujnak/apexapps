prompt --application/deployment/buildoptions
begin
--   Manifest
--     INSTALL BUILD OPTIONS: 63416
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>30040104978234657984
,p_default_application_id=>63416
,p_default_id_offset=>67776734671150896252
,p_default_owner=>'WKSP_JAPANCOMMUNITY'
);
null;
wwv_flow_imp.component_end;
end;
/
