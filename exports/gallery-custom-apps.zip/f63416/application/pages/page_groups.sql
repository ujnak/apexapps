prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 63416
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.3'
,p_default_workspace_id=>30040104978234657984
,p_default_application_id=>63416
,p_default_id_offset=>67776734671150896252
,p_default_owner=>'WKSP_JAPANCOMMUNITY'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(101654528762487603993)
,p_group_name=>unistr('\7BA1\7406')
);
wwv_flow_imp.component_end;
end;
/
