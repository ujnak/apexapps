prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('APEX 24.2\306E\8907\6570\9078\629E\3068\30DD\30C3\30D7\30A2\30C3\30D7LOV')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33590441245395845)
,p_plug_name=>unistr('APEX 24.2\306E\8907\6570\9078\629E\3068\30DD\30C3\30D7\30A2\30C3\30D7LOV')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28631720936763836)
,p_name=>'P1_SELECT_MANY'
,p_item_sequence=>10
,p_prompt=>unistr('\8907\6570\9078\629E')
,p_display_as=>'NATIVE_SELECT_MANY'
,p_named_lov=>'LOV_COUNTRIES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    c.country_id',
'    , c.name country_name',
'    , c.country_code',
'    , c.iso_alpha2',
'    , c.capital capital_name',
'    , c.population',
'    , r.name region_name',
'    , s.name sub_region_name',
'    , ''fa-flag-'' || lower(c.iso_alpha2) icon',
'from eba_countries c join eba_country_regions r on c.region_id = r.id',
'     join eba_country_sub_regions s on c.sub_region_id = s.id'))
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0',
  'use_defaults', 'Y')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28631839838763837)
,p_name=>'P1_POPUP_LOV'
,p_item_sequence=>20
,p_prompt=>unistr('\30DD\30C3\30D7\30A2\30C3\30D7LOV')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_COUNTRIES2'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    c.country_id',
'    , c.name country_name',
'    , c.country_code',
'    , c.iso_alpha2',
'    , c.capital capital_name',
'    , c.population',
'    , r.name region_name',
'    , s.name sub_region_name',
'    , ''fa-flag-'' || lower(c.iso_alpha2) icon',
'from eba_countries c join eba_country_regions r on c.region_id = r.id',
'     join eba_country_sub_regions s on c.sub_region_id = s.id'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp.component_end;
end;
/
