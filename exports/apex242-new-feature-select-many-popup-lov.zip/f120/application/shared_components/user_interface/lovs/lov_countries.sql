prompt --application/shared_components/user_interface/lovs/lov_countries
begin
--   Manifest
--     LOV_COUNTRIES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(33597712014676698)
,p_lov_name=>'LOV_COUNTRIES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    c.country_id',
'    , c.name country_name',
'    , c.country_code',
'    , c.iso_alpha2',
'    , c.capital capital_name',
'    , c.population',
'    , r.name region_name',
'    , s.name sub_region_name',
'    , ''fa-flag-'' || lower(c.iso_alpha2) icon',
'from eba_countries c join eba_country_regions r on c.region_id = r.id',
'     join eba_country_sub_regions s on c.sub_region_id = s.id'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'COUNTRY_ID'
,p_display_column_name=>'COUNTRY_NAME'
,p_icon_column_name=>'ICON'
,p_group_column_name=>'REGION_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'COUNTRY_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>12971869
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(33598128772739834)
,p_query_column_name=>'COUNTRY_ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(33598533193739834)
,p_query_column_name=>'COUNTRY_NAME'
,p_heading=>'Country Name'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(33598928305739834)
,p_query_column_name=>'REGION_NAME'
,p_heading=>'Region Name'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(33599391058739834)
,p_query_column_name=>'ICON'
,p_heading=>'Icon'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp.component_end;
end;
/
