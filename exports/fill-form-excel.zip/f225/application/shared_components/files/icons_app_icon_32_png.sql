prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 225
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>225
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000CC494441545847636CDC1DFF9F610001E3A8034643603404464360D08700EB1F2E06D6BF1C2865E5CB2F4F187885B9A8527E12';
wwv_flow_imp.g_varchar2_table(2) := '2C09B97E0A31A82BEA605876F6E671863F2CDF18D83859297208D90E00D9FAE0E56D869FDF7EE274C0877F2F093A906C07BCFFF89641805D0CAFEFEF3EBFCEF099FD055E35041DC0FB538241595213C3107B0D6F82417FF0C656860BEFF653E600032147';
wwv_flow_imp.g_varchar2_table(3) := '06622CC366CBA8034643607884C0E7B7DF186C550967396CB9E0F0EDAD048B6C82E500C1CC4EA18251078C86C068088C86C080870000952DA261879314360000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(33273244926819404)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
