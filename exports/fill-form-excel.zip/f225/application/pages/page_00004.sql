prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>225
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>unistr('\30B3\30EC\30AF\30B7\30E7\30F3')
,p_alias=>unistr('\30B3\30EC\30AF\30B7\30E7\30F3')
,p_step_title=>unistr('\30B3\30EC\30AF\30B7\30E7\30F3')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230703054654'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33307343098198862)
,p_button_sequence=>20
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(33164303661819310)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98283025797555363)
,p_name=>'P4_FILE'
,p_item_sequence=>10
,p_prompt=>unistr('\7533\8ACB\30D5\30A1\30A4\30EB')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98283323926555366)
,p_name=>'P4_NAME'
,p_item_sequence=>30
,p_prompt=>unistr('\6C0F\540D')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98283424880555367)
,p_name=>'P4_DEPT'
,p_item_sequence=>40
,p_prompt=>unistr('\6240\5C5E')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98283578816555368)
,p_name=>'P4_PURPOSE'
,p_item_sequence=>50
,p_prompt=>unistr('\76EE\7684')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98283648893555369)
,p_name=>'P4_AMOUNT'
,p_item_sequence=>60
,p_prompt=>unistr('\91D1\984D')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(33298685731100003)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fill Form'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql varchar2(2000);',
'begin',
unistr('    -- APEX\30B3\30EC\30AF\30B7\30E7\30F3\306E\30BD\30FC\30B9\3068\306A\308BSELECT\6587'),
'    l_sql := q''~select col001, col002',
'from apex_data_parser.parse(',
'    p_content => (',
'        select blob_content from apex_application_temp_files where name = ''&P4_FILE.''',
'    ),',
'    p_file_name => ''dummy.xlsx''',
')~'';',
'    l_sql := replace(l_sql, ''&P4_FILE.'',:P4_FILE);',
unistr('    -- APEX\30B3\30EC\30AF\30B7\30E7\30F3\3092\4F5C\308B'),
'    apex_collection.create_collection_from_query(',
'        p_collection_name => ''DOCUMENT''',
'        ,p_query => l_sql',
'        ,p_truncate_if_exists => ''YES''',
'    );',
unistr('    -- \30D5\30A9\30FC\30E0\306E\7A74\57CB\3081'),
unistr('    select c002 into :P4_NAME    from apex_collections where collection_name = ''DOCUMENT'' and c001 = ''\6C0F\540D'';'),
unistr('    select c002 into :P4_DEPT    from apex_collections where collection_name = ''DOCUMENT'' and c001 = ''\6240\5C5E'';'),
unistr('    select c002 into :P4_PURPOSE from apex_collections where collection_name = ''DOCUMENT'' and c001 = ''\76EE\7684'';'),
unistr('    select c002 into :P4_AMOUNT  from apex_collections where collection_name = ''DOCUMENT'' and c001 = ''\91D1\984D'';'),
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(33307343098198862)
,p_internal_uid=>33298685731100003
);
wwv_flow_imp.component_end;
end;
/
