prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>225
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Classic Report'
,p_alias=>'CLASSIC-REPORT'
,p_step_title=>'Classic Report'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// \30EC\30DD\30FC\30C8\3092\975E\8868\793A\306B\3059\308B'),
'document.getElementById("document").style.display = "none";',
'',
'let doc = document.getElementById("report_table_document").tBodies[0];',
'for (let i = 0; i < doc.rows.length; i++) {',
'    let label = doc.rows[i].cells[0].textContent;',
'    let value = doc.rows[i].cells[1].textContent;',
'    switch(label) {',
unistr('        case "\6C0F\540D":'),
'            apex.items.P2_NAME.setValue(value);',
'            break;',
unistr('        case "\6240\5C5E":'),
'            apex.items.P2_DEPT.setValue(value);',
'            break;',
unistr('        case "\76EE\7684":'),
'            apex.items.P2_PURPOSE.setValue(value);',
'            break;',
unistr('        case "\91D1\984D":'),
'            apex.items.P2_AMOUNT.setValue(value);',
'            break;',
'    };',
'}'))
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230703052427'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(31679401926259747)
,p_name=>'Document'
,p_region_name=>'document'
,p_template=>wwv_flow_imp.id(33073429467819248)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select col001, col002',
'from apex_data_parser.parse(',
'    p_content => (',
'        select blob_content from apex_application_temp_files where name = :P2_FILE',
'    ),',
'    p_file_name => ''dummy.xlsx''',
')'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(33117744046819274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(31679599200259748)
,p_query_column_id=>1
,p_column_alias=>'COL001'
,p_column_display_sequence=>10
,p_column_heading=>'Col001'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(31679661365259749)
,p_query_column_id=>2
,p_column_alias=>'COL002'
,p_column_display_sequence=>20
,p_column_heading=>'Col002'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33286303519831310)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(33085860247819256)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(32987805387819196)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(33165949471819311)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31678625471259739)
,p_button_sequence=>20
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(33164303661819310)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31678402454259737)
,p_name=>'P2_FILE'
,p_item_sequence=>10
,p_prompt=>unistr('\7533\8ACB\30D5\30A1\30A4\30EB')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31678700583259740)
,p_name=>'P2_NAME'
,p_item_sequence=>30
,p_prompt=>unistr('\6C0F\540D')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31678801537259741)
,p_name=>'P2_DEPT'
,p_item_sequence=>40
,p_prompt=>unistr('\6240\5C5E')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31678955473259742)
,p_name=>'P2_PURPOSE'
,p_item_sequence=>50
,p_prompt=>unistr('\76EE\7684')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31679025550259743)
,p_name=>'P2_AMOUNT'
,p_item_sequence=>60
,p_prompt=>unistr('\91D1\984D')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp.component_end;
end;
/
