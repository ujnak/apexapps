prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>225
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>unistr('\9045\5EF6\30ED\30FC\30C9')
,p_alias=>unistr('\9045\5EF6\30ED\30FC\30C9')
,p_step_title=>unistr('\9045\5EF6\30ED\30FC\30C9')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230703060359'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(64973297768356505)
,p_name=>'Document'
,p_region_name=>'document'
,p_template=>wwv_flow_imp.id(33073429467819248)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select col001, col002',
'from apex_data_parser.parse(',
'    p_content => (',
'        select blob_content from apex_application_temp_files where name = :P3_FILE',
'    ),',
'    p_file_name => ''dummy.xlsx''',
')'))
,p_display_when_condition=>'P3_FILE'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>true
,p_query_row_template=>wwv_flow_imp.id(33117744046819274)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33295636481096763)
,p_query_column_id=>1
,p_column_alias=>'COL001'
,p_column_display_sequence=>10
,p_column_heading=>'Col001'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33295296424096762)
,p_query_column_id=>2
,p_column_alias=>'COL002'
,p_column_display_sequence=>20
,p_column_heading=>'Col002'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33296426740096764)
,p_button_sequence=>20
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(33164303661819310)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64975279664356501)
,p_name=>'P3_FILE'
,p_item_sequence=>10
,p_prompt=>unistr('\7533\8ACB\30D5\30A1\30A4\30EB')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64975577793356504)
,p_name=>'P3_NAME'
,p_item_sequence=>30
,p_prompt=>unistr('\6C0F\540D')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64975678747356505)
,p_name=>'P3_DEPT'
,p_item_sequence=>40
,p_prompt=>unistr('\6240\5C5E')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64975832683356506)
,p_name=>'P3_PURPOSE'
,p_item_sequence=>50
,p_prompt=>unistr('\76EE\7684')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64975902760356507)
,p_name=>'P3_AMOUNT'
,p_item_sequence=>60
,p_prompt=>unistr('\91D1\984D')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33161860669819308)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31679713554259750)
,p_name=>unistr('\30EA\30D5\30EC\30C3\30B7\30E5\5F8C\306B\7A74\57CB\3081')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(64973297768356505)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33298463391100001)
,p_event_id=>wwv_flow_imp.id(31679713554259750)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let doc = document.getElementById("report_table_document").tBodies[0];',
'for (let i = 0; i < doc.rows.length; i++) {',
'    let label = doc.rows[i].cells[0].textContent;',
'    let value = doc.rows[i].cells[1].textContent;',
'    switch(label) {',
unistr('        case "\6C0F\540D":'),
'            apex.items.P3_NAME.setValue(value);',
'            break;',
unistr('        case "\6240\5C5E":'),
'            apex.items.P3_DEPT.setValue(value);',
'            break;',
unistr('        case "\76EE\7684":'),
'            apex.items.P3_PURPOSE.setValue(value);',
'            break;',
unistr('        case "\91D1\984D":'),
'            apex.items.P3_AMOUNT.setValue(value);',
'            break;',
'    };',
'}',
'',
unistr('// \30EC\30DD\30FC\30C8\3092\975E\8868\793A\306B\3059\308B'),
'document.getElementById("document").style.display = "none";'))
);
wwv_flow_imp.component_end;
end;
/
