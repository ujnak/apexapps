prompt --application/deployment/install/install_utl_openai_chat_api_pkh
begin
--   Manifest
--     INSTALL: INSTALL-utl_openai_chat_api.pkh
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>102
,p_default_id_offset=>15031380584218014
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(82797841116982783)
,p_install_id=>wwv_flow_imp.id(95913803395707145)
,p_name=>'utl_openai_chat_api.pkh'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package utl_openai_chat_api as',
'/**',
' * Change History:',
' * 2025/05/01 - ynakakos    max for recursive tool calls set as p_recursive_call_limit for chat.',
' * 2024/11/29 - ynakakos    change name and strict included in the json_schema to arguments.',
' * 2024/10/29 - ynakakos    add OpenAI Structured Outputs support.',
' */',
'',
'/**',
unistr(' * \30C4\30FC\30EB\30BB\30C3\30C8\540D\304B\3089JSON\5F62\5F0F\306E\30C4\30FC\30EB\5B9A\7FA9\3092\751F\6210\3059\308B\3002'),
' *',
unistr(' * @param p_tool_set   \30C4\30FC\30EB\30BB\30C3\30C8\540D'),
unistr(' * @return json_array_t  tools\3068\3057\3066\9001\4FE1\3059\308B\30D5\30A1\30F3\30AF\30B7\30E7\30F3\5B9A\7FA9'),
' */',
'function generate_tools(',
'    p_tool_set        in varchar2',
') return json_array_t;',
'',
'/**',
unistr(' * OpenAI Chat Completions API\304A\3088\3073\4E92\63DBAPI\3092\547C\3073\51FA\3059\3002'),
unistr(' * OpenAI\306E\30A8\30F3\30C9\30DD\30A4\30F3\30C8 https://api.openai.com/v1/chat/completions\3068\4E92\63DB\304C\304C\3042\308B\3053\3068\3002'),
' *',
unistr(' * @param p_content         \30E1\30C3\30BB\30FC\30B8\672C\6587'),
unistr(' * @param p_collection_name \30C1\30E3\30C3\30C8\5C65\6B74\3092\4FDD\5B58\3059\308BAPEX\30B3\30EC\30AF\30B7\30E7\30F3\306E\540D\524D'),
unistr(' * @param p_api_endpoint    Chat Completions API\3092\547C\3073\51FA\3059URL'),
unistr(' * @param p_model_name      \30E2\30C7\30EB\540D\FF08\5FC5\9808)'),
unistr(' * @param p_max_tokens      \30C8\30FC\30AF\30F3\6570\306E\4E0A\9650'),
unistr(' * @param p_stream          streaming\306E\8A31\53EF - APEX\306Fstreaming\304C\6271\3048\306A\3044\305F\3081\30C7\30D5\30A9\30EB\30C8\3067false'),
unistr(' * @param p_credential_static_id Web\8CC7\683C\8A3C\660E\306E\9759\7684ID'),
unistr(' * @param p_tool_set  \8868GENAI_TOOLS\306ETOO_SET\5217\306E\540D\524D'),
unistr(' * @param p_response_format text\3001json_object \307E\305F\306F json_schema'),
unistr(' * @param p_json_schema_name   respons_format\304Cjson_schemat\306E\3068\304D\306Ename\5C5E\6027\306E\5024'),
unistr(' * @param p_json_schema_strict \540C\4E0A\306Estrict\5C5E\6027\306E\5024'),
unistr(' * @param p_json_schema        \540C\4E0A\306Eschema\5C5E\6027\306E\5024 - \30EA\30AF\30A8\30B9\30C8\306B\542B\3081\308BJSON schema'),
unistr(' * @param p_request_out     \30C7\30D0\30C3\30B0\7528 - Chat API\306B\9001\4FE1\3057\305F\30EA\30AF\30A8\30B9\30C8\672C\6587'),
unistr(' * @param p_response_out    \30C7\30D0\30C3\30B0\7528 - Chat API\304B\3089\53D7\4FE1\3057\305F\30EC\30B9\30DD\30F3\30B9\672C\6587'),
unistr(' * @param p_transfer_timeout Chat API\306E\5FDC\7B54\306E\30BF\30A4\30E0\30A2\30A6\30C8 - \79D2'),
unistr(' * @param p_recursive_call_count \518D\8D77\7684\306B\767A\884C\3055\308C\3066\3044\308B\30C4\30FC\30EB\547C\3073\51FA\3057\306E\56DE\6570\3002'),
unistr(' * @param p_recursive_call_limit \518D\8D77\7684\306B\767A\884C\3055\308C\308B\30C4\30FC\30EB\547C\3073\51FA\3057\306E\4E0A\9650\3002'),
' */',
'procedure chat(',
'    p_content          in clob      default null',
'    ,p_collection_name in varchar2',
'    ,p_api_endpoint    in varchar2',
'    ,p_model_name      in varchar2',
'    ,p_max_tokens      in number    default null',
'    ,p_stream          in boolean   default false',
'    ,p_credential_static_id in varchar2 default null',
unistr('    /* function calling & Structured Outputs \5411\3051 */'),
'    ,p_tool_set        in varchar2 default null',
'    ,p_response_format in varchar2 default null',
unistr('    /* p_response_format\304Cjson_schema\306E\3068\304D\306B\6709\52B9 */'),
'    ,p_json_schema_name   in varchar2 default null',
'    ,p_json_schema_strict in boolean  default true',
'    ,p_json_schema        in clob     default null ',
unistr('    /* \4EE5\4E0B\3001\30C7\30D0\30C3\30B0\7528 */'),
'    ,p_request_out  out clob',
'    ,p_response_out out clob',
unistr('    /* \7121\8996\3057\3066\3082\826F\3044\30D1\30E9\30E1\30FC\30BF */'),
'    ,p_transfer_timeout in number default 360 -- 10 min',
'    ,p_recursive_call_count in number default 0',
unistr('    /* \518D\8D77\7684\306A\30C4\30FC\30EB\30FB\30B3\30FC\30EB\306E\547C\3073\51FA\3057\4E0A\9650 */'),
'    ,p_recursive_call_limit in number default 10',
');',
'',
'end utl_openai_chat_api;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
