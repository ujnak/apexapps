prompt --application/deployment/install/install_tool_definitions
begin
--   Manifest
--     INSTALL: INSTALL-tool definitions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>102
,p_default_id_offset=>15031380584218014
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(42241899179470253)
,p_install_id=>wwv_flow_imp.id(95913803395707145)
,p_name=>'tool definitions'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
unistr('    --OPENAI_TOOLS: 2/10000 \884C\304C\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\307E\3057\305F, APEX$DATA$PKG/OPENAI_TOOLS$349346'),
'    apex_data_install.load_supporting_object_data(p_table_name => ''OPENAI_TOOLS'', p_delete_after_install => false );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
