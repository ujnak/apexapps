prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>101
,p_default_id_offset=>14118654753225023
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Chat with Generative AI'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38786849045808205)
,p_plug_name=>'Last Response'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_content clob;',
'    l_think_start integer;',
'    l_think_end   integer;',
'    l_markdown    clob;',
'begin',
'    select clob001 into l_content',
'    from apex_collections',
'    where collection_name = :G_CHAT_HISTORY ',
'    order by seq_id desc fetch first 1 rows only;',
'    /* convert markdown into html if content starts with <think> */',
'    l_think_start := instr(l_content, ''<think>'');',
'    if l_think_start = 1 then',
'        /* strip <think> from last response */',
'        l_think_end := instr(l_content, ''</think>'');',
'        l_markdown := substr(l_content, l_think_end + 8);',
'        l_content := apex_markdown.to_html(l_markdown);',
'    end if;',
'    return l_content;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74987135498990924)
,p_plug_name=>'System Prompt'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74987615657990928)
,p_plug_name=>'User Message'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74987866724990931)
,p_plug_name=>'Chat History'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select seq_id, c001, c002, clob001, n001, n002, n003, dbms_lob.getlength(clob001) cnt',
'from apex_collections',
'where collection_name = :G_CHAT_HISTORY order by seq_id desc'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(74988015361990932)
,p_region_id=>wwv_flow_imp.id(74987866724990931)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'C001'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'C002'
,p_body_adv_formatting=>false
,p_body_column_name=>'CLOB001'
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'char count: &CNT.',
'{if N001/}',
', prompt_tokens: &N001. completion_tokens: &N002. total_tokens: &N003.',
'{endif/}'))
,p_media_adv_formatting=>false
,p_pk1_column_name=>'SEQ_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76938896397648612)
,p_plug_name=>'Chat with Generative AI'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74987770781990930)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(74987615657990928)
,p_button_name=>'SEND_MESSAGE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Send Message'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74987383190990926)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(74987135498990924)
,p_button_name=>'SET_PROMPT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Set Prompt'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74986929488990922)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(76938896397648612)
,p_button_name=>'INIT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Start New Conversation'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.:INIT_CONVERSATION:&DEBUG.:::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71177758435167836)
,p_name=>'P1_API_ENDPOINT'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(74987135498990924)
,p_item_default=>'&G_API_ENDPOINT.'
,p_prompt=>'API Endpoint'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71177831760167837)
,p_name=>'P1_MODEL_NAME'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(74987135498990924)
,p_item_default=>'&G_MODEL_NAME.'
,p_prompt=>'Model Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71177999463167838)
,p_name=>'P1_CREDENTIAL_STATIC_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74987135498990924)
,p_item_default=>'&G_CREDENTIAL.'
,p_prompt=>'Credential Static ID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74987287910990925)
,p_name=>'P1_PROMPT'
,p_data_type=>'CLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(74987135498990924)
,p_prompt=>'Prompt'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74987720063990929)
,p_name=>'P1_MESSAGE'
,p_data_type=>'CLOB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74987615657990928)
,p_prompt=>'Message'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74988072170990933)
,p_name=>'P1_REQUEST'
,p_data_type=>'CLOB'
,p_item_sequence=>50
,p_prompt=>'Request'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74988121644990934)
,p_name=>'P1_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>60
,p_prompt=>'Response'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76946377355719199)
,p_name=>'P1_TOOL_SET'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74987135498990924)
,p_prompt=>'Tool Set'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select tool_set d, tool_set r from openai_tools group by tool_set'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select Tool Set --'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74987513188990927)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Prompt'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_seq number;',
'begin',
'    /* ',
unistr('     * \767B\9332\6E08\307F\306Esystem\30D7\30ED\30F3\30D7\30C8\306E\4F4D\7F6E\3092\6C42\3081\308B\3002'),
unistr('     * \30B3\30EC\30AF\30B7\30E7\30F3\521D\671F\5316\76F4\5F8C\306B\7A7A\306Esystem\30D7\30ED\30F3\30D7\30C8\304C\4F5C\6210\6E08\307F\306A\306E\3067\3001\901A\5E38\306F\5148\982D\306B\3042\308B\3002'),
'     */',
'    select seq_id into l_seq from apex_collections where collection_name = :G_CHAT_HISTORY and c001 = ''system'';',
unistr('    /* \30D7\30ED\30F3\30D7\30C8\3092\66F4\65B0\3059\308B */'),
'    apex_collection.update_member(',
'        p_collection_name => :G_CHAT_HISTORY',
'        ,p_seq => l_seq',
'        ,p_c001 => ''system''',
'        ,p_clob001 => :P1_PROMPT',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74987383190990926)
,p_internal_uid=>3627092372973834
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74988251853990935)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Send Message'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'UTL_OPENAI_CHAT_API'
,p_attribute_04=>'CHAT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74987770781990930)
,p_internal_uid=>3627831037973842
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74988343641990936)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_content'
,p_direction=>'IN'
,p_data_type=>'CLOB'
,p_has_default=>true
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P1_MESSAGE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74988463717990937)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_collection_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'STATIC'
,p_value=>'&G_CHAT_HISTORY.'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74988535873990938)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_api_endpoint'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P1_API_ENDPOINT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74988663567990939)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_model_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P1_MODEL_NAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74988784209990940)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_max_tokens'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74988916535990941)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_stream'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74988943024990942)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_credential_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P1_CREDENTIAL_STATIC_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74989067451990943)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_tool_set'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P1_TOOL_SET'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76945850193719194)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_response_format'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>90
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76946008561719195)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_request_out'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P1_REQUEST'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76946045213719196)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_response_out'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>110
,p_value_type=>'ITEM'
,p_value=>'P1_RESPONSE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76946122479719197)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_transfer_timeout'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>120
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76946275857719198)
,p_page_process_id=>wwv_flow_imp.id(74988251853990935)
,p_page_id=>1
,p_name=>'p_recursive_call_count'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>130
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74987093870990923)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init Conversation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if not apex_collection.collection_exists(:G_CHAT_HISTORY) or :REQUEST = ''INIT_CONVERSATION'' then',
'        /*',
unistr('         * \30C1\30E3\30C3\30C8\5C65\6B74\3092\521D\671F\5316\3059\308B\3002 '),
unistr('         * \7A7A\306Esystem\30ED\30FC\30EB\306E\30E1\30C3\30BB\30FC\30B8\3092\6700\521D\306B\767B\9332\3059\308B\3002\30E1\30C3\30BB\30FC\30B8\304C\304B\3089\306E\307E\307E\306E\5834\5408\3001Chat Completions API\3078\306E'),
unistr('         * \30EA\30A8\30AF\30A8\30B9\30C8\306Bsystem\30ED\30FC\30EB\306E\30E1\30C3\30BB\30FC\30B8\81EA\4F53\3092\542B\3081\306A\3044\3002'),
'         */',
'        apex_collection.create_or_truncate_collection(:G_CHAT_HISTORY);',
'        apex_collection.add_member(',
'            p_collection_name => :G_CHAT_HISTORY',
'            ,p_c001 => ''system''',
'            ,p_clob001 => ''''',
'        );',
'        :P1_REQUEST  := '''';',
'        :P1_RESPONSE := '''';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>3626673054973830
);
wwv_flow_imp.component_end;
end;
/
