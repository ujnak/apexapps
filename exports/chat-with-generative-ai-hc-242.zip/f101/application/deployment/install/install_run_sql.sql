prompt --application/deployment/install/install_run_sql
begin
--   Manifest
--     INSTALL: INSTALL-run_sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>101
,p_default_id_offset=>14118654753225023
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(55076522610331159)
,p_install_id=>wwv_flow_imp.id(68192102923038615)
,p_name=>'run_sql'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace function run_sql(',
'    p_args in clob',
')',
'return clob',
'as',
'    C_STMT constant varchar2(4000) :=     q''~select json_arrayagg(object) from (',
'        select json_object(*) object from (',
'            %s',
'        )',
'    )~'';',
'    l_stmt   clob;',
'    l_result clob;',
'    l_args json_object_t;',
'    l_sql  varchar2(32767);',
'begin',
'    l_args := json_object_t(p_args);',
'    l_sql := trim(l_args.get_string(''sql''));',
'    /* remove trailing ; from the sql */',
'    l_sql := rtrim(l_sql, '';'');',
'    l_stmt := apex_string.format(C_STMT, l_sql);',
'    apex_debug.info(''sql: %s'', l_stmt);',
'    execute immediate l_stmt into l_result;',
'    if l_result is null then',
'        l_result := ''{ "result": "no data found, please consider to change the condition supplied with this select statment." }'';',
'    end if;',
'    return l_result;',
'end run_sql;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
