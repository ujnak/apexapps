prompt --application/deployment/install/install_get_schema
begin
--   Manifest
--     INSTALL: INSTALL-get_schema
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>101
,p_default_id_offset=>13918083745208547
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40957708002102712)
,p_install_id=>wwv_flow_imp.id(54073448169813592)
,p_name=>'get_schema'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace function get_schema(',
'    p_args in clob',
')',
'return clob',
'as',
'    l_owner_object json_object_t;',
'    l_owner varchar2(128);',
'    l_schema clob;',
'begin',
'    l_owner_object := json_object_t(p_args);',
'    l_owner := l_owner_object.get_string(''schema'');',
'    if l_owner is null then',
'        /* set default owner */',
'        l_owner := SYS_CONTEXT(''USERENV'', ''CURRENT_USER'');',
'    else',
'        l_owner := upper(l_owner);',
'    end if;',
'    select json_arrayagg(objects) into l_schema from (',
'        select json_object(table_name, columns) objects from (',
'            select table_name, json_arrayagg(json_object(column_name, data_type)) columns ',
'            from all_tab_columns where owner = l_owner group by table_name',
'        )',
'    );',
'    return l_schema;',
'end get_schema;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
