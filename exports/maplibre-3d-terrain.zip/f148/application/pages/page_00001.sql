prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>148
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'3D terrain'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://unpkg.com/maplibre-gl@2.4.0/dist/maplibre-gl.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var map = (window.map = new maplibregl.Map({',
'    container: ''map'',',
'    zoom: 12,',
'    center: [11.39085, 47.27574],',
'    pitch: 52,',
'    hash: true,',
'    style: {',
'        version: 8,',
'        sources: {',
'            osm: {',
'                type: ''raster'',',
'                tiles: [''https://a.tile.openstreetmap.org/{z}/{x}/{y}.png''],',
'                tileSize: 256,',
'                attribution: ''&copy; OpenStreetMap Contributors'',',
'                maxzoom: 19',
'            },',
'            terrainSource: {',
'                type: ''raster-dem'',',
'                url: ''https://demotiles.maplibre.org/terrain-tiles/tiles.json'',',
'                tileSize: 256',
'            },',
'            hillshadeSource: {',
'                type: ''raster-dem'',',
'                url: ''https://demotiles.maplibre.org/terrain-tiles/tiles.json'',',
'                tileSize: 256',
'            }',
'        },',
'        layers: [',
'            {',
'                id: ''osm'',',
'                type: ''raster'',',
'                source: ''osm''',
'            },',
'            {',
'                id: ''hills'',',
'                type: ''hillshade'',',
'                source: ''hillshadeSource'',',
'                layout: { visibility: ''visible'' },',
'                paint: { ''hillshade-shadow-color'': ''#473B24'' }',
'            }',
'        ],',
'        terrain: {',
'            source: ''terrainSource'',',
'            exaggeration: 1',
'        }',
'    },',
'    maxZoom: 18,',
'    maxPitch: 85',
'}));',
' ',
'map.addControl(',
'    new maplibregl.NavigationControl({',
'        visualizePitch: true,',
'        showZoom: true,',
'        showCompass: true',
'    })',
');',
' ',
'map.addControl(',
'    new maplibregl.TerrainControl({',
'        source: ''terrainSource'',',
'        exaggeration: 1',
'    })',
');'))
,p_css_file_urls=>'https://unpkg.com/maplibre-gl@2.4.0/dist/maplibre-gl.css'
,p_inline_css=>'#map { position: absolute; top: 0; bottom: 0; width: 100%; }'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230213033144'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43037397739984834)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:i-h640:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(45867652711350797)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<div id="map"></div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46010222611350964)
,p_plug_name=>'3D terrain'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(45907436801350817)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
