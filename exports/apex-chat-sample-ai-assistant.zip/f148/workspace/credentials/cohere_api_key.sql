prompt --workspace/credentials/cohere_api_key
begin
--   Manifest
--     CREDENTIAL: COHERE_API_KEY
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7216617235130697
,p_default_application_id=>148
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(9776877457959588)
,p_name=>'COHERE_API_KEY'
,p_static_id=>'COHERE_API_KEY'
,p_authentication_type=>'HTTP_HEADER'
,p_valid_for_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://api.cohere.ai',
''))
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
