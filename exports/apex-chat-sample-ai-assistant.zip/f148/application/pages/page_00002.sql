prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7216617235130697
,p_default_application_id=>148
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Documents'
,p_alias=>'DOCUMENTS'
,p_step_title=>'Documents'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'24'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15726362744842707)
,p_plug_name=>'Documents'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15787963333729522)
,p_plug_display_sequence=>40
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(16709807425290429)
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>true
,p_landmark_type=>'region'
,p_row_selection_type=>'MULTIPLE'
,p_current_selection_page_item=>'P2_SELECTED'
,p_select_all_page_item=>'P2_SELECT_ALL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'DESCRIPTION', '<a href="&DOWNLOAD_URL.">&DOWNLOAD_URL.</a>',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'Y',
  'STYLE', 't-ContentRow--styleCompact',
  'TITLE', '&NAME.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15726423658842708)
,p_name=>'SHA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SHA'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15726537453842709)
,p_name=>'URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'URL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15726606309842710)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15726709317842711)
,p_name=>'PATH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PATH'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15726889327842712)
,p_name=>'SIZE_'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SIZE_'
,p_data_type=>'NUMBER'
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15726959628842713)
,p_name=>'TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TYPE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15727022276842714)
,p_name=>'C_LINKS_GIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C_LINKS_GIT'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15727138124842715)
,p_name=>'C_LINKS_HTML'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C_LINKS_HTML'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15727237532842716)
,p_name=>'C_LINKS_SELF'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C_LINKS_SELF'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15727388658842717)
,p_name=>'GIT_URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GIT_URL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15727439396842718)
,p_name=>'HTML_URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HTML_URL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15727597046842719)
,p_name=>'DOWNLOAD_URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DOWNLOAD_URL'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16052829780730345)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(15865583496729699)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(15726362744842707)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'compact_numbers_threshold', '10000',
  'more_filters_suggestion_chip', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15726076729842704)
,p_button_sequence=>10
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(15926720474729855)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Load'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15726177075842705)
,p_name=>'P2_SELECT_ALL'
,p_item_sequence=>20
,p_prompt=>unistr('\3059\3079\3066\9078\629E')
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(15924291505729846)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15726213547842706)
,p_name=>'P2_SELECTED'
,p_data_type=>'CLOB'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15727652482842720)
,p_name=>'P2_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16052829780730345)
,p_prompt=>unistr('\691C\7D22')
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15727703424842721)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_docs    apex_t_varchar2;',
'    l_content blob;',
'    l_text    clob;',
'    l_chunks  vector_array_t;',
'    l_url     varchar2(4000);',
'    e_get_document_failed exception;',
'    l_chunk_count integer;',
'    l_chunk_text  apex_t_varchar2;',
'    l_call_count  integer;',
'',
'    /*',
unistr('     * Cohere\306EEmbed API\3092\547C\3073\51FA\3057\3001\5F15\6570\306E\30C1\30E3\30F3\30AF\304B\3089\30A8\30F3\30D9\30C7\30A3\30F3\30B0\3092\751F\6210\3059\308B\3002'),
unistr('     * \751F\6210\3057\305F\30A8\30F3\30D9\30C7\30A3\30F3\30B0\306F\8868EBMJ_EMBEDDINGS\3078\4FDD\5B58\3059\308B\3002'),
'     */',
'    procedure generate_embeddings(',
'        p_chunk_count in integer',
'        ,p_chunk_text in apex_t_varchar2',
'        ,p_call_count in integer default 0',
'    )',
'    as',
'        l_request_json  json_object_t;',
'        l_request       clob;',
'        l_texts         json_array_t;',
'        l_response      clob;',
'        l_response_json json_object_t;',
'        l_embeddings    json_array_t;',
'        l_embedding     json_array_t;',
'        e_embed_failed  exception;',
'        l_chunk    ebmj_embeddings.chunk%type;',
'        l_embed    ebmj_embeddings.embedding%type;',
'        l_chunk_id ebmj_embeddings.chunk_id%type;',
'    begin',
'        /* ',
unistr('         * Cohere Embed API\306B\9001\4FE1\3059\308B\30EA\30AF\30A8\30B9\30C8\3092\751F\6210\3059\308B\3002'),
'         */',
'        l_request_json := json_object_t();',
'        l_request_json.put(''model'', ''embed-multilingual-light-v3.0'');',
'        l_request_json.put(''input_type'', ''search_document'');',
'        l_texts := json_array_t();',
'        for i in 1 .. p_chunk_count',
'        loop',
'            l_texts.append(p_chunk_text(i));',
'        end loop;',
'        l_request_json.put(''texts'', l_texts);',
'        l_request := l_request_json.to_clob();',
'        /*',
unistr('         * Cohere Embed API\3092\547C\3073\51FA\3059\3002'),
'         */',
'        apex_web_service.clear_request_headers;',
'        apex_web_service.set_request_headers(''Accept'',''application/json'', p_reset => false);',
'        apex_web_service.set_request_headers(''Content-Type'',''application/json'', p_reset => false);                ',
'        l_response := apex_web_service.make_rest_request(',
'            p_url => ''https://api.cohere.ai/v1/embed''',
'            ,p_http_method => ''POST''',
'            ,p_body => l_request',
'            ,p_credential_static_id => ''COHERE_API_KEY''',
'        );',
'        if apex_web_service.g_status_code <> 200 then',
'            apex_debug.info(l_response);',
'            raise e_embed_failed;',
'        end if;',
'        /*',
unistr('         * \30EC\30B9\30DD\30F3\30B9\304B\3089\30A8\30F3\30D9\30C7\30A3\30F3\30B0\3092\53D6\308A\51FA\3057\3001\8868EBMJ_EMBEDDINGS\3078\4FDD\5B58\3059\308B\3002'),
'         */',
'        l_response_json := json_object_t.parse(l_response);',
'        l_embeddings := l_response_json.get_array(''embeddings'');',
'        for i in 1 .. p_chunk_count',
'        loop',
'            l_chunk := l_texts.get(i-1).to_string();',
'            l_embed := to_vector(l_embeddings.get(i-1).to_string());',
'            l_chunk_id := (p_call_count * 96) + i;',
'            insert into ebmj_embeddings(url, chunk, embedding, chunk_id) values(l_url, l_chunk, l_embed, l_chunk_id);',
'            -- apex_debug.info(''url %s, id %s, chunk %s, embed %s'', l_url, l_chunk_id, l_chunk, from_vector(l_embed));',
'        end loop;',
'    end generate_embeddings;',
'begin',
'    /*',
unistr('     * \30C9\30AD\30E5\30E1\30F3\30C8\304C\4F55\3082\9078\629E\3055\308C\3066\3044\306A\3051\308C\3070\51E6\7406\3092\30B9\30AD\30C3\30D7\3002'),
'     */',
'    if :P2_SELECTED is null then',
'        apex_debug.info(''Do nothing!'');',
'        return;',
'    end if;',
'    /*',
unistr('     * \305D\308C\305E\308C\306E\30C0\30A6\30F3\30ED\30FC\30C9URL\3092https:\306E\30B3\30ED\30F3\3067\533A\5207\3089\308C\306A\3044\3088\3046\306B .pdf: \3067\533A\5207\308B\3002'),
unistr('     * \4E00\756A\6700\5F8C\306E\30D5\30A1\30A4\30EB\306F.pdf\3067 : \304C\306A\3044\305F\3081\3001\62E1\5F35\5B50\306F\524A\9664\3055\308C\306A\3044\3002'),
'     */',
'    l_docs := apex_string.split(:P2_SELECTED, ''\.pdf\:'');',
'    for i in l_docs.first .. l_docs.last',
'    loop',
'        /*',
unistr('         * \30C0\30A6\30F3\30ED\30FC\30C9\3059\308BPDF\30D5\30A1\30A4\30EB\3054\3068\306E\51E6\7406'),
'         */',
'        l_url := l_docs(i);',
'        if substr(l_url, -4) <> ''.pdf'' then',
unistr('            /* \524A\9664\3055\308C\305F\62E1\5F35\5B50.pdf\3092\623B\3059 */'),
'            l_url := l_url || ''.pdf'';',
'        end if;',
'        /*',
unistr('         * GitHub\304B\3089PDF\30D5\30A1\30A4\30EB\3092\30C0\30A6\30F3\30ED\30FC\30C9\3059\308B\3002'),
unistr('         * \30C0\30A6\30F3\30ED\30FC\30C9\3057\305F\30D5\30A1\30A4\30EB\306Fl_content\306BBLOB\3068\3057\3066\4FDD\5B58\3055\308C\308B\3002'),
'         */',
'        l_url := utl_url.escape(l_url, false, ''AL32UTF8'');',
'        apex_debug.info(''Download PDF file from GitHub, %s'', l_url);',
'        apex_web_service.clear_request_headers();',
'        l_content := apex_web_service.make_rest_request_b(',
'            p_url => l_url',
'            ,p_http_method => ''GET''',
'        );',
'        if apex_web_service.g_status_code <> 200 then',
'            raise e_get_document_failed;',
'        end if;',
'        /*',
unistr('         * PDF\30D5\30A1\30A4\30EB\304B\3089\30C6\30AD\30B9\30C8\3092\53D6\308A\51FA\3059\3002'),
'         */',
'        l_text := dbms_vector_chain.utl_to_text(',
'            data => l_content',
'            ,params => JSON(',
'                json_object(',
'                    key ''plaintext'' value true',
'                )',
'            )',
'        );',
'        apex_debug.info(''Text retrieved length = %s'', dbms_lob.getlength(l_text));',
'        /*',
unistr('         * \53D6\308A\51FA\3057\305F\30C6\30AD\30B9\30C8\3092\30C1\30E3\30F3\30AF\306B\5206\5272\3059\308B\3002\30C1\30E3\30F3\30AF\3054\3068\306B\30A8\30F3\30D9\30C7\30A3\30F3\30B0\3092\751F\6210\3059\308B\304C\3001'),
unistr('         * Cohere\306EAPI\547C\3073\51FA\3057\306E\56DE\6570\3092\6E1B\3089\3059\305F\3081\3001\6700\592796\306E\30C1\30E3\30F3\30AF\3092\307E\3068\3081\3066\3001API\3092\547C\3073\51FA\3059\3002'),
'         */',
'        l_chunk_count := 0;',
'        l_chunk_text  := apex_t_varchar2();',
'        l_call_count  := 0;',
'        for r in (',
'            /*',
unistr('             * \30C1\30E3\30F3\30AF\306F500\30EF\30FC\30C9\3054\3068\306B\3057\3066\3044\308B\3002Cohere\306EEmbed API\306E\30D1\30E9\30E1\30FC\30BF texts \306E'),
unistr('             * \8AAC\660E:'),
'             * An array of strings for the model to embed. Maximum number of texts per call is 96. ',
'             * We recommend reducing the length of each text to be under 512 tokens for optimal quality.',
'             */',
'            select rownum, t.chunk_offset, t.chunk_length, t.chunk_text',
'            from vector_chunks(',
'                l_text',
'                by words',
'                max 500',
'                overlap 0',
'                split by recursively',
'                language japanese',
'                normalize all',
'            ) t',
'        )',
'        loop',
'            apex_debug.info(''ID %s, Chunk Offset %s, Length %s'', r.rownum, r.chunk_offset, r.chunk_length);',
'            l_chunk_count := l_chunk_count + 1;',
'            apex_string.push(l_chunk_text, r.chunk_text);',
'            /* ',
unistr('             * \30C1\30E3\30F3\30AF\306E\500B\6570\304C96\3067Cohere\306EEmbed API\3092\547C\3073\51FA\3059\3002'),
'             */',
'            if l_chunk_count = 96 then',
'                generate_embeddings(',
'                    p_chunk_count => l_chunk_count',
'                    ,p_chunk_text => l_chunk_text',
'                    ,p_call_count => l_call_count',
'                );',
unistr('                dbms_session.sleep(1); /* Cohere\306EFree\67A0\306B\53CE\3081\308B\305F\3081\30011\79D2\5F85\3064 */'),
'                l_chunk_count := 0;',
'                l_chunk_text  := apex_t_varchar2();',
'                l_call_count  := l_call_count + 1;',
'            end if;',
'        end loop;',
'        /*',
unistr('         * \6B8B\308A\306E\30C1\30E3\30F3\30AF\3092\5BFE\8C61\306B\3001Cohere\306EEmbed API\3092\547C\3073\51FA\3059\3002'),
'         */',
'        if l_chunk_count > 0 then',
'            generate_embeddings(',
'                p_chunk_count => l_chunk_count',
'                ,p_chunk_text => l_chunk_text',
'                ,p_call_count => l_call_count',
'            );',
'            dbms_session.sleep(1);',
'        end if;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15726076729842704)
,p_internal_uid=>15727703424842721
);
wwv_flow_imp.component_end;
end;
/
