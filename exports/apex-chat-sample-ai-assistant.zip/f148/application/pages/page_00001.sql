prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7216617235130697
,p_default_application_id=>148
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'APEX Chat'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15728016861842724)
,p_plug_name=>unistr('AI\30C1\30E3\30C3\30C8')
,p_region_name=>'chat'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15786563764729518)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16051501556730340)
,p_plug_name=>'APEX Chat'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(15819845479729596)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15727942843842723)
,p_button_sequence=>20
,p_button_name=>'ASK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(15926720474729855)
,p_button_image_alt=>unistr('\554F\3044\5408\308F\305B\308B')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15727862647842722)
,p_name=>'P1_QUESTION'
,p_item_sequence=>10
,p_prompt=>unistr('\8CEA\554F')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(15924291505729846)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15728237714842726)
,p_name=>'P1_RESP'
,p_item_sequence=>40
,p_prompt=>unistr('\56DE\7B54')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(15924291505729846)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15728370936842727)
,p_name=>'P1_PROMPT'
,p_data_type=>'CLOB'
,p_item_sequence=>50
,p_prompt=>unistr('\77E5\8B58')
,p_display_as=>'NATIVE_MARKDOWN_EDITOR'
,p_field_template=>wwv_flow_imp.id(15924291505729846)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'SIMPLE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15728457246842728)
,p_name=>'onClick Start AI Assistant'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15727942843842723)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15728733527842731)
,p_event_id=>wwv_flow_imp.id(15728457246842728)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request_json  json_object_t;',
'    l_request       clob;',
'    l_texts         json_array_t;',
'    l_response      clob;',
'    l_response_json json_object_t;',
'    l_embeddings    json_array_t;',
'    l_embedding     json_array_t;',
'    e_embed_failed  exception;',
'    l_embed vector;',
'    l_prompt clob;',
'    l_norm   varchar2(4000);',
'begin',
'    /* ',
unistr('     * Cohere Embed API\306B\9001\4FE1\3059\308B\30EA\30AF\30A8\30B9\30C8\3092\751F\6210\3059\308B\3002'),
'     */',
'    l_request_json := json_object_t();',
'    l_request_json.put(''model'', ''embed-multilingual-light-v3.0'');',
'    l_request_json.put(''input_type'', ''search_query'');',
'    l_texts := json_array_t();',
'    l_texts.append(:P1_QUESTION);',
'    l_request_json.put(''texts'', l_texts);',
'    l_request := l_request_json.to_clob();',
'    /*',
unistr('     * Cohere Embed API\3092\547C\3073\51FA\3059\3002'),
'     */',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'', p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'', p_reset => false);                ',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => ''https://api.cohere.ai/v1/embed''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''COHERE_API_KEY''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        apex_debug.info(l_response);',
'        raise e_embed_failed;',
'    end if;',
'    /*',
unistr('     * \30EC\30B9\30DD\30F3\30B9\304B\3089\8CEA\554F\6587\306E\30D9\30AF\30C8\30EB\3092\53D6\308A\51FA\3059\3002'),
'     */',
'    l_response_json := json_object_t.parse(l_response);',
'    l_embeddings := l_response_json.get_array(''embeddings'');',
'    l_embed := to_vector(l_embeddings.get(0).to_string());',
'    /*',
unistr('     * \56DE\7B54\306B\4F7F\3046\6587\5B57\5217\3092P1_PROMPT\3078\4FDD\5B58\3059\308B\3002'),
'     */',
'    l_prompt := '''';',
'    for r in (',
'        select chunk',
'        from ebmj_embeddings',
'        order by vector_distance(l_embed, embedding) asc',
'        fetch first 2 partitions by url, 2 rows only',
'    )',
'    loop',
'        l_prompt := l_prompt || ''######'';',
'        l_prompt := l_prompt || apex_application.CRLF;',
'        l_norm := r.chunk;',
unistr('        -- CR\3068LF\3092\53D6\308A\9664\304F\3002'),
'        l_norm := replace(l_norm, chr(10));',
'        l_norm := replace(l_norm, chr(13));',
'        l_norm := replace(l_norm, ''\n'');',
'        l_prompt := l_prompt || l_norm;',
'        l_prompt := l_prompt || apex_application.CRLF;',
'    end loop;',
'    :P1_PROMPT := l_prompt;',
'end;'))
,p_attribute_02=>'P1_QUESTION'
,p_attribute_03=>'P1_PROMPT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15728894510842732)
,p_event_id=>wwv_flow_imp.id(15728457246842728)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_AI_ASSISTANT'
,p_attribute_01=>'INLINE'
,p_attribute_03=>'#chat'
,p_attribute_04=>'ITEM'
,p_attribute_05=>'P1_PROMPT'
,p_attribute_06=>unistr('### \524D\63D0\77E5\8B58\3092\8FFD\52A0\3057\307E\3057\305F\3002 ###')
,p_attribute_07=>'&P1_QUESTION.'
,p_attribute_09=>'ITEM'
,p_attribute_10=>'P1_RESP'
,p_attribute_13=>'this.fullContent.toLowerCase().includes( "json" ) ? this.fullContent : ""'
,p_ai_remote_server_id=>wwv_flow_imp.id(15725390203830155)
,p_ai_system_prompt=>unistr('\3042\306A\305F\306FOracle APEX\306E\5C02\9580\5BB6\3067\3059\3002')
,p_ai_welcome_message=>unistr('Oracle APEX\306E\8CEA\554F\306B\7B54\3048\307E\3059\3002')
);
wwv_flow_imp.component_end;
end;
/
