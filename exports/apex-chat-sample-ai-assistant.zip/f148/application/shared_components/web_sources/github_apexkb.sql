prompt --application/shared_components/web_sources/github_apexkb
begin
--   Manifest
--     WEB SOURCE: GitHub APEXKB
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7216617235130697
,p_default_application_id=>148
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(16709807425290429)
,p_name=>'GitHub APEXKB'
,p_static_id=>'github_apexkb'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(16706070237290407)
,p_remote_server_id=>wwv_flow_imp.id(16705863369290403)
,p_url_path_prefix=>'ujnak/APEXKB/contents/'
,p_version_scn=>41118043462058
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(16710039117290431)
,p_web_src_module_id=>wwv_flow_imp.id(16709807425290429)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
