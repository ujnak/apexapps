prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5991163557068424
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Browser JS'
,p_alias=>'BROWSER-JS'
,p_step_title=>'Browser JS'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode#MIN#.js'
,p_javascript_code=>'var qrcode = null;'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230629171526'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7294097495032796)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7111235465030265)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(6995565934030206)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(7173666022030291)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7294944739037001)
,p_plug_name=>'QR Code'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7032234163030242)
,p_plug_display_sequence=>40
,p_plug_source=>'<div id="qrcode"></div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7295190948037003)
,p_button_sequence=>30
,p_button_name=>'GENERATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7172018477030291)
,p_button_image_alt=>'Generate'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7295030919037002)
,p_name=>'P2_SOURCE'
,p_item_sequence=>20
,p_prompt=>'Source'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(7169515144030288)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7295285817037004)
,p_name=>'onClick Generate'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(7295190948037003)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7295342161037005)
,p_event_id=>wwv_flow_imp.id(7295285817037004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (qrcode !== null) {',
unistr('    // \3059\3067\306B\8868\793A\3055\308C\3066\3044\308BQR\30B3\30FC\30C9\3092\6D88\53BB\3057\3066\3001\65B0\305F\306A\5024\3067\66F4\65B0\3059\308B\3002'),
'    qrcode.clear();',
'    qrcode.makeCode(apex.items.P2_SOURCE.value);',
'}',
'else',
'{',
unistr('    // id\304Cqrcode\306E\8981\7D20\3092\521D\671F\5316\3057\3066\3001QR\30B3\30FC\30C9\3092\8868\793A\3059\308B\3002'),
'    qrcode = new QRCode(document.getElementById("qrcode"), {',
'	    text: apex.items.P2_SOURCE.value,',
'	    width: 128,',
'	    height: 128,',
'	    colorDark : "#000000",',
'	    colorLight : "#ffffff",',
'	    correctLevel : QRCode.CorrectLevel.H',
'    });',
'};'))
);
wwv_flow_imp.component_end;
end;
/
