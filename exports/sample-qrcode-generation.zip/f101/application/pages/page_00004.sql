prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5991163557068424
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Server JS'
,p_alias=>'SERVER-JS'
,p_step_title=>'Server JS'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230629183913'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7631525858087019)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7111235465030265)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(6995565934030206)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(7173666022030291)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7296074036037012)
,p_button_sequence=>20
,p_button_name=>'GENERATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7172018477030291)
,p_button_image_alt=>'Generate'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7295990116037011)
,p_name=>'P4_SOURCE'
,p_item_sequence=>10
,p_prompt=>'Source'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(7169515144030288)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7296162843037013)
,p_name=>'P4_QR'
,p_item_sequence=>30
,p_prompt=>'QR'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(7169262177030287)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7296472099037016)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generate QR Code'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { default: qrcode } = await import ("qrcode");',
'const code = qrcode(0, ''L'');',
'code.addData(apex.env.P4_SOURCE);',
'code.make();',
'apex.env.P4_QR = code.createDataURL(4);'))
,p_process_clob_language=>'JAVASCRIPT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(7296074036037012)
,p_internal_uid=>7296472099037016
);
wwv_flow_imp.component_end;
end;
/
