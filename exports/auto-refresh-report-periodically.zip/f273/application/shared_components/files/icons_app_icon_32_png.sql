prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 273
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>273
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000B2494441545847637C191DF29F610001E3A8034643603404464360D087C097DF7F18FECAC933FC60606010D6D2C12833DF5EBB';
wwv_flow_imp.g_varchar2_table(2) := 'C2C081A32465FBFC8981F3CB67BCE52CC192F011332B03BF9818590EF8F8EA1583DCDFDF9439E0A3A43483B8BA3AC317665606515F3F0CC35E6FDEC4C083C39297376F32F03F7F3AC41D301A05A32130E0B960340A5E7EFFC1C0A1A44C5649F8E3DE5D06';
wwv_flow_imp.g_varchar2_table(3) := '714E5C0535A47C225814D3BAC13CEA80D110180D81D11018F0100000BDDAD901EE7C2CCB0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(94436282285147306)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
