prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>266
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'with Database'
,p_alias=>'WITH-DATABASE'
,p_step_title=>'with Database'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// Canvas\3068\30B3\30F3\30C6\30AD\30B9\30C8\306E\53D6\5F97'),
'const canvas = document.getElementById(''gameCanvas'');',
'const ctx = canvas.getContext(''2d'');',
'',
unistr('// \30DE\30A6\30B9\304CCanvas\4E0A\306B\3042\308B\3068\304D\306E\307F\30AD\30FC\30DC\30FC\30C9\64CD\4F5C\3092\6709\52B9\306B\3059\308B\305F\3081\3001'),
unistr('// mouseenter\6642\306BCanvas\3078\30D5\30A9\30FC\30AB\30B9\3001mouseleave\6642\306B\30D5\30A9\30FC\30AB\30B9\3092\5916\3059'),
'canvas.addEventListener(''mouseenter'', (e) => {',
'    canvas.focus();',
'});',
'canvas.addEventListener(''mouseleave'', (e) => {',
'    canvas.blur();',
'});',
'',
unistr('// \30B2\30FC\30E0\306E\4E00\6642\505C\6B62\30D5\30E9\30B0'),
'let isPaused = false;',
'',
'// ------------------------------------------------------------',
unistr('// APEX\30A2\30AF\30B7\30E7\30F3\306B\3088\308B\5B9F\88C5\306B\7F6E\304D\63DB\3048\308B\3002'),
'// ------------------------------------------------------------',
'/*',
unistr('// \30DC\30BF\30F3\3068\30C6\30AD\30B9\30C8\30A8\30EA\30A2\306E\53D6\5F97'),
'const pauseButton = document.getElementById(''pauseButton'');',
'const resumeButton = document.getElementById(''resumeButton'');',
'const exportButton = document.getElementById(''exportButton'');',
'const importButton = document.getElementById(''importButton'');',
'const stateOutput = document.getElementById(''stateOutput'');',
'',
unistr('// \5404\30DC\30BF\30F3\306E\30AF\30EA\30C3\30AF\30A4\30D9\30F3\30C8\FF08preventDefault()\3067\5F8C\7D9A\306E\30A4\30D9\30F3\30C8\51E6\7406\3092\30AD\30E3\30F3\30BB\30EB\FF09'),
'pauseButton.addEventListener(''click'', (e) => {',
'    e.preventDefault();',
'    isPaused = true;',
'});',
'',
'resumeButton.addEventListener(''click'', (e) => {',
'    e.preventDefault();',
'    isPaused = false;',
'});',
'',
'exportButton.addEventListener(''click'', (e) => {',
'    e.preventDefault();',
'    const json = exportGameState();',
'    stateOutput.value = json;',
'    console.log("Exported state:", json);',
'});',
'',
'importButton.addEventListener(''click'', (e) => {',
'    e.preventDefault();',
'    const json = stateOutput.value;',
'    importGameState(json);',
'    console.log("Imported state:", json);',
'});',
'*/',
'',
'// ------------------------------------------------------------',
unistr('// \3053\308C\4EE5\964D\306F\3001APEX \306E JavaScript API \3092\5229\7528\3057\3066\3001APEX \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\3068\9023\643A\3059\308B\305F\3081\306E\30B3\30FC\30C9'),
'// ------------------------------------------------------------',
'',
unistr('// \30DC\30BF\30F3\306E\51E6\7406\306FAPEX\30A2\30AF\30B7\30E7\30F3\3068\3057\3066\5B9A\7FA9\3059\308B\3002'),
'const appCtx = apex.actions.createContext("controls", document.getElementById("CONTROLS"));',
'',
unistr('// \30DC\30BF\30F3\306E\30A2\30AF\30B7\30E7\30F3\3092\5B9A\7FA9'),
'appCtx.add([',
'    {',
'        name: "PAUSE",',
'        action: (event, element, args) => {',
'            isPaused = true;',
'        }',
'    },',
'    {',
'        name: "RESUME",',
'        action: (event, element, args) => {',
'            isPaused = false;',
'        }',
'    },',
'    {',
'        name: "EXPORT",',
'        action: (event, element, args) => {',
'            apex.debug.info("export");',
'            const stateJSON = exportGameState();',
'            let spinner$ = apex.util.showSpinner($("#CONTROLS"));',
'            apex.server.process("EXPORT", {',
'                x01: stateJSON,',
'                pageItems: "#P5_STATE_NAME,#P5_STATE_NAME_NEW"',
'            }, {',
'                success: (data) => {',
'                    apex.item("P5_STATE_NAME").refresh();',
unistr('                    apex.message.showPageSuccess("\6210\529F");'),
'                    spinner$.remove();',
'                }',
'            });',
'        }',
'    },',
'    {',
'        name: "IMPORT",',
'        action: (event, element, args) => {',
'            apex.debug.info("import");',
'            let spinner$ = apex.util.showSpinner($("#CONTROLS"));',
'            apex.server.process("IMPORT", {',
'                pageItems: "#P5_STATE_NAME"',
'            }, {',
'                success: (data) => {',
'                    const stateJSON = data.state;',
'                    apex.debug.info(stateJSON);',
'                    try {',
'                        importGameState(JSON.stringify(stateJSON));',
unistr('                        apex.message.showPageSuccess("\6210\529F");'),
'                    } catch (error) {',
unistr('                        alert("\72B6\614B\306E\8AAD\307F\8FBC\307F\306B\5931\6557\3057\307E\3057\305F: " + error);'),
'                    }',
'                    spinner$.remove();',
'                }',
'            });',
'        }',
'    }',
']);',
'',
'// ------------------------------------------------------------',
unistr('// APEX\3068\306E\30A4\30F3\30C6\30B0\30EC\30FC\30B7\30E7\30F3\306E\30B3\30FC\30C9\306F\3053\3053\307E\3067\3002'),
'// ------------------------------------------------------------',
'',
unistr('// \30D7\30EC\30A4\30E4\30FC\306E\30D7\30ED\30D1\30C6\30A3'),
'const player = {',
'    x: canvas.width / 2 - 20,',
'    y: canvas.height - 50,',
'    width: 40,',
'    height: 20,',
'    speed: 5,',
'    movingLeft: false,',
'    movingRight: false',
'};',
'',
unistr('// \30D7\30EC\30A4\30E4\30FC\306E\5F3E\FF08\30B7\30E7\30C3\30C8\FF09\306E\914D\5217'),
'const bullets = [];',
'',
unistr('// \30A4\30F3\30D9\30FC\30C0\30FC\306E\8A2D\5B9A'),
'const invaders = [];',
'const invaderRowCount = 3;',
'const invaderColumnCount = 8;',
'const invaderWidth = 30;',
'const invaderHeight = 20;',
'const invaderPadding = 10;',
'const invaderOffsetTop = 30;',
'const invaderOffsetLeft = 30;',
'',
unistr('// \30A4\30F3\30D9\30FC\30C0\30FC\30AA\30D6\30B8\30A7\30AF\30C8\3092\4F5C\6210'),
'for (let row = 0; row < invaderRowCount; row++) {',
'    for (let col = 0; col < invaderColumnCount; col++) {',
'        const x = invaderOffsetLeft + col * (invaderWidth + invaderPadding);',
'        const y = invaderOffsetTop + row * (invaderHeight + invaderPadding);',
'        invaders.push({ x, y, width: invaderWidth, height: invaderHeight, alive: true });',
'    }',
'}',
'',
unistr('// \30A4\30F3\30D9\30FC\30C0\30FC\306E\79FB\52D5\65B9\5411\3068\30B9\30D4\30FC\30C9'),
unistr('let invaderDirection = 1; // 1:\53F3\65B9\5411\3001-1:\5DE6\65B9\5411'),
'const invaderSpeed = 0.5;',
'const invaderDrop = 10;',
'',
unistr('// \30AD\30FC\30DC\30FC\30C9\30A4\30D9\30F3\30C8\306FCanvas\306B\30D5\30A9\30FC\30AB\30B9\304C\3042\308B\5834\5408\306E\307F\6709\52B9'),
'canvas.addEventListener(''keydown'', (e) => {',
unistr('    // \30AD\30FC\30DC\30FC\30C9\64CD\4F5C\306FCanvas\304C\30D5\30A9\30FC\30AB\30B9\3055\308C\3066\3044\308B\3068\304D\306E\307F\52D5\4F5C\3059\308B'),
'    if (document.activeElement !== canvas) return;',
'',
'    if (e.code === ''ArrowLeft'') {',
'        player.movingLeft = true;',
'    } else if (e.code === ''ArrowRight'') {',
'        player.movingRight = true;',
'    } else if (e.code === ''Space'') {',
unistr('        // \30B9\30DA\30FC\30B9\30AD\30FC\3067\5F3E\3092\767A\5C04\FF08\30D7\30EC\30A4\30E4\30FC\306E\4E2D\592E\304B\3089\FF09'),
'        bullets.push({',
'            x: player.x + player.width / 2 - 2.5,',
'            y: player.y,',
'            width: 5,',
'            height: 10,',
'            speed: 7',
'        });',
'    }',
'});',
'',
'canvas.addEventListener(''keyup'', (e) => {',
unistr('    // \30AD\30FC\30DC\30FC\30C9\64CD\4F5C\306FCanvas\304C\30D5\30A9\30FC\30AB\30B9\3055\308C\3066\3044\308B\3068\304D\306E\307F\52D5\4F5C\3059\308B'),
'    if (document.activeElement !== canvas) return;',
'',
'    if (e.code === ''ArrowLeft'') {',
'        player.movingLeft = false;',
'    } else if (e.code === ''ArrowRight'') {',
'        player.movingRight = false;',
'    }',
'});',
'',
unistr('// \30B2\30FC\30E0\306E\72B6\614B\3092\66F4\65B0\3059\308B\95A2\6570'),
'function update() {',
'    if (!isPaused) {',
unistr('        // \30D7\30EC\30A4\30E4\30FC\306E\79FB\52D5'),
'        if (player.movingLeft && player.x > 0) {',
'            player.x -= player.speed;',
'        }',
'        if (player.movingRight && player.x + player.width < canvas.width) {',
'            player.x += player.speed;',
'        }',
'',
unistr('        // \5F3E\306E\79FB\52D5\3068\753B\9762\5916\306E\5F3E\306E\524A\9664'),
'        for (let i = 0; i < bullets.length; i++) {',
'            bullets[i].y -= bullets[i].speed;',
'            if (bullets[i].y + bullets[i].height < 0) {',
'                bullets.splice(i, 1);',
'                i--;',
'            }',
'        }',
'',
unistr('        // \30A4\30F3\30D9\30FC\30C0\30FC\306E\79FB\52D5'),
'        let hitEdge = false;',
'        for (const invader of invaders) {',
'            if (!invader.alive) continue;',
'            invader.x += invaderSpeed * invaderDirection;',
'            if (invader.x + invader.width > canvas.width || invader.x < 0) {',
'                hitEdge = true;',
'            }',
'        }',
'        if (hitEdge) {',
'            invaderDirection *= -1;',
'            for (const invader of invaders) {',
'                invader.y += invaderDrop;',
'            }',
'        }',
'',
unistr('        // \5F3E\3068\30A4\30F3\30D9\30FC\30C0\30FC\306E\885D\7A81\5224\5B9A'),
'        for (let i = 0; i < bullets.length; i++) {',
'            for (const invader of invaders) {',
'                if (!invader.alive) continue;',
'                if (',
'                    bullets[i].x < invader.x + invader.width &&',
'                    bullets[i].x + bullets[i].width > invader.x &&',
'                    bullets[i].y < invader.y + invader.height &&',
'                    bullets[i].y + bullets[i].height > invader.y',
'                ) {',
'                    invader.alive = false;',
'                    bullets.splice(i, 1);',
'                    i--;',
'                    break;',
'                }',
'            }',
'        }',
'',
unistr('        // \30B2\30FC\30E0\30AA\30FC\30D0\30FC\30C1\30A7\30C3\30AF\FF1A\3044\305A\308C\304B\306E\30A4\30F3\30D9\30FC\30C0\30FC\304C\30D7\30EC\30A4\30E4\30FC\306E\4F4D\7F6E\307E\3067\6765\305F\3089\7D42\4E86'),
'        for (const invader of invaders) {',
'            if (invader.alive && invader.y + invader.height >= player.y) {',
'                alert("Game Over!");',
'                document.location.reload();',
'                return;',
'            }',
'        }',
'    }',
'}',
'',
unistr('// \753B\9762\3092\63CF\753B\3059\308B\95A2\6570'),
'function draw() {',
'    ctx.clearRect(0, 0, canvas.width, canvas.height);',
'',
unistr('    // \30D7\30EC\30A4\30E4\30FC\63CF\753B\FF08\7DD1\8272\FF09'),
'    ctx.fillStyle = ''#00ff00'';',
'    ctx.fillRect(player.x, player.y, player.width, player.height);',
'',
unistr('    // \5F3E\63CF\753B\FF08\9EC4\8272\FF09'),
'    ctx.fillStyle = ''#ffff00'';',
'    for (const bullet of bullets) {',
'        ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);',
'    }',
'',
unistr('    // \30A4\30F3\30D9\30FC\30C0\30FC\63CF\753B\FF08\8D64\8272\FF09'),
'    ctx.fillStyle = ''#ff0000'';',
'    for (const invader of invaders) {',
'        if (invader.alive) {',
'            ctx.fillRect(invader.x, invader.y, invader.width, invader.height);',
'        }',
'    }',
'',
unistr('    // \4E00\6642\505C\6B62\4E2D\306F\300CPaused\300D\3068\8868\793A'),
'    if (isPaused) {',
'        ctx.font = "30px Arial";',
'        ctx.fillStyle = "white";',
'        ctx.fillText("Paused", canvas.width / 2 - 50, canvas.height / 2);',
'    }',
'}',
'',
unistr('// \30E1\30A4\30F3\30EB\30FC\30D7'),
'function gameLoop() {',
'    update();',
'    draw();',
'    requestAnimationFrame(gameLoop);',
'}',
'gameLoop();',
'',
'// *********************************************',
unistr('// \30B2\30FC\30E0\72B6\614B\3092JSON\30C9\30AD\30E5\30E1\30F3\30C8\3068\3057\3066\51FA\529B\3059\308B\95A2\6570'),
'function exportGameState() {',
'    const state = {',
'        player: {',
'            x: player.x,',
'            y: player.y,',
'            width: player.width,',
'            height: player.height,',
'            speed: player.speed',
'        },',
'        bullets: bullets.map(bullet => ({',
'            x: bullet.x,',
'            y: bullet.y,',
'            width: bullet.width,',
'            height: bullet.height,',
'            speed: bullet.speed',
'        })),',
'        invaders: invaders.map(inv => ({',
'            x: inv.x,',
'            y: inv.y,',
'            width: inv.width,',
'            height: inv.height,',
'            alive: inv.alive',
'        })),',
'        invaderDirection: invaderDirection',
'    };',
'    return JSON.stringify(state);',
'}',
'',
unistr('// JSON\30C9\30AD\30E5\30E1\30F3\30C8\3092\53D7\3051\53D6\3063\3066\72B6\614B\3092\5FA9\5143\3057\30B2\30FC\30E0\3092\518D\958B\3059\308B\95A2\6570'),
'function importGameState(jsonDocument) {',
'    try {',
'        const state = JSON.parse(jsonDocument);',
'',
unistr('        // \30D7\30EC\30A4\30E4\30FC\306E\72B6\614B\3092\5FA9\5143'),
'        player.x = state.player.x;',
'        player.y = state.player.y;',
'        player.width = state.player.width;',
'        player.height = state.player.height;',
'        player.speed = state.player.speed;',
'',
unistr('        // \5F3E\306E\72B6\614B\3092\5FA9\5143\FF08\65E2\5B58\306E\914D\5217\3092\30AF\30EA\30A2\3057\3066\304B\3089\8FFD\52A0\FF09'),
'        bullets.length = 0;',
'        state.bullets.forEach(b => bullets.push(b));',
'',
unistr('        // \30A4\30F3\30D9\30FC\30C0\30FC\306E\72B6\614B\3092\5FA9\5143'),
'        invaders.length = 0;',
'        state.invaders.forEach(inv => invaders.push(inv));',
'',
unistr('        // \30A4\30F3\30D9\30FC\30C0\30FC\79FB\52D5\65B9\5411\306E\5FA9\5143'),
'        invaderDirection = state.invaderDirection;',
'',
unistr('        // \72B6\614B\8AAD\8FBC\5F8C\306F\518D\958B\72B6\614B\306B\3059\308B'),
'        isPaused = false;',
'    } catch (e) {',
unistr('        console.error("\72B6\614B\306E\8AAD\8FBC\306B\5931\6557\3057\307E\3057\305F:", e);'),
'    }',
'}',
'',
'',
unistr('// \30B2\30FC\30E0\306E\72B6\614B\3092\66F4\65B0\3059\308B\95A2\6570'),
'function update() {',
'    if (!isPaused) {',
unistr('        // \30D7\30EC\30A4\30E4\30FC\306E\79FB\52D5'),
'        if (player.movingLeft && player.x > 0) {',
'            player.x -= player.speed;',
'        }',
'        if (player.movingRight && player.x + player.width < canvas.width) {',
'            player.x += player.speed;',
'        }',
'',
unistr('        // \5F3E\306E\79FB\52D5\3068\753B\9762\5916\306E\5F3E\306E\524A\9664'),
'        for (let i = 0; i < bullets.length; i++) {',
'            bullets[i].y -= bullets[i].speed;',
'            if (bullets[i].y + bullets[i].height < 0) {',
'                bullets.splice(i, 1);',
'                i--;',
'            }',
'        }',
'',
unistr('        // \30A4\30F3\30D9\30FC\30C0\30FC\306E\79FB\52D5'),
'        let hitEdge = false;',
'        for (const invader of invaders) {',
'            if (!invader.alive) continue;',
'            invader.x += invaderSpeed * invaderDirection;',
'            if (invader.x + invader.width > canvas.width || invader.x < 0) {',
'                hitEdge = true;',
'            }',
'        }',
'        if (hitEdge) {',
'            invaderDirection *= -1;',
'            for (const invader of invaders) {',
'                invader.y += invaderDrop;',
'            }',
'        }',
'',
unistr('        // \5F3E\3068\30A4\30F3\30D9\30FC\30C0\30FC\306E\885D\7A81\5224\5B9A'),
'        for (let i = 0; i < bullets.length; i++) {',
'            for (const invader of invaders) {',
'                if (!invader.alive) continue;',
'                if (',
'                    bullets[i].x < invader.x + invader.width &&',
'                    bullets[i].x + bullets[i].width > invader.x &&',
'                    bullets[i].y < invader.y + invader.height &&',
'                    bullets[i].y + bullets[i].height > invader.y',
'                ) {',
'                    invader.alive = false;',
'                    bullets.splice(i, 1);',
'                    i--;',
'                    break;',
'                }',
'            }',
'        }',
'',
unistr('        // \30B2\30FC\30E0\30AA\30FC\30D0\30FC\30C1\30A7\30C3\30AF\FF1A\3044\305A\308C\304B\306E\30A4\30F3\30D9\30FC\30C0\30FC\304C\30D7\30EC\30A4\30E4\30FC\306E\4F4D\7F6E\307E\3067\6765\305F\3089\7D42\4E86'),
'        for (const invader of invaders) {',
'            if (invader.alive && invader.y + invader.height >= player.y) {',
'                alert("Game Over!");',
'                document.location.reload();',
'                return;',
'            }',
'        }',
'    }',
'}',
'',
unistr('// \753B\9762\3092\63CF\753B\3059\308B\95A2\6570'),
'function draw() {',
'    ctx.clearRect(0, 0, canvas.width, canvas.height);',
'',
unistr('    // \30D7\30EC\30A4\30E4\30FC\63CF\753B\FF08\7DD1\8272\FF09'),
'    ctx.fillStyle = ''#00ff00'';',
'    ctx.fillRect(player.x, player.y, player.width, player.height);',
'',
unistr('    // \5F3E\63CF\753B\FF08\9EC4\8272\FF09'),
'    ctx.fillStyle = ''#ffff00'';',
'    for (const bullet of bullets) {',
'        ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);',
'    }',
'',
unistr('    // \30A4\30F3\30D9\30FC\30C0\30FC\63CF\753B\FF08\8D64\8272\FF09'),
'    ctx.fillStyle = ''#ff0000'';',
'    for (const invader of invaders) {',
'        if (invader.alive) {',
'            ctx.fillRect(invader.x, invader.y, invader.width, invader.height);',
'        }',
'    }',
'',
unistr('    // \4E00\6642\505C\6B62\4E2D\306F\300CPaused\300D\3068\8868\793A'),
'    if (isPaused) {',
'        ctx.font = "30px Arial";',
'        ctx.fillStyle = "white";',
'        ctx.fillText("Paused", canvas.width / 2 - 50, canvas.height / 2);',
'    }',
'}',
'',
unistr('// \30E1\30A4\30F3\30EB\30FC\30D7'),
'function gameLoop() {',
'    update();',
'    draw();',
'    requestAnimationFrame(gameLoop);',
'}',
'gameLoop();',
'',
'// *********************************************',
unistr('// \30B2\30FC\30E0\72B6\614B\3092JSON\30C9\30AD\30E5\30E1\30F3\30C8\3068\3057\3066\51FA\529B\3059\308B\95A2\6570'),
'function exportGameState() {',
'    const state = {',
'        player: {',
'            x: player.x,',
'            y: player.y,',
'            width: player.width,',
'            height: player.height,',
'            speed: player.speed',
'        },',
'        bullets: bullets.map(bullet => ({',
'            x: bullet.x,',
'            y: bullet.y,',
'            width: bullet.width,',
'            height: bullet.height,',
'            speed: bullet.speed',
'        })),',
'        invaders: invaders.map(inv => ({',
'            x: inv.x,',
'            y: inv.y,',
'            width: inv.width,',
'            height: inv.height,',
'            alive: inv.alive',
'        })),',
'        invaderDirection: invaderDirection',
'    };',
'    return JSON.stringify(state);',
'}',
'',
unistr('// JSON\30C9\30AD\30E5\30E1\30F3\30C8\3092\53D7\3051\53D6\3063\3066\72B6\614B\3092\5FA9\5143\3057\30B2\30FC\30E0\3092\518D\958B\3059\308B\95A2\6570'),
'function importGameState(jsonDocument) {',
'    try {',
'        const state = JSON.parse(jsonDocument);',
'',
unistr('        // \30D7\30EC\30A4\30E4\30FC\306E\72B6\614B\3092\5FA9\5143'),
'        player.x = state.player.x;',
'        player.y = state.player.y;',
'        player.width = state.player.width;',
'        player.height = state.player.height;',
'        player.speed = state.player.speed;',
'',
unistr('        // \5F3E\306E\72B6\614B\3092\5FA9\5143\FF08\65E2\5B58\306E\914D\5217\3092\30AF\30EA\30A2\3057\3066\304B\3089\8FFD\52A0\FF09'),
'        bullets.length = 0;',
'        state.bullets.forEach(b => bullets.push(b));',
'',
unistr('        // \30A4\30F3\30D9\30FC\30C0\30FC\306E\72B6\614B\3092\5FA9\5143'),
'        invaders.length = 0;',
'        state.invaders.forEach(inv => invaders.push(inv));',
'',
unistr('        // \30A4\30F3\30D9\30FC\30C0\30FC\79FB\52D5\65B9\5411\306E\5FA9\5143'),
'        invaderDirection = state.invaderDirection;',
'',
unistr('        // \72B6\614B\8AAD\8FBC\5F8C\306F\518D\958B\72B6\614B\306B\3059\308B'),
'        isPaused = false;',
'    } catch (e) {',
unistr('        console.error("\72B6\614B\306E\8AAD\8FBC\306B\5931\6557\3057\307E\3057\305F:", e);'),
'    }',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    canvas {',
'      display: block;',
'      margin: 0 auto;',
'      background: #111;',
'    }',
'    #controls {',
'      text-align: center;',
'      margin: 10px;',
'    }',
'    button {',
'      font-size: 16px;',
'      margin: 0 5px;',
'      padding: 5px 10px;',
'    }',
'    #stateOutput {',
'      display: block;',
'      width: 90%;',
'      margin: 10px auto;',
'      height: 100px;',
'    }'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(145407705972092022)
,p_plug_name=>'Controls'
,p_region_name=>'CONTROLS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(145468443720171112)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(291152128367689777)
,p_plug_name=>'Game'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(145535070542171251)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<canvas id="gameCanvas" width="800" height="600" tabindex="0"></canvas>',
'',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(291485737003064646)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(145547457406171277)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(145431722245171025)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(145610234926171436)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(145407850203092023)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(145407705972092022)
,p_button_name=>'PAUSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(145608612985171432)
,p_button_image_alt=>unistr('\4E00\6642\505C\6B62')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="PAUSE"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(145407924873092024)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(145407705972092022)
,p_button_name=>'RESUME'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(145608612985171432)
,p_button_image_alt=>unistr('\518D\958B')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="RESUME"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(145408005297092025)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(145407705972092022)
,p_button_name=>'EXPORT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(145608612985171432)
,p_button_image_alt=>unistr('\72B6\614B\51FA\529B')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="EXPORT"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(145408125120092026)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(145407705972092022)
,p_button_name=>'IMPORT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(145608612985171432)
,p_button_image_alt=>unistr('\72B6\614B\5165\529B')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="IMPORT"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(145408209185092027)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(145407705972092022)
,p_button_name=>'RESET'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(145608612985171432)
,p_button_image_alt=>unistr('\30EA\30BB\30C3\30C8')
,p_confirm_message=>unistr('\521D\671F\72B6\614B\306B\623B\3057\307E\3059\304B\FF1F')
,p_confirm_style=>'warning'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(145408311898092028)
,p_name=>'P5_STATE_NAME'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(145407705972092022)
,p_prompt=>unistr('\72B6\614B\540D')
,p_display_as=>'NATIVE_COMBOBOX'
,p_lov=>'select state_name d from ebaj_retro_game_state order by id asc'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(145606196715171423)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_04=>'N'
,p_attribute_07=>'N'
,p_attribute_09=>'0'
,p_attribute_11=>'P5_STATE_NAME_NEW'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(145408480116092029)
,p_name=>'P5_STATE_NAME_NEW'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(145407705972092022)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(145408724163092032)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RESET'
,p_process_sql_clob=>'delete from ebaj_retro_game_state;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(145408209185092027)
,p_internal_uid=>145408724163092032
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(145408537062092030)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EXPORT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_state_name_new ebaj_retro_game_state.state_name%type;',
'    l_state_name     ebaj_retro_game_state.state_name%type;',
'    l_state clob;',
'    e_export_failed exception;',
'begin',
'    l_state_name     := :P5_STATE_NAME;',
'    l_state_name_new := :P5_STATE_NAME_NEW;',
'    l_state := apex_application.g_x01;',
'    if length(l_state_name) > 0 then',
'        apex_debug.info(''existing state = %s, %s'', l_state_name, l_state);',
'        update ebaj_retro_game_state set state = l_state where state_name = l_state_name;',
'    elsif length(l_state_name_new) > 0 then',
'        apex_debug.info(''new state = %s, %s'', l_state_name_new, l_state);',
'        insert into ebaj_retro_game_state(state_name, state) values(l_state_name_new, l_state);',
'    else',
'        apex_debug.info(''Both P5_STATE_NAME and P5_STATE_NAME_NEW is empty'');',
'        raise e_export_failed;',
'    end if;',
'    commit;',
'    htp.p(''{ "success": true }'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>145408537062092030
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(145408630977092031)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'IMPORT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_state_name ebaj_retro_game_state.state_name%type;',
'    l_state clob;',
'    l_state_json json_object_t;',
'    l_response clob;',
'    l_response_json json_object_t;',
'begin',
'    l_state_name := :P5_STATE_NAME;',
'    select state into l_state from ebaj_retro_game_state where state_name = l_state_name;',
'    l_state_json := json_object_t(l_state);',
'    l_response_json := json_object_t();',
'    l_response_json.put(''success'', true);',
'    l_response_json.put(''state'', l_state_json );',
'    l_response := l_response_json.to_clob();',
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>145408630977092031
);
wwv_flow_imp.component_end;
end;
/
