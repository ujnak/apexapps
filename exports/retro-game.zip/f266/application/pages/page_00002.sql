prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>266
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Pause and Resume'
,p_alias=>'PAUSE-AND-RESUME'
,p_step_title=>'Pause and Resume'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('    // Canvas\3068\30B3\30F3\30C6\30AD\30B9\30C8\306E\53D6\5F97'),
'    const canvas = document.getElementById(''gameCanvas'');',
'    const ctx = canvas.getContext(''2d'');',
'',
unistr('    // \30B2\30FC\30E0\306E\4E00\6642\505C\6B62\30D5\30E9\30B0'),
'    let isPaused = false;',
'',
unistr('    // \4E00\6642\505C\6B62\30FB\518D\958B\30DC\30BF\30F3\306E\53D6\5F97\3068\30A4\30D9\30F3\30C8\30EA\30B9\30CA\30FC\8A2D\5B9A'),
'    const pauseButton = document.getElementById(''pauseButton'');',
'    const resumeButton = document.getElementById(''resumeButton'');',
'',
'    pauseButton.addEventListener(''click'', () => {',
'      isPaused = true;',
'    });',
'',
'    resumeButton.addEventListener(''click'', () => {',
'      isPaused = false;',
'    });',
'',
unistr('    // \30D7\30EC\30A4\30E4\30FC\306E\30D7\30ED\30D1\30C6\30A3'),
'    const player = {',
'      x: canvas.width / 2 - 20,',
'      y: canvas.height - 50,',
'      width: 40,',
'      height: 20,',
'      speed: 5,',
'      movingLeft: false,',
'      movingRight: false',
'    };',
'',
unistr('    // \30D7\30EC\30A4\30E4\30FC\306E\5F3E\FF08\30B7\30E7\30C3\30C8\FF09\306E\914D\5217'),
'    const bullets = [];',
'',
unistr('    // \30A4\30F3\30D9\30FC\30C0\30FC\306E\8A2D\5B9A'),
'    const invaders = [];',
'    const invaderRowCount = 3;',
'    const invaderColumnCount = 8;',
'    const invaderWidth = 30;',
'    const invaderHeight = 20;',
'    const invaderPadding = 10;',
'    const invaderOffsetTop = 30;',
'    const invaderOffsetLeft = 30;',
'',
unistr('    // \30A4\30F3\30D9\30FC\30C0\30FC\30AA\30D6\30B8\30A7\30AF\30C8\3092\4F5C\6210'),
'    for (let row = 0; row < invaderRowCount; row++) {',
'      for (let col = 0; col < invaderColumnCount; col++) {',
'        const x = invaderOffsetLeft + col * (invaderWidth + invaderPadding);',
'        const y = invaderOffsetTop + row * (invaderHeight + invaderPadding);',
'        invaders.push({ x, y, width: invaderWidth, height: invaderHeight, alive: true });',
'      }',
'    }',
'',
unistr('    // \30A4\30F3\30D9\30FC\30C0\30FC\306E\79FB\52D5\65B9\5411\3068\30B9\30D4\30FC\30C9'),
unistr('    let invaderDirection = 1; // 1:\53F3\65B9\5411\3001-1:\5DE6\65B9\5411'),
'    const invaderSpeed = 0.5;',
'    const invaderDrop = 10;',
'',
unistr('    // \30AD\30FC\30A4\30D9\30F3\30C8\306E\30EA\30B9\30CA\30FC'),
'    document.addEventListener(''keydown'', (e) => {',
'      if (e.code === ''ArrowLeft'') {',
'        player.movingLeft = true;',
'      } else if (e.code === ''ArrowRight'') {',
'        player.movingRight = true;',
'      } else if (e.code === ''Space'') {',
unistr('        // \30B9\30DA\30FC\30B9\30AD\30FC\3067\5F3E\3092\767A\5C04\FF08\30D7\30EC\30A4\30E4\30FC\306E\4E2D\592E\304B\3089\FF09'),
'        bullets.push({',
'          x: player.x + player.width / 2 - 2.5,',
'          y: player.y,',
'          width: 5,',
'          height: 10,',
'          speed: 7',
'        });',
'      }',
'    });',
'',
'    document.addEventListener(''keyup'', (e) => {',
'      if (e.code === ''ArrowLeft'') {',
'        player.movingLeft = false;',
'      } else if (e.code === ''ArrowRight'') {',
'        player.movingRight = false;',
'      }',
'    });',
'',
unistr('    // \30B2\30FC\30E0\306E\72B6\614B\3092\66F4\65B0\3059\308B\95A2\6570'),
'    function update() {',
unistr('      // \30D7\30EC\30A4\30E4\30FC\306E\79FB\52D5'),
'      if (player.movingLeft && player.x > 0) {',
'        player.x -= player.speed;',
'      }',
'      if (player.movingRight && player.x + player.width < canvas.width) {',
'        player.x += player.speed;',
'      }',
'',
unistr('      // \5F3E\306E\79FB\52D5\3068\753B\9762\5916\306E\5F3E\306E\524A\9664'),
'      for (let i = 0; i < bullets.length; i++) {',
'        bullets[i].y -= bullets[i].speed;',
'        if (bullets[i].y + bullets[i].height < 0) {',
'          bullets.splice(i, 1);',
'          i--;',
'        }',
'      }',
'',
unistr('      // \30A4\30F3\30D9\30FC\30C0\30FC\306E\79FB\52D5'),
'      let hitEdge = false;',
'      for (const invader of invaders) {',
'        if (!invader.alive) continue;',
'        invader.x += invaderSpeed * invaderDirection;',
unistr('        // \30AD\30E3\30F3\30D0\30B9\306E\5DE6\53F3\7AEF\306B\5230\9054\3057\305F\3089\30D5\30E9\30B0\3092\7ACB\3066\308B'),
'        if (invader.x + invader.width > canvas.width || invader.x < 0) {',
'          hitEdge = true;',
'        }',
'      }',
unistr('      // \7AEF\306B\5230\9054\3057\305F\3089\3001\5168\30A4\30F3\30D9\30FC\30C0\30FC\3092\4E0B\306B\79FB\52D5\3057\3001\79FB\52D5\65B9\5411\3092\53CD\8EE2'),
'      if (hitEdge) {',
'        invaderDirection *= -1;',
'        for (const invader of invaders) {',
'          invader.y += invaderDrop;',
'        }',
'      }',
'',
unistr('      // \5F3E\3068\30A4\30F3\30D9\30FC\30C0\30FC\306E\885D\7A81\5224\5B9A'),
'      for (let i = 0; i < bullets.length; i++) {',
'        for (const invader of invaders) {',
'          if (!invader.alive) continue;',
'          if (',
'            bullets[i].x < invader.x + invader.width &&',
'            bullets[i].x + bullets[i].width > invader.x &&',
'            bullets[i].y < invader.y + invader.height &&',
'            bullets[i].y + bullets[i].height > invader.y',
'          ) {',
unistr('            // \885D\7A81\FF1A\30A4\30F3\30D9\30FC\30C0\30FC\3092\975E\8868\793A\306B\3057\3001\5F3E\3092\524A\9664'),
'            invader.alive = false;',
'            bullets.splice(i, 1);',
'            i--;',
'            break;',
'          }',
'        }',
'      }',
'',
unistr('      // \30B2\30FC\30E0\30AA\30FC\30D0\30FC\30C1\30A7\30C3\30AF\FF1A\3044\305A\308C\304B\306E\30A4\30F3\30D9\30FC\30C0\30FC\304C\30D7\30EC\30A4\30E4\30FC\306E\4F4D\7F6E\307E\3067\6765\305F\3089\7D42\4E86'),
'      for (const invader of invaders) {',
'        if (invader.alive && invader.y + invader.height >= player.y) {',
'          alert("Game Over!");',
'          document.location.reload();',
'          return;',
'        }',
'      }',
'    }',
'',
unistr('    // \753B\9762\3092\63CF\753B\3059\308B\95A2\6570'),
'    function draw() {',
unistr('      // \30AD\30E3\30F3\30D0\30B9\3092\30AF\30EA\30A2'),
'      ctx.clearRect(0, 0, canvas.width, canvas.height);',
'',
unistr('      // \30D7\30EC\30A4\30E4\30FC\3092\63CF\753B\FF08\7DD1\8272\FF09'),
'      ctx.fillStyle = ''#00ff00'';',
'      ctx.fillRect(player.x, player.y, player.width, player.height);',
'',
unistr('      // \5F3E\3092\63CF\753B\FF08\9EC4\8272\FF09'),
'      ctx.fillStyle = ''#ffff00'';',
'      for (const bullet of bullets) {',
'        ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);',
'      }',
'',
unistr('      // \30A4\30F3\30D9\30FC\30C0\30FC\3092\63CF\753B\FF08\8D64\8272\FF09'),
'      ctx.fillStyle = ''#ff0000'';',
'      for (const invader of invaders) {',
'        if (invader.alive) {',
'          ctx.fillRect(invader.x, invader.y, invader.width, invader.height);',
'        }',
'      }',
'    }',
'',
unistr('    // \30E1\30A4\30F3\30EB\30FC\30D7\FF08update\2192draw\3092\7E70\308A\8FD4\3059\FF09'),
'    function gameLoop() {',
'      if (!isPaused) {',
'        update();',
'        draw();',
'      } else {',
unistr('        // \4E00\6642\505C\6B62\4E2D\306F\753B\9762\3092\66F4\65B0\3057\3066\300CPaused\300D\3068\8868\793A'),
'        draw();',
'        ctx.font = "30px Arial";',
'        ctx.fillStyle = "white";',
'        ctx.fillText("Paused", canvas.width / 2 - 50, canvas.height / 2);',
'      }',
'      requestAnimationFrame(gameLoop);',
'    }',
'',
unistr('    // \30B2\30FC\30E0\958B\59CB'),
'    gameLoop();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    canvas {',
'      display: block;',
'      margin: 0 auto;',
'      background: #111;',
'    }',
'    #controls {',
'      text-align: center;',
'      margin: 10px;',
'    }',
'    button {',
'      font-size: 16px;',
'      margin: 0 5px;',
'      padding: 5px 10px;',
'    }'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(145407449044092019)
,p_plug_name=>'Game'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(145535070542171251)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  <div id="controls">',
unistr('    <button id="pauseButton">\4E00\6642\505C\6B62</button>'),
unistr('    <button id="resumeButton">\518D\958B</button>'),
'  </div>',
'  <canvas id="gameCanvas" width="800" height="600"></canvas>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(145736740287305708)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(145547457406171277)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(145431722245171025)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(145610234926171436)
);
wwv_flow_imp.component_end;
end;
/
