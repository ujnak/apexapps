prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>285
,p_default_id_offset=>115593026989766295
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\30D5\30A9\30FC\30AB\30B9\306E\79FB\52D5')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// P1_TEXT to P1_LIST',
'document.getElementById("P1_TEXT").onkeydown = function(event) {',
'    if (event.key == "Enter") {',
'            apex.items.P1_LIST.setFocus();',
'    }',
'};',
'// P1_LIST to P1_LOV',
'document.getElementById("P1_LIST").onkeydown = function(event) {',
'    if (event.key == "Enter") {',
'            apex.items.P1_LOV.setFocus();',
'    }',
'};',
'// P1_LOV to P1_DATE',
'document.getElementById("P1_LOV").onkeydown = function(event) {',
'    if (event.key == "Enter") {',
'            apex.items.P1_DATE.setFocus();',
'    }',
'};',
'// P1_DATE to P1_TEXT',
'document.getElementById("P1_DATE").onkeydown = function(event) {',
'    if (event.key == "Enter") {',
'            document.getElementById("P1_CHECKBOX_GROUP_0").focus();',
'    }',
'};',
'//',
'document.getElementById("P1_CHECKBOX_GROUP_0").onkeydown = function(event) {',
'    if (event.key == "Enter") {',
'            document.getElementById("P1_CHECKBOX_GROUP_1").focus();',
'    }',
'};',
'document.getElementById("P1_CHECKBOX_GROUP_1").onkeydown = function(event) {',
'    if (event.key == "Enter") {',
'            apex.items.P1_TEXT.setFocus();',
'    }',
'};',
'',
'document.getElementById("B_SUBMIT").onkeydown = function(event) {',
'    if (event.key == "Tab") {',
'        apex.items.P1_TEXT.setFocus();',
'        event.preventDefault();',
'    }',
'};'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231025025446'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190254168217649186)
,p_plug_name=>unistr('Enter\3067\79FB\52D5')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(190926178341282004)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(191032462569282072)
,p_plug_name=>unistr('\30D5\30A9\30FC\30AB\30B9\306E\79FB\52D5')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(190898295861281991)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(190254598610649191)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(190254168217649186)
,p_button_name=>'B_SUBMIT'
,p_button_static_id=>'B_SUBMIT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(190999034731282043)
,p_button_image_alt=>unistr('\9001\4FE1')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111143482216178141)
,p_name=>'P1_CHECKBOX_GROUP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(190254168217649186)
,p_prompt=>unistr('\30C1\30A7\30C3\30AF\30DC\30C3\30AF\30B9\30FB\30B0\30EB\30FC\30D7')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC:\6709\52B9;1,\7121\52B9;0')
,p_field_template=>wwv_flow_imp.id(190996544578282041)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190254190284649187)
,p_name=>'P1_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(190254168217649186)
,p_prompt=>unistr('\30C6\30AD\30B9\30C8')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(190996544578282041)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190254383081649188)
,p_name=>'P1_LIST'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(190254168217649186)
,p_prompt=>unistr('\30EA\30B9\30C8')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:A;A,B;B'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- \9078\629E\3059\308B -')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(190996544578282041)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190254411717649189)
,p_name=>'P1_LOV'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(190254168217649186)
,p_prompt=>unistr('\30DD\30C3\30D7\30A2\30C3\30D7LOV')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>unistr('STATIC:\6771\4EAC;TOKYO,\795E\5948\5DDD;KANAGAWA,\5343\8449;CIBA,\57FC\7389;SAITAMA')
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- \90FD\9053\5E9C\770C\306E\9078\629E -')
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(190996544578282041)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190254501782649190)
,p_name=>'P1_DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(190254168217649186)
,p_prompt=>unistr('\65E5\4ED8')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(190996544578282041)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'IMAGE'
);
wwv_flow_imp.component_end;
end;
/
