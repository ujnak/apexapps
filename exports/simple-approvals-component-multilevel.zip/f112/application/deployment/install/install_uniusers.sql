prompt --application/deployment/install/install_uniusers
begin
--   Manifest
--     INSTALL: INSTALL-uniusers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>112
,p_default_id_offset=>29638745585804104755
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13325136168567044)
,p_install_id=>wwv_flow_imp.id(25405291812992814)
,p_name=>'uniusers'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table uni_users(',
'    empno  number primary key,',
'    emp_name varchar2(80) not null,',
'    mgr    number',
');',
'',
unistr('insert into uni_users values(10, ''\7533\8ACB\592A\90CE'', 30);'),
unistr('insert into uni_users values(20, ''\7533\8ACB\82B1\5B50'', 40);'),
unistr('insert into uni_users values(30, ''\627F\8A8D\592A\90CE'', 50);'),
unistr('insert into uni_users values(40, ''\627F\8A8D\82B1\5B50'', 50);'),
unistr('insert into uni_users values(50, ''\7BA1\7406\8005'', null);'),
'commit;'))
);
wwv_flow_imp.component_end;
end;
/
