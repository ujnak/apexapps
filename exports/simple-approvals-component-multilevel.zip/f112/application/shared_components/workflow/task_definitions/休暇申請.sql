prompt --application/shared_components/workflow/task_definitions/休暇申請
begin
--   Manifest
--     TASK_DEF: 休暇申請
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>112
,p_default_id_offset=>29638745585804104755
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(29648605412726672525)
,p_name=>unistr('\4F11\6687\7533\8ACB')
,p_static_id=>'LEAVE_REQUEST'
,p_subject=>unistr('&REASON. &START_DATE. - &END_DATE.\3000&REQUESTER.')
,p_priority=>2
,p_due_on_interval=>'PT30M'
,p_details_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP,5:P5_TASK_ID:&TASK_ID.'
,p_actions_table_name=>'UNI_REQUESTS'
,p_actions_pk_column_name=>'ID'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(25378443706108634)
,p_task_def_id=>wwv_flow_imp.id(29648605412726672525)
,p_name=>unistr('\627F\8A8D')
,p_execution_sequence=>10
,p_outcome=>'APPROVED'
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    r_request uni_requests%rowtype;',
'    l_task_id number;',
'begin',
'    select * into r_request from uni_requests where id = :APEX$TASK_PK;',
'    if r_request.status is null then',
unistr('        -- STATUS\304CNULL\306A\306E\3067\3001\76F4\63A5\306E\4E0A\53F8\304C\7533\8ACB\3092\53D7\3051\53D6\3063\3066\627F\8A8D\3057\305F\3002'),
'        if (r_request.end_date - r_request.start_date) <= 7 then',
unistr('            -- \671F\9593\304C\4E00\9031\9593\4EE5\4E0B\3067\3042\308C\3070\3001\3053\306E\627F\8A8D\51E6\7406\3067\5B8C\4E86\3002'),
'            update uni_requests ',
'                set status = ''APPROVED''',
'                , approver = :APEX$TASK_OWNER',
'                , approve_date = sysdate',
'            where id = :APEX$TASK_PK;',
'        else',
unistr('            -- \4E00\9031\9593\3092\8D85\3048\308B\5834\5408\306F\3001\4E0A\53F8\306B\8EE2\9001\3059\308B\3002'),
unistr('            -- \3053\306E\30BF\30B9\30AF\81EA\4F53\306F\3001\3053\308C\3067\5B8C\4E86\3059\308B\3002'),
'            update uni_requests ',
'                set status = ''TRANSFERED''',
'                , approver = :APEX$TASK_OWNER',
'                , approve_date = sysdate',
'            where id = :APEX$TASK_PK;',
unistr('            -- \4E0A\53F8\306B\627F\8A8D\3092\6C42\3081\308B\3001\65B0\305F\306A\30BF\30B9\30AF\3092\751F\6210\3059\308B\3002'),
'            l_task_id := apex_approval.create_task(',
'                p_application_id => :APP_ID',
'                , p_task_def_static_id => ''LEAVE_REQUEST''',
'                , p_initiator => :REQUESTER',
'                , p_detail_pk => :APEX$TASK_PK',
'            );',
'        end if;',
'    elsif r_request.status = ''TRANSFERED'' then',
unistr('        --  \8EE2\9001\3055\308C\305F\627F\8A8D\3067\3042\308C\3070\3001\3053\306E\627F\8A8D\3067\5B8C\4E86\3002'),
'        update uni_requests ',
'            set status = ''APPROVED''',
'            , approver = :APEX$TASK_OWNER',
'            , approve_date = sysdate',
'        where id = :APEX$TASK_PK;',
'    end if;',
'end;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(25378714998114472)
,p_task_def_id=>wwv_flow_imp.id(29648605412726672525)
,p_name=>unistr('\5374\4E0B')
,p_execution_sequence=>20
,p_outcome=>'REJECTED'
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update uni_requests ',
'        set status = ''REJECTED''',
'        , approver = :APEX$TASK_OWNER',
'        , approve_date = sysdate',
'    where id = :APEX$TASK_PK;',
'end;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(29648606438538676455)
,p_task_def_id=>wwv_flow_imp.id(29648605412726672525)
,p_participant_type=>'BUSINESS_ADMIN'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>unistr('\7BA1\7406\8005')
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(29648658397709839580)
,p_task_def_id=>wwv_flow_imp.id(29648605412726672525)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_mgr_name uni_users.emp_name%type;',
'begin',
'    select m.emp_name as mgr_name into l_mgr_name',
'    from uni_users u join uni_users m on u.mgr = m.empno',
'    where u.emp_name = :APP_USER;',
'    return l_mgr_name;',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
