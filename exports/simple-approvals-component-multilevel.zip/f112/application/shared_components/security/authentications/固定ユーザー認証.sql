prompt --application/shared_components/security/authentications/固定ユーザー認証
begin
--   Manifest
--     AUTHENTICATION: 固定ユーザー認証
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>112
,p_default_id_offset=>29638745585804104755
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(29648605076853662076)
,p_name=>unistr('\56FA\5B9A\30E6\30FC\30B6\30FC\8A8D\8A3C')
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'uni_auth'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function uni_auth (',
'    p_username in varchar2,',
'    p_password in varchar2 )',
'    return boolean',
'is',
'    l_count pls_integer;',
'begin',
'    select count(*) into l_count from uni_users where emp_name = p_username;',
'    if l_count = 1 then',
'        return true;',
'    end if;',
'    return false;',
'end;'))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
