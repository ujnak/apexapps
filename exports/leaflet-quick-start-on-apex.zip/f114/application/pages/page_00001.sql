prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>5050556754310867
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Leaflet'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"',
'    integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="',
'    crossorigin=""/>',
'<!-- Make sure you put this AFTER Leaflet''s CSS -->',
' <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"',
'     integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="',
'     crossorigin=""></script>'))
,p_javascript_file_urls=>'#APP_FILES#app#MIN#.js'
,p_inline_css=>'#map { height: 640px; }'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12079523594064407)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<div id="map"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12079731940064409)
,p_plug_name=>'Controls'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12236718956164677)
,p_plug_name=>'Leaflet'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12079629476064408)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12079731940064409)
,p_button_name=>'TOGGLE_MARKER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Toggle Marker'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="TOGGLE_MARKER"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12080087098064412)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(12079731940064409)
,p_button_name=>'TOGGLE_CIRCLE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Toggle Circle'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="TOGGLE_CIRCLE"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12080145058064413)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(12079731940064409)
,p_button_name=>'TOGGLE_POLYGON'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'<span class="custom-label">Polygon On</span>'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="TOGGLE_POLYGON"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12080280537064414)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(12079731940064409)
,p_button_name=>'TOGGLE_MARKER_POPUP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Toggle Marker Popup'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="TOGGLE_MARKER_POPUP"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12080368184064415)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(12079731940064409)
,p_button_name=>'TOGGLE_CIRCLE_POPUP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Toggle Circle Popup'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="TOGGLE_CIRCLE_POPUP"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12080424621064416)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(12079731940064409)
,p_button_name=>'TOGGLE_POLYGON_POPUP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Toggle Polygon Popup'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="TOGGLE_POLYGON_POPUP"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12080584628064417)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(12079731940064409)
,p_button_name=>'TOGGLE_STANDALONE_POPUP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Toggle Standalone Popup'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="TOGGLE_STANDALONE_POPUP"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp.component_end;
end;
/
