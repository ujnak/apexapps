prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(34854960518685260)
,p_prompt_sub_string_02=>'Y'
,p_install_prompt_02=>unistr('Whisper\3092\547C\3073\51FA\3059API\306E\30A8\30F3\30C9\30DD\30A4\30F3\30C8URL')
);
wwv_flow_imp.component_end;
end;
/
