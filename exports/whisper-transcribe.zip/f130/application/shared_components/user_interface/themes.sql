prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(34817255454478475)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(34665286926478391)
,p_default_dialog_template=>wwv_flow_imp.id(34660028827478388)
,p_error_template=>wwv_flow_imp.id(34650013936478384)
,p_printer_friendly_template=>wwv_flow_imp.id(34665286926478391)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(34650013936478384)
,p_default_button_template=>wwv_flow_imp.id(34814232402478469)
,p_default_region_template=>wwv_flow_imp.id(34741340694478430)
,p_default_chart_template=>wwv_flow_imp.id(34741340694478430)
,p_default_form_template=>wwv_flow_imp.id(34741340694478430)
,p_default_reportr_template=>wwv_flow_imp.id(34741340694478430)
,p_default_tabform_template=>wwv_flow_imp.id(34741340694478430)
,p_default_wizard_template=>wwv_flow_imp.id(34741340694478430)
,p_default_menur_template=>wwv_flow_imp.id(34753765742478435)
,p_default_listr_template=>wwv_flow_imp.id(34741340694478430)
,p_default_irr_template=>wwv_flow_imp.id(34731569756478425)
,p_default_report_template=>wwv_flow_imp.id(34779292041478448)
,p_default_label_template=>wwv_flow_imp.id(34811796478478466)
,p_default_menu_template=>wwv_flow_imp.id(34815802176478469)
,p_default_calendar_template=>wwv_flow_imp.id(34815927572478470)
,p_default_list_template=>wwv_flow_imp.id(34795660465478457)
,p_default_nav_list_template=>wwv_flow_imp.id(34807403519478464)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(34807403519478464)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(34802061615478461)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(34678111681478399)
,p_default_dialogr_template=>wwv_flow_imp.id(34675393414478398)
,p_default_option_label=>wwv_flow_imp.id(34811796478478466)
,p_default_required_label=>wwv_flow_imp.id(34813005249478467)
,p_default_navbar_list_template=>wwv_flow_imp.id(34801644175478460)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/22.2/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
