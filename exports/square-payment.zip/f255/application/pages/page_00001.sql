prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>255
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Square Payment'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://sandbox.web.squarecdn.com/v1/square.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const appId = ''&SQUARE_APP_ID.'';',
'const locationId = ''&SQUARE_LOCATION_ID.'';',
'',
'async function initializeCard(payments) {',
'    const card = await payments.card();',
'    await card.attach(''#card-container''); ',
'    return card; ',
'}',
'',
'// Call this function to send a payment token, buyer name, and other details',
'// to the project server code so that a payment can be created with ',
'// Payments API',
'async function createPayment(token) {',
'    apex.server.process(',
'        "CREATE_PAYMENT",',
'        {',
'            x01: token,',
'            x02: locationId,',
'            pageItems: ["P1_AMOUNT"]',
'        },',
'        {',
'            success: (data) => {',
'                return data;',
'            },',
'            error: (data) => {',
'                throw new Error(data);',
'            }',
'        }',
'    );',
'}',
'',
'// This function tokenizes a payment method. ',
unistr('// The \2018error\2019 thrown from this async function denotes a failed tokenization,'),
'// which is due to buyer error (such as an expired card). It''s up to the',
'// developer to handle the error and provide the buyer the chance to fix',
'// their mistakes.',
'async function tokenize(paymentMethod) {',
'    const tokenResult = await paymentMethod.tokenize();',
'    if (tokenResult.status === ''OK'') {',
'        return tokenResult.token;',
'    } else {',
'        let errorMessage = `Tokenization failed-status: ${tokenResult.status}`;',
'        if (tokenResult.errors) {',
'            errorMessage += ` and errors: ${JSON.stringify(',
'                tokenResult.errors',
'            )}`;',
'        }',
'        throw new Error(errorMessage);',
'    }',
'}',
'',
'document.addEventListener(''DOMContentLoaded'', async function () {',
'    if (!window.Square) {',
'        throw new Error(''Square.js failed to load properly'');',
'    }',
'    const payments = window.Square.payments(appId, locationId);',
'    let card;',
'    try {',
'        card = await initializeCard(payments);',
'    } catch (e) {',
'        console.error(''Initializing Card failed'', e);',
'        return;',
'    }',
'',
'    // Step 5.2: create card payment',
'    async function handlePaymentMethodSubmission(event, paymentMethod) {',
'        event.preventDefault();',
'',
'        try {',
'            // disable the submit button as we await tokenization and make a',
'            // payment request.',
'            cardButton.disabled = true;',
'            const token = await tokenize(paymentMethod);',
'            const paymentResults = await createPayment(token);',
'            // displayPaymentResults(''SUCCESS'');',
'            apex.message.showPageSuccess("Payment Success!")',
'            console.debug(''Payment Success'', paymentResults);',
'        } catch (e) {',
'            cardButton.disabled = false;',
'            // displayPaymentResults(''FAILURE'');',
'            aepx.message.clearErrors();',
'            apex.message.showErrors([',
'                {',
'                    type: "error",',
'                    location: "page",',
'                    message: "Payment Failed!",',
'                    unsafe: false',
'                }',
'            ]);',
'            console.error(e.message);',
'        }',
'    }',
'',
'    const cardButton = document.getElementById(',
'        ''card-button''',
'    );',
'    cardButton.addEventListener(''click'', async function (event) {',
'        await handlePaymentMethodSubmission(event, card);',
'    });',
'',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230821033208'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65570033728802109)
,p_plug_name=>'Card Container'
,p_region_name=>'card-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(66781764555475872)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65570528483802114)
,p_button_sequence=>30
,p_button_name=>'PAY'
,p_button_static_id=>'card-button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(66921567585475972)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Pay'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65570484564802113)
,p_name=>'P1_AMOUNT'
,p_item_sequence=>10
,p_prompt=>'Amount'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(66919043947475966)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(65570307531802112)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CREATE_PAYMENT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request clob;',
'    l_response clob;',
'    l_idempotency_key varchar2(35);',
'    l_source_id varchar2(64);   -- token',
'    l_location_id varchar2(32); -- location id',
'    l_amount_money_amount number;',
'    e_create_payment_failed exception;',
'begin',
'    -- guid for idempotency_key.',
'    l_idempotency_key := regexp_replace(lower(rawtohex(sys_guid())),''(........)(....)(....)(................)'',''\1-\2-\3-\4'');',
'    l_amount_money_amount := to_number(:P1_AMOUNT);',
'    l_source_id           := apex_application.g_x01;',
'    l_location_id         := apex_application.g_x02;',
'    select json_object(',
'        key ''source_id'' value l_source_id,',
'        key ''location_id'' value l_location_id,',
'        key ''idempotency_key'' value l_idempotency_key,',
'        key ''amount_money'' value json_object(',
'            key ''amount'' value l_amount_money_amount,',
'            key ''currency'' value ''JPY''',
'        )',
'    ) into l_request from dual;',
'    apex_debug.info(l_request);',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Square-Version'',''2023-08-16'',p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'',p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => :SQUARE_ENDPOINT || ''/v2/payments''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''SQUARE_CRED''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_create_payment_failed;',
'    end if;',
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>65570307531802112
);
wwv_flow_imp.component_end;
end;
/
