prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>156
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Dynamic JET Chart'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>'require(["ojs/ojchart"], function() {});'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47207922539404421)
,p_plug_name=>'Chart'
,p_region_template_options=>'#DEFAULT#:i-h640:t-Region--scrollBody:margin-top-md'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>'<div id="chart"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47343635056579049)
,p_plug_name=>'Dynamic JET Chart'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47207832160404420)
,p_button_sequence=>30
,p_button_name=>'GENERATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Generate'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47207618462404418)
,p_name=>'P1_CHART_TYPE'
,p_item_sequence=>10
,p_prompt=>'Chart Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Bar Chart;bar,Pie Chart;pie'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Chart Type -'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47207786380404419)
,p_name=>'P1_SQL'
,p_item_sequence=>20
,p_prompt=>'Source SQL Statement'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47208184537404423)
,p_name=>'onClick GENERATE'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47207832160404420)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47208204343404424)
,p_event_id=>wwv_flow_imp.id(47208184537404423)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process( "GET_CHART", {',
'    pageItems: "#P1_CHART_TYPE,#P1_SQL"',
'}, {',
'    success: function( data )  {',
'        apex.debug.info(data.markup);',
'        const elem = document.getElementById("chart");',
'        elem.insertAdjacentHTML(''afterbegin'', data.markup);',
'    }',
'} );'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47208074859404422)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CHART'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
unistr('    /* SELECT\6587\306E\5B9F\884C */'),
'    l_sql varchar2(32767);',
'    l_cursor    integer;',
'    l_col_cnt   integer;',
'    l_desc_tab  dbms_sql.desc_tab;',
'    e_invalid_sql exception;',
'    l_label varchar2(4000);',
'    l_label_name varchar2(4000);',
'    l_value number;',
'    l_rows  number;',
unistr('    /* JET\30C1\30E3\30FC\30C8\306B\57CB\3081\8FBC\3080\30C7\30FC\30BF */'),
'    l_groups_arr json_array_t;',
'    l_group      json_object_t;',
'    l_series_arr json_array_t;',
'    l_series     json_object_t;',
'    l_items_arr  json_array_t;',
'    l_item       json_object_t;',
'    l_series_clob clob;',
'    l_groups_clob clob;',
'    l_items_clob  clob;',
unistr('    /* JET\30C1\30E3\30FC\30C8\306E\30DE\30FC\30AF\30A2\30C3\30D7 */'),
'    l_html clob;',
'    l_response_clob clob;',
'    l_response json_object_t;',
'    l_chart_id varchar2(40);',
'    l_chart_type varchar2(8);',
'    e_invalid_chart_type exception;',
'/*',
unistr('* \30D0\30FC\30C1\30E3\30FC\30C8\306E\30C6\30F3\30D7\30EC\30FC\30C8'),
'*/',
'C_TEMPLATE_BAR_CHART constant clob := q''~',
'<oj-chart',
'    id="#CHART_ID#"',
'    type="bar"',
'    orientation="horizontal"',
'    stack="off"',
'    groups=''#GROUPS#''',
'    series=''[ { "items": #ITEMS# } ]''',
'    animation-on-display="auto"',
'    animation-on-data-change="auto"',
'    hover-behavior="dim">',
'</oj-chart>',
'~'';',
'/*',
unistr('* \30D1\30A4\30C1\30E3\30FC\30C8\306E\30C6\30F3\30D7\30EC\30FC\30C8'),
'*/',
'C_TEMPLATE_PIE_CHART constant clob := q''~',
'<oj-chart',
'  id="#CHART_ID#"',
'  type="pie"',
'  selection-mode="single"',
'  series=''#SERIES#''',
'  animation-on-display="auto"',
'  animation-on-data-change="auto"',
'  hover-behavior="dim">',
'</oj-chart>',
'~'';',
'begin',
'    l_chart_type := :P1_CHART_TYPE;',
'    /*',
unistr('    * JET\30C1\30E3\30FC\30C8\306B\4E0E\3048\308B\30C7\30FC\30BF\3092\4FDD\6301\3059\308B\3002'),
'    */',
'    l_groups_arr := json_array_t();',
'    l_series_arr := json_array_t();',
'    l_items_arr  := json_array_t();',
'    /*',
unistr('    * P1_SQL\306B\306F\FF12\3064\306E\5217\3001\6700\521D\306B\30E9\30D9\30EB\3068\306A\308B\5217\3068\6B21\306B\5024\3068\306A\308B\6570\5024\5217\3092'),
unistr('    * \6301\3064SELECT\6587\304C\8A18\8F09\3055\308C\3066\3044\308B\3053\3068\3092\524D\63D0\3068\3057\3066\3044\308B\3002'),
'    */',
unistr('    -- \4E0E\3048\3089\308C\305FSQL\306E\691C\8A3C'),
'    l_sql := :P1_SQL;',
'    if l_sql is null or l_sql = '''' then',
'        raise e_invalid_sql;',
'    end if;',
unistr('    -- \30AB\30FC\30BD\30EB\306E\30AA\30FC\30D7\30F3'),
'    l_cursor := dbms_sql.open_cursor;',
unistr('    -- SQL\306E\30D1\30FC\30B9'),
'    dbms_sql.parse(l_cursor, l_sql, dbms_sql.native);',
'    /*',
unistr('    * \6700\521D\306E\30E9\30D9\30EB\3068\306A\308B\5217\306E\540D\524D\3092\53D6\5F97\3059\308B\3002\305F\3060\3057\3001\4ECA\306E\6240\306F\4F7F\7528\3057\3066\3044\306A\3044\3002'),
'    */',
'    dbms_sql.describe_columns(l_cursor, l_col_cnt, l_desc_tab);',
'    l_label_name := l_desc_tab(1).col_name;',
unistr('    -- \5217\306E\5B9A\7FA9'),
'    dbms_sql.define_column(l_cursor, 1, l_label, 4000);',
'    dbms_sql.define_column(l_cursor, 2, l_value);',
unistr('    -- SELECT\6587\306E\5B9F\884C'),
'    l_rows := dbms_sql.execute(l_cursor);',
'    loop',
'        exit when dbms_sql.fetch_rows(l_cursor) = 0;',
'        dbms_sql.column_value(l_cursor, 1, l_label);',
'        dbms_sql.column_value(l_cursor, 2, l_value);',
unistr('        /* JET\30C1\30E3\30FC\30C8\306B\542B\3081\308B\30C7\30FC\30BF\3092\4F5C\6210\3059\308B */'),
'        if l_chart_type = ''bar'' then',
'            l_group := json_object_t();',
'            l_group.put(''name'', l_label);',
'            l_groups_arr.append(l_group);',
'            l_items_arr.append(l_value);       ',
'        elsif l_chart_type = ''pie'' then',
'            l_series := json_object_t();',
'            l_series.put(''name'', l_label);',
'            l_items_arr := json_array_t();',
'            l_items_arr.append(l_value);',
'            l_series.put(''items'', l_items_arr);',
'            l_series_arr.append(l_series);',
'        else',
'            raise e_invalid_chart_type;',
'        end if;',
'    end loop;',
unistr('    -- \30AB\30FC\30BD\30EB\306E\30AF\30ED\30FC\30BA'),
'    dbms_sql.close_cursor(l_cursor);',
'    /*',
unistr('    * JET\30C1\30E3\30FC\30C8\306E\30DE\30FC\30AF\30A2\30C3\30D7\3092\751F\6210\3059\308B\3002'),
'    */',
'    l_groups_clob := l_groups_arr.to_clob();',
'    l_series_clob := l_series_arr.to_clob();',
'    l_items_clob  := l_items_arr.to_clob();',
'    /*',
unistr('    * JET\30C1\30E3\30FC\30C8\306E\30C6\30F3\30D7\30EC\30EC\30FC\30C8\306B\30C7\30FC\30BF\3092\57CB\3081\8FBC\307F\3001'),
unistr('    * \30DE\30FC\30AF\30A2\30C3\30D7\3092\5B8C\6210\3055\305B\308B'),
'    */',
'    l_chart_id := ''chart'' || sys_guid();',
'    if l_chart_type = ''bar'' then',
'        l_html := replace(C_TEMPLATE_BAR_CHART, ''#CHART_ID#'', l_chart_id);',
unistr('        /* \30D0\30FC\30C1\30E3\30FC\30C8\306Fgroups\3068series\306B\30C7\30FC\30BF\3092\4E0E\3048\308B */'),
'        l_html := replace(l_html, ''#GROUPS#'', l_groups_clob);',
'        l_html := replace(l_html, ''#ITEMS#'', l_items_clob);',
'    elsif l_chart_type = ''pie'' then',
'        l_html := replace(C_TEMPLATE_PIE_CHART, ''#CHART_ID#'', l_chart_id);',
unistr('        /* \30D1\30A4\30C1\30E3\30FC\30C8\306Fseries\306B\30C7\30FC\30BF\3092\4E0E\3048\308B */'),
'        l_html := replace(l_html, ''#SERIES#'', l_series_clob);',
'    end if;',
'    /*',
unistr('    * \547C\3073\51FA\3057\5143\306BJSON\5F62\5F0F\3067JET\30C1\30E3\30FC\30C8\306E\8981\7D20\3092\8FD4\3059\3002'),
unistr('    * { "markup": "JET\30C1\30E3\30FC\30C8\306E\8981\7D20" }'),
'    */',
'    l_response := json_object_t();',
'    l_response.put(''markup'', l_html);',
'    l_response_clob := l_response.to_clob();',
'    htp.p(l_response_clob);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>47208074859404422
);
wwv_flow_imp.component_end;
end;
/
