prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>324
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\6B69\304F\65B9\5411')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240213102731'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54701418100232643)
,p_plug_name=>'My Tasks'
,p_region_name=>'MYTASKS'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(54878760696122484)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>'select task_id, subject, ''L'' as LEFT, ''C'' as CENTER, ''R'' as RIGHT from apex_approval.get_tasks()'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'My Tasks'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(54701506849232644)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>54701506849232644
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54701658166232645)
,p_db_column_name=>'TASK_ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Task Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54701719238232646)
,p_db_column_name=>'SUBJECT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Subject'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54701897273232647)
,p_db_column_name=>'LEFT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Left'
,p_column_html_expression=>unistr('<button type="button" class="t-Button actionLeft" data-id=#TASK_ID#>\5DE6</button>')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54701928982232648)
,p_db_column_name=>'CENTER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Center'
,p_column_html_expression=>unistr('<button type="button" class="t-Button actionCenter" data-id=#TASK_ID#>\4E2D\5FC3</button>')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54702069870232649)
,p_db_column_name=>'RIGHT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Right'
,p_column_html_expression=>unistr('<button type="button" class="t-Button actionRight" data-id=#TASK_ID#>\53F3</button>')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(55104027517820567)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'551041'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TASK_ID:SUBJECT:LEFT:CENTER:RIGHT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55086038625122982)
,p_plug_name=>unistr('\6B69\304F\65B9\5411')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(54855203434122470)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55097220125640914)
,p_plug_name=>'Start Workflow'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(54880818875122485)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(55097426812640916)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(55097220125640914)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(54961713297122550)
,p_button_image_alt=>'Submit'
,p_button_position=>'BUTTON_END'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55096074812640902)
,p_name=>'P1_TASK_ID'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55097390816640915)
,p_name=>'P1_CORNER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(55097220125640914)
,p_prompt=>'Corner'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(54959251652122546)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54702104412232650)
,p_name=>'Move Left'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.actionLeft'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#MYTASKS'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55095901857640901)
,p_event_id=>wwv_flow_imp.id(54702104412232650)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_TASK_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.id'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55096150941640903)
,p_event_id=>wwv_flow_imp.id(54702104412232650)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_approval.set_task_parameter_values(',
'        p_task_id     => :P1_TASK_ID',
'        ,p_parameters => apex_approval.t_task_parameters(',
'            1 => apex_approval.t_task_parameter(',
'                static_id => ''DIRECTION''',
'                ,string_value => ''LEFT''',
'            )',
'        )',
'    );',
'    apex_approval.complete_task(',
'        p_task_id => :P1_TASK_ID',
'        ,p_autoclaim => true',
'    );',
'end;'))
,p_attribute_02=>'P1_TASK_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55096296012640904)
,p_event_id=>wwv_flow_imp.id(54702104412232650)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('apex.message.showPageSuccess("\5DE6\306B\66F2\304C\308A\307E\3057\305F\3002");'),
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(55096360165640905)
,p_name=>'Move Center'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.actionCenter'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#MYTASKS'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55096423980640906)
,p_event_id=>wwv_flow_imp.id(55096360165640905)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_TASK_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.id'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55096571974640907)
,p_event_id=>wwv_flow_imp.id(55096360165640905)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_approval.set_task_parameter_values(',
'        p_task_id     => :P1_TASK_ID',
'        ,p_parameters => apex_approval.t_task_parameters(',
'            1 => apex_approval.t_task_parameter(',
'                static_id => ''DIRECTION''',
'                ,string_value => ''CENTER''',
'            )',
'        )',
'    );',
'    apex_approval.complete_task(',
'        p_task_id => :P1_TASK_ID',
'        ,p_autoclaim => true',
'    );',
'end;'))
,p_attribute_02=>'P1_TASK_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55096624000640908)
,p_event_id=>wwv_flow_imp.id(55096360165640905)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('apex.message.showPageSuccess("\4E2D\5FC3\3092\9032\307F\307E\3059\3002");'),
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(55096898606640910)
,p_name=>'Move Right'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.actionRight'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#MYTASKS'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55096937822640911)
,p_event_id=>wwv_flow_imp.id(55096898606640910)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_TASK_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.id'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55097001562640912)
,p_event_id=>wwv_flow_imp.id(55096898606640910)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_approval.set_task_parameter_values(',
'        p_task_id     => :P1_TASK_ID',
'        ,p_parameters => apex_approval.t_task_parameters(',
'            1 => apex_approval.t_task_parameter(',
'                static_id => ''DIRECTION''',
'                ,string_value => ''RIGHT''',
'            )',
'        )',
'    );',
'    apex_approval.complete_task(',
'        p_task_id => :P1_TASK_ID',
'        ,p_autoclaim => true',
'    );',
'end;'))
,p_attribute_02=>'P1_TASK_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55097197018640913)
,p_event_id=>wwv_flow_imp.id(55096898606640910)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>unistr('apex.message.showPageSuccess("\53F3\306B\66F2\304C\308A\307E\3057\305F\3002");')
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(55097528865640917)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_WORKFLOW'
,p_process_name=>'Start Workflow'
,p_attribute_01=>'START'
,p_attribute_02=>wwv_flow_imp.id(54697959517232608)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(55097426812640916)
,p_internal_uid=>55097528865640917
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(55097668805640918)
,p_page_id=>1
,p_workflow_variable_id=>wwv_flow_imp.id(54699250501232621)
,p_page_process_id=>wwv_flow_imp.id(55097528865640917)
,p_value_type=>'ITEM'
,p_value=>'P1_CORNER'
);
wwv_flow_imp.component_end;
end;
/
