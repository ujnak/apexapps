prompt --application/shared_components/workflow/task_definitions/方向を決定する
begin
--   Manifest
--     TASK_DEF: 方向を決定する
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>324
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(55087925545146665)
,p_name=>unistr('\65B9\5411\3092\6C7A\5B9A\3059\308B')
,p_static_id=>'DECIDE_DIRECTION'
,p_subject=>unistr('\6B69\304F\65B9\5411 - &CORNER.')
,p_task_type=>'ACTION'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(53427663305701505)
,p_task_def_id=>wwv_flow_imp.id(55087925545146665)
,p_label=>'Corner'
,p_static_id=>'CORNER'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(53427937247701507)
,p_task_def_id=>wwv_flow_imp.id(55087925545146665)
,p_label=>'Direction'
,p_static_id=>'DIRECTION'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_is_visible=>true
,p_is_updatable=>true
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(55088275605146669)
,p_task_def_id=>wwv_flow_imp.id(55087925545146665)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'APEXDEV'
);
wwv_flow_imp.component_end;
end;
/
