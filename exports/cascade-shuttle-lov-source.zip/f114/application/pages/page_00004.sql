prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>unistr('\30EA\30D5\30EC\30C3\30B7\30E5')
,p_alias=>'REFRESH'
,p_step_title=>unistr('\30EA\30D5\30EC\30C3\30B7\30E5')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221216014640'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43730513949877871)
,p_plug_name=>unistr('\30EA\30D5\30EC\30C3\30B7\30E5')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(22142406583153274)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(22027321448153215)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(22204517679153311)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22297320451882357)
,p_name=>'P4_DEPTNO'
,p_item_sequence=>10
,p_prompt=>'DEPT'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>'select dname d, ''EMP_'' || dname r from dept'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(22200498000153307)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'ALL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22297714364882357)
,p_name=>'P4_EMPNO'
,p_item_sequence=>20
,p_prompt=>'EMP'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_tables apex_t_varchar2;',
'    l_sql varchar2(4000);',
'begin',
'    if :P4_DEPTNO is null then',
'        return ''select null d, null r from dual where 1<>1'';',
'    end if;',
'    l_tables := apex_string.split(:P4_DEPTNO, '':'');',
'    for i in 1..l_tables.count',
'    loop',
'        if l_sql is not null then',
'            l_sql := l_sql || '' union '';',
'        end if;',
'        l_sql := l_sql || ''select ename d, empno r from '' || dbms_assert.enquote_name(l_tables(i));',
'    end loop;',
'    return l_sql;',
'end;'))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(22200498000153307)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'ALL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21435087477995521)
,p_name=>unistr('\8868\540D\306E\5909\66F4')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P4_DEPTNO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21435261281995523)
,p_event_id=>wwv_flow_imp.id(21435087477995521)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('\5909\66F4\3057\305F\5024\3092\30B5\30FC\30D0\30FC\306B\9001\4FE1')
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P4_DEPTNO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21435127376995522)
,p_event_id=>wwv_flow_imp.id(21435087477995521)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>unistr('\30B7\30E3\30C8\30EB\306E\30EA\30D5\30EC\30C3\30B7\30E5')
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_EMPNO'
);
wwv_flow_imp.component_end;
end;
/
