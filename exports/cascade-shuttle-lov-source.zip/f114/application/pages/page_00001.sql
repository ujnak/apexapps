prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\30AB\30B9\30B1\30FC\30C9\30FB\30B7\30E3\30C8\30EB')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221216014519'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21434854773995519)
,p_plug_name=>unistr('\30AB\30B9\30B1\30FC\30C9\30FB\30B7\30E3\30C8\30EB')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(22142406583153274)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(22027321448153215)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(22204517679153311)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21434457285995515)
,p_name=>'P1_DEPTNO'
,p_item_sequence=>10
,p_prompt=>'DEPT'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>'select dname d, deptno r from dept'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(22200498000153307)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'ALL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21434734300995518)
,p_name=>'P1_EMPNO'
,p_item_sequence=>20
,p_prompt=>'EMP'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ename d, empno r from emp',
'where deptno in (',
'    select column_value from table(apex_string.split(:P1_DEPTNO,'':''))',
')'))
,p_lov_cascade_parent_items=>'P1_DEPTNO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(22200498000153307)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'ALL'
);
wwv_flow_imp.component_end;
end;
/
