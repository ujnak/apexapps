prompt --application/shared_components/data_loads/employees
begin
--   Manifest
--     DATA LOAD: Employees
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>314
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(33434767526936771)
,p_name=>'Employees'
,p_format=>'CSV'
,p_encoding=>'utf-8'
,p_csv_enclosed=>'"'
,p_has_header_row=>true
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(33435022591936820)
,p_data_profile_id=>wwv_flow_imp.id(33434767526936771)
,p_name=>'EMPID'
,p_sequence=>1
,p_is_primary_key=>true
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_selector_type=>'NAME'
,p_selector=>'EMPID'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(33435316128936822)
,p_data_profile_id=>wwv_flow_imp.id(33434767526936771)
,p_name=>'NAME'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>320
,p_selector_type=>'NAME'
,p_selector=>'NAME'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(33450783474960842)
,p_data_profile_id=>wwv_flow_imp.id(33434767526936771)
,p_name=>'HIRE_DATE'
,p_sequence=>12
,p_column_type=>'SQL_EXPRESSION'
,p_data_type=>'DATE'
,p_has_time_zone=>true
,p_transform_type=>'SQL_EXPRESSION'
,p_expression1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'case when (select hire_date from tst_employees where empid = :apex$c1) is null',
'then sysdate',
'else (select hire_date from tst_employees where empid = :apex$c1)',
'end'))
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(33451135471963767)
,p_data_profile_id=>wwv_flow_imp.id(33434767526936771)
,p_name=>'IS_NEW'
,p_sequence=>22
,p_column_type=>'SQL_EXPRESSION'
,p_data_type=>'VARCHAR2'
,p_max_length=>1
,p_has_time_zone=>true
,p_transform_type=>'SQL_EXPRESSION'
,p_expression1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'case when (select hire_date from tst_employees where empid = :apex$c1) is null',
'then ''Y''',
'else ''N''',
'end'))
);
wwv_flow_imp_shared.create_load_table(
 p_id=>wwv_flow_imp.id(33435548944936822)
,p_name=>'Employees'
,p_static_id=>'employees'
,p_target_type=>'TABLE'
,p_table_name=>'TST_EMPLOYEES'
,p_data_profile_id=>wwv_flow_imp.id(33434767526936771)
,p_loading_method=>'MERGE'
,p_commit_interval=>200
,p_error_handling=>'ABORT'
,p_skip_validation=>'N'
);
wwv_flow_imp.component_end;
end;
/
