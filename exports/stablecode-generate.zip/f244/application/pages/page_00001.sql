prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>244
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Generate Code'
,p_allow_duplicate_submissions=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230817025409'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61590016324142236)
,p_plug_name=>'Generate Code'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(61381862853142016)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(60044295974031832)
,p_button_sequence=>50
,p_button_name=>'GENERATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(61470813915142089)
,p_button_image_alt=>'Generate'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60044151770031831)
,p_name=>'P1_INPUT'
,p_item_sequence=>40
,p_prompt=>'Input'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(61468385018142086)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60044328622031833)
,p_name=>'P1_CODE'
,p_data_type=>'CLOB'
,p_item_sequence=>60
,p_prompt=>'Code'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>30
,p_field_template=>wwv_flow_imp.id(61468385018142086)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60044691469031836)
,p_name=>'P1_TEMPERATURE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_default=>'0.1'
,p_prompt=>'temperature'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(61468385018142086)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60044755174031837)
,p_name=>'P1_TOP_K'
,p_is_required=>true
,p_item_sequence=>20
,p_item_default=>'2'
,p_prompt=>'top_k'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(61468385018142086)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60044866474031838)
,p_name=>'P1_TOP_P'
,p_is_required=>true
,p_item_sequence=>30
,p_item_default=>'0.95'
,p_prompt=>'top_p'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(61468385018142086)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(60044415505031834)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generate Code'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request json_object_t;',
'    l_request_clob clob;',
'    l_response clob;',
'    e_codegen_failed exception;',
'begin',
'    l_request := json_object_t();',
'    l_request.put(''input'', :P1_INPUT);',
'    l_request.put(''temperature'', to_number(:P1_TEMPERATURE));',
'    l_request.put(''top_k'', to_number(:P1_TOP_K));',
'    l_request.put(''top_p'', to_number(:P1_TOP_P));',
'    l_request_clob := l_request.to_clob();',
'    apex_debug.info(l_request_clob);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => :G_SERVER || ''/generate''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'        ,p_transfer_timeout => 720',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_codegen_failed;',
'    end if;',
'    :P1_CODE := l_response;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(60044295974031832)
,p_internal_uid=>60044415505031834
);
wwv_flow_imp.component_end;
end;
/
