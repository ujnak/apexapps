prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 242
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>242
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000B2494441545847636CDC1DFF9F610001E3A8034643603404464360D087C0AFEFBF1944D86518FEFF66645096D4C42833EF3EBF';
wwv_flow_imp.g_varchar2_table(2) := 'CEC0C88ABD30FDC9F085E127D357BCE52CC192F0F75B6606614111B21CF0F6FD1B0656E1BF943980EF9F3883B28C3AC3FF1FCC0CF61ADE18861DBCB195819103BB25779FDC64F8C4F472883B60340A464360C073C168147C7EFB8D415A5091AC92F0E9FB';
wwv_flow_imp.g_varchar2_table(3) := 'FB0CBCC25C941544B46E3013AC0B461D301A02A321301A02B40E0100AAD9E461E2D037480000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(57506714561202108)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
