prompt --application/shared_components/logic/application_items/g_preauth_url
begin
--   Manifest
--     APPLICATION ITEM: G_PREAUTH_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>220
,p_default_id_offset=>35161692422838330
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(69329059308607481)
,p_name=>'G_PREAUTH_URL'
,p_protection_level=>'I'
);
wwv_flow_imp.component_end;
end;
/
