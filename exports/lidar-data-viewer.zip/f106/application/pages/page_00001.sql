prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>7601775501100353
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('LiDAR\30C7\30FC\30BF\30FB\30D3\30E5\30EF\30FC')
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'  {',
'    "imports": {',
'      "three": "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js",',
'      "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/"',
'    }',
'  }',
'</script>'))
,p_javascript_file_urls=>'[module]#APP_FILES#pointcloud#MIN#.js'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#canvas-container {',
'    flex: 1;',
'    width: 100%;',
'    height: 1000px;',
'    position: relative;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21038752376687306)
,p_plug_name=>'Controls'
,p_region_name=>'CONTROLS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21038803404687307)
,p_plug_name=>'Canvas'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>'<div id="canvas-container"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21384508051963370)
,p_plug_name=>unistr('LiDAR\30C7\30FC\30BF\30FB\30D3\30E5\30EF\30FC')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21038977950687308)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(21038752376687306)
,p_button_name=>'GENERATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\70B9\7FA4\30C7\30FC\30BF\306E\8AAD\307F\8FBC\307F')
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="GENERATE"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21039097731687309)
,p_name=>'P1_ZOOM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(21038752376687306)
,p_prompt=>unistr('\30BA\30FC\30E0')
,p_display_as=>'PLUGIN_UNITEDCODES_RANGE_SLIDER'
,p_cHeight=>1
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'    config.numberFormat = {',
'        "decimals": 2',
'    };',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'number',
  'attribute_02', '1',
  'attribute_03', '0',
  'attribute_04', '5',
  'attribute_08', '0.01',
  'attribute_09', 'horizontal',
  'attribute_10', 'enable-ticks:enable-tooltip:connects-bar',
  'attribute_11', '6',
  'attribute_13', '#0076df')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21039381962687312)
,p_name=>'P1_ROTATION_H'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(21038752376687306)
,p_prompt=>unistr('\6C34\5E73\56DE\8EE2')
,p_display_as=>'PLUGIN_UNITEDCODES_RANGE_SLIDER'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'    config.numberFormat = {',
unistr('        "postfix": "\00B0"'),
'    };',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'number',
  'attribute_02', '1',
  'attribute_03', '0',
  'attribute_04', '360',
  'attribute_08', '1',
  'attribute_09', 'horizontal',
  'attribute_10', 'enable-ticks:enable-tooltip',
  'attribute_11', '5')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21039632255687315)
,p_name=>'P1_ROTATION_V'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(21038752376687306)
,p_prompt=>unistr('\5782\76F4\56DE\8EE2')
,p_display_as=>'PLUGIN_UNITEDCODES_RANGE_SLIDER'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'    config.numberFormat = {',
unistr('        "postfix": "\00B0"'),
'    };',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'number',
  'attribute_02', '1',
  'attribute_03', '-90',
  'attribute_04', '90',
  'attribute_08', '1',
  'attribute_09', 'horizontal',
  'attribute_10', 'enable-ticks:enable-tooltip',
  'attribute_11', '5')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21039974149687318)
,p_name=>'P1_CENTER_X'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(21038752376687306)
,p_prompt=>unistr('\4E2D\5FC3 X')
,p_display_as=>'PLUGIN_UNITEDCODES_RANGE_SLIDER'
,p_cHeight=>1
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'    config.numberFormat = {',
'        "decimals": 2',
'    };',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'number',
  'attribute_02', '1',
  'attribute_03', '-2',
  'attribute_04', '2',
  'attribute_08', '0.01',
  'attribute_09', 'horizontal',
  'attribute_10', 'enable-ticks:enable-tooltip',
  'attribute_11', '5')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21040245773687321)
,p_name=>'P1_CENTER_Y'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(21038752376687306)
,p_prompt=>unistr('\4E2D\5FC3 Y')
,p_display_as=>'PLUGIN_UNITEDCODES_RANGE_SLIDER'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'    config.numberFormat = {',
'        "decimals": 2',
'    };',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'number',
  'attribute_02', '1',
  'attribute_03', '-2',
  'attribute_04', '2',
  'attribute_08', '0.01',
  'attribute_09', 'horizontal',
  'attribute_10', 'enable-ticks:enable-tooltip',
  'attribute_11', '5')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21040597400687324)
,p_name=>'P1_CENTER_Z'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(21038752376687306)
,p_prompt=>unistr('\4E2D\5FC3 Z')
,p_display_as=>'PLUGIN_UNITEDCODES_RANGE_SLIDER'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'    config.numberFormat = {',
'        "decimals": 2',
'    };',
'    return config;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'number',
  'attribute_02', '1',
  'attribute_03', '-2',
  'attribute_04', '2',
  'attribute_08', '0.01',
  'attribute_09', 'horizontal',
  'attribute_10', 'enable-ticks:enable-tooltip',
  'attribute_11', '5')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21039102729687310)
,p_name=>'onChange ZOOM'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_ZOOM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_UNITEDCODES_RANGE_SLIDER|ITEM TYPE|uc-rangeslider-change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21039284770687311)
,p_event_id=>wwv_flow_imp.id(21039102729687310)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.findContextById("CONTROLS").invoke("ZOOM", this.browserEvent, this.triggeringElement);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21039442497687313)
,p_name=>'onChange ROTATION_H'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_ROTATION_H'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_UNITEDCODES_RANGE_SLIDER|ITEM TYPE|uc-rangeslider-change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21039586116687314)
,p_event_id=>wwv_flow_imp.id(21039442497687313)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.findContextById("CONTROLS").invoke("ROTATION_H", this.browserEvent, this.triggeringElement);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21039784823687316)
,p_name=>'onChange ROTATION_V'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_ROTATION_V'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_UNITEDCODES_RANGE_SLIDER|ITEM TYPE|uc-rangeslider-change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21039897776687317)
,p_event_id=>wwv_flow_imp.id(21039784823687316)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.findContextById("CONTROLS").invoke("ROTATION_V", this.browserEvent, this.triggeringElement);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21040050463687319)
,p_name=>'onChange CENTER_X'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_CENTER_X'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_UNITEDCODES_RANGE_SLIDER|ITEM TYPE|uc-rangeslider-change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21040107002687320)
,p_event_id=>wwv_flow_imp.id(21040050463687319)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.findContextById("CONTROLS").invoke("CENTER_X", this.browserEvent, this.triggeringElement);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21040313770687322)
,p_name=>'onChange CENTER_Y'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_CENTER_Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_UNITEDCODES_RANGE_SLIDER|ITEM TYPE|uc-rangeslider-change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21040446827687323)
,p_event_id=>wwv_flow_imp.id(21040313770687322)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.findContextById("CONTROLS").invoke("CENTER_Y", this.browserEvent, this.triggeringElement);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21040624607687325)
,p_name=>'onChange CENTER_Z'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_CENTER_Z'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_UNITEDCODES_RANGE_SLIDER|ITEM TYPE|uc-rangeslider-change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21040775506687326)
,p_event_id=>wwv_flow_imp.id(21040624607687325)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.findContextById("CONTROLS").invoke("CENTER_Z", this.browserEvent, this.triggeringElement);'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(21040845940687327)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_POINTS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response json_object_t := json_object_t();',
'    l_blob     blob;',
'    l_compressed_blob blob;',
'    l_points   json_object_t := json_object_t();',
'    l_positions clob;',
'    l_colors    clob;',
'    l_indices   clob;',
'    l_extent    clob;',
'begin',
unistr('    -- \5358\4E00\306ESELECT\6587\3067\5168\3066\306E\914D\5217\3068extent\60C5\5831\3092\53D6\5F97'),
'    select',
'        json_arrayagg(rownum - 1 order by rownum returning clob),',
'        json_arrayagg(json_array(x, y, z) order by rownum returning clob),',
'        json_arrayagg(json_array(',
'            r / 255, ',
'            g / 255, ',
'            b / 255',
'        ) order by rownum returning clob),',
'        json_object(',
'            ''minX'' value min(x),',
'            ''minY'' value min(y),',
'            ''minZ'' value min(z),',
'            ''maxX'' value max(x),',
'            ''maxY'' value max(y),',
'            ''maxZ'' value max(z)',
'            returning clob',
'        )',
'    into l_indices, l_positions, l_colors, l_extent',
'    from myaku_points;',
'    ',
unistr('    -- JSON\30AA\30D6\30B8\30A7\30AF\30C8\69CB\7BC9\FF08\7A7A\30C7\30FC\30BF\306E\30CF\30F3\30C9\30EA\30F3\30B0\4ED8\304D\FF09'),
'    l_response.put(''extent'', json_object_t(l_extent));',
'    ',
unistr('    -- positions, colors\306F\FF12\6B21\5143\306E\914D\5217\3067\8FD4\3059\3002xeogl\5411\3051\306E\30D5\30E9\30C3\30C8\5316\306F\30AF\30E9\30A4\30A2\30F3\30C8\3067\5B9F\65BD\3059\308B\3002'),
'    if l_positions is null or length(l_positions) = 0 then',
'        l_points.put(''positions'', json_array_t());',
'    else',
'        l_points.put(''positions'', json_array_t(l_positions));',
'    end if;',
'    ',
'    if l_colors is null or length(l_colors) = 0 then',
'        l_points.put(''colors'', json_array_t());',
'    else',
'        l_points.put(''colors'', json_array_t(l_colors));',
'    end if;',
'    ',
'    if l_indices is null or length(l_indices) = 0 then',
'        l_points.put(''indices'', json_array_t());',
'    else',
'        l_points.put(''indices'', json_array_t(l_indices));',
'    end if;',
'    ',
'    l_response.put(''points'', l_points);',
'    ',
unistr('    -- JSON\3092BLOB\306B\5909\63DB'),
'    l_blob := l_response.to_blob();',
'    ',
unistr('    -- GZIP\5727\7E2E'),
'    l_compressed_blob := utl_compress.lz_compress(l_blob);',
'    ',
unistr('    -- HTTP\30D8\30C3\30C0\30FC\3068GZIP\5727\7E2E\30C7\30FC\30BF\3092\9001\4FE1'),
'    sys.htp.init;',
'    sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_compressed_blob));',
'    sys.htp.p(''Content-Type: application/json'');',
unistr('    sys.htp.p(''Content-Encoding: gzip'');  -- GZIP\5727\7E2E\3092\901A\77E5'),
'    sys.htp.p(''Content-Disposition: attachment; filename=PointCloud.json.gz'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_compressed_blob);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>21040845940687327
);
wwv_flow_imp.component_end;
end;
/
