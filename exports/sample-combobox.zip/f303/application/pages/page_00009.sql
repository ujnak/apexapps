prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>303
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Fancy Combobox'
,p_alias=>'FANCY-COMBOBOX'
,p_step_title=>'Fancy Combobox'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231208074842'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42047164033496442)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(20766424947674169)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(20668439902674094)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(20846569255674226)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21032628813647765)
,p_button_sequence=>40
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(20844995240674225)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\9001\4FE1')
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41671199151659674)
,p_name=>'P9_FAVORITES'
,p_item_sequence=>10
,p_prompt=>'Favorites'
,p_source=>'select listagg(food_id,'':'') within group (order by food_id asc) from combo_favorites where person_name = :APP_USER group by person_name'
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_COMBOBOX'
,p_named_lov=>'COMBO_FOODS.NAME'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(20842485505674223)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>',
'    <b>&NAME.</b>',
'    {if COUNTRY/}: &COUNTRY.{endif/}',
'    {if DESCRIPTION/}: &DESCRIPTION.{endif/}',
'</div>'))
,p_attribute_04=>'N'
,p_attribute_05=>'7'
,p_attribute_06=>'Y'
,p_attribute_07=>'Y'
,p_attribute_08=>':'
,p_attribute_09=>'0'
,p_attribute_11=>'P9_MANUAL_VALUES'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41671303260659675)
,p_name=>'P9_MANUAL_VALUES'
,p_item_sequence=>20
,p_prompt=>'Manual Values'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(20842485505674223)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41671345779659676)
,p_name=>'P9_ACTUAL_VALUES'
,p_item_sequence=>30
,p_prompt=>'Actual Values'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(20842485505674223)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21035124420647771)
,p_name=>'Change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_FAVORITES'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21035605749647772)
,p_event_id=>wwv_flow_imp.id(21035124420647771)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9_ACTUAL_VALUES'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$v(this.triggeringElement)'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(21034770622647771)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Favorites\306E\767B\9332')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_id combo_foods.id%type;',
'begin',
unistr('    /* \4ECA\307E\3067\767B\9332\3055\308C\3066\3044\308B\597D\307F\306E\98DF\3079\7269\3092\524A\9664\3059\308B\3002 */'),
'    delete from combo_favorites where person_name = :APP_USER;',
unistr('    /* \8868COMBO_FOODS\306B\767B\9332\6E08\307F\306E\98DF\3079\7269\306E\3046\3061\3067\9078\629E\3055\308C\305F\597D\307F\3092\4FDD\5B58\3059\308B\3002 */'),
'    insert into combo_favorites(person_name, food_id)',
'        select :APP_USER, column_value from apex_string.split(:P9_FAVORITES,'':'');',
unistr('    /* \624B\52D5\5165\529B\306E\98DF\3079\7269\306F\8868COMBO_FOODS\306B\767B\9332\3057\305F\306E\3061\3001COMBO_FAVORITES\306B\767B\9332\3059\308B\3002 */'),
'    for c in (',
'        select column_value from apex_string.split(:P9_MANUAL_VALUES,'':'')',
'    )',
'    loop',
unistr('        /* \8868COMBO_FOODS\306B\767B\9332\3059\308B\3002 */'),
'        insert into combo_foods(name) values(c.column_value) returning id into l_id;',
unistr('        /* \8868COMBO_FAVORITES\306B\767B\9332\3059\308B\3002 */'),
'        insert into combo_favorites(person_name, food_id) values(:APP_USER, l_id);',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(21032628813647765)
,p_internal_uid=>21034770622647771
);
wwv_flow_imp.component_end;
end;
/
