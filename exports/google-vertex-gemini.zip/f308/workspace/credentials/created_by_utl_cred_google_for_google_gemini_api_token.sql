prompt --workspace/credentials/created_by_utl_cred_google_for_google_gemini_api_token
begin
--   Manifest
--     CREDENTIAL: Created by UTL_CRED_GOOGLE for GOOGLE_GEMINI_API_TOKEN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>308
,p_default_id_offset=>23779389793247009
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(26387500577852676)
,p_name=>'Created by UTL_CRED_GOOGLE for GOOGLE_GEMINI_API_TOKEN'
,p_static_id=>'GOOGLE_GEMINI_API_TOKEN'
,p_authentication_type=>'HTTP_HEADER'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
