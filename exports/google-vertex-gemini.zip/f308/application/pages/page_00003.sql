prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>308
,p_default_id_offset=>23779389793247009
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Image'
,p_alias=>'IMAGE'
,p_step_title=>'Image'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240115025004'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(70970773869898282)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(47185873239024479)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(47070093660024348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(47248254569024542)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47377238708112478)
,p_button_sequence=>30
,p_button_name=>'RUN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(47246675192024540)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5B9F\884C')
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44418536616258933)
,p_name=>'P3_IMAGE'
,p_item_sequence=>20
,p_prompt=>'Image'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(68017110980124414)
,p_name=>'P3_TEXT'
,p_item_sequence=>10
,p_prompt=>'Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(68017271399124415)
,p_name=>'P3_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_prompt=>'Response'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'MARKDOWN'
,p_attribute_04=>'180'
,p_attribute_25=>'TINYMCE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47379062035112498)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\753B\50CF\3092\542B\3080\547C\3073\51FA\3057')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response        clob;',
'    l_role varchar2(8);',
'    l_blob blob;',
'    l_mime_type varchar2(100);',
'begin',
'    select mime_type, blob_content into l_mime_type, l_blob',
'    from apex_application_temp_files where name = :P3_IMAGE;',
'    utl_vertex_ai_gemini_api.generate_content(',
'        p_project_id       => :G_PROJECT_ID',
'        ,p_region          => :G_REGION',
'        ,p_text            => :P3_TEXT',
'        ,p_image           => l_blob',
'        ,p_mimetype        => l_mime_type',
'        ,p_response        => l_response',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    :P3_RESPONSE := utl_vertex_ai_gemini_api.get_concat_text_in_all_candidates(',
'        p_response => l_response',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(47377238708112478)
,p_internal_uid=>23599672241865489
);
wwv_flow_imp.component_end;
end;
/
