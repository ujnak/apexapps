prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>308
,p_default_id_offset=>23779389793247009
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Embeddings'
,p_alias=>'EMBEDDINGS'
,p_step_title=>'Embeddings'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240115042408'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23801486132634532)
,p_plug_name=>'Text'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(47173434618024471)
,p_plug_display_sequence=>90
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23801584616634533)
,p_plug_name=>'Image'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(47173434618024471)
,p_plug_display_sequence=>100
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23807301190635438)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(47185873239024479)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(47070093660024348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(47248254569024542)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23800582450634523)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(23801584616634533)
,p_button_name=>'COUNT_TOKENS_INLINE_DATA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(47246675192024540)
,p_button_image_alt=>'Count Tokens'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25972519694240642)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(23801584616634533)
,p_button_name=>'EMBED_CONTENT_INLINE_DATA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(47246675192024540)
,p_button_image_alt=>'Embed Content'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23798627759634504)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(23801486132634532)
,p_button_name=>'COUNT_TOKENS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(47246675192024540)
,p_button_image_alt=>'Count Tokens'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23799486421634512)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(23801486132634532)
,p_button_name=>'EMBED_CONTENT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(47246675192024540)
,p_button_image_alt=>'Embed Content'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23798433667634502)
,p_name=>'P7_TEXT'
,p_data_type=>'CLOB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(23801486132634532)
,p_prompt=>'Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23798747838634505)
,p_name=>'P7_TOTAL_TOKENS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(23801486132634532)
,p_prompt=>'Total Tokens'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23800289704634520)
,p_name=>'P7_DIMENSION_TEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(23801486132634532)
,p_prompt=>'Dimension Text'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23800456998634522)
,p_name=>'P7_FILE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(23801584616634533)
,p_prompt=>'File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23801894435634536)
,p_name=>'P7_TOTAL_TOKENS_V'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(23801584616634533)
,p_prompt=>'Total Tokens'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23802065895634538)
,p_name=>'P7_EMBEDDING_TEXT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(23801486132634532)
,p_prompt=>'Embedding Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25972425826240641)
,p_name=>'P7_DIMENSION_IMAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(23801584616634533)
,p_prompt=>'Dimension Image'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25972647583240643)
,p_name=>'P7_EMBEDDING_IMAGE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(23801584616634533)
,p_prompt=>'Embedding Image'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(23798861725634506)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Count Tokens'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'UTL_VERTEX_AI_GEMINI_API'
,p_attribute_04=>'COUNT_TOKENS'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(23798627759634504)
,p_internal_uid=>23798861725634506
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(23798922034634507)
,p_page_process_id=>wwv_flow_imp.id(23798861725634506)
,p_page_id=>7
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P7_TOTAL_TOKENS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(23799072487634508)
,p_page_process_id=>wwv_flow_imp.id(23798861725634506)
,p_page_id=>7
,p_name=>'p_text'
,p_direction=>'IN'
,p_data_type=>'CLOB'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P7_TEXT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(23799125999634509)
,p_page_process_id=>wwv_flow_imp.id(23798861725634506)
,p_page_id=>7
,p_name=>'p_parts'
,p_direction=>'IN'
,p_data_type=>'CLOB'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(23799244518634510)
,p_page_process_id=>wwv_flow_imp.id(23798861725634506)
,p_page_id=>7
,p_name=>'p_credential_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'STATIC'
,p_value=>'&G_CREDENTIAL.'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(25971401129240631)
,p_page_process_id=>wwv_flow_imp.id(23798861725634506)
,p_page_id=>7
,p_name=>'p_project_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'STATIC'
,p_value=>'&G_PROJECT_ID.'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(25971565971240632)
,p_page_process_id=>wwv_flow_imp.id(23798861725634506)
,p_page_id=>7
,p_name=>'p_region'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>60
,p_value_type=>'STATIC'
,p_value=>'&G_REGION.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(23799523514634513)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Embed Content'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'UTL_VERTEX_AI_GEMINI_API'
,p_attribute_04=>'EMBED_CONTENT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(23799486421634512)
,p_internal_uid=>23799523514634513
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(23800927036634527)
,p_page_process_id=>wwv_flow_imp.id(23799523514634513)
,p_page_id=>7
,p_name=>'p_text'
,p_direction=>'IN'
,p_data_type=>'CLOB'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P7_TEXT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(23801267244634530)
,p_page_process_id=>wwv_flow_imp.id(23799523514634513)
,p_page_id=>7
,p_name=>'p_credential_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>60
,p_value_type=>'STATIC'
,p_value=>'&G_CREDENTIAL.'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(25971655845240633)
,p_page_process_id=>wwv_flow_imp.id(23799523514634513)
,p_page_id=>7
,p_name=>'p_project_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>70
,p_value_type=>'STATIC'
,p_value=>'&G_PROJECT_ID.'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(25971784833240634)
,p_page_process_id=>wwv_flow_imp.id(23799523514634513)
,p_page_id=>7
,p_name=>'p_region'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>80
,p_value_type=>'STATIC'
,p_value=>'&G_REGION.'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(25971865580240635)
,p_page_process_id=>wwv_flow_imp.id(23799523514634513)
,p_page_id=>7
,p_name=>'p_model_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>90
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(25971907868240636)
,p_page_process_id=>wwv_flow_imp.id(23799523514634513)
,p_page_id=>7
,p_name=>'p_image'
,p_direction=>'IN'
,p_data_type=>'BLOB'
,p_has_default=>true
,p_display_sequence=>100
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(25972049193240637)
,p_page_process_id=>wwv_flow_imp.id(23799523514634513)
,p_page_id=>7
,p_name=>'p_embedding_text'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>110
,p_value_type=>'ITEM'
,p_value=>'P7_EMBEDDING_TEXT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(25972181985240638)
,p_page_process_id=>wwv_flow_imp.id(23799523514634513)
,p_page_id=>7
,p_name=>'p_embedding_image'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>true
,p_display_sequence=>120
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(25972258837240639)
,p_page_process_id=>wwv_flow_imp.id(23799523514634513)
,p_page_id=>7
,p_name=>'p_dimension_text'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>130
,p_value_type=>'ITEM'
,p_value=>'P7_DIMENSION_TEXT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(25972379552240640)
,p_page_process_id=>wwv_flow_imp.id(23799523514634513)
,p_page_id=>7
,p_name=>'p_dimension_image'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>true
,p_display_sequence=>140
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(23800650848634524)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Count Tokens Inline Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_blob blob;',
'    l_mime_type varchar2(100);',
'    l_values json_array_t;',
'    l_parts    json_array_t  := json_array_t();',
'    l_part     json_object_t;',
'    l_file_clob clob;',
'    l_inline_data json_object_t;',
'begin',
'    select mime_type, blob_content into l_mime_type, l_blob',
'    from apex_application_temp_files where name = :P7_FILE;',
'    l_part := json_object_t();',
'    l_inline_data := json_object_t();',
'    l_inline_data.put(''mimeType'', l_mime_type);',
'    l_file_clob := apex_web_service.blob2clobbase64(l_blob, ''N'',''N'');',
'    l_inline_data.put(''data'', l_file_clob);',
'    l_part.put(''inlineData'', l_inline_data);',
'    l_parts.append(l_part);',
'    :P7_TOTAL_TOKENS_V := utl_vertex_ai_gemini_api.count_tokens(',
'        p_project_id => :G_PROJECT_ID',
'        ,p_region    => :G_REGION',
'        ,p_parts => l_parts.to_clob()',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
' end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(23800582450634523)
,p_internal_uid=>23800650848634524
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25972771381240644)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Embed Content Inline Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_blob blob;',
'    l_mime_type varchar2(100);',
'    l_embedding_text clob;',
'    l_dimension_text number;',
'begin',
'    select mime_type, blob_content into l_mime_type, l_blob',
'    from apex_application_temp_files where name = :P7_FILE;',
'    utl_vertex_ai_gemini_api.embed_content(',
'        p_project_id => :G_PROJECT_ID',
'        ,p_region    => :G_REGION',
'        ,p_image => l_blob',
'        ,p_credential_static_id => :G_CREDENTIAL',
'        ,p_embedding_image => :P7_EMBEDDING_IMAGE',
'        ,p_dimension_image => :P7_DIMENSION_IMAGE',
'        ,p_embedding_text => l_embedding_text',
'        ,p_dimension_text => l_dimension_text',
'    );',
' end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(25972519694240642)
,p_internal_uid=>25972771381240644
);
wwv_flow_imp.component_end;
end;
/
