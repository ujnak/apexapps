prompt --application/shared_components/user_interface/lovs/google_cloud_storage_files
begin
--   Manifest
--     GOOGLE CLOUD STORAGE FILES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>308
,p_default_id_offset=>23779389793247009
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(27372698737024255)
,p_lov_name=>'GOOGLE CLOUD STORAGE FILES'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(27330123015961142)
,p_use_local_sync_table=>false
,p_return_column_name=>'NAME'
,p_display_column_name=>'NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(27373342896032708)
,p_query_column_name=>'NAME'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(27373771179032709)
,p_query_column_name=>'CONTENTTYPE'
,p_heading=>'Contenttype'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(27372911141024258)
,p_web_src_param_id=>wwv_flow_imp.id(27330706423961147)
,p_shared_lov_id=>wwv_flow_imp.id(27372698737024255)
,p_value_type=>'STATIC'
,p_value=>'&G_BUCKET_NAME.'
);
wwv_flow_imp.component_end;
end;
/
