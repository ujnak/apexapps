prompt --application/create_application
begin
--   Manifest
--     FLOW: 207
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>207
,p_default_id_offset=>48710702492848853
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_flow(
 p_id=>wwv_flow.g_flow_id
,p_owner=>nvl(wwv_flow_application_install.get_schema,'WKSP_APEXDEV')
,p_name=>nvl(wwv_flow_application_install.get_application_name,'Sample Google Analytics 4')
,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'SAMPLE-GOOGLE-ANALYTICS-4')
,p_page_view_logging=>'YES'
,p_page_protection_enabled_y_n=>'Y'
,p_checksum_salt=>'A085130856D99DE84AF689E805A4DE3BE12CFB0393F8380D04F4A3E8E56CDBFD'
,p_bookmark_checksum_function=>'SH512'
,p_compatibility_mode=>'21.2'
,p_flow_language=>'ja'
,p_flow_language_derived_from=>'FLOW_PRIMARY_LANGUAGE'
,p_allow_feedback_yn=>'Y'
,p_date_format=>'DS'
,p_timestamp_format=>'DS'
,p_timestamp_tz_format=>'DS'
,p_direction_right_to_left=>'N'
,p_flow_image_prefix => nvl(wwv_flow_application_install.get_image_prefix,'')
,p_authentication_id=>wwv_flow_imp.id(95934714935989435)
,p_application_tab_set=>0
,p_logo_type=>'T'
,p_logo_text=>'Sample Google Analytics 4'
,p_proxy_server=>nvl(wwv_flow_application_install.get_proxy,'')
,p_no_proxy_domains=>nvl(wwv_flow_application_install.get_no_proxy_domains,'')
,p_flow_version=>'Release 1.0'
,p_flow_status=>'AVAILABLE_W_EDIT_LINK'
,p_flow_unavailable_text=>unistr('\3053\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306F\3001\73FE\6642\70B9\3067\306F\4F7F\7528\3067\304D\307E\305B\3093\3002')
,p_exact_substitutions_only=>'Y'
,p_browser_cache=>'N'
,p_browser_frame=>'D'
,p_rejoin_existing_sessions=>'N'
,p_csv_encoding=>'Y'
,p_auto_time_zone=>'N'
,p_substitution_string_01=>'APP_NAME'
,p_substitution_value_01=>'Sample Google Analytics 4'
,p_substitution_string_02=>'G_PROPERTY_ID'
,p_substitution_string_03=>'G_GA4_CREDENTIAL_TOKEN'
,p_substitution_value_03=>'GOOGLE_GA4_API_TOKEN'
,p_substitution_string_04=>'G_SECRET_ID'
,p_substitution_string_05=>'G_OCI_CREDENTIAL'
,p_substitution_value_05=>'OCI_API_ACCESS'
,p_substitution_string_06=>'G_REGION'
,p_substitution_value_06=>'us-ashburn-1'
,p_substitution_string_07=>'G_GA4_CREDENTIAL_JWT'
,p_substitution_value_07=>'GOOGLE_GA4_API_JWT'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240307050720'
,p_file_prefix => nvl(wwv_flow_application_install.get_static_app_file_prefix,'')
,p_files_version=>8
,p_print_server_type=>'NATIVE'
,p_file_storage=>'DB'
,p_file_remote_server_id=>wwv_flow_imp.id(19227142993348355)
,p_is_pwa=>'Y'
,p_pwa_is_installable=>'N'
,p_pwa_is_push_enabled=>'N'
);
wwv_flow_imp.component_end;
end;
/
