prompt --application/deployment/install/install_ga4master
begin
--   Manifest
--     INSTALL: INSTALL-GA4MASTER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>207
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(48709831965823196)
,p_install_id=>wwv_flow_imp.id(48707720811813616)
,p_name=>'GA4MASTER'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
unistr('    --GA4_DIMENSIONS: 194/10000 \884C\304C\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\307E\3057\305F, APEX$DATA$PKG/GA4_DIMENSIONS$900133'),
'    apex_data_install.load_supporting_object_data(p_table_name => ''GA4_DIMENSIONS'', p_delete_after_install => true );',
unistr('    --GA4_METRICS: 87/10000 \884C\304C\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\307E\3057\305F, APEX$DATA$PKG/GA4_METRICS$706716'),
'    apex_data_install.load_supporting_object_data(p_table_name => ''GA4_METRICS'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
