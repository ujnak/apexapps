prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>207
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Google Analytics 4'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240207081026'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47525056667141091)
,p_plug_name=>'Sample Google Analytics 4'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(47294312055140637)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47529324543150506)
,p_button_sequence=>60
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(47400804301140708)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47528824975150501)
,p_name=>'P1_DIMENSIONS'
,p_item_sequence=>20
,p_prompt=>'Dimensions'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select api_name from ga4_dimensions'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(47398336315140705)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_11=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47528919749150502)
,p_name=>'P1_METRICS'
,p_item_sequence=>30
,p_prompt=>'Metrics'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select api_name from ga4_metrics'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(47398336315140705)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_11=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47529050650150503)
,p_name=>'P1_START_DATE'
,p_item_sequence=>40
,p_prompt=>'startDate'
,p_format_mask=>'YYYY-MM-DD'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(47398336315140705)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47529156871150504)
,p_name=>'P1_ENDDATE'
,p_item_sequence=>50
,p_prompt=>'endDate'
,p_format_mask=>'YYYY-MM-DD'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(47398336315140705)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47529209269150505)
,p_name=>'P1_TITLE'
,p_item_sequence=>10
,p_prompt=>'Title'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(47398336315140705)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47529519036150508)
,p_name=>'P1_DATA_ID'
,p_item_sequence=>70
,p_item_default=>'select id from ga4_data where title = :P1_TITLE'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Data Id'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select title d, id r from ga4_data'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(47398336315140705)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'REDIRECT_SET_VALUE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47529665584150509)
,p_name=>'P1_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>80
,p_prompt=>'Response'
,p_source=>'select response from ga4_data where id = :P1_DATA_ID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>30
,p_field_template=>wwv_flow_imp.id(47398336315140705)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47529414224150507)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Call GA4 DATA API'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request json_object_t;',
'    l_request_clob clob;',
'    l_dimension json_object_t;',
'    l_dimension_array json_array_t := json_array_t();',
'    l_metric    json_object_t;',
'    l_metric_array json_array_t := json_array_t();',
'    l_date_range json_object_t;',
'    l_date_range_array json_array_t := json_array_t();',
'    l_response clob;',
'    e_call_api_failed exception;',
'begin',
'    l_request := json_object_t();',
'    /* prep dimension */',
'    for r in (select column_value from apex_string.split(:P1_DIMENSIONS,'':''))',
'    loop',
'        l_dimension := json_object_t();',
'        l_dimension.put(''name'', r.column_value);',
'        l_dimension_array.append(l_dimension);',
'    end loop;',
'    l_request.put(''dimensions'', l_dimension_array);',
'    /* prep metrics */',
'    for r in (select column_value from apex_string.split(:P1_METRICS, '':''))',
'    loop',
'        l_metric := json_object_t();',
'        l_metric.put(''name'', r.column_value);',
'        l_metric_array.append(l_metric);',
'    end loop;',
'    l_request.put(''metrics'', l_metric_array);',
'    /* date range */',
'    l_date_range := json_object_t();',
'    l_date_range.put(''startDate'', :P1_START_DATE);',
'    l_date_range.put(''endDate'',   :P1_ENDDATE);',
'    l_date_range.put(''name'', ''first_period'');',
'    l_date_range_array.append(l_date_range);',
'    l_request.put(''dateRanges'', l_date_range_array);',
'    l_request_clob := l_request.to_clob();',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''applicaton/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => ''https://analyticsdata.googleapis.com/v1beta/properties/'' || :G_PROPERTY_ID || '':runReport''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_call_api_failed;',
'    end if;',
'    insert into ga4_data(title, response) values(:P1_TITLE, l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(47529324543150506)
,p_internal_uid=>47529414224150507
);
wwv_flow_imp.component_end;
end;
/
