prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>115
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(16066634923721677)
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Inline Editor'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.ckeditor.com/ckeditor5/35.0.1/inline/ckeditor.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// Inline editor\3092\751F\6210\3059\308B\3002'),
'InlineEditor',
'    .create( document.querySelector( ''#editor'' ) )',
'    .then ( editor => {',
'        inlineEditor = editor;',
'        console.log(editor);',
'    })',
'    .catch( error => {',
'        console.error( error );',
'    } );',
'',
unistr('// Inline editor\3078\306E\30C7\30FC\30BF\306E\53D6\5F97\3002'),
'apex.server.process (',
'    "GET_DOCUMENT",',
'    {',
'        x01: "test",',
'        pageItems: "#P1_ID"',
'    },',
'    {',
'        dataType: "text",',
'        success: function( pData ) {',
unistr('            // Inline editor\3078\30C7\30FC\30BF\3092\8A2D\5B9A\3059\308B\3002'),
'            inlineEditor.data.set(pData);',
'        }',
'    }',
');',
'',
'//',
'apex.actions.add([',
'{',
'    name: "store_document",',
'    action: function ( event, element, args ) {',
'        apex.server.process(',
'            "STORE_DOCUMENT",',
'            {',
'                x01: inlineEditor.data.get(),',
'                pageItems: "#P1_ID"',
'            }, ',
'            {',
'                dataType: ''text'',',
'                success: function (data) {',
unistr('                    // \7279\306B\4F55\3082\3057\306A\3044\3002'),
'                },',
'                error: function( jqXHR, textStatus, errorThrown ) {',
unistr('                    // \30A8\30E9\30FC\51E6\7406\3092\8A18\8FF0\3059\308B\3002'),
'                }',
'            }',
'        );',
'    }',
'}',
']);'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20220829052258'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15858384430947310)
,p_plug_name=>'Inline Editor'
,p_region_name=>'editor'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15909876851721568)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16075212230721725)
,p_plug_name=>'Inline Editor'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(15941068233721586)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15858879230947315)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(16075212230721725)
,p_button_name=>'B_STORE_DOCUMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(16041736995721645)
,p_button_image_alt=>unistr('\4FDD\5B58')
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$store_document"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15858414985947311)
,p_name=>'P1_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15858599119947312)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\30B3\30EC\30AF\30B7\30E7\30F3\306E\521D\671F\5316')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.create_or_truncate_collection(',
'    p_collection_name => ''INLINE_EDITOR''',
');',
':P1_ID := apex_collection.add_member(',
'    p_collection_name => ''INLINE_EDITOR''',
');'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P1_ID'
,p_process_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15858619494947313)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DOCUMENT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob clob;',
'begin',
'    select clob001 into l_clob from apex_collections',
'    where collection_name = ''INLINE_EDITOR'' and seq_id = :P1_ID;',
'    htp.p(l_clob);',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15858739839947314)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'STORE_DOCUMENT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_collection.update_member_attribute (',
'        p_collection_name => ''INLINE_EDITOR''',
'        , p_seq => :P1_ID',
'        , p_clob_number => 1',
'        , p_clob_value => apex_application.g_x01',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
