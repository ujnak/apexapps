prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>244
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Dynamic SQL Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(132152471928770687)
,p_plug_name=>'Dynamic SQL Report'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(131921432650769999)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(133170139340806028)
,p_name=>'Dynamic SQL Report'
,p_template=>wwv_flow_imp.id(131944947837770049)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql varchar2(32767);',
'begin',
'    l_sql := :P1_SELECT;',
'    if l_sql is null or l_sql = '''' then',
unistr('        -- \FF10\884C\3092\8FD4\3059SELECT\6587\3092\623B\3059\3068\3001\30EC\30DD\30FC\30C8\306F\8868\793A\3055\308C\306A\3044\3002'),
'        return ''select * from dual where 1 <> 1'';',
'    end if;',
'    return l_sql;',
'end;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(131993160333770153)
,p_plug_query_max_columns=>10
,p_query_headings=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_header    varchar2(32767);',
'    l_cursor    integer;',
'    l_col_cnt   integer;',
'    l_desc_tab  dbms_sql.desc_tab;',
'    l_sql       varchar2(32767);',
'begin',
'    l_sql := :P1_SELECT;',
'    if l_sql is null or l_sql = '''' then',
unistr('        -- SELECT\6587\304C\7121\3051\308C\3070\5217\540D\6307\5B9A\306F\4E0D\8981\3002'),
'        return '''';',
'    end if;',
unistr('    -- \6700\521D\306B\30AB\30FC\30BD\30EB\3092\30AA\30FC\30D7\30F3\3059\308B\3002'),
'    l_cursor := dbms_sql.open_cursor;',
unistr('    -- \30AA\30FC\30D7\30F3\3057\305F\30AB\30FC\30BD\30EB\3092\4F7F\3063\3066\3001\4E0E\3048\3089\308C\305FSELECT\6587\3092\89E3\6790\3059\308B\3002'),
'    dbms_sql.parse(l_cursor, l_sql, dbms_sql.native);',
unistr('    -- \5217\60C5\5831\3092\53D6\5F97\3059\308B\3002'),
'    dbms_sql.describe_columns(l_cursor, l_col_cnt, l_desc_tab);',
unistr('    -- \5217\60C5\5831\304B\3089\30EC\30DD\30FC\30C8\30FB\30D8\30C3\30C0\30FC\3092\8A2D\5B9A\3059\308B\3002'),
'    for i in 1 .. l_col_cnt',
'    loop',
unistr('        -- \5217\540D\3092\30D8\30C3\30C0\30FC\306B\8FFD\52A0\3059\308B\3002'),
'        if i = 1 then',
'            l_header := l_desc_tab(i).col_name;',
'        else',
'            l_header := l_header || '':'' || l_desc_tab(i).col_name;',
'        end if;',
'        apex_debug.info(''header: %s'', l_header);',
'    end loop;',
unistr('    -- \30AB\30FC\30BD\30EB\3092\30AF\30ED\30FC\30BA\3059\308B\3002'),
'    dbms_sql.close_cursor(l_cursor);',
'    return l_header;',
'exception',
'    when others then',
'        if dbms_sql.is_open(l_cursor) then',
'            dbms_sql.close_cursor(l_cursor);',
'        end if;',
'        /*',
unistr('         * SELECT\6587\306E\554F\984C\306F\30EC\30DD\30FC\30C8\306E\30BD\30FC\30B9\5074\3067\4F8B\5916\304C\767A\751F\3059\308B\3002'),
unistr('         * \305D\306E\305F\3081\3001\30D8\30C3\30C0\30FC\306E\8A2D\5B9A\3067\306F\4F8B\5916\306F\7121\8996\3059\308B\3002'),
'         */',
'        -- raise; ',
'end;'))
,p_query_headings_type=>'FUNCTION_BODY_RETURNING_COLON_DELIMITED_LIST'
,p_query_num_rows=>15
,p_query_options=>'GENERIC_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(133170393772806030)
,p_query_column_id=>1
,p_column_alias=>'COL01'
,p_column_display_sequence=>10
,p_column_heading=>'Col01'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(133170489776806031)
,p_query_column_id=>2
,p_column_alias=>'COL02'
,p_column_display_sequence=>20
,p_column_heading=>'Col02'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(133170523909806032)
,p_query_column_id=>3
,p_column_alias=>'COL03'
,p_column_display_sequence=>30
,p_column_heading=>'Col03'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(133170641218806033)
,p_query_column_id=>4
,p_column_alias=>'COL04'
,p_column_display_sequence=>40
,p_column_heading=>'Col04'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(133170733801806034)
,p_query_column_id=>5
,p_column_alias=>'COL05'
,p_column_display_sequence=>50
,p_column_heading=>'Col05'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(133170837593806035)
,p_query_column_id=>6
,p_column_alias=>'COL06'
,p_column_display_sequence=>60
,p_column_heading=>'Col06'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(133170937158806036)
,p_query_column_id=>7
,p_column_alias=>'COL07'
,p_column_display_sequence=>70
,p_column_heading=>'Col07'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(133171053162806037)
,p_query_column_id=>8
,p_column_alias=>'COL08'
,p_column_display_sequence=>80
,p_column_heading=>'Col08'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(133171105578806038)
,p_query_column_id=>9
,p_column_alias=>'COL09'
,p_column_display_sequence=>90
,p_column_heading=>'Col09'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(133171291983806039)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>100
,p_column_heading=>'Col10'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132165589983799514)
,p_button_sequence=>10
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(132028373957770238)
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126290186600997523)
,p_name=>'P1_SELECT'
,p_item_sequence=>20
,p_prompt=>'Select Statement'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(132025847051770232)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
