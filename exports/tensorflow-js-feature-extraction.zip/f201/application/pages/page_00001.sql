prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>201
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'TensorFlow.js'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/tf.min.js'
,p_javascript_code=>'var model;'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tf.ready().then(() => {',
'    /*',
'     * Learning TensorFlow.js, Grant Laborde, O''Reilly Media, Inc.',
'     * Chapter 5: Introducing Model',
'     * ISBN-13: 978-1492090793',
'     */',
'    const modelPath = "https://raw.githubusercontent.com/GantMan/learn-tfjs/refs/heads/master/chapter5/simple/simple-object-localization/model/tfjs_quant_uint8/model.json";',
'    ',
'    apex.items.P1_STATUS.setValue("TensorFlow.js is Ready, Loading Model...");',
'    tf.loadLayersModel(modelPath, { fromTFHub: true }).then((m) => {',
'        model = m;',
'        apex.items.P1_STATUS.setValue("Model is Loaded");',
'    });',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105695696212803720)
,p_plug_name=>'Image'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(106035594333808401)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="position: relative;" >',
'  <img id="pet" src="" class="w95p" />',
'  <canvas id="detection" style="position: absolute; left: 0;" ><canvas/>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105695705537803721)
,p_button_sequence=>20
,p_button_name=>'DETECT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(106109161896808584)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Detect'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105694953705803713)
,p_name=>'P1_STATUS'
,p_item_sequence=>30
,p_prompt=>'Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(106106467896808574)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105695120400803715)
,p_name=>'P1_IMAGE'
,p_item_sequence=>40
,p_prompt=>'Image'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(106106694958808575)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
,p_attribute_18=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(105695347756803717)
,p_name=>'onChange Image'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_IMAGE'
,p_condition_element=>'P1_IMAGE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105695420060803718)
,p_event_id=>wwv_flow_imp.id(105695347756803717)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// get image file and its URL for img src.',
'const imageFile = this.triggeringElement.files[0];',
'const imageUrl = URL.createObjectURL(imageFile);',
'document.getElementById("pet").src = imageUrl;',
'// Clear Canvas',
'const detection = document.getElementById("detection");',
'const ctx = detection.getContext("2d");',
'ctx.clearRect(9, 0, detection.width, detection.height);',
'// Reset Status',
'apex.items.P1_STATUS.setValue("Ready for Detection");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(105695857097803722)
,p_name=>'onClick DETECT'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(105695705537803721)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105696159716803725)
,p_event_id=>wwv_flow_imp.id(105695857097803722)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tf.tidy(() => {',
'    const petImage = document.getElementById("pet");',
'    const myTensor = tf.browser.fromPixels(petImage);',
'    // Model expects 256x256 0-1 value 3D tensor',
'    const readyfied = tf.image',
'        .resizeNearestNeighbor(myTensor, [256,256], true)',
'        .div(255)',
'        .reshape([1,256,256,3]);',
'    apex.items.P1_STATUS.setValue("Start prediction !");',
'    // predict.',
'    const result = model.predict(readyfied);',
'    result.print();',
'    apex.items.P1_STATUS.setValue("Prediction Done !");',
'    // Draw box on canvas',
'    const detection = document.getElementById("detection");',
'    const imgWidth  = petImage.width;',
'    const imgHeight = petImage.height;',
'    detection.width = imgWidth;',
'    detection.height = imgHeight;',
'    const box = result.dataSync();',
'    const startX = box[0] * imgWidth;',
'    const startY = box[1] * imgHeight;',
'    const width = (box[2] - box[0]) * imgWidth;',
'    const height = (box[3] - box[1]) * imgHeight;',
'    const ctx = detection.getContext("2d");',
'    ctx.strokeStyle = "#0F0";',
'    ctx.lineWidth = 4;',
'    ctx.strokeRect(startX, startY, width, height);',
'});'))
);
wwv_flow_imp.component_end;
end;
/
