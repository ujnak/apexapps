prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>111
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Call n8n Workflow'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18066844446868496)
,p_plug_name=>'Call n8n Workflow'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18071490109176201)
,p_plug_name=>'n8n Callback'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'N8N_CALLBACK'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(18071537176176202)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>18071537176176202
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18071697904176203)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18071789682176204)
,p_db_column_name=>'RESPONSE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Response'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(18077824114265601)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'180779'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:RESPONSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17868116404538748)
,p_button_sequence=>10
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17868069573538747)
,p_name=>'P1_REQUEST'
,p_item_sequence=>20
,p_prompt=>'Request'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>15
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17868232132538749)
,p_name=>'P1_RESPONSE'
,p_item_sequence=>30
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>15
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17868336871538750)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Call n8n Workflow'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_N8N_WEBHOOK_URL constant varchar2(255) := :G_WEBHOOK_URL;',
'    C_JWT_SECRET      constant varchar2(255) := :G_SECRET;',
'    C_ISSUER          constant varchar2(80)  := ''Oracle'';',
'    C_SUBSCRIBER      constant varchar2(80)  := ''Oracle'';',
'    C_AUDIENCE        constant varchar2(80)  := ''n8n'';',
'    l_jwt_value varchar2(32767);',
'    l_secret raw(255);',
'    l_request  clob;',
'    l_response clob;',
'    e_call_n8n_workflow_failed exception;',
'begin',
unistr('    /* JWT\3092\751F\6210\3059\308B\3002 */'),
'    l_secret := utl_raw.cast_to_raw(C_JWT_SECRET);',
'    l_jwt_value := apex_jwt.encode (',
'        p_iss => C_ISSUER,',
'        p_sub => C_SUBSCRIBER,',
'        p_aud => C_AUDIENCE,',
'        p_signature_key => l_secret',
'    );',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', p_reset => false);',
'    apex_web_service.set_request_headers(''Accept'', ''application/json'', p_reset => false);',
unistr('    /* JWT\3092Authorization\30D8\30C3\30C0\30FC\306B\8A2D\5B9A\3059\308B\3002 */'),
'    apex_web_service.set_request_headers(''Authorization'', ''Bearer '' || l_jwt_value, p_reset => false);',
unistr('    /* n8n\306EWebhook\3092\547C\3073\51FA\3059\3002 */'),
'    l_request := :P1_REQUEST;',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_N8N_WEBHOOK_URL,',
'        p_http_method => ''POST'',',
'        p_body => l_request',
'    );',
'    if not apex_web_service.g_status_code between 200 and 300 then',
'        raise e_call_n8n_workflow_failed;',
'    end if;',
'    :P1_RESPONSE := l_response;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(17868116404538748)
,p_internal_uid=>17868336871538750
);
wwv_flow_imp.component_end;
end;
/
