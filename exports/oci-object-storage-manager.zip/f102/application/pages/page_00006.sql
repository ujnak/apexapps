prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'download'
,p_alias=>'DOWNLOAD'
,p_step_title=>'download'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221202040608'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8973349710610811)
,p_name=>'P6_BUCKET_NAME'
,p_item_sequence=>10
,p_prompt=>'Bucket Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8973467042610812)
,p_name=>'P6_OBJECT_NAME'
,p_item_sequence=>20
,p_prompt=>'Object Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8973502983610813)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'download'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response dbms_cloud_oci_obs_object_storage_get_object_response_t;',
'    l_status_code number;',
'    l_blob blob;',
'    l_object_name varchar2(4000);',
'    plsql_sdk_error exception;',
unistr('    -- \65E5\672C\8A9E\306B\5BFE\5FDC\3055\305B\308B'),
'    function cs_workaround(str varchar2)',
'    return varchar2',
'    as',
'    begin',
'        return utl_url.escape(str, false, ''AL32UTF8'');',
'    end cs_workaround;',
'begin',
'    l_object_name := cs_workaround(:P6_OBJECT_NAME);',
'    l_response := dbms_cloud_oci_obs_object_storage.get_object(',
'        namespace_name => :G_NAMESPACE_NAME',
'        ,bucket_name => :P6_BUCKET_NAME',
'        ,object_name => l_object_name',
'        ,region => :G_REGION',
'        ,credential_name => :G_CREDENTIAL_NAME',
'    );',
'    l_status_code := l_response.status_code;',
'    if l_status_code != 200 then',
'        raise plsql_sdk_error;',
'    end if;',
'    l_blob := l_response.response_body;',
'    sys.htp.init;',
'    sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_blob));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || l_object_name || ''"'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_blob);',
'    apex_application.stop_apex_engine;',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
