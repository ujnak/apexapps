prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>unistr('\30AA\30D6\30B8\30A7\30AF\30C8\64CD\4F5C')
,p_alias=>unistr('\30AA\30D6\30B8\30A7\30AF\30C8\64CD\4F5C')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\30AA\30D6\30B8\30A7\30AF\30C8\64CD\4F5C')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221202032751'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9453134238980425)
,p_plug_name=>unistr('\30AA\30D6\30B8\30A7\30AF\30C8\64CD\4F5C')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(9024079260068254)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from list_objects',
'(',
'    p_namespace_name => :G_NAMESPACE_NAME',
'    , p_bucket_name => :P4_BUCKET_NAME',
'    , p_region => :G_REGION',
'    , p_credential_name => :G_CREDENTIAL_NAME',
')'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9459251963980432)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(9026860705068256)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9459654741980433)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9459251963980432)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(9162911394068345)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9461036786980435)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9459251963980432)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(9162911394068345)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9461487667980435)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9459251963980432)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(9162911394068345)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_position=>'NEXT'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9461857589980436)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9459251963980432)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(9162911394068345)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'NEXT'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8973101686610809)
,p_name=>'P5_BUCKET_NAME'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8973235878610810)
,p_name=>'P5_FILE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_prompt=>'Filename'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9453512978980426)
,p_name=>'P5_ID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_item_source_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9453937299980427)
,p_name=>'P5_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_item_source_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9454341424980427)
,p_name=>'P5_L_SIZE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_item_source_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_use_cache_before_default=>'NO'
,p_prompt=>'L Size'
,p_source=>'L_SIZE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9454751982980429)
,p_name=>'P5_MD5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_item_source_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Md5'
,p_source=>'MD5'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9455152724980429)
,p_name=>'P5_TIME_CREATED'
,p_source_data_type=>'TIMESTAMP_TZ'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_item_source_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Time Created'
,p_source=>'TIME_CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9455986831980430)
,p_name=>'P5_ETAG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_item_source_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Etag'
,p_source=>'ETAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9456335200980430)
,p_name=>'P5_TIME_MODIFIED'
,p_source_data_type=>'TIMESTAMP_TZ'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_item_source_plug_id=>wwv_flow_imp.id(9453134238980425)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Time Modified'
,p_source=>'TIME_MODIFIED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(9455604542980430)
,p_validation_name=>'P5_TIME_CREATED must be timestamp'
,p_validation_sequence=>40
,p_validation=>'P5_TIME_CREATED'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>unistr('#LABEL#\306F\6709\52B9\306A\30BF\30A4\30E0\30B9\30BF\30F3\30D7\3067\3042\308B\5FC5\8981\304C\3042\308A\307E\3059\3002')
,p_associated_item=>wwv_flow_imp.id(9455152724980429)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(9456884781980431)
,p_validation_name=>'P5_TIME_MODIFIED must be timestamp'
,p_validation_sequence=>60
,p_validation=>'P5_TIME_MODIFIED'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>unistr('#LABEL#\306F\6709\52B9\306A\30BF\30A4\30E0\30B9\30BF\30F3\30D7\3067\3042\308B\5FC5\8981\304C\3042\308A\307E\3059\3002')
,p_associated_item=>wwv_flow_imp.id(9456335200980430)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9459785114980433)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9459654741980433)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9460523459980435)
,p_event_id=>wwv_flow_imp.id(9459785114980433)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9462654687980439)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(9453134238980425)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0\30AA\30D6\30B8\30A7\30AF\30C8\64CD\4F5C')
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_rename_object_details dbms_cloud_oci_object_storage_rename_object_details_t;',
'    l_put_response    dbms_cloud_oci_obs_object_storage_put_object_response_t;',
'    l_rename_response dbms_cloud_oci_obs_object_storage_rename_object_response_t;',
'    l_delete_response dbms_cloud_oci_obs_object_storage_delete_object_response_t;',
'    l_status_code integer;',
'    l_filename varchar2(4000);',
'    l_content_type varchar2(4000);',
'    l_blob blob;',
'    l_loc number;',
'    plsql_sdk_error exception;',
unistr('    -- \65E5\672C\8A9E\306B\5BFE\5FDC\3055\305B\308B'),
'    function cs_workaround(str varchar2)',
'    return varchar2',
'    as',
'    begin',
'        return utl_url.escape(str, false, ''AL32UTF8'');',
'    end cs_workaround;',
'begin',
'    case',
'    when :APEX$ROW_STATUS = ''C'' then',
'        begin',
'            select filename, mime_type, blob_content into l_filename, l_content_type, l_blob',
'            from apex_application_temp_files',
'            where name = :P5_FILE;',
'        exception',
'            when no_data_found then',
'                l_blob := null;',
'        end;',
'        if lengthb(:P5_NAME) > 0 then',
'            l_filename := :P5_NAME;',
'        end if;',
'        l_filename := cs_workaround(l_filename);',
'        l_put_response := dbms_cloud_oci_obs_object_storage.put_object',
'        (',
'	        namespace_name => :G_NAMESPACE_NAME',
'            , bucket_name => :P5_BUCKET_NAME',
'            , object_name => l_filename',
'            , content_type => l_content_type',
'            , put_object_body => l_blob',
'	        , region => :G_REGION',
'	        , credential_name => :G_CREDENTIAL_NAME',
'        );',
'        l_status_code := l_put_response.status_code;',
'    when :APEX$ROW_STATUS = ''U'' then',
'        l_rename_object_details := new',
'            dbms_cloud_oci_object_storage_rename_object_details_t;',
'        l_rename_object_details.source_name := :P5_ID;',
'        l_rename_object_details.new_name := :P5_NAME;            ',
'        l_rename_response := dbms_cloud_oci_obs_object_storage.rename_object',
'        (',
'	        namespace_name => :G_NAMESPACE_NAME',
'            , bucket_name => :P5_BUCKET_NAME',
'            , rename_object_details => l_rename_object_details',
'	        , region => :G_REGION',
'	        , credential_name => :G_CREDENTIAL_NAME',
'        );',
'        l_status_code := l_put_response.status_code;',
'    when :APEX$ROW_STATUS = ''D'' then',
'        l_delete_response := dbms_cloud_oci_obs_object_storage.delete_object',
'        (',
'	        namespace_name => :G_NAMESPACE_NAME',
'            ,bucket_name => :P5_BUCKET_NAME',
'            ,object_name => cs_workaround(:P5_NAME)',
'	        , region => :G_REGION',
'	        , credential_name => :G_CREDENTIAL_NAME',
'        );',
'        l_status_code := l_put_response.status_code;',
'    end case;',
'    if l_status_code != 200 then',
'        raise plsql_sdk_error;',
'   end if;   ',
'end;'))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9463007658980439)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9462240326980436)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(9453134238980425)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0\30AA\30D6\30B8\30A7\30AF\30C8\64CD\4F5C')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
