prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>unistr('\30D0\30B1\30C3\30C8\64CD\4F5C')
,p_alias=>unistr('\30D0\30B1\30C3\30C8\64CD\4F5C')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\30D0\30B1\30C3\30C8\64CD\4F5C')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221202014551'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9208971052424478)
,p_plug_name=>unistr('\30D0\30B1\30C3\30C8\64CD\4F5C')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(9024079260068254)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from list_buckets',
'(',
'    p_namespace_name => :G_NAMESPACE_NAME',
'    , p_compartment_id => :G_COMPARTMENT_ID',
'    , p_region => :G_REGION',
'    , p_credential_name => :G_CREDENTIAL_NAME',
')'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9214654086424494)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(9026860705068256)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9215057493424494)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9214654086424494)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(9162911394068345)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9216408180424496)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9214654086424494)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(9162911394068345)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9216883079424499)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9214654086424494)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(9162911394068345)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9217238500424499)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9214654086424494)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(9162911394068345)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9209396067424479)
,p_name=>'P3_ID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_item_source_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9209712936424481)
,p_name=>'P3_NAMESPACE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_item_source_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_item_default=>'G_NAMESPACE_NAME'
,p_item_default_type=>'ITEM'
,p_prompt=>'Namespace'
,p_source=>'NAMESPACE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9210115485424481)
,p_name=>'P3_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_item_source_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9210523790424481)
,p_name=>'P3_COMPARTMENT_ID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_item_source_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_item_default=>'G_COMPARTMENT_ID'
,p_item_default_type=>'ITEM'
,p_prompt=>'Compartment Id'
,p_source=>'COMPARTMENT_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9210974216424482)
,p_name=>'P3_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_item_source_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Created By'
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9211316203424482)
,p_name=>'P3_TIME_CREATED'
,p_source_data_type=>'TIMESTAMP_TZ'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_item_source_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Time Created'
,p_source=>'TIME_CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>4000
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9212163557424491)
,p_name=>'P3_ETAG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_item_source_plug_id=>wwv_flow_imp.id(9208971052424478)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Etag'
,p_source=>'ETAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(9160448431068344)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(9211806378424483)
,p_validation_name=>'P3_TIME_CREATED must be timestamp'
,p_validation_sequence=>50
,p_validation=>'P3_TIME_CREATED'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>unistr('#LABEL#\306F\6709\52B9\306A\30BF\30A4\30E0\30B9\30BF\30F3\30D7\3067\3042\308B\5FC5\8981\304C\3042\308A\307E\3059\3002')
,p_associated_item=>wwv_flow_imp.id(9211316203424482)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9215173086424494)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9215057493424494)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9215987328424496)
,p_event_id=>wwv_flow_imp.id(9215173086424494)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9218043741424501)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(9208971052424478)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0\30D0\30B1\30C3\30C8\64CD\4F5C')
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_create_bucket_details dbms_cloud_oci_object_storage_create_bucket_details_t;',
'    l_update_bucket_details dbms_cloud_oci_object_storage_update_bucket_details_t;',
'    l_create_response dbms_cloud_oci_obs_object_storage_create_bucket_response_t;',
'    l_update_response dbms_cloud_oci_obs_object_storage_update_bucket_response_t;',
'    l_delete_response dbms_cloud_oci_obs_object_storage_delete_bucket_response_t;',
'    l_status_code integer;',
'    plsql_sdk_error exception;',
'begin',
'    case',
'    when :APEX$ROW_STATUS = ''C'' then',
'        l_create_bucket_details :=',
'            new dbms_cloud_oci_object_storage_create_bucket_details_t;',
'        l_create_bucket_details.name := :P3_NAME;',
'        l_create_bucket_details.compartment_id := :P3_COMPARTMENT_ID;',
'        l_create_response := dbms_cloud_oci_obs_object_storage.create_bucket',
'        (',
'	        namespace_name => :P3_NAMESPACE',
'	        , create_bucket_details => l_create_bucket_details',
'	        , region => :G_REGION',
'	        , credential_name => :G_CREDENTIAL_NAME',
'        );',
'        l_status_code := l_create_response.status_code;',
'    when :APEX$ROW_STATUS = ''U'' then',
unistr('        -- \4F55\3082\30A2\30C3\30D7\30C7\30FC\30C8\3057\306A\3044\3051\3069\3001\53C2\8003\306E\305F\3081\306Bupdate_bucket\3092\547C\3073\51FA\3057\307E\3059\3002'),
'        l_update_bucket_details :=',
'            new dbms_cloud_oci_object_storage_update_bucket_details_t;',
'        l_update_response := dbms_cloud_oci_obs_object_storage.update_bucket',
'        (',
'	        namespace_name => :P3_NAMESPACE',
'            , bucket_name => :P3_NAME',
'	        , update_bucket_details => l_update_bucket_details',
'	        , region => :G_REGION',
'	        , credential_name => :G_CREDENTIAL_NAME',
'        );',
'        l_status_code := l_create_response.status_code;',
'    when :APEX$ROW_STATUS = ''D'' then',
'        l_delete_response := dbms_cloud_oci_obs_object_storage.delete_bucket',
'        (',
'	        namespace_name => :P3_NAMESPACE',
'            , bucket_name => :P3_NAME',
'	        , region => :G_REGION',
'	        , credential_name => :G_CREDENTIAL_NAME',
'        );',
'        l_status_code := l_create_response.status_code;',
'    end case;',
'    if l_status_code != 200 then',
'        raise plsql_sdk_error;',
'    end if;',
'end;'))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9218416143424501)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9217698574424500)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(9208971052424478)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0\30D0\30B1\30C3\30C8\64CD\4F5C')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
