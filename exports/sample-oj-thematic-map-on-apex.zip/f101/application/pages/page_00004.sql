prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>5050556754310867
,p_default_application_id=>101
,p_default_id_offset=>12094138139694653
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Links'
,p_alias=>'LINKS'
,p_step_title=>'Links'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' * Ref: https://www.oracle.com/webfolder/technetwork/jet/jetCookbook.html?component=thematicMap&demo=links',
unistr(' * \9759\7684\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\30FB\30D5\30A1\30A4\30EB\304B\3089world_countries.json\3068flightData.json\3092\53D6\308A\51FA\3059\3088\3046\306B\5909\66F4\3002'),
' */',
'require(["require", "exports", "knockout", "ojs/ojbootstrap", "ojs/ojarraydataprovider", "ojs/ojknockout", "ojs/ojthematicmap"], function (require, exports, ko, ojbootstrap_1, ArrayDataProvider, geo, flightData) {',
'    "use strict";',
'      ',
'    class DemoModel {',
'        constructor(geo, flightData) {',
'            this.mapProvider = {',
unistr('                geo: geo,  // JSON.parse\306E\7F6E\304D\63DB\3048'),
'                propertiesKeys: {',
'                    id: ''CC3'',',
'                    shortLabel: ''CC3'',',
'                    longLabel: ''NAME''',
'                }',
'            };',
unistr('            this.data = flightData;  // JSON.parse\306E\7F6E\304D\63DB\3048'),
'            this.airports = this.data.airports.map((airport) => {',
'                return {',
'                    city: airport.city,',
'                    outgoing: airport.outgoing,',
'                    incoming: airport.incoming,',
'                    longitude: airport.longitude,',
'                    latitude: airport.latitude',
'                };',
'            });',
'            this.airportDataProvider = new ArrayDataProvider(this.airports, {',
'                keyAttributes: ''city''',
'            });',
'            this.flights = this.data.flights;',
'            this.flightDataProvider = new ArrayDataProvider(this.flights, {',
'                keyAttributes: ''flight''',
'            });',
'            this.getStyleUrl = (styleId) => {',
'                return ''url('' + document.URL + ''#'' + styleId + '')'';',
'            };',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        (async() => {',
'            const worldCountries = await fetch(''#APP_FILES#world_countries.json'');',
'            const geo = await worldCountries.json();',
'            const flightData = await fetch(''#APP_FILES#flightData.json'');',
'            const jsonData = await flightData.json();',
'            ko.applyBindings(new DemoModel(geo, jsonData), document.getElementById(''map1''));',
'        })();',
'    });',
'});'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.demo-thematicmap-link-movingLine {',
'    stroke: black;',
'    stroke-width: 3;',
'    stroke-dasharray: 4;',
'    animation: dash 5s linear infinite;',
'}',
'@keyframes dash {',
'    to {',
'        stroke-dashoffset: 100;',
'    }',
'}',
'.demo-thematicmap-link-height {',
'    height: 0rem;',
'}',
'.demo-thematicmap-min-width {',
'    min-width: 12.5rem;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24001231735434803)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- ',
'    Ref: https://www.oracle.com/webfolder/technetwork/jet/jetCookbook.html?component=thematicMap&demo=links',
unistr('    demo.html\306E<div class="demo-thematicmap-link-height">\306E\90E8\5206\3092\5207\308A\51FA\3057\3066\3044\308B\3002'),
'-->',
'<div class="demo-thematicmap-link-height">',
'    <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">',
'        <defs>',
'            <marker',
'                id="leftMarker"',
'                viewBox="0 0 10 10"',
'                refX="10"',
'                refY="5"',
'                markerWidth="20"',
'                markerHeight="20"',
'                markerUnits="userSpaceOnUse"',
'                orient="auto">',
'                <path d="M 0 0 L 10 5 L 0 10 z" fill="green" />',
'            </marker>',
'            <marker',
'                id="rightMarker"',
'                markerUnits="userSpaceOnUse"',
'                viewBox="0 0 10 10"',
'                refX="0"',
'                refY="5"',
'                markerWidth="20"',
'                markerHeight="20"',
'                orient="auto">',
'                <path d="M 10 0 L 0 5 L 10 10 z" fill="red" />',
'            </marker>',
'        </defs>',
'    </svg>',
'</div>',
'<oj-thematic-map',
'    id="map1"',
'    panning="auto"',
'    zooming="auto"',
'    selection-mode="single"',
'    marker-data="[[airportDataProvider]]"',
'    map-provider="[[mapProvider]]"',
'    link-data="[[flightDataProvider]]"',
'    class="demo-thematicmap-min-width">',
'    <template slot="markerTemplate">',
'        <oj-thematic-map-marker',
'            x="[[$current.data.longitude]]"',
'            y="[[$current.data.latitude]]"',
'            short-desc="[[$current.data.city + '': '' + $current.data.outgoing + '' outgoing, '' + $current.data.incoming + '' incoming'']]">',
'        </oj-thematic-map-marker>',
'    </template>',
'    <template slot="linkTemplate">',
'        <oj-thematic-map-link',
'            start-location.id="[[$current.data.start]]"',
'            end-location.id="[[$current.data.end]]"',
'            short-desc="[[''Flight '' + $current.data.flight + '': '' + $current.data.start + '' to '' + $current.data.end]]"',
'            svg-class-name="[[$current.data.flight === 980 ? ''demo-thematicmap-link-movingLine'' : null]]"',
'            svg-style="[[$current.data.flight === 529 ? {markerStart: getStyleUrl(''rightMarker''), markerEnd: getStyleUrl(''leftMarker'')} : $current.data.flight === 752 ? {''strokeDasharray'': 6} : null]]">',
'        </oj-thematic-map-link>',
'    </template>',
'</oj-thematic-map>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24167693356519142)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(24144484834423944)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp.component_end;
end;
/
