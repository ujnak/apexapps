prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>5050556754310867
,p_default_application_id=>101
,p_default_id_offset=>12094138139694653
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Projecting Coordinates'
,p_alias=>'PROJECTING-COORDINATES'
,p_step_title=>'Projecting Coordinates'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' * Ref: https://www.oracle.com/webfolder/technetwork/jet/jetCookbook.html?component=thematicMap&demo=coordinates',
unistr(' * uk_27700.json\3068ukIrelandCities.json\3092\9759\7684\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\30FB\30D5\30A1\30A4\30EB\3092\53C2\7167\3059\308B\3002'),
' */',
'require(["require", "exports", "proj4", "knockout", "ojs/ojbootstrap", "ojs/ojarraydataprovider", "ojs/ojknockout", "ojs/ojthematicmap"], function (require, exports, proj4, ko, ojbootstrap_1, ArrayDataProvider) {',
'    "use strict";',
'      ',
'    class DemoModel {',
'        constructor(geo, cityData) {',
'            this.mapProvider = {',
unistr('                geo: geo, // JSON.parse\306E\7F6E\304D\63DB\3048'),
'                propertiesKeys: {',
'                    id: ''NAME'',',
'                    longLabel: ''NAME''',
'                }',
'            };',
unistr('            this.cities = cityData.map((city) => {  // JSON.parse\306E\7F6E\304D\63DB\3048'),
'                // Call proj4js API with the proj4 projection mapping for EPSG:2770 and the long/lat coordinates.',
'                const coords = proj4(''+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs'', [city.long, city.lat]);',
'                return {',
'                    city: city.city,',
'                    projectedLatitude: coords[1],',
'                    projectedLongitude: coords[0]',
'                };',
'            });',
'            this.dataProvider = new ArrayDataProvider(this.cities, {',
'                keyAttributes: ''city''',
'            });',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        (async() => {',
'            const uk27700 = await fetch(''#APP_FILES#uk_27700.json'');',
'            const geo = await uk27700.json();',
'            const ukIrelandCities = await fetch(''#APP_FILES#ukIrelandCities.json'');',
'            const cityData = await ukIrelandCities.json();        ',
'            ko.applyBindings(new DemoModel(geo, cityData), document.getElementById(''map1''));',
'        })();',
'    });',
'});'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24001046137434802)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:i-h640:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!--',
'    Ref: https://www.oracle.com/webfolder/technetwork/jet/jetCookbook.html?component=thematicMap&demo=coordinates',
unistr('    demo.html\306Eoj-thematic-map\8981\7D20\3092\5207\308A\51FA\3057\3066\3044\308B\3002'),
'-->',
'<oj-thematic-map',
'    id="map1"',
'    marker-data="[[dataProvider]]"',
'    areas=''[{"id": "a1", "location": "Scotland", "color": "rgb(255, 181, 77)"},',
'        {"id": "a2", "location": "Wales", "color": "rgb(255, 181, 77)"},',
'        {"id": "a3", "location": "Northern Ireland", "color": "rgb(255, 181, 77)"},',
'        {"id": "a4", "location": "England", "color": "rgb(255, 181, 77)"},',
'        {"id": "a5", "location": "Channel Islands", "color": "rgb(255, 181, 77)"},',
'        {"id": "a6", "location": "Wales", "color": "rgb(255, 181, 77)"}]''',
'    zooming="auto"',
'    panning="auto"',
'    map-provider="[[mapProvider]]"',
'    class="demo-thematicmap-min-width">',
'    <template slot="markerTemplate">',
'        <oj-thematic-map-marker',
'            x="[[$current.data.projectedLongitude]]"',
'            y="[[$current.data.projectedLatitude]]"',
'            short-desc="[[$current.data.city]]">',
'        </oj-thematic-map-marker>',
'    </template>',
'</oj-thematic-map>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24163167981444841)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(24144484834423944)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp.component_end;
end;
/
