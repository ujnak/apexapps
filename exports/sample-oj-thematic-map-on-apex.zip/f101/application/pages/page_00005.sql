prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>5050556754310867
,p_default_application_id=>101
,p_default_id_offset=>12094138139694653
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Generating Maps'
,p_alias=>'GENERATING-MAPS'
,p_step_title=>'Generating Maps'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' * Ref: https://www.oracle.com/webfolder/technetwork/jet/jetCookbook.html?component=thematicMap&demo=basemaps',
unistr(' * \5404\30A8\30EA\30A2\306EJSON\30D5\30A1\30A4\30EB\306F\5236\5B9A\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\30FB\30D5\30A1\30A4\30EB\3092\53C2\7167\3059\308B\3088\3046\306B\5909\66F4\3002'),
unistr(' * \8868\793A\30A8\30EA\30A2\306E\9078\629E\30EA\30B9\30C8\306F\3001APEX\306E\9078\629E\30EA\30B9\30C8\3092\4F7F\3046\3088\3046\306B\5909\66F4\3002'),
' */',
'require(["require", "exports", "knockout", "ojs/ojbootstrap", "ojs/ojarraydataprovider", "ojs/ojattributegrouphandler", "ojs/ojknockout", "ojs/ojinputnumber", "ojs/ojformlayout", "ojs/ojthematicmap"], function (require, exports, ko, ojbootstrap_1, Ar'
||'rayDataProvider, ojattributegrouphandler_1) {',
'    "use strict";',
'      ',
'    class DemoModel {',
'        maps;',
'',
'        constructor(maps) {',
unistr('            this.maps = maps;   // \3059\3079\3066\306E\30A8\30EA\30A2\306E\30DE\30C3\30D7\3092\4FDD\6301\3059\308B\3002'),
'            this.map = ko.observable(''World'');',
'            this.areaData = ko.observableArray();',
'            this.dataProvider = new ArrayDataProvider(this.areaData, {',
'                keyAttributes: ''@index''',
'            });',
'            this.mapProvider = ko.observable();',
'            this.getColor = (id) => {',
'                return this.handler.getValue(id);',
'            };',
'            this.updateMap = (map) => {',
unistr('                let geo = this.maps[map] ?? maps["World"];   // \8868\793A\3059\308B\30DE\30C3\30D7\3092\9078\629E\3002'),
'                this.mapProvider({',
'                    geo: geo,',
'                    propertiesKeys: {',
'                        id: ''CC3'',',
'                        shortLabel: ''CC3'',',
'                        longLabel: ''NAME''',
'                    }',
'                });',
'                this.areaData(geo[''features'']);',
'                // For demo purposes, use the color attribute group handler to give',
'                // areas different colors based on a non important data dimension.',
'                // In a real application, the color attribute group handler should be',
'                // passed a meaningful data dimension.',
'                this.handler = new ojattributegrouphandler_1.ColorAttributeGroupHandler();',
'            };',
'            this.mapListener = (event) => {',
'                console.log(event);',
'                this.updateMap(event.detail.value);',
'            }',
'            this.updateMap(this.map());',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        (async() => {',
'            let maps = {};',
'            const responseAfrica = await fetch(''#APP_FILES#africa_countries.json'');',
'            maps["Africa"]       = await responseAfrica.json();',
'            const responseAsia = await fetch(''#APP_FILES#asia_countries.json'');',
'            maps["Asia"]       = await responseAsia.json();',
'            const responseAustralia = await fetch(''#APP_FILES#australia_countries.json'');',
'            maps["Australia"]       = await responseAustralia.json();',
'            const responseEurope = await fetch(''#APP_FILES#europe_countries.json'');',
'            maps["Europe"]       = await responseEurope.json();',
'            const responseNorthAmerica = await fetch(''#APP_FILES#north_america_countries.json'');',
'            maps["North America"]      = await responseNorthAmerica.json();',
'            const responseSouthAmerica = await fetch(''#APP_FILES#south_america_countries.json'');',
'            maps["South America"]      = await responseSouthAmerica.json();',
'            const responseWorld = await fetch(''#APP_FILES#world_countries.json'');',
'            maps["World"]       = await responseWorld.json();',
'            ko.applyBindings(new DemoModel(maps), document.getElementById(''map1''));',
'        })();',
'    });',
'});'))
,p_css_file_urls=>'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.demo-thematicmap-min-width {',
'    min-width: 12.5rem;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24172391149753019)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(24144484834423944)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24173066629759054)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!--',
'    Ref: https://www.oracle.com/webfolder/technetwork/jet/jetCookbook.html?component=thematicMap&demo=basemaps',
unistr('    \5909\66F4\30A4\30D9\30F3\30C8\FF08on-change\FF09\3092\53D7\3051\3066\3001mapListener\3092\547C\3073\51FA\3059\3088\3046\306B\5C5E\6027\3092\8FFD\52A0\3002'),
'-->',
'<oj-thematic-map',
'    id="map1"',
'    area-data="[[dataProvider]]"',
'    zooming="auto"',
'    panning="auto"',
'    animation-on-display="auto"',
'    selection-mode="single"',
'    map-provider="[[mapProvider]]"',
'    class="demo-thematicmap-min-width"',
'    on-change="[[mapListener]]"',
'    >',
'    <template slot="areaTemplate" data-oj-as="area">',
'        <oj-thematic-map-area',
'            color="[[getColor(area.data.properties.CC3)]]"',
'            location="[[area.data.properties.CC3]]">',
'        </oj-thematic-map-area>',
'    </template>',
'</oj-thematic-map>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24173141642759055)
,p_name=>'P5_AREA'
,p_item_sequence=>10
,p_prompt=>'Area'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Africa;Africa,Asia;Asia,Australia;Australia,Europe;Europe,North America;North America,South America;South America,World;World'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24173297905759056)
,p_name=>'onChange Area'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_AREA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24173412781759057)
,p_event_id=>wwv_flow_imp.id(24173297905759056)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// Thematic Map\306B\5909\66F4\30A4\30D9\30F3\30C8\3092\767A\884C\3059\308B\3002'),
'document.getElementById("map1").dispatchEvent(',
'    new CustomEvent("change", {',
'        detail: { value: $v(this.triggeringElement) }',
'    })',
');'))
);
wwv_flow_imp.component_end;
end;
/
