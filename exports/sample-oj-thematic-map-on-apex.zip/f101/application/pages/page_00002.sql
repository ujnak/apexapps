prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>5050556754310867
,p_default_application_id=>101
,p_default_id_offset=>12094138139694653
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Basic'
,p_alias=>'BASIC'
,p_step_title=>'Basic'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[require jet]',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' * Ref: https://www.oracle.com/webfolder/technetwork/jet/jetCookbook.html?component=thematicMap&demo=default',
unistr(' * demo.js\306Euusa_status.json\3068usaRainfall.json\3092\9759\7684\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\30FB\30D5\30A1\30A4\30EB\304B\3089\53D6\5F97\3059\308B\3088\3046\306B\5909\66F4\3002'),
unistr(' * require()\304B\3089\4E0A\8A18\306Ejson\306E\53C2\7167\3092\9664\5916\3057\3066\3044\308B\3002'),
' */',
'require(["require", "exports", "knockout", "ojs/ojbootstrap", "ojs/ojarraydataprovider", "ojs/ojpalette", "ojs/ojknockout", "ojs/ojlegend", "ojs/ojthematicmap"], function (require, exports, ko, ojbootstrap_1, ArrayDataProvider, ojpalette_1) {',
'    "use strict";',
'      ',
'    class DemoModel {',
'        constructor(geo, jsonData) {',
'            this.mapProvider = {',
unistr('                geo: geo, // JSON.parse\306E\7F6E\304D\63DB\3048\3002'),
'                propertiesKeys: {',
'                    id: ''Name'',',
'                    shortLabel: ''CC3'',',
'                    longLabel: ''Name''',
'                }',
'            };',
'            this.colors = (0, ojpalette_1.getColorValuesFromPalette)(''viridis'', 5);',
'            this.getRainfallColor = (rainfall) => {',
'                // Bucket rainfall data into categories to color',
'                if (rainfall <= 20)',
'                    return this.colors[0];',
'                else if (rainfall <= 30)',
'                    return this.colors[1];',
'                else if (rainfall <= 40)',
'                    return this.colors[2];',
'                else if (rainfall <= 50)',
'                    return this.colors[3];',
'                else',
'                    return this.colors[4];',
'            };',
unistr('            this.dataProvider = new ArrayDataProvider(jsonData, {  // JSON.parse\306E\7F6E\304D\63DB\3048'),
'                keyAttributes: ''State''',
'            });',
'            this.legendSections = [',
'                {',
'                    items: [',
'                        { text: ''0-20'', color: this.colors[0] },',
'                        { text: ''21-30'', color: this.colors[1] },',
'                        { text: ''31-40'', color: this.colors[2] },',
'                        { text: ''41-50'', color: this.colors[3] },',
'                        { text: ''51+'', color: this.colors[4] }',
'                    ]',
'                }',
'            ];',
'            this.legendDataProvider = new ArrayDataProvider(this.legendSections, {',
'                keyAttributes: ''text''',
'            });',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        (async() => {',
'            /*',
unistr('             * \9759\7684\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\30FB\30D5\30A1\30A4\30EB\306EJSON\30D5\30A1\30A4\30EB\3092\8AAD\307F\8FBC\3080\3002'),
'             */',
'            const usaStates = await fetch(''#APP_FILES#usa_states.json'');',
'            const geo = await usaStates.json();',
'            const usaRainfall = await fetch(''#APP_FILES#usaRainfall.json'');',
'            const jsonData = await usaRainfall.json();',
'            /*',
unistr('             * \80CC\666F\5730\56F3\3068\306A\308Bgeo\3068\5730\56F3\4E0A\306B\8868\793A\3059\308B\30C7\30FC\30BF\3092jsonData\3068\3057\3066\30B3\30F3\30B9\30C8\30E9\30AF\30BF\306B\6E21\3059\3002'),
'             */',
'            ko.applyBindings(new DemoModel(geo, jsonData), document.getElementById(''mapdemo''));',
'        })();',
'    });',
'});'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.demo-thematicmap-min-width {',
'    min-width: 12.5rem;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24001032778434801)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!--',
'    Ref: https://www.oracle.com/webfolder/technetwork/jet/jetCookbook.html?component=thematicMap&demo=default',
unistr('    demo.html\306Eid="mapdemo"\306E\90E8\5206\3092\5207\308A\51FA\3057\3066\3044\308B\3002'),
'-->',
'<div id="mapdemo">',
'    <oj-thematic-map',
'        id="thematicmap1"',
'        area-data="[[dataProvider]]"',
'        map-provider="[[mapProvider]]"',
'        class="demo-thematicmap-min-width">',
'        <template slot="areaTemplate" data-oj-as="area">',
'            <oj-thematic-map-area',
'                color="[[getRainfallColor(area.data.Inches)]]"',
'                location="[[area.data.State]]"',
'                short-desc=''[[area.data.Inches + " inches of annual rainfall"]]''>',
'            </oj-thematic-map-area>',
'        </template>',
'    </oj-thematic-map>',
'    <div class="oj-typography-bold oj-sm-margin-2x-top oj-helper-text-align-center">',
'        Annual Rainfall (Inches)',
'    </div>',
'    <oj-legend',
'        id="legend1"',
'        halign="center"',
'        orientation="horizontal"',
'        data="[[legendDataProvider]]">',
'    </oj-legend>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24160211852424674)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(24144484834423944)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp.component_end;
end;
/
