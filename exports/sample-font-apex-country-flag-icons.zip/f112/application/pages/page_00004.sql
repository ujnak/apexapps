prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>112
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>unistr('\4E16\754C\5730\56F3')
,p_alias=>unistr('\4E16\754C\5730\56F3')
,p_step_title=>unistr('\4E16\754C\5730\56F3')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'19'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27147869652274002)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(26684932094092581)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27148572666274003)
,p_plug_name=>unistr('\4E16\754C\5730\56F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>10
,p_location=>null
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(27148956185274003)
,p_region_id=>wwv_flow_imp.id(27148572666274003)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
,p_custom_styles=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[',
'  {',
'    "name": "fa-flag-jp",',
'    "width": 24,',
'    "height": 24,',
'    "paint-order": "stroke",',
'    "viewBox": "0 0 24 24",',
'    "fill": "none",',
'    "fill-rule": "evenodd",',
'    "elements": [',
'      {',
'        "type": "rect",',
'        "width": 24,',
'        "height": 18,',
'        "y": 3,',
'        "fill": "#fcfbfa",',
'        "rx": 2',
'      },',
'      {',
'        "type": "circle",',
'        "cx": 12,',
'        "cy": 12,',
'        "r": 5,',
'        "fill": "#e70a2d"',
'      },',
'      {',
'        "type": "rect",',
'        "width": 23,',
'        "height": 17,',
'        "x": 0.5,',
'        "y": 3.5,',
'        "stroke": "#100f0e",',
'        "opacity": 0.1,',
'        "rx": 2',
'      }',
'    ]',
'  }',
']'))
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(27149476795274003)
,p_map_region_id=>wwv_flow_imp.id(27148956185274003)
,p_name=>unistr('\4E16\754C\5730\56F3')
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ISO_CODE,',
'       COUNTRY_NAME,',
'       CAPITAL_NAME,',
'       LONGITUDE,',
'       LATITUDE,',
'       ''fa-flag-'' || iso_code icon',
' from EBAJ_COUNTRIES'))
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'&ICON.'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'COUNTRY_NAME'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp.component_end;
end;
/
