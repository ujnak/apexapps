prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>271
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Fruits and Vegetables'
,p_alias=>'HOME'
,p_step_title=>'JET Bind For Each (Nested)'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'#JET_BASE_DIRECTORY#js/libs/require/require.js?v=#APP_VERSION#',
'#APEX_FILES#libraries/apex/minified/requirejs.jetConfig.min.js?v=#APP_VERSION#',
'*/'))
,p_javascript_code=>'var simple;'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'require(["require", "exports", "ojs/ojbootstrap", "knockout", "ojs/ojarraytreedataprovider", "ojs/ojknockout", "ojs/ojbutton"], function (require, exports, ojbootstrap_1, ko, ArrayTreeDataProvider) {',
'    "use strict";',
'      ',
'    class SimpleModel {',
'        update(data) {',
'            this.data(data);',
'        };',
'',
'        constructor() {',
'            this.data = ko.observableArray();',
'            this.categories = new ArrayTreeDataProvider(this.data, {',
'                keyAttributes: "name",',
'                childrenAttribute: "products",',
'            });',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        simple = new SimpleModel();    ',
'        ko.applyBindings(simple, document.getElementById("form-container"));',
'        apex.actions.invoke("update-nested");',
'    });',
'});',
'',
'/*',
unistr(' * \8868\793A\3092\66F4\65B0\3059\308B\3002'),
' */',
'apex.actions.add([',
'    {',
'        name: "update-nested",',
'        action: () => {',
'            apex.server.process ( "GET_DATA", {},',
'                {',
'                    success: (data) =>  {',
'                        // console.log(data);',
'                        simple.update(data);',
'                    }',
'                }',
'            );',
'        }',
'    }',
']);'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230905060153'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(83432643738149207)
,p_plug_name=>'For Each (Nested)'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(83825426364749291)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="form-container">',
'    <h4>Fruits and Vegetables</h4>',
'    <ul>',
'        <oj-bind-for-each data="[[categories]]">',
'            <template data-oj-as="category">',
'                <li>',
'                    <oj-bind-text value="[[category.data.name]]"></oj-bind-text>',
'                    <ul>',
'                        <oj-bind-for-each data="[[categories.getChildDataProvider(category.data.name)]]">',
'                            <template data-oj-as="item">',
'                                <li>',
'                                    <oj-bind-text',
'                                        value="[[item.data.name]]">',
'                                    </oj-bind-text>',
'                                </li>',
'                            </template>',
'                        </oj-bind-for-each>',
'                    </ul>',
'                </li>',
'            </template>',
'        </oj-bind-for-each>',
'    </ul>',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84083645065749496)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(83826875916749292)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84084464540749498)
,p_plug_name=>'Ag Categories'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(83875422278749319)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'AG_CATEGORIES'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'AG_CATEGORIES'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(84085772075749502)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(84086223404749502)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>unistr('\30A2\30AF\30B7\30E7\30F3')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(84087236843749504)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'ID'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(84088256937749505)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>80
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(84084925631749499)
,p_internal_uid=>84084925631749499
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(84085300195749500)
,p_interactive_grid_id=>wwv_flow_imp.id(84084925631749499)
,p_static_id=>'840854'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>10
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(84085578920749501)
,p_report_id=>wwv_flow_imp.id(84085300195749500)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(84086619799749503)
,p_view_id=>wwv_flow_imp.id(84085578920749501)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(84086223404749502)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(84087601832749504)
,p_view_id=>wwv_flow_imp.id(84085578920749501)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(84087236843749504)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(84088631196749505)
,p_view_id=>wwv_flow_imp.id(84085578920749501)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(84088256937749505)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84089589721749529)
,p_plug_name=>'Ag Products'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(83875422278749319)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'AG_PRODUCTS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_master_region_id=>wwv_flow_imp.id(84084464540749498)
,p_prn_page_header=>'AG_PRODUCTS'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(84090772708749531)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(84091236165749531)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>unistr('\30A2\30AF\30B7\30E7\30F3')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(84092253932749532)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'ID'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(84093268458749533)
,p_name=>'CATEGORY_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATEGORY_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'Category'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_parent_column_id=>wwv_flow_imp.id(84087236843749504)
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(84094228598749533)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>80
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(84089962204749530)
,p_internal_uid=>84089962204749530
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(84090334135749530)
,p_interactive_grid_id=>wwv_flow_imp.id(84089962204749530)
,p_static_id=>'840904'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>10
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(84090507311749530)
,p_report_id=>wwv_flow_imp.id(84090334135749530)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(84091627684749531)
,p_view_id=>wwv_flow_imp.id(84090507311749530)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(84091236165749531)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(84092607351749532)
,p_view_id=>wwv_flow_imp.id(84090507311749530)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(84092253932749532)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(84093695456749533)
,p_view_id=>wwv_flow_imp.id(84090507311749530)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(84093268458749533)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(84094602091749534)
,p_view_id=>wwv_flow_imp.id(84090507311749530)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(84094228598749533)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(84084083351749498)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(84083645065749496)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(83963892637749378)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4FDD\5B58')
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83432853978149209)
,p_name=>'onSAVE Products'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(84089589721749529)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83432932190149210)
,p_event_id=>wwv_flow_imp.id(83432853978149209)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.invoke("update-nested");'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(84089250920749506)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(84084464540749498)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('AG_CATEGORIES - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(84084083351749498)
,p_internal_uid=>84089250920749506
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(84095205375749534)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(84089589721749529)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('AG_PRODUCTS - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>84095205375749534
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(83432798300149208)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'begin',
'    select ',
'        json_arrayagg(',
'            json_object(',
'                key ''name'' value name',
'                ,key ''products'' value products',
'            )',
'        ) into l_response',
'    from',
'    (',
'        select',
'            c.name name',
'            ,json_arrayagg(',
'                json_object(',
'                    key ''name'' value p.name',
'                )',
'            ) as products',
'        from ag_categories c join ag_products p on c.id = p.category_id ',
'        group by c.name',
'    );',
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>83432798300149208
);
wwv_flow_imp.component_end;
end;
/
