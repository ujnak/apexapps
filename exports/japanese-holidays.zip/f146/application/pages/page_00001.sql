prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>146
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\65E5\672C\306E\4F11\65E5')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let result = apex.server.process("GET_HOLIDAYS");',
'',
'result.done( (data) => {',
'    window.holidays = data;',
'    console.log("holidays loaded.");',
'    //',
'    apex.item("P1_DATE3").dayFormatter = (pDate) => {',
'        const d = window.holidays.find(e => e.day == pDate);',
'        if (d != null) {',
'            return {',
unistr('                disabled: false, // \307E\305F\306Ftrue'),
'                class: "u-danger-text",',
'                tooltip: d.name',
'            };',
'        }',
'    }',
'    apex.item("P1_DATE3").refresh();',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230209063816'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43840666622121134)
,p_plug_name=>unistr('\65E5\672C\306E\4F11\65E5')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(43698754234121050)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43035334019984814)
,p_name=>'P1_DATE'
,p_item_sequence=>10
,p_prompt=>unistr('\65E5\672C\306E\4F11\65E5')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(43802176591121101)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43035675231984817)
,p_name=>'P1_DATE2'
,p_item_sequence=>20
,p_prompt=>unistr('\65E5\672C\306E\4F11\65E5')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(43802176591121101)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43036085355984821)
,p_name=>'P1_DATE3'
,p_item_sequence=>30
,p_prompt=>unistr('\65E5\672C\306E\4F11\65E5')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(43802176591121101)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43035490844984815)
,p_name=>unistr('\65E5\4ED8\30D4\30C3\30AB\30FC\306E\521D\671F\5316')
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43035530116984816)
,p_event_id=>wwv_flow_imp.id(43035490844984815)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.ORACLE.APEX.FORMAT_DATEPICKER_DAYS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_DATE'
,p_attribute_01=>'ics'
,p_attribute_02=>'https://calendar.google.com/calendar/ical/ja.japanese%23holiday@group.v.calendar.google.com/public/basic.ics'
,p_attribute_10=>'u-danger-text'
,p_attribute_11=>'server'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43035795895984818)
,p_event_id=>wwv_flow_imp.id(43035490844984815)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.ORACLE.APEX.FORMAT_DATEPICKER_DAYS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_DATE2'
,p_attribute_01=>'sql'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
unistr('    trunc("\56FD\6C11\306E\795D\65E5_\4F11\65E5\6708\65E5") as start_date,'),
unistr('    trunc("\56FD\6C11\306E\795D\65E5_\4F11\65E5\6708\65E5") as end_date,'),
'    ''u-danger-text''           as css_class,',
unistr('    "\56FD\6C11\306E\795D\65E5_\4F11\65E5\540D\79F0"        as tooltip,'),
unistr('    -- 0 = \9078\629E\53EF\80FD, 1 = \9078\629E\4E0D\53EF'),
'    0                         as is_disabled',
'from',
'    syukujitsu'))
,p_attribute_04=>'START_DATE'
,p_attribute_05=>'END_DATE'
,p_attribute_06=>'TOOLTIP'
,p_attribute_07=>'CSS_CLASS'
,p_attribute_08=>'IS_DISABLED'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43035803706984819)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_HOLIDAYS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob clob;',
'begin',
'    select ',
'--        json_object(''holidays'' value',
'            json_arrayagg(',
unistr('                json_object(''day'' value to_char("\56FD\6C11\306E\795D\65E5_\4F11\65E5\6708\65E5",''YYYY-MM-DD''), ''name'' value "\56FD\6C11\306E\795D\65E5_\4F11\65E5\540D\79F0")'),
'            )',
'--        )',
'    into l_clob',
unistr('    from syukujitsu where "\56FD\6C11\306E\795D\65E5_\4F11\65E5\6708\65E5" >= (sysdate - 365);'),
unistr('    -- \30C7\30FC\30BF\304C\591A\3059\304E\308B\3068\30A8\30E9\30FC\306B\306A\308B\306E\3067\3001\FF11\5E74\524D\306E\4F11\65E5\306B\9650\5B9A\3002'),
'    htp.p(l_clob);',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
