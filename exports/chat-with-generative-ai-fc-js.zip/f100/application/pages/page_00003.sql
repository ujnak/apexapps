prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.6'
,p_default_workspace_id=>2138965587838225
,p_default_application_id=>100
,p_default_id_offset=>5768918050551366
,p_default_owner=>'APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Tool Detail'
,p_alias=>'TOOL-DETAIL'
,p_page_mode=>'MODAL'
,p_step_title=>'Tool Detail'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(11047334076181161)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20240426113935'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11369507144886450)
,p_plug_name=>'Tool Detail'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11083239415181320)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'OPENAI_TOOLS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11373798243886662)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11086099535181330)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11374185053886668)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(11373798243886662)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(11223018158181868)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11375587945886701)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(11373798243886662)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(11223018158181868)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11375945782886703)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(11373798243886662)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(11223018158181868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11376399133886704)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(11373798243886662)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(11223018158181868)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5586561178702112)
,p_name=>'P3_JAVASCRIPT_FUNCTION_BODY'
,p_data_type=>'CLOB'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_prompt=>'JavaScript Function Body'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(11220562038181857)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11369766536886476)
,p_name=>'P3_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_item_source_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(11220562038181857)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11370129808886606)
,p_name=>'P3_TOOL_SET'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_item_source_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tool Set'
,p_source=>'TOOL_SET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(11221906880181862)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11370490211886626)
,p_name=>'P3_TOOL_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_item_source_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tool Type'
,p_source=>'TOOL_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(11221906880181862)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11370890574886628)
,p_name=>'P3_DESCRIPTION'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_item_source_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Description'
,p_source=>'DESCRIPTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(11221906880181862)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11371274089886638)
,p_name=>'P3_TOOL_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_item_source_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tool Name'
,p_source=>'TOOL_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(11221906880181862)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11371661145886641)
,p_name=>'P3_PARAMETERS'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_item_source_plug_id=>wwv_flow_imp.id(11369507144886450)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Parameters'
,p_source=>'PARAMETERS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(11220562038181857)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11374273394886668)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11374185053886668)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11375070356886692)
,p_event_id=>wwv_flow_imp.id(11374273394886668)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5586600627702113)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create or Replace JavaScript Function'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_ddl clob;',
'begin',
'    /*',
unistr('     * \5F15\6570pArgs\306E\30BF\30A4\30D7\3068\3057\3066CLOB\3092\6307\5B9A\3059\308B\3068\5024\304C\6B63\3057\304F\6E21\3089\306A\3044\3002JSON\306B\3059\308B\3079\304D\304B\3082\3057\308C\306A\3044\304C\3001PL/SQL\3068\306E'),
unistr('     * \4E92\63DB\6027\3092\8003\616E\3057\3066 - 23c\4EE5\524D\306EDB\3067\3082\3053\306E\30A2\30D7\30EA\306F\52D5\304F - VARCHAR2\3068\3059\308B\3002'),
'     */',
'    l_ddl := ''create or replace function '' || :P3_TOOL_NAME || ''(''',
'        || ''"pArgs" in varchar2) return clob as mle language javascript q'' || chr(39) || chr(126)',
'        || :P3_JAVASCRIPT_FUNCTION_BODY || chr(126) || chr(39) || '';'';',
'    apex_debug.info(l_ddl);',
'    execute immediate l_ddl;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST in (''SAVE'', ''CREATE'') and :P3_JAVASCRIPT_FUNCTION_BODY is not null'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>5586600627702113
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11377162459886733)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(11369507144886450)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0Tool Detail')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>5608244409335367
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11377566522886736)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>5608648472335370
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11376727252886713)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(11369507144886450)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0Tool Detail')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>5607809202335347
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5586704584702114)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load JavaScript Source'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_text varchar2(32767);',
'    l_clob clob;',
'    l_start integer;',
'    l_end   integer;',
'begin',
'    dbms_lob.createTemporary(',
'        lob_loc => l_clob',
'        ,cache =>  false',
'        ,dur => DBMS_LOB.CALL',
'    );',
'    for r in (',
'        select text from user_source where name = upper(:P3_TOOL_NAME) order by to_number(line) asc',
'    )',
'    loop',
'        dbms_lob.writeAppend(',
'            lob_loc => l_clob',
'            ,amount => length(r.text)',
'            ,buffer => r.text ',
'        );',
'    end loop;',
'    -- dbms_output.put_line(l_clob);',
'    l_start := dbms_lob.instr(',
'        lob_loc => l_clob',
'        ,pattern => ''q''''~''',
'    );',
'    l_clob := dbms_lob.substr(',
'        lob_loc => l_clob',
'        ,offset => (l_start + 3)',
'    );',
'    l_clob := dbms_lob.substr(',
'        lob_loc => l_clob',
'        ,amount => length(l_clob) - 3',
'    );',
'    -- dbms_output.put_line(l_clob);',
'    :P3_JAVASCRIPT_FUNCTION_BODY := l_clob;',
'',
'    dbms_lob.freeTemporary(',
'        lob_loc => l_clob',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'select 1 from user_mle_procedures where object_name = upper(:P3_TOOL_NAME)'
,p_process_when_type=>'EXISTS'
,p_internal_uid=>5586704584702114
);
wwv_flow_imp.component_end;
end;
/
