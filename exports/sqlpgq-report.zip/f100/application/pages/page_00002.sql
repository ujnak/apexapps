prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>6400485102012540
,p_default_application_id=>100
,p_default_id_offset=>10308146693328751
,p_default_owner=>'APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'PGQ1'
,p_alias=>'PGQ1'
,p_step_title=>'PGQ1'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230407172500'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77151661916797180)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(77054937191734100)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(76945421943734028)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(77117010137734137)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(77152272224797181)
,p_name=>'PGQ1'
,p_template=>wwv_flow_imp.id(77042472804734094)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select acct_id, count(*) as NumDeposits',
'from graph_table(sqlcl_bank_graph',
'    match',
'    (m is account) -[e is transfer] ->(v is account)',
'    columns (v.acct_id)',
')',
'group by acct_id',
'order by NumDeposits desc',
'fetch first :P2_ROWS rows only;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P2_ROWS'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(77080388458734113)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10310461030343301)
,p_query_column_id=>1
,p_column_alias=>'ACCT_ID'
,p_column_display_sequence=>10
,p_column_heading=>'Acct Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10310518796343302)
,p_query_column_id=>2
,p_column_alias=>'NUMDEPOSITS'
,p_column_display_sequence=>20
,p_column_heading=>'Numdeposits'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77156083967819752)
,p_name=>'P2_ROWS'
,p_item_sequence=>10
,p_prompt=>unistr('\884C\6570')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(77112877327734133)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77156211646819753)
,p_name=>unistr('\884C\6570\306E\5909\66F4')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_ROWS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77156278628819754)
,p_event_id=>wwv_flow_imp.id(77156211646819753)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77152272224797181)
);
wwv_flow_imp.component_end;
end;
/
