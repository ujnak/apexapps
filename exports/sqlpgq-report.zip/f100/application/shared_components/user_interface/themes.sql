prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>6400485102012540
,p_default_application_id=>100
,p_default_id_offset=>10308146693328751
,p_default_owner=>'APEXDEV'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(77118375941734148)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(76972034348734055)
,p_default_dialog_template=>wwv_flow_imp.id(76966749547734053)
,p_error_template=>wwv_flow_imp.id(76956769247734048)
,p_printer_friendly_template=>wwv_flow_imp.id(76972034348734055)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(76956769247734048)
,p_default_button_template=>wwv_flow_imp.id(77115442950734136)
,p_default_region_template=>wwv_flow_imp.id(77042472804734094)
,p_default_chart_template=>wwv_flow_imp.id(77042472804734094)
,p_default_form_template=>wwv_flow_imp.id(77042472804734094)
,p_default_reportr_template=>wwv_flow_imp.id(77042472804734094)
,p_default_tabform_template=>wwv_flow_imp.id(77042472804734094)
,p_default_wizard_template=>wwv_flow_imp.id(77042472804734094)
,p_default_menur_template=>wwv_flow_imp.id(77054937191734100)
,p_default_listr_template=>wwv_flow_imp.id(77042472804734094)
,p_default_irr_template=>wwv_flow_imp.id(77037926075734092)
,p_default_report_template=>wwv_flow_imp.id(77080388458734113)
,p_default_label_template=>wwv_flow_imp.id(77112877327734133)
,p_default_menu_template=>wwv_flow_imp.id(77117010137734137)
,p_default_calendar_template=>wwv_flow_imp.id(77117143891734139)
,p_default_list_template=>wwv_flow_imp.id(77096747037734123)
,p_default_nav_list_template=>wwv_flow_imp.id(77108638652734130)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(77108638652734130)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(77103233739734127)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(76984887708734064)
,p_default_dialogr_template=>wwv_flow_imp.id(76982137382734063)
,p_default_option_label=>wwv_flow_imp.id(77112877327734133)
,p_default_required_label=>wwv_flow_imp.id(77114201703734134)
,p_default_navbar_list_template=>wwv_flow_imp.id(77102785854734126)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/22.1/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
