prompt --application/shared_components/user_interface/lovs/cke_documents_title
begin
--   Manifest
--     CKE_DOCUMENTS.TITLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495801124689411
,p_default_application_id=>115
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14958718575717671)
,p_lov_name=>'CKE_DOCUMENTS.TITLE'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'CKE_DOCUMENTS'
,p_return_column_name=>'ID'
,p_display_column_name=>'TITLE'
,p_default_sort_column_name=>'TITLE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
