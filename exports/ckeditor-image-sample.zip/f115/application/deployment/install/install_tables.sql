prompt --application/deployment/install/install_tables
begin
--   Manifest
--     INSTALL: INSTALL-tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495801124689411
,p_default_application_id=>115
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15334900213772676)
,p_install_id=>wwv_flow_imp.id(15334312689763971)
,p_name=>'tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "CKE_DOCUMENTS" ',
'   (	"ID" NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ENABLE, ',
'	"TITLE" VARCHAR2(200 CHAR), ',
'	"CONTENT" CLOB, ',
'	"AUTHOR" VARCHAR2(80 CHAR), ',
'	"PUBLISHED" DATE, ',
'	"CREATED" DATE NOT NULL ENABLE, ',
'	"CREATED_BY" VARCHAR2(255 CHAR) NOT NULL ENABLE, ',
'	"UPDATED" DATE NOT NULL ENABLE, ',
'	"UPDATED_BY" VARCHAR2(255 CHAR) NOT NULL ENABLE, ',
'	 CONSTRAINT "CKE_DOCUMENTS_ID_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE TABLE "CKE_IMAGES" ',
'   (	"ID" NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ENABLE, ',
'	"DOCUMENT_ID" NUMBER, ',
'	"CONTENT_TYPE" VARCHAR2(200 CHAR), ',
'	"IMAGE" BLOB, ',
'	"CREATED" DATE NOT NULL ENABLE, ',
'	"CREATED_BY" VARCHAR2(255 CHAR) NOT NULL ENABLE, ',
'	 CONSTRAINT "CKE_IMAGES_ID_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'ALTER TABLE "CKE_IMAGES" ADD CONSTRAINT "CKE_IMAGES_DOCUMENT_ID_FK" FOREIGN KEY ("DOCUMENT_ID")',
'	  REFERENCES "CKE_DOCUMENTS" ("ID") ON DELETE CASCADE ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(15335072081772679)
,p_script_id=>wwv_flow_imp.id(15334900213772676)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'CKE_DOCUMENTS'
,p_last_updated_by=>'APEXDEV'
,p_last_updated_on=>to_date('20221130015108','YYYYMMDDHH24MISS')
,p_created_by=>'APEXDEV'
,p_created_on=>to_date('20221130015108','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(15335284349772679)
,p_script_id=>wwv_flow_imp.id(15334900213772676)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'CKE_IMAGES'
,p_last_updated_by=>'APEXDEV'
,p_last_updated_on=>to_date('20221130015108','YYYYMMDDHH24MISS')
,p_created_by=>'APEXDEV'
,p_created_on=>to_date('20221130015108','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
