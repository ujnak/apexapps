prompt --application/deployment/install/install_ckeditor
begin
--   Manifest
--     INSTALL: INSTALL-ckeditor
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7324704527453303
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(10229009039108564)
,p_install_id=>wwv_flow_imp.id(10228179858093707)
,p_name=>'ckeditor'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- create tables',
'create table cke_documents (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint cke_documents_id_pk primary key,',
'    title                          varchar2(200 char),',
'    content                        clob,',
'    author                         varchar2(80 char),',
'    published                      date,',
'    created                        date not null,',
'    created_by                     varchar2(255 char) not null,',
'    updated                        date not null,',
'    updated_by                     varchar2(255 char) not null',
')',
';',
'',
'create table cke_images (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint cke_images_id_pk primary key,',
'    document_id                    number',
'                                   constraint cke_images_document_id_fk',
'                                   references cke_documents on delete cascade,',
'    content_type                   varchar2(200 char),',
'    image                          blob,',
'    created                        date not null,',
'    created_by                     varchar2(255 char) not null',
')',
';',
'',
'-- table index',
'create index cke_images_i1 on cke_images (document_id);',
'',
'',
'-- triggers',
'create or replace trigger cke_documents_biu',
'    before insert or update ',
'    on cke_documents',
'    for each row',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    end if;',
'    :new.updated := sysdate;',
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'end cke_documents_biu;',
'/',
'',
'create or replace trigger cke_images_biu',
'    before insert or update ',
'    on cke_images',
'    for each row',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    end if;',
'end cke_images_biu;',
'/',
'',
'-- load data',
''))
);
wwv_flow_imp.component_end;
end;
/
