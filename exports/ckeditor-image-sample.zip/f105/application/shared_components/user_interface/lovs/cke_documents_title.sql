prompt --application/shared_components/user_interface/lovs/cke_documents_title
begin
--   Manifest
--     CKE_DOCUMENTS.TITLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7324704527453303
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9263966006377983)
,p_lov_name=>'CKE_DOCUMENTS.TITLE'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'CKE_DOCUMENTS'
,p_return_column_name=>'ID'
,p_display_column_name=>'TITLE'
,p_default_sort_column_name=>'TITLE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
