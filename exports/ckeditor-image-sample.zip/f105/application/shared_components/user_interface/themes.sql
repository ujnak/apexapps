prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 105
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7324704527453303
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(9213528496377399)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(9051662895377282)
,p_default_dialog_template=>wwv_flow_imp.id(9065036256377289)
,p_error_template=>wwv_flow_imp.id(9062474447377288)
,p_printer_friendly_template=>wwv_flow_imp.id(9051662895377282)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(9062474447377288)
,p_default_button_template=>wwv_flow_imp.id(9210559089377386)
,p_default_region_template=>wwv_flow_imp.id(9112873343377320)
,p_default_chart_template=>wwv_flow_imp.id(9112873343377320)
,p_default_form_template=>wwv_flow_imp.id(9112873343377320)
,p_default_reportr_template=>wwv_flow_imp.id(9112873343377320)
,p_default_tabform_template=>wwv_flow_imp.id(9112873343377320)
,p_default_wizard_template=>wwv_flow_imp.id(9112873343377320)
,p_default_menur_template=>wwv_flow_imp.id(9125419536377326)
,p_default_listr_template=>wwv_flow_imp.id(9112873343377320)
,p_default_irr_template=>wwv_flow_imp.id(9110772342377318)
,p_default_report_template=>wwv_flow_imp.id(9173365235377356)
,p_default_label_template=>wwv_flow_imp.id(9208050653377381)
,p_default_menu_template=>wwv_flow_imp.id(9212164230377387)
,p_default_calendar_template=>wwv_flow_imp.id(9212223102377389)
,p_default_list_template=>wwv_flow_imp.id(9196334526377373)
,p_default_nav_list_template=>wwv_flow_imp.id(9200552281377375)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(9200552281377375)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(9202583837377377)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(9080095288377301)
,p_default_dialogr_template=>wwv_flow_imp.id(9077261796377300)
,p_default_option_label=>wwv_flow_imp.id(9208050653377381)
,p_default_required_label=>wwv_flow_imp.id(9209387089377383)
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_default_navbar_list_template=>wwv_flow_imp.id(9202159691377376)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/22.1/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
