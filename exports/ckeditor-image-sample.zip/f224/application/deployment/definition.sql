prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 224
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>224
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(34164322092254249)
,p_prompt_sub_string_02=>'Y'
,p_install_prompt_02=>unistr('\753B\50CF\30A2\30C3\30D7\30ED\30FC\30C9URL')
);
wwv_flow_imp.component_end;
end;
/
