prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>289
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\76EE\6483\60C5\5831')
,p_alias=>'HOME'
,p_step_title=>unistr('\718A\76EE\6483\60C5\5831')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(117203772428587521)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231027062023'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(111144119066178148)
,p_plug_name=>unistr('\5730\56F3')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(117236719409587553)
,p_plug_display_sequence=>20
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(111144259383178149)
,p_region_id=>wwv_flow_imp.id(111144119066178148)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'STATIC'
,p_init_position_lon_static=>'141.3543'
,p_init_position_lat_static=>'43.062'
,p_init_zoomlevel_static=>'9'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(111144330492178150)
,p_map_region_id=>wwv_flow_imp.id(111144259383178149)
,p_name=>unistr('\76EE\6483\60C5\5831')
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    id,',
'    sighting_no,',
'    sighting_date,',
'    address,',
'    location,',
unistr('    /* \306A\305C\304BTool Tip\306E\62E1\5F35\30D5\30A9\30FC\30DE\30C3\30C8\304C\52B9\304B\306A\3044 */'),
'    ''No: '' || sighting_no || '' / '' ||',
'    to_char(sighting_date,''DL TS'') || '' / '' ||',
'    address || '' / '' ||',
'    note info,',
'    note',
'from bear_sightings',
'where ',
'    sighting_no in ',
'    (',
'        select pid from table(',
'            facet_report_keys(',
'                p_app_id => :APP_ID',
'                ,p_page_id => :APP_PAGE_ID',
'                ,p_region => ''bear_sightings''',
'                ,p_column => ''SIGHTING_NO''',
'            )',
'        )',
'    )',
' '))
,p_has_spatial_index=>false
,p_pk_column=>'ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'LOCATION'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>true
,p_info_window_html_expr=>'&INFO.'
,p_allow_hide=>true
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(117496212806588021)
,p_name=>'Bear Sightings'
,p_region_name=>'bear_sightings'
,p_template=>wwv_flow_imp.id(117303309465587603)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       SIGHTING_NO,',
'       SIGHTING_DATE,',
unistr('       substr(address, 1, instr(address,''\533A'')) ward,'),
'       ADDRESS,',
'       LOCATION,',
'       ATTRIBUTES,',
'       NOTE',
'  from BEAR_SIGHTINGS'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(117329977069587624)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>100000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117499069299588038)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>0
,p_column_heading=>'ID'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_hidden_column=>'Y'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117499450658588042)
,p_query_column_id=>2
,p_column_alias=>'SIGHTING_NO'
,p_column_display_sequence=>2
,p_column_heading=>'No'
,p_use_as_row_header=>'N'
,p_column_format=>'990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117499814948588043)
,p_query_column_id=>3
,p_column_alias=>'SIGHTING_DATE'
,p_column_display_sequence=>3
,p_column_heading=>unistr('\65E5\6642')
,p_use_as_row_header=>'N'
,p_column_format=>'DL TS'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(111143980031178146)
,p_query_column_id=>4
,p_column_alias=>'WARD'
,p_column_display_sequence=>13
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117500202849588044)
,p_query_column_id=>5
,p_column_alias=>'ADDRESS'
,p_column_display_sequence=>23
,p_column_heading=>unistr('\5834\6240')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117500665264588044)
,p_query_column_id=>6
,p_column_alias=>'LOCATION'
,p_column_display_sequence=>33
,p_column_heading=>'Location'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(117199430701587459)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117501015436588045)
,p_query_column_id=>7
,p_column_alias=>'ATTRIBUTES'
,p_column_display_sequence=>43
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(117501477953588046)
,p_query_column_id=>8
,p_column_alias=>'NOTE'
,p_column_display_sequence=>53
,p_column_heading=>unistr('\5185\5BB9')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>-wwv_flow_imp.id(117199430701587459)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117496383095588021)
,p_plug_name=>unistr('\691C\7D22')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(117303309465587603)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(117496212806588021)
,p_landmark_label=>unistr('\30D5\30A3\30EB\30BF')
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117497928583588028)
,p_plug_name=>unistr('\30DC\30BF\30F3\30FB\30D0\30FC')
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(117266948966587576)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117502015094588048)
,p_plug_name=>unistr('\718A\76EE\6483\60C5\5831')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(117287579765587589)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(117498466988588030)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(117497928583588028)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(117376678734587682)
,p_button_image_alt=>unistr('\30EA\30BB\30C3\30C8')
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:RR,1::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111143718316178144)
,p_name=>'P1_ATTRIBUTES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(117496383095588021)
,p_prompt=>unistr('\72B6\6CC1')
,p_source=>'ATTRIBUTES'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
,p_multi_value_type=>'JSON_ARRAY'
,p_fc_filter_combination=>'AND'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111144085001178147)
,p_name=>'P1_WARD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(117496383095588021)
,p_prompt=>unistr('\533A')
,p_source=>'WARD'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117496835107588024)
,p_name=>'P1_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(117496383095588021)
,p_prompt=>unistr('\691C\7D22')
,p_source=>'ADDRESS,NOTE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
,p_attribute_04=>'N'
,p_fc_collapsible=>false
,p_fc_initial_collapsed=>false
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(117528373328902501)
,p_name=>unistr('\5730\56F3\3092\30EA\30D5\30EC\30C3\30B7\30E5')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(117496212806588021)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(117528442802902502)
,p_event_id=>wwv_flow_imp.id(117528373328902501)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(111144119066178148)
);
wwv_flow_imp.component_end;
end;
/
