prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('data-parent-element\30B5\30F3\30D7\30EB')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#page-actions#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230126071109'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(35112857069093044)
,p_plug_name=>unistr('\5F79\8077\306E\9078\629E')
,p_region_name=>'POPUP_SELECT_JOB'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-nosize'
,p_region_attributes=>'data-parent-element="#SELECT_JOB"'
,p_plug_template=>wwv_flow_imp.id(36355307416930416)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36479406165930488)
,p_plug_name=>unistr('data-parent-element\30B5\30F3\30D7\30EB')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(36337510540930408)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35112743332093043)
,p_button_sequence=>20
,p_button_name=>'SELECT_JOB'
,p_button_static_id=>'SELECT_JOB'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(36443466240930457)
,p_button_image_alt=>unistr('\5F79\8077\306E\9078\629E')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$open-inline-popup?source=P1_JOB&target=P1_JOB_SELECT&region=POPUP_SELECT_JOB"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35112638591093042)
,p_name=>'P1_JOB'
,p_item_sequence=>10
,p_prompt=>unistr('\5F79\8077')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LIST_OF_JOBS'
,p_lov=>'select distinct job from emp'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(36440931419930456)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35112936786093045)
,p_name=>'P1_JOB_SELECT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(35112857069093044)
,p_prompt=>unistr('\5F79\8077\4E00\89A7')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LIST_OF_JOBS'
,p_lov=>'select distinct job from emp'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('\672A\9078\629E')
,p_field_template=>wwv_flow_imp.id(36440931419930456)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35113343518093049)
,p_name=>'onChange P1_JOB_SELECT'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_JOB_SELECT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36485655290314705)
,p_event_id=>wwv_flow_imp.id(35113343518093049)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('\30A4\30F3\30E9\30A4\30F3\30FB\30DD\30C3\30D7\30A2\30C3\30D7\3092\9589\3058\308B')
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.invoke("close-inline-popup", this.browserEvent, this.triggeringElement, {',
'    source: "P1_JOB_SELECT",',
'    target: "P1_JOB",',
'    region: "POPUP_SELECT_JOB"',
'} );'))
);
wwv_flow_imp.component_end;
end;
/
