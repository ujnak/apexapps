prompt --application/shared_components/security/authentications/no_auth
begin
--   Manifest
--     AUTHENTICATION: No Auth
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>203
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(89483076233486806)
,p_name=>'No Auth'
,p_scheme_type=>'NATIVE_DAD'
,p_attribute_01=>'nobody'
,p_cookie_name=>'MY_CUST_SESSION'
,p_use_secure_cookie_yn=>'Y'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
