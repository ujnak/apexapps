prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 203
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>203
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000B4494441545847633C1531F73FC30002C651078C86C068088C86C0A00F816F7F7E30B0C8F131FC62FCC320A1258F5166BEB8F6';
wwv_flow_imp.g_varchar2_table(2) := '9081ED3F0BD6B294E9F31F0696CFFFF096B3044BC257AC5F18044485C872C087D7EF18C47EF350E6805F526C0C52EAF20C3F58FE3028FA196318767FD359068E3FD843E0D9CD870C6CCF7E0D71078C46C168080C782E188D8237DF3F30F0298B9155127E';
wwv_flow_imp.g_varchar2_table(3) := 'BAFB8A41845380B28288D60D668275C1A8034643603404464380D6210000DDF0E8E115CDB40B0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(89021143373379118)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
