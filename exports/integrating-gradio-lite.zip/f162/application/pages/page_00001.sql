prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>162
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Gradio Lite'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="module" crossorigin src="https://cdn.jsdelivr.net/npm/@gradio/lite/dist/lite.js"></script>',
'<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@gradio/lite/dist/lite.css" />'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * gradio-lite\306E\30AB\30B9\30BF\30E0\8981\7D20\306B\542B\307E\308C\308B\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3057\305F\3068\304D\306B\3001'),
unistr(' * APEX\304C\30DA\30FC\30B8\3092\9001\4FE1\3059\308B\306E\3092\6291\5236\3059\308B\3002'),
' * ',
unistr(' * gradio-lite\5185\306E\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3067\304D\308B\3068\3044\3046\3053\3068\306F\3001Gradio Lite\306E'),
unistr(' * \521D\671F\5316\306F\5B8C\4E86\3057\3066\3044\308B\304B\3089\3001document.querySelectorAll\3067\30DC\30BF\30F3\3092\53D6\5F97\3067\304D\308B\3002'),
' */',
'document.addEventListener(''click'', (event) => {',
'    const buttons = document.querySelectorAll("gradio-lite button");',
'    buttons.forEach( (button) => {',
'        if (button === event.target) {',
'            console.log(''click on button within gradio-lite is ignored to prevent page submittion.'', event.target);',
'            event.preventDefault();',
'        }',
'    });',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47903228923861204)
,p_plug_name=>'First Sample'
,p_region_name=>'GRADIO-REGION'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(53380478541082368)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<gradio-lite>',
'import gradio as gr',
'',
'def greet(name):',
'	return "Hello, " + name + "!"',
'',
'gr.Interface(greet, "textbox", "textbox").launch()',
'</gradio-lite>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47903812246861210)
,p_plug_name=>'Multiple Files'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(53380478541082368)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<gradio-lite>',
'',
'<gradio-file name="app.py" entrypoint>',
'import gradio as gr',
'from utils import add',
'',
'demo = gr.Interface(fn=add, inputs=["number", "number"], outputs="number")',
'',
'demo.launch()',
'</gradio-file>',
'',
'<gradio-file name="utils.py" >',
'def add(a, b):',
'	return a + b',
'</gradio-file>',
'',
'</gradio-lite>'))
,p_required_patch=>wwv_flow_imp.id(53276642118082106)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47903917543861211)
,p_plug_name=>'Additonal Requiremnts'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(53380478541082368)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<gradio-lite>',
'',
'<gradio-requirements>',
'transformers_js_py',
'</gradio-requirements>',
'',
'<gradio-file name="app.py" entrypoint>',
'from transformers_js import import_transformers_js',
'import gradio as gr',
'',
'transformers = await import_transformers_js()',
'pipeline = transformers.pipeline',
'pipe = await pipeline(''sentiment-analysis'')',
'',
'async def classify(text):',
'	return await pipe(text)',
'',
'demo = gr.Interface(classify, "textbox", "json")',
'demo.launch()',
'</gradio-file>',
'',
'</gradio-lite>'))
,p_required_patch=>wwv_flow_imp.id(53276642118082106)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47904014515861212)
,p_plug_name=>'Playground'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(53380478541082368)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<gradio-lite playground layout="horizontal">',
'import gradio as gr',
'',
'gr.Interface(fn=lambda x: x,',
'			inputs=gr.Textbox(),',
'			outputs=gr.Textbox()',
'		).launch()',
'</gradio-lite>'))
,p_required_patch=>wwv_flow_imp.id(53276642118082106)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53578222412083075)
,p_plug_name=>'Gradio Lite'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(53347183522082290)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47903343764861205)
,p_name=>'beforeSubmit'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'apexbeforepagesubmit'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47903444760861206)
,p_event_id=>wwv_flow_imp.id(47903343764861205)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(this.browserEvent);',
'this.browserEvent.preventDefault();'))
);
wwv_flow_imp.component_end;
end;
/
