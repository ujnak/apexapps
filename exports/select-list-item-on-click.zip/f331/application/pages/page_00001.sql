prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>331
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Active List'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add([',
'    {',
'        name: "select-city",',
'        action: function( event, element, args ) {',
unistr('            // \30BB\30EC\30AF\30BF\306F\9078\629E\3057\305F\30EA\30B9\30C8\30FB\30C6\30F3\30D7\30EC\30FC\30C8\306B\3088\3063\3066\7570\306A\308B\3002\3053\308C\306F Links List\306E\5834\5408\3002'),
'            const allLabels = document.querySelectorAll("#CITY_LIST li .t-LinksList-label");',
'            allLabels.forEach((e) => {',
unistr('                // element\3068\3057\3066\8FD4\3055\308C\308B\306E\306Fli\8981\7D20\3002'),
'                if (element == e) {',
'                    /*',
unistr('                     * \30AF\30EA\30C3\30AF\3055\308C\305F\8981\7D20\3067\3042\308C\3070\3001P1_CITY\306B\90FD\5E02\540D\3092\8A2D\5B9A\3057\3001'),
unistr('                     * \8868\793A\3092\5909\3048\308B\305F\3081\306Bu-danger\30AF\30E9\30B9\3092\8FFD\52A0\3057\3066\3044\308B\3002'),
unistr('                     * \9078\629E\6642\306E\30EA\30F3\30AF\306E\898B\305B\65B9\3092\5909\3048\308B\306B\306Fu-danger\306E\30AF\30E9\30B9\3092\5909\3048\308B\3002'),
'                     */',
'                    apex.items.P1_CITY.setValue(e.textContent, e.textContent, true);',
'                    e.classList.add("u-danger");',
'                }',
'                else',
'                {',
'                    /*',
unistr('                     * \4E00\81F4\3057\3066\3044\306A\3044li\8981\7D20\304B\3089\306Fu-danger\3092\9664\304F\3002'),
'                     */',
'                    e.classList.remove("u-danger");',
'                }',
'            })',
'        }',
'    }',
']);'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240208063346'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47531651525150529)
,p_plug_name=>'Sample List'
,p_region_name=>'CITY_LIST'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(50777157271897514)
,p_plug_display_sequence=>10
,p_list_id=>wwv_flow_imp.id(51042120882915199)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(50896970744897590)
,p_landmark_type=>'region'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(51039893143897994)
,p_plug_name=>'Active List'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(50809012890897536)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47531959714150532)
,p_name=>'P1_CITY'
,p_item_sequence=>30
,p_prompt=>'City'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>unistr('STATIC2:\672D\5E4C;\672D\5E4C,\6771\4EAC;\6771\4EAC,\4EAC\90FD;\4EAC\90FD,\5927\962A;\5927\962A,\798F\5CA1;\798F\5CA1')
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(50912754624897601)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'6'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47532092202150533)
,p_name=>'onChange City'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_CITY'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47532151307150534)
,p_event_id=>wwv_flow_imp.id(47532092202150533)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const v = $v(this.triggeringElement);',
'const allLabels = document.querySelectorAll("#CITY_LIST li .t-LinksList-label");',
'allLabels.forEach((e) => {',
'    if ( e.textContent == v ) {',
'        /*',
unistr('         * \9078\629E\3055\308C\305F\90FD\5E02\540D\3068\3001\30EA\30B9\30C8\306E\30C6\30AD\30B9\30C8\30FB\30CE\30FC\30C9\304C\540C\3058\3067\3042\308C\3070'),
unistr('         * \30EA\30F3\30AF\3092\30CF\30A4\30E9\30A4\30C8\3059\308B\3002'),
'         */',
'        e.classList.add("u-danger");',
'    }',
'    else',
'    {',
'        /*',
unistr('         * \4E00\81F4\3057\3066\3044\306A\3044li\8981\7D20\304B\3089\306Fu-danger\3092\9664\304F\3002'),
'         */',
'        e.classList.remove("u-danger");',
'    }',
'});'))
);
wwv_flow_imp.component_end;
end;
/
