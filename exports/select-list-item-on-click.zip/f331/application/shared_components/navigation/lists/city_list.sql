prompt --application/shared_components/navigation/lists/city_list
begin
--   Manifest
--     LIST: City List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>331
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(51042120882915199)
,p_name=>'City List'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(51042335552915199)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('\672D\5E4C')
,p_list_item_link_target=>'#action$select-city'
,p_list_item_current_for_pages=>unistr('#action$set-city?city=\672D\5E4C')
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(51042701960915200)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('\6771\4EAC')
,p_list_item_link_target=>'#action$select-city'
,p_list_item_current_for_pages=>unistr('#action$set-city?city=\6771\4EAC')
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(51043159201915200)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('\4EAC\90FD')
,p_list_item_link_target=>'#action$select-city'
,p_list_item_current_for_pages=>unistr('#action$set-city?city=\4EAC\90FD')
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(51043516340915200)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('\5927\962A')
,p_list_item_link_target=>'#action$select-city'
,p_list_item_current_for_pages=>unistr('#action$set-city?city=\5927\962A')
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(51043953553915200)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('\798F\5CA1')
,p_list_item_link_target=>'#action$select-city'
,p_list_item_current_for_pages=>unistr('#action$set-city?city=\798F\5CA1')
);
wwv_flow_imp.component_end;
end;
/
