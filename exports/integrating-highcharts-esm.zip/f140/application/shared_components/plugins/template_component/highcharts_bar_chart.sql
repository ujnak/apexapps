prompt --application/shared_components/plugins/template_component/highcharts_bar_chart
begin
--   Manifest
--     PLUGIN: HIGHCHARTS_BAR_CHART
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>140
,p_default_id_offset=>35317023863981757
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(35323364337250196)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '')
,p_name=>'HIGHCHARTS_BAR_CHART'
,p_display_name=>'Highcharts Bar Chart'
,p_supported_component_types=>'PARTIAL'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','HIGHCHARTS_BAR_CHART'),'')
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://code.highcharts.com/highcharts.js',
'#PLUGIN_FILES#js/script#MIN#.js'))
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="#APEX$DOM_ID#" class="#CSS_CLASSES#"><div>',
'<script type="module">',
'    import Highcharts from ''highcharts'';',
'',
'    const groups = ''#GROUPS#'';',
'    const value  = ''#VALUE#'';',
'',
'    let config = {',
'        chart: {',
'            type: ''bar''',
'        },',
'        title: {',
'            text: ''''',
'        },',
'        xAxis: {',
'            categories: JSON.parse(groups)',
'        },',
'        yAxis: {',
'            title: {',
'                text: ''''',
'            },',
'            labels: {',
'                format: ''{value:.0f}''',
'            }',
'        },',
'        series: [{',
'            data: JSON.parse(value),',
'            showInLegend: false',
'        }]',
'    };',
'',
'    const color = ''#COLOR#'';',
'    if ( color ) {',
'        config.series[0].color = color;',
'    };',
'    const orientation = ''#ORIENTATION#'';',
'    if ( orientation !== null ) {',
'        config.chart.type = orientation;',
'    };',
'    const width = ''#WIDTH#'';',
'    if ( width ) {',
'        config.chart.width = width;',
'    };',
'    const height = ''#HEIGHT#'';',
'    if ( height ) {',
'        config.chart.height = height;',
'    };',
'    /* draw chart */',
'    let chart = Highcharts.chart(''#APEX$DOM_ID#'', config);',
'</script>'))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>1
,p_standard_attributes=>'REGION_TEMPLATE'
,p_substitute_attributes=>true
,p_version_scn=>41129000616182
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_files_version=>29
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35324089295250209)
,p_plugin_id=>wwv_flow_imp.id(35323364337250196)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_static_id=>'GROUPS'
,p_prompt=>'Groups'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>true
,p_escape_mode=>'RAW'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35324442507250209)
,p_plugin_id=>wwv_flow_imp.id(35323364337250196)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>70
,p_static_id=>'HEIGHT'
,p_prompt=>'Height'
,p_attribute_type=>'INTEGER'
,p_is_required=>false
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35324875557250210)
,p_plugin_id=>wwv_flow_imp.id(35323364337250196)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>50
,p_static_id=>'ORIENTATION'
,p_prompt=>'Orientation'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35326467996255164)
,p_plugin_attribute_id=>wwv_flow_imp.id(35324875557250210)
,p_display_sequence=>10
,p_display_value=>'horizontal'
,p_return_value=>'bar'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35326835078255740)
,p_plugin_attribute_id=>wwv_flow_imp.id(35324875557250210)
,p_display_sequence=>20
,p_display_value=>'vertical'
,p_return_value=>'column'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35325217514250211)
,p_plugin_id=>wwv_flow_imp.id(35323364337250196)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>30
,p_static_id=>'VALUE'
,p_prompt=>'Value'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>true
,p_escape_mode=>'RAW'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35325662919250212)
,p_plugin_id=>wwv_flow_imp.id(35323364337250196)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>6
,p_display_sequence=>60
,p_static_id=>'WIDTH'
,p_prompt=>'Width'
,p_attribute_type=>'INTEGER'
,p_is_required=>true
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(37662331797675683)
,p_plugin_id=>wwv_flow_imp.id(35323364337250196)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>7
,p_display_sequence=>40
,p_static_id=>'COLOR'
,p_prompt=>'Color'
,p_attribute_type=>'COLOR'
,p_is_required=>false
,p_escape_mode=>'RAW'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(37664856655681235)
,p_plugin_id=>wwv_flow_imp.id(35323364337250196)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>8
,p_display_sequence=>10
,p_static_id=>'CSS_CLASSES'
,p_prompt=>'CSS Classes'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
