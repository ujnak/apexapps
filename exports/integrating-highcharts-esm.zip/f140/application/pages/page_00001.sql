prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>140
,p_default_id_offset=>35317023863981757
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Integrating Highcharts'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "highcharts": "https://code.highcharts.com/es-modules/masters/highcharts.src.js"',
'        }',
'    }',
'</script>'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(100113032452127439)
,p_plug_name=>'Highcharts'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(100826398340256782)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="myChart"></div>',
'<script type="module">',
'    import Highcharts from ''highcharts'';',
'',
'    const groups = apex.item("P1_GROUPS").getValue();',
'    const value  = apex.item("P1_VALUE").getValue();',
'        ',
'    let config = {',
'        chart: {',
'            type: ''bar'',',
'            width: 400,',
'            height: 200',
'        },',
'        title: {',
'            text: ''''',
'        },',
'        xAxis: {',
'            categories: JSON.parse(groups)',
'        },',
'        yAxis: {',
'            title: {',
'                text: ''''',
'            },',
'            labels: {',
'                format: ''{value:.0f}''',
'            }',
'        },',
'        series: [{',
'            name: ''Salary'',',
'            data: JSON.parse(value),',
'            color: ''#309fdb'',',
'            showInLegend: false',
'        }]',
'    };',
'    let chart = Highcharts.chart(''myChart'', config);',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101024416764257483)
,p_plug_name=>'Integrating Highcharts'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(100803131199256733)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(100112605822127435)
,p_name=>'P1_GROUPS'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(100112708832127436)
,p_name=>'P1_VALUE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(100112776014127437)
,p_computation_sequence=>10
,p_computation_item=>'P1_GROUPS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        ename',
'    order by empno asc )',
'from emp where deptno = 10'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(100112892392127438)
,p_computation_sequence=>20
,p_computation_item=>'P1_VALUE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        sal',
'    order by empno asc )',
'from emp where deptno = 10'))
);
wwv_flow_imp.component_end;
end;
/
