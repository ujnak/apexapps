prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>309
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'OpenAI DALL-E'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(34512117325238545)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240126060628'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30307853972748849)
,p_button_sequence=>40
,p_button_name=>'GENERATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(34670152237238680)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Generate'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30307566570748846)
,p_name=>'P1_MODEL'
,p_item_sequence=>10
,p_item_default=>'dall-e-2'
,p_prompt=>'model'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:dall-e-3;dall-e-3,dall-e-2;dall-e-2'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(34667681468238674)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30307680352748847)
,p_name=>'P1_SIZE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_default=>'1024x1024'
,p_prompt=>'size'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:1024x1024;1024x1024,1024x1792;1024x1792,1792x1024;1792x1024'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(34667681468238674)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30307766800748848)
,p_name=>'P1_PROMPT'
,p_item_sequence=>30
,p_prompt=>'Prompt'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(34667681468238674)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30307977105748850)
,p_name=>'P1_RESPONSE'
,p_item_sequence=>60
,p_prompt=>'Resonse'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(34667681468238674)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34798867511281402)
,p_name=>'P1_IMAGE'
,p_item_sequence=>50
,p_prompt=>'Generated Image'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(34667681468238674)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(34798729326281401)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generate Image'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request json_object_t;',
'    l_request_clob clob;',
'    l_response clob;',
'    l_response_json json_object_t;',
'    e_api_call_failed exception;',
'    l_data   json_array_t;',
'    l_object json_object_t;',
'    l_url    varchar2(32767);',
'begin',
'    l_request := json_object_t();',
'    l_request.put(''model'', :P1_MODEL);',
'    l_request.put(''size'', :P1_SIZE);',
'    l_request.put(''prompt'', :P1_PROMPT);',
'    l_request_clob := l_request.to_clob();',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => :G_REQUEST_URL',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_api_call_failed;',
'    end if;',
'    :P1_RESPONSE := l_response;',
'    l_response_json := json_object_t(l_response);',
'    l_data := l_response_json.get_array(''data'');',
'    l_object := treat(l_data.get(0) as json_object_t);',
'    l_url := l_object.get_string(''url'');',
'    :P1_IMAGE := l_url;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(30307853972748849)
,p_internal_uid=>34798729326281401
);
wwv_flow_imp.component_end;
end;
/
