prompt --workspace/remote_servers/291_bucket
begin
--   Manifest
--     REMOTE SERVER: 291_BUCKET
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>309
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(19227142993348355)
,p_name=>'291_BUCKET'
,p_static_id=>'291_BUCKET'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('291_BUCKET'),'https://id9lwqituhyg.objectstorage.us-ashburn-1.oci.customer-oci.com/n/id9lwqituhyg/b/apex-static-files/o/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('291_BUCKET'),'')
,p_server_type=>'CLOUD_OBJECT_STORE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('291_BUCKET'),'')
,p_credential_id=>wwv_flow_imp.id(8715697685729597)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('291_BUCKET'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('291_BUCKET'),'')
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
