prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 270
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>270
,p_default_id_offset=>84108923274648876
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(247789894305779230)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(247554995789779031)
,p_default_dialog_template=>wwv_flow_imp.id(247549814770779028)
,p_error_template=>wwv_flow_imp.id(247539776034779022)
,p_printer_friendly_template=>wwv_flow_imp.id(247554995789779031)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(247539776034779022)
,p_default_button_template=>wwv_flow_imp.id(247704928491779130)
,p_default_region_template=>wwv_flow_imp.id(247631729514779076)
,p_default_chart_template=>wwv_flow_imp.id(247631729514779076)
,p_default_form_template=>wwv_flow_imp.id(247631729514779076)
,p_default_reportr_template=>wwv_flow_imp.id(247631729514779076)
,p_default_tabform_template=>wwv_flow_imp.id(247631729514779076)
,p_default_wizard_template=>wwv_flow_imp.id(247631729514779076)
,p_default_menur_template=>wwv_flow_imp.id(247644059029779083)
,p_default_listr_template=>wwv_flow_imp.id(247631729514779076)
,p_default_irr_template=>wwv_flow_imp.id(247603989520779060)
,p_default_report_template=>wwv_flow_imp.id(247658316496779093)
,p_default_label_template=>wwv_flow_imp.id(247702357452779128)
,p_default_menu_template=>wwv_flow_imp.id(247706546234779131)
,p_default_calendar_template=>wwv_flow_imp.id(247706563267779132)
,p_default_list_template=>wwv_flow_imp.id(247692323704779117)
,p_default_nav_list_template=>wwv_flow_imp.id(247701140885779126)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(247701140885779126)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(247699275782779124)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(247595334417779055)
,p_default_dialogr_template=>wwv_flow_imp.id(247565102048779038)
,p_default_option_label=>wwv_flow_imp.id(247702357452779128)
,p_default_required_label=>wwv_flow_imp.id(247703731275779129)
,p_default_navbar_list_template=>wwv_flow_imp.id(247698927565779124)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/23.1/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
