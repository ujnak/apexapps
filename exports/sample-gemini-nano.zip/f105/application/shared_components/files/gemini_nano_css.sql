prompt --application/shared_components/files/gemini_nano_css
begin
--   Manifest
--     APP STATIC FILES: 105
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19591634751348691
,p_default_application_id=>105
,p_default_id_offset=>28837615670297496
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E6F70656E2D617373697374616E742D627574746F6E207B0A20202020706F736974696F6E3A2066697865643B202F2A20E59BBAE5AE9AE4BD8DE7BDAEE381ABE38199E3828B202A2F0A20202020626F74746F6D3A20383070783B202020202F2A20E794';
wwv_flow_imp.g_varchar2_table(2) := 'BBE99DA2E4B88BE3818BE38289E381AEE8B79DE99BA2202A2F0A2020202072696768743A20323070783B20202020202F2A20E794BBE99DA2E58FB3E3818BE38289E381AEE8B79DE99BA2202A2F0A7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(157748269139642600)
,p_file_name=>'gemini-nano.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
