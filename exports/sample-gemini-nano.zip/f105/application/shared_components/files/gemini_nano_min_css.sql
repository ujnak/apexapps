prompt --application/shared_components/files/gemini_nano_min_css
begin
--   Manifest
--     APP STATIC FILES: 105
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19591634751348691
,p_default_application_id=>105
,p_default_id_offset=>28837615670297496
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E6F70656E2D617373697374616E742D627574746F6E7B706F736974696F6E3A66697865643B626F74746F6D3A383070783B72696768743A323070787D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(157749350586643646)
,p_file_name=>'gemini-nano.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
