prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>277
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('apex.date\30B5\30F3\30D7\30EB')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231005055506'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(95522232758745160)
,p_plug_name=>unistr('apex.date\30B5\30F3\30D7\30EB')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(95296581480744993)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93795661670200531)
,p_name=>'P1_START_DATE'
,p_item_sequence=>10
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('\958B\59CB\65E5')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(95400599937745054)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93795790810200532)
,p_name=>'P1_DAYS'
,p_item_sequence=>20
,p_prompt=>unistr('\7D4C\904E\65E5\6570')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(95400599937745054)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93795804597200533)
,p_name=>'P1_END_DATE'
,p_item_sequence=>30
,p_prompt=>unistr('\7D42\4E86\4E88\5B9A\65E5')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(95400599937745054)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(93795919506200534)
,p_name=>unistr('\7D42\4E86\65E5\306E\66F4\65B0')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_DAYS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93796054649200535)
,p_event_id=>wwv_flow_imp.id(93795919506200534)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* ',
unistr(' * Jon Dixson\3055\3093\306E\30D6\30ED\30B0\8A18\4E8B\3092\53C2\7167\3057\3066\3044\307E\3059\3002'),
' * ',
' * Easy Date Handling in JavaScript with apex.date',
' * https://blog.cloudnueva.com/apex-date-js-api',
' * Example 1 - Date Calculations',
' * ',
unistr(' * apex.date\306E\30EA\30D5\30A1\30EC\30F3\30B9\306F\4EE5\4E0B\3002'),
' * https://docs.oracle.com/en/database/oracle/apex/23.1/aexjs/apex.date.html',
' */',
'/* ',
unistr(' * \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\5B9A\7FA9\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\65E5\4ED8\66F8\5F0F\3092\53D6\308A\51FA\3057\307E\3059\3002'),
unistr(' * \30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306B\500B\5225\306B\65E5\4ED8\66F8\5F0F\3092\8A2D\5B9A\3057\3066\3044\308B\5834\5408\306F\3001dateFormat\306F'),
unistr(' * \305D\306E\5024\3092\6307\5B9A\3057\307E\3059\3002\307E\305F\3001apex.date.parse\306F\30AA\30E9\30AF\30EB\30FB\30C7\30FC\30BF\30D9\30FC\30B9\306E'),
unistr(' * \4E00\90E8\306E\65E5\4ED8\66F8\5F0F\3092\30B5\30DD\30FC\30C8\3057\3066\3044\307E\305B\3093\3002\FF08\8A73\7D30\306F\30EA\30D5\30A1\30EC\30F3\30B9\3092\78BA\8A8D\306E\3053\3068\FF09\3002'),
'*/',
'const dateFormat   = apex.locale.getDateFormat();',
unistr('// \7D4C\904E\65E5\6570\3092\53D6\308A\51FA\3057\6570\5024\306B\5909\63DB\3057\307E\3059\3002\FF08\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306E\5024\306F\6587\5B57\3067\3059\3002\FF09'),
'const addDays      = Number(apex.items.P1_DAYS.value);',
unistr('// \958B\59CB\65E5\306E\6587\5B57\5217\3092\65E5\4ED8\66F8\5F0F\306B\5F93\3063\3066JavaScript\306EDate\30AA\30D6\30B8\30A7\30AF\30C8\3068\3057\3066\53D6\308A\51FA\3057\307E\3059\3002'),
'let startDate    = apex.date.parse(apex.items.P1_START_DATE.value, dateFormat);',
unistr('// \7D4C\904E\65E5\6570\3092\52A0\3048\3066\7D42\4E86\4E88\5B9A\65E5\3068\3057\307E\3059\3002'),
'let endDate = apex.date.add(startDate, addDays, apex.date.UNIT.DAY);',
unistr('// \7D42\4E86\4E88\5B9A\65E5\3092\6307\5B9A\3057\305F\65E5\4ED8\66F8\5F0F\3067\6587\5B57\5217\306B\5909\63DB\3057\307E\3059\3002'),
'let endDateStr = apex.date.format(endDate, dateFormat);',
unistr('// \5F97\3089\308C\305F\7D42\4E86\4E88\5B9A\65E5\306E\6587\5B57\5217\3092\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306B\8A2D\5B9A\3057\307E\3059\3002'),
'apex.items.P1_END_DATE.setValue(endDateStr);'))
);
wwv_flow_imp.component_end;
end;
/
