prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>312
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'multiMonthYear (1 - Stacked)'
,p_alias=>'MULTIMONTHYEAR-1-STACKED'
,p_step_title=>'multiMonthYear (1 - Stacked)'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'08'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240116020753'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28374984277533810)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(28181900833482701)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(28066285529482632)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(28244335460482740)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56740631587016839)
,p_plug_name=>unistr('\56FD\6C11\306E\795D\65E5\30FB\4F11\65E5')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(28102985334482655)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'CAL_NATIONAL_HOLIDAYS'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'    config.endDateExclusive = false;',
'    config.headerToolbar.end = "";',
'    config.initialView = ''multiMonthYear'';',
'    config.multiMonthMaxColumns = 1;',
'}'))
,p_attribute_01=>'HOLIDAY_DATE'
,p_attribute_03=>'HOLIDAY_NAME'
,p_attribute_09=>'list:navigation'
,p_attribute_13=>'N'
,p_attribute_17=>'Y'
,p_attribute_19=>'Y'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_imp.component_end;
end;
/
