prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>268
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'JET Bind For Each'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code=>'var simple;'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'require(["require", "exports", "ojs/ojbootstrap", "knockout", "ojs/ojarraydataprovider", "ojs/ojknockout", "ojs/ojbutton"], function (require, exports, ojbootstrap_1, ko, ArrayDataProvider) {',
'    "use strict";',
'      ',
'    class SimpleModel {',
'        constructor() {',
'            this.userIdCount = 0;',
'            this.users = ko.observableArray([]);',
'            /*',
'            this.users = ko.observableArray([',
'                {',
'                    name: "Bert",',
'                },',
'                {',
'                    name: "Charles",',
'                },',
'                {',
'                    name: "Denise",',
'                },',
'            ]);',
'            */',
'            this.dataProvider = new ArrayDataProvider(this.users, {',
'                keyAttributes: "name",',
'            });',
'            this.removeUser = (event, current, bindingContext) => {',
'                this.users.remove(current.data);',
'              ',
'            };',
'            this.addUser = (event) => {',
'                this.users.push({',
'                    name: "User " + this.userIdCount++,',
'                });',
'            };',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        /*',
unistr('         * APEX\306B\3088\308B\30DA\30FC\30B8\9001\4FE1\3092\6291\5236\3059\308B\305F\3081\3001JET\304C\751F\6210\3059\308Bbuttun\8981\7D20\306Btype="button"\3092\8FFD\52A0\3059\308B\3002'),
unistr('         * \4EE5\4E0B\306EForum\3092\53C2\7167\3002'),
'         * https://forums.oracle.com/ords/apexds/post/how-to-avoid-a-oj-button-submit-the-page-8005',
'         */',
'        let form = document.getElementById("form-container");',
'        let ojbutton = form.querySelector("oj-button#addPerson");',
'        $(ojbutton).ready(() => {',
'            ojbutton.querySelector("button").setAttribute("type", "button");',
'        });',
'        /*',
unistr('         * form-container\306E\521D\671F\5316\3002'),
'         */',
'        simple = new SimpleModel();',
'        ko.applyBindings(simple, form);',
'        /*',
unistr('         * \521D\671F\5316\5F8C\306B\30C7\30FC\30BF\3092\8FFD\52A0\3059\308B\3002'),
'         */',
'        simple.users.push({ name: "Bert" });',
'        simple.users.push({ name: "Charles" });',
'        simple.users.push({ name: "Denise" });',
'    });',
'});'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#JET_CSS_DIRECTORY#alta/oj-alta-notag-min.css',
'https://static.oracle.com/cdn/fnd/gallery/2310.0.1/images/iconfont/ojuxIconFont.min.css',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230905130100'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80657462982902628)
,p_plug_name=>'For Each'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(82461165360590615)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="form-container">',
'    <h4>List of Users</h4>',
'    <oj-button id="addPerson" class="oj-button-sm" on-oj-action="[[addUser]]">Add User</oj-button>',
'    <ul>',
'        <oj-bind-for-each data="[[dataProvider]]">',
'            <template>',
'                <li class="oj-flex oj-sm-align-items-center">',
'                    <oj-bind-text value="[[$current.observableIndex]]"></oj-bind-text>',
'                    :',
'                    <oj-bind-text value="[[$current.data.name]]"></oj-bind-text>',
'                    <oj-button',
'                        class="oj-button-sm oj-sm-margin-1x-vertical"',
'                        chroming="borderless"',
'                        display="icons"',
'                        on-oj-action="[[removeUser]]">',
'                        <span slot="startIcon" class="oj-ux-ico-close"></span>',
'                        Remove',
'                    </oj-button>',
'                </li>',
'            </template>',
'            <template slot="noData">',
'                <div class="oj-typography-body-md oj-typography-bold oj-sm-padding-2x-top">',
'                    No Users to display',
'                </div>',
'            </template>',
'        </oj-bind-for-each>',
'    </ul>',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(80657626418902630)
,p_button_sequence=>20
,p_button_name=>'LIST_USERS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(82599576578590695)
,p_button_image_alt=>'List Users'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80657747904902631)
,p_name=>'P1_USERS'
,p_item_sequence=>30
,p_prompt=>'Users'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(82597009678590692)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80657819867902632)
,p_name=>'onClick LIST_USERS'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(80657626418902630)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80657997377902633)
,p_event_id=>wwv_flow_imp.id(80657819867902632)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let users = '''';',
'simple.users().forEach ((element, index) => {',
'    if (index > 0) {',
'        users = users + ":";',
'    }',
'    users = users + element.name;',
'});',
'apex.items.P1_USERS.setValue(users);'))
);
wwv_flow_imp.component_end;
end;
/
