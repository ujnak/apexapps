prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>159
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Create Schema'
,p_alias=>'CREATE-SCHEMA'
,p_step_title=>'Create Schema'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(63253058228249732)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(63066331034249142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(62950613917248896)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(63129192668249291)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61990154910061616)
,p_button_sequence=>20
,p_button_name=>'CREATE_JSON_SCHEMA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(63127589808249287)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Json Schema'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61989992471061614)
,p_name=>'P2_JSON_DATA'
,p_item_sequence=>10
,p_prompt=>'JSON Data'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>20
,p_field_template=>wwv_flow_imp.id(63125007870249280)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61990012547061615)
,p_name=>'P2_JSON_SCHEMA'
,p_item_sequence=>30
,p_prompt=>'JSON Schema'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>20
,p_field_template=>wwv_flow_imp.id(63125007870249280)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61990231122061617)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create JSON Schema'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const Genson = await import(''/npm/genson-js@0.0.8/+esm'');',
'',
'const jsonData = JSON.parse(apex.env.P2_JSON_DATA);',
'',
'const schema = Genson.createSchema(',
'    jsonData',
');',
'',
'apex.env.P2_JSON_SCHEMA = JSON.stringify(schema, null, 2);'))
,p_process_clob_language=>'JAVASCRIPT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(61990154910061616)
,p_internal_uid=>61990231122061617
);
wwv_flow_imp.component_end;
end;
/
