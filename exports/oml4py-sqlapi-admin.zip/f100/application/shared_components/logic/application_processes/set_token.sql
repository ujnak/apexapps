prompt --application/shared_components/logic/application_processes/set_token
begin
--   Manifest
--     APPLICATION PROCESS: Set Token
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880890015302417
,p_default_application_id=>100
,p_default_id_offset=>8882174263317214
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(17962270025076113)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Token'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    pyqSetAuthToken(:G_ACCESS_TOKEN);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'G_ACCESS_TOKEN'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_version_scn=>44501912249813
);
wwv_flow_imp.component_end;
end;
/
