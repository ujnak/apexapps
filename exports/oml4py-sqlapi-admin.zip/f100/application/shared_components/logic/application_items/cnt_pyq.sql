prompt --application/shared_components/logic/application_items/cnt_pyq
begin
--   Manifest
--     APPLICATION ITEM: CNT_PYQ
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880890015302417
,p_default_application_id=>100
,p_default_id_offset=>8882174263317214
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(9661589385708797)
,p_name=>'CNT_PYQ'
,p_protection_level=>'I'
,p_version_scn=>45045328399212
);
wwv_flow_imp.component_end;
end;
/
