prompt --application/shared_components/logic/application_items/cnt_e04
begin
--   Manifest
--     APPLICATION ITEM: CNT_E04
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880890015302417
,p_default_application_id=>100
,p_default_id_offset=>9936411107833520
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(58965385011305595)
,p_name=>'CNT_E04'
,p_protection_level=>'I'
,p_version_scn=>45045327206093
);
wwv_flow_imp.component_end;
end;
/
