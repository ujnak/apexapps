prompt --application/shared_components/logic/application_computations/cnt_e01
begin
--   Manifest
--     APPLICATION COMPUTATION: CNT_E01
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880890015302417
,p_default_application_id=>100
,p_default_id_offset=>9817970158658807
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(29272802737823880)
,p_computation_sequence=>10
,p_computation_item=>'CNT_E01'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'select count(*) from pyq_e01'
,p_version_scn=>45045327474844
);
wwv_flow_imp.component_end;
end;
/
