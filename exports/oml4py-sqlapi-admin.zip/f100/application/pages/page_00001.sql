prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880890015302417
,p_default_application_id=>100
,p_default_id_offset=>9817970158658807
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'OML4Py SQL API Admin'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37548251295018353)
,p_plug_name=>'OML4Py SQL API Admin'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37552943844967832)
,p_plug_name=>'Examples'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28634186983786210)
,p_plug_name=>'PYQ_E17'
,p_parent_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>170
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28634473844786213)
,p_plug_name=>'PYQ_E18'
,p_parent_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>180
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28635493997786223)
,p_plug_name=>'PYQ_E19'
,p_parent_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>190
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28634605579786214)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(28634473844786213)
,p_button_name=>'PYQ_E18_SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'linregrPredict - submit'
,p_grid_new_row=>'Y'
,p_grid_row_css_classes=>'u-flex u-align-items-center'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28635581001786224)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(28635493997786223)
,p_button_name=>'PYQ_E19_SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'MyFitMultiple - submit'
,p_grid_new_row=>'Y'
,p_grid_row_css_classes=>'u-flex u-align-items-center'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37553445419967837)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E01'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'pyqFun1  - JSON'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37553853235967841)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E02'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'pyqFun1  - ID, NAME, FLOAT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28635792311786226)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(28635493997786223)
,p_button_name=>'PYQ_E19_STATUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'myFitMultiple - status'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37554092602967844)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E03'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'test_seaborn_noinp'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37554461763967847)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E04'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'create_iris_table'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28634725945786216)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(28634473844786213)
,p_button_name=>'PYQ_E18_STATUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'linregrPredict - status'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28635942195786228)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(28635493997786223)
,p_button_name=>'PYQ_E19_RESULT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'myFitMultiple - result'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37551652583967819)
,p_button_sequence=>50
,p_button_name=>'GET_TOKEN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Get Token / Set Auth Token'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37554744394967850)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E05'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'test_seaborn_inp'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37555194414967855)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E06'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'myLinearRegressionModel'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37555501975967858)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E07'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'test_seaborn_inp - pyqRowEval'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37555906657967862)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E08'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'sample_iris_table'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28522639595818704)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E09'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'linregrPredict'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28635011929786218)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(28634473844786213)
,p_button_name=>'PYQ_E18_RESULT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'linregrPredict - result'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28522927089818707)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E10'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'linregrPredict - XML'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28523139673818709)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E11'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'test_seaborn_inp - pyqGroupEval'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28523415588818712)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E12'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'mygroupcount'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28523772602818715)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E13'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'mygroupcount - XML'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28524058438818718)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E14'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'mygroupcount - PNG'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28524601065818723)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E15'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'test_seaborn_idx'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28524744365818725)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_imp.id(37552943844967832)
,p_button_name=>'PYQ_E16'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'myFitMultiple'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28525067196818728)
,p_button_sequence=>180
,p_button_plug_id=>wwv_flow_imp.id(28634186983786210)
,p_button_name=>'PYQ_E17_SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'computeGradeDiff - submit'
,p_grid_new_row=>'Y'
,p_grid_row_css_classes=>'u-flex u-align-items-center'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28525335381818731)
,p_button_sequence=>220
,p_button_plug_id=>wwv_flow_imp.id(28634186983786210)
,p_button_name=>'PYQ_E17_STATUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'computeGradeDiff - status'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28525739965818735)
,p_button_sequence=>260
,p_button_plug_id=>wwv_flow_imp.id(28634186983786210)
,p_button_name=>'PYQ_E17_RESULT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'computeGradeDiff - result'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(37553765681967840)
,p_branch_name=>'Go to PYQ_E01'
,p_branch_action=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(37553445419967837)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(37554073687967843)
,p_branch_name=>'Go to PYQ_E02'
,p_branch_action=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(37553853235967841)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(37554303993967846)
,p_branch_name=>'Go to PYQ_E03'
,p_branch_action=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(37554092602967844)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(37554684366967849)
,p_branch_name=>'Go to PYQ_E04'
,p_branch_action=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(37554461763967847)
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(37555099539967854)
,p_branch_name=>'Go to PYQ_E05'
,p_branch_action=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(37554744394967850)
,p_branch_sequence=>50
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(37555460087967857)
,p_branch_name=>'Go to PYQ_E06'
,p_branch_action=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(37555194414967855)
,p_branch_sequence=>60
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(37555800419967861)
,p_branch_name=>'Go to PYQ_E07'
,p_branch_action=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(37555501975967858)
,p_branch_sequence=>70
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28522434506818702)
,p_branch_name=>'Go to PYQ_E08'
,p_branch_action=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(37555906657967862)
,p_branch_sequence=>80
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28522790605818705)
,p_branch_name=>'Go to PYQ_E09'
,p_branch_action=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28522639595818704)
,p_branch_sequence=>90
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28523074515818708)
,p_branch_name=>'Go to PYQ_E10'
,p_branch_action=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28522927089818707)
,p_branch_sequence=>100
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28523360837818711)
,p_branch_name=>'Go to PYQ_E11'
,p_branch_action=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28523139673818709)
,p_branch_sequence=>110
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28523674601818714)
,p_branch_name=>'Go to PYQ_E12'
,p_branch_action=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28523415588818712)
,p_branch_sequence=>120
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28523991897818717)
,p_branch_name=>'Go to PYQ_E13'
,p_branch_action=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28523772602818715)
,p_branch_sequence=>130
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28524374970818721)
,p_branch_name=>'Go to PYQ_E14'
,p_branch_action=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28524058438818718)
,p_branch_sequence=>140
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28524695152818724)
,p_branch_name=>'Go to PYQ_E15'
,p_branch_action=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28524601065818723)
,p_branch_sequence=>150
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28524954811818727)
,p_branch_name=>'Go to PYQ_E16'
,p_branch_action=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28524744365818725)
,p_branch_sequence=>160
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28634342903786212)
,p_branch_name=>'Go to PYQ_E17'
,p_branch_action=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28525739965818735)
,p_branch_sequence=>170
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28635387568786222)
,p_branch_name=>'Go to PYQ_E18'
,p_branch_action=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28635011929786218)
,p_branch_sequence=>180
,p_required_patch=>wwv_flow_imp.id(37534569521018495)
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28636809263786236)
,p_branch_name=>'Go to PYQ_E18_JSON'
,p_branch_action=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28635011929786218)
,p_branch_sequence=>190
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28636348945786232)
,p_branch_name=>'Go to PYQ_E19'
,p_branch_action=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(28635942195786228)
,p_branch_sequence=>200
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9017932513603945)
,p_name=>'P1_IS_TOKEN_SET'
,p_item_sequence=>10
,p_prompt=>'Is Token Set'
,p_source=>'to_char(sys.pyqIsTokenSet())'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28633951286786208)
,p_name=>'P1_E17_JOB_ID'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(28634186983786210)
,p_prompt=>'Job Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28634043735786209)
,p_name=>'P1_E17_STATUS'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(28634186983786210)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28634654736786215)
,p_name=>'P1_E18_JOB_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(28634473844786213)
,p_prompt=>'Job Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28634888228786217)
,p_name=>'P1_E18_STATUS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(28634473844786213)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28635683477786225)
,p_name=>'P1_E19_JOB_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(28635493997786223)
,p_prompt=>'Job Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28635821554786227)
,p_name=>'P1_E19_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(28635493997786223)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28636989655786238)
,p_name=>'P1_ACCESS_TOKEN'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551297648967816)
,p_name=>'P1_HOST'
,p_item_sequence=>20
,p_item_default=>'owa_util.get_cgi_env(''HTTP_HOST'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'SQL'
,p_prompt=>'Host'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551433783967817)
,p_name=>'P1_USERNAME'
,p_item_sequence=>30
,p_item_default=>'SYS_CONTEXT(''USERENV'', ''CURRENT_USER'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'SQL'
,p_prompt=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551557162967818)
,p_name=>'P1_PASSWORD'
,p_item_sequence=>40
,p_prompt=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37551747458967820)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Token'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_token_url     varchar2(4000);',
'    l_request       clob;',
'    l_request_json  json_object_t;',
'    l_response      clob;',
'    l_response_json json_object_t;',
'    e_get_token_failed exception;',
'begin',
'    /* construct the token url for OML4Py */',
'    l_token_url := apex_string.format(''https://%s/omlusers/api/oauth2/v1/token'', :P1_HOST);',
'    apex_debug.info(''toekn url = %s'', l_token_url);',
'    /* prepare request body */',
'    l_request_json := json_object_t();',
'    l_request_json.put(''grant_type'', ''password'');',
'    l_request_json.put(''username'', :P1_USERNAME);',
'    l_request_json.put(''password'', :P1_PASSWORD);',
'    l_request := l_request_json.to_clob();',
'    /* get token */',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', ''Accept'', ''application/json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_token_url',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'    );',
'    if not apex_web_service.g_status_code between 200 and 300 then',
'        raise e_get_token_failed;',
'    end if;',
'    /* get token from the response */',
'    apex_debug.info(l_response);',
'    l_response_json := json_object_t.parse(l_response);',
'    /* tokenType is always Bearer and expiresIn is always in 3600 */',
'    :P1_ACCESS_TOKEN := l_response_json.get_string(''accessToken'');',
'    /* once access token is taken, set it to token store */',
'    if :P1_ACCESS_TOKEN is not null then',
'        apex_debug.info(''Set Access Token: %s'', substr(:P1_ACCESS_TOKEN,1,10));',
'        sys.pyqSetAuthToken(:P1_ACCESS_TOKEN);',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37551652583967819)
,p_internal_uid=>9049758084468305
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37553553162967838)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E01'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e01;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e01(name, value)',
'    select name, value from table(',
'        pyqEval(',
'            par_lst => ''{"oml_service_level":"LOW"}'',',
'            out_fmt => ''JSON'',',
'            scr_name => ''pyqFun1''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37553445419967837)
,p_internal_uid=>9051563788468323
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37553957913967842)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E02'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e02;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e02("ID", "NAME", "FLOAT")',
'    select "ID", "NAME", "FLOAT" from table(',
'        pyqEval(',
'            par_lst => ''{"oml_service_level":"LOW"}'',',
'            out_fmt => ''{"ID":"number", "NAME":"VARCHAR2(8)", "FLOAT":"binary_double"}'',',
'            scr_name => ''pyqFun1''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37553853235967841)
,p_internal_uid=>9051968539468327
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37554200643967845)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E03'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e03;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e03("RID", "ID", "NAME", "TITLE", "IMAGE")',
'    select rownum "RID", "ID", "NAME", "TITLE", "IMAGE" from table(',
'        pyqEval(',
'            par_lst => ''{"oml_graphics_flag":true}'',',
'            out_fmt => ''PNG'',',
'            scr_name => ''test_seaborn_noinp'',',
'            scr_owner => NULL,',
'            env_name => ''seaborn''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37554092602967844)
,p_internal_uid=>9052211269468330
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37554502476967848)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E04'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from iris;',
'    /* copy SQL API result into the table */',
'    insert into iris("Species", "Sepal_Length", "Sepal_Width", "Petal_Length", "Petal_Width")',
'    select "Species", "Sepal_Length", "Sepal_Width", "Petal_Length", "Petal_Width" from table(',
'        pyqEval(',
'            par_lst => NULL,',
'            out_fmt => ''{"Species":"VARCHAR2(10)","Sepal_Length":"number","Sepal_Width":"number","Petal_Length":"number","Petal_Width":"number"}'',',
'            scr_name => ''create_iris_table''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37554461763967847)
,p_internal_uid=>9052513102468333
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37555068760967853)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E05'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e05;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e05("RID", "ID", "NAME", "TITLE", "IMAGE")',
'    select rownum "RID", "ID", "NAME", "TITLE", "IMAGE" from table(',
'        pyqTableEval(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"oml_graphics_flag":true}'',',
'            out_fmt => ''PNG'',',
'            scr_name => ''test_seaborn_inp'',',
'            scr_owner => NULL,',
'            env_name => ''seaborn''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37554744394967850)
,p_internal_uid=>9053079386468338
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37555323158967856)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E06'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e06;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e06("NAME", "VALUE")',
'    select "NAME", "VALUE" from table(',
'        pyqTableEval(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"modelName":"linregr","datastoreName":"pymodel"}'',',
'            out_fmt => ''XML'',',
'            scr_name => ''myLinearRegressionModel''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37555194414967855)
,p_internal_uid=>9053333784468341
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37555742495967860)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E07'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e07;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e07("RID", "ID", "NAME", "TITLE", "IMAGE")',
'    select rownum "RID", "ID", "NAME", "TITLE", "IMAGE" from table(',
'        pyqRowEval(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"oml_graphics_flag":true}'',',
'            out_fmt => ''PNG'',',
'            row_num => 50,',
'            scr_name => ''test_seaborn_inp'',',
'            scr_owner => NULL,',
'            env_name => ''seaborn''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37555501975967858)
,p_internal_uid=>9053753121468345
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37556010290967863)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E08'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from sample_iris;',
'    /* copy SQL API result into the table */',
'    insert into sample_iris("Species", "Sepal_Length", "Sepal_Width", "Petal_Length", "Petal_Width")',
'    select "Species", "Sepal_Length", "Sepal_Width", "Petal_Length", "Petal_Width" from table(',
'        pyqEval(',
'            par_lst => ''{"size":20}'',',
'            out_fmt => ''{"Species":"VARCHAR2(10)","Sepal_Length":"number","Sepal_Width":"number","Petal_Length":"number","Petal_Width":"number"}'',',
'            scr_name => ''sample_iris_table''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37555906657967862)
,p_internal_uid=>9054020916468348
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28522569075818703)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E09'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e09;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e09("Species", "Petal_Length", "Pred_Petal_Width")',
'    select "Species", "Petal_Length", "Pred_Petal_Width" from table(',
'        pyqRowEval(',
'            inp_nam => ''SAMPLE_IRIS'',',
'            par_lst => ''{"oml_input_type":"pandas.DataFrame","modelName":"linregr", "datastoreName":"pymodel"}'',',
'            out_fmt => ''{"Species":"varchar2(12)", "Petal_Length":"number", "Pred_Petal_Width":"number"}'',',
'            row_num => 5,',
'            scr_name => ''linregrPredict''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28522639595818704)
,p_internal_uid=>8902753964636402
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28522905508818706)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E10'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e10;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e10("NAME", "VALUE")',
'    select "NAME", "VALUE" from table(',
'        pyqRowEval(',
'            inp_nam => ''SAMPLE_IRIS'',',
'            par_lst => ''{"oml_input_type":"pandas.DataFrame","modelName":"linregr","datastoreName":"pymodel","oml_parallel_flag":true,"oml_service_level":"MEDIUM"}'',',
'            out_fmt => ''XML'',',
'            row_num => 10,',
'            scr_name => ''linregrPredict''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28522927089818707)
,p_internal_uid=>8903090397636405
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28523304440818710)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E11'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e11;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e11("RID", "ID", "NAME", "TITLE", "IMAGE")',
'    select rownum "RID", "ID", "NAME", "TITLE", "IMAGE" from table(',
'        pyqGroupEval(',
'            inp_nam =>  ''IRIS'',',
'            par_lst => ''{"oml_graphics_flag":true}'',',
'            out_fmt => ''PNG'',',
'            grp_col => ''Species'',',
'            ord_col => NULL,',
'            scr_name => ''test_seaborn_inp'',',
'            scr_owner => NULL,',
'            env_name => ''seaborn''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28523139673818709)
,p_internal_uid=>8903489329636409
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28523596580818713)
,p_process_sequence=>180
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E12'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e12;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e12("Species", "CNT")',
'    select "Species", "CNT" from table(',
'        pyqGroupEval(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"oml_input_type":"pandas.DataFrame"}'',',
'            out_fmt => ''{"Species":"varchar2(10)", "CNT":"number"}'',',
'            grp_col => ''Species'',',
'            ord_col => NULL,',
'            scr_name => ''mygroupcount''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28523415588818712)
,p_internal_uid=>8903781469636412
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28523876351818716)
,p_process_sequence=>190
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E13'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e13;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e13("NAME", "VALUE")',
'    select "NAME", "VALUE" from table(',
'        pyqGroupEval(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"oml_input_type":"pandas.DataFrame", "oml_graphics_flag":true, "oml_parallel_flag":true, "oml_service_level":"MEDIUM"}'',',
'            out_fmt => ''XML'',',
'            grp_col => ''Species'',',
'            ord_col => NULL,',
'            scr_name => ''mygroupcount''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28523772602818715)
,p_internal_uid=>8904061240636415
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28524312608818720)
,p_process_sequence=>200
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E14'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e14;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e14("RID", "ID", "NAME", "TITLE", "IMAGE")',
'    select rownum "RID", "ID", "NAME", "TITLE", "IMAGE" from table(',
'        pyqGroupEval(',
'            inp_nam => ''IRIS'',',
'            par_lst => ''{"oml_input_type":"pandas.DataFrame", "oml_graphics_flag":true}'',',
'            out_fmt => ''PNG'',',
'            grp_col => ''Species'',',
'            ord_col => NULL,',
'            scr_name => ''mygroupcount''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28524058438818718)
,p_internal_uid=>8904497497636419
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28524514731818722)
,p_process_sequence=>210
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E15'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e15;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e15("RID", "ID", "NAME", "TITLE", "IMAGE")',
'    select rownum "RID", "ID", "NAME", "TITLE", "IMAGE" from table(',
'        pyqIndexEval(',
'            par_lst => ''{"oml_graphics_flag":true}'',',
'            out_fmt => ''PNG'',',
'            times_num => 2,',
'            scr_name => ''test_seaborn_idx'',',
'            scr_owner => NULL,',
'            env_name => ''seaborn''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28524601065818723)
,p_internal_uid=>8904699620636421
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28524903635818726)
,p_process_sequence=>220
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E16'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e16;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e16("id", "score")',
'    select "id", "score" from table(',
'        pyqIndexEval(',
'            par_lst => ''{"sample_size":80,"oml_parallel_flag":true, "oml_service_level":"MEDIUM"}'',',
'            out_fmt => ''{"id":"number","score":"number"}'',',
'            times_num => 3,',
'            scr_name => ''myFitMultiple''',
'        )',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28524744365818725)
,p_internal_uid=>8905088524636425
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28525168588818729)
,p_process_sequence=>230
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E17_SUBMIT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_LOCATOR constant varchar2(40) := ''/oml/api/py-scripts/v1/jobs/'';',
'    l_url varchar2(400);',
'    l_idx pls_integer;',
'begin',
'    <<submit_job>>',
'    for r in (',
'        /* call SQL API for job_id */',
'        select "NAME", "VALUE" from table(',
'            pyqTableEval(',
'                inp_nam => ''GRADE'',',
'                par_lst => ''{"oml_async_flag":true}'',',
'                out_fmt => NULL,',
'                scr_name => ''computeGradeDiff'',',
'                scr_owner => NULL',
'            )',
'        )',
'    )',
'    loop',
'        l_idx := instr(r.value, C_LOCATOR) + length(C_LOCATOR);',
'        :P1_E17_JOB_ID := substr(r.value, l_idx);',
'        exit submit_job;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28525067196818728)
,p_internal_uid=>8905353477636428
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28525475318818732)
,p_process_sequence=>250
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E17_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_set PYQSYS.pyqClobSet;',
'begin',
'    <<status_loop>>',
'    for r in (',
'        select * from pyqJobStatus(',
'            job_id => :P1_E17_JOB_ID',
'        )',
'    )',
'    loop',
'        :P1_E17_STATUS := r.value;',
'        exit status_loop;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28525335381818731)
,p_internal_uid=>8905660207636431
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28525702869818734)
,p_process_sequence=>270
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E17_RESULT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e17;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e17("NAME", "SCORE", "FINALGRADE", "DIFF")',
'    select "NAME", "SCORE", "FINALGRADE", "DIFF" from pyqJobResult(',
'        job_id => :P1_E17_JOB_ID,',
'        out_fmt => ''{"NAME":"varchar2(7)","SCORE":"number","FINALGRADE":"number","DIFF":"number"}''',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28525739965818735)
,p_internal_uid=>8905887758636433
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28635057133786219)
,p_process_sequence=>290
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E18_SUBMIT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_LOCATOR constant varchar2(40) := ''/oml/api/py-scripts/v1/jobs/'';',
'    l_url varchar2(400);',
'    l_idx pls_integer;',
'begin',
'    <<submit_job>>',
'    for r in (',
'        /* call SQL API for job_id */',
'        select "NAME", "VALUE" from table(',
'            pyqGroupEval(',
'                inp_nam => ''SAMPLE_IRIS'',',
'                par_lst => ''{"oml_input_type":"pandas.DataFrame","oml_async_flag":true,"oml_graphics_flag":true,"modelName":"linregr","datastoreName":"pymodel"}'',',
'                out_fmt => NULL,',
'                grp_col => ''Species'',',
'                ord_col => NULL,',
'                scr_name => ''linregrPredict'',',
'                scr_owner => NULL,',
'                env_name => ''seaborn''',
'            )',
'        )',
'    )',
'    loop',
'        l_idx := instr(r.value, C_LOCATOR) + length(C_LOCATOR);',
'        :P1_E18_JOB_ID := substr(r.value, l_idx);',
'        exit submit_job;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28634605579786214)
,p_required_patch=>wwv_flow_imp.id(37534569521018495)
,p_internal_uid=>9015242022603918
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28636656989786235)
,p_process_sequence=>300
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E18_SUBMIT_JSON'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_LOCATOR constant varchar2(40) := ''/oml/api/py-scripts/v1/jobs/'';',
'    l_url varchar2(400);',
'    l_idx pls_integer;',
'begin',
'    <<submit_job>>',
'    for r in (',
'        /* call SQL API for job_id */',
'        select "NAME", "VALUE" from table(',
'            pyqGroupEval(',
'                inp_nam => ''IRIS'',',
'                par_lst => ''{"oml_input_type":"pandas.DataFrame","oml_async_flag":true,"modelName":"linregr","datastoreName":"pymodel"}'',',
'                out_fmt => NULL,',
'                grp_col => ''Species'',',
'                ord_col => NULL,',
'                scr_name => ''linregrPredict'',',
'                scr_owner => NULL',
'            )',
'        )',
'    )',
'    loop',
'        l_idx := instr(r.value, C_LOCATOR) + length(C_LOCATOR);',
'        :P1_E18_JOB_ID := substr(r.value, l_idx);',
'        exit submit_job;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28634605579786214)
,p_internal_uid=>9016841878603934
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28635142281786220)
,p_process_sequence=>310
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E18_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_set PYQSYS.pyqClobSet;',
'begin',
'    <<status_loop>>',
'    for r in (',
'        select * from pyqJobStatus(',
'            job_id => :P1_E18_JOB_ID',
'        )',
'    )',
'    loop',
'        :P1_E18_STATUS := r.value;',
'        exit status_loop;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28634725945786216)
,p_internal_uid=>9015327170603919
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28635235841786221)
,p_process_sequence=>320
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E18_RESULT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e18;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e18("RID", "ID", "NAME", "TITLE", "IMAGE")',
'    select rownum "RID", "ID", "NAME", "TITLE", "IMAGE" from pyqJobResult(',
'        job_id => :P1_E18_JOB_ID,',
'        out_fmt => ''PNG''',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28635011929786218)
,p_required_patch=>wwv_flow_imp.id(37534569521018495)
,p_internal_uid=>9015420730603920
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28636584297786234)
,p_process_sequence=>330
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E18_RESULT_JSON'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e18_json;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e18_json("NAME", "VALUE")',
'    select "NAME", "VALUE" from pyqJobResult(',
'        job_id => :P1_E18_JOB_ID,',
'        out_fmt => ''JSON''',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28635011929786218)
,p_internal_uid=>9016769186603933
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28636030061786229)
,p_process_sequence=>340
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E19_SUBMIT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_LOCATOR constant varchar2(40) := ''/oml/api/py-scripts/v1/jobs/'';',
'    l_url varchar2(400);',
'    l_idx pls_integer;',
'begin',
'    <<submit_job>>',
'    for r in (',
'        /* call SQL API for job_id */',
'        select "NAME", "VALUE" from table(',
'            pyqIndexEval(',
'                par_lst => ''{"sample_size":80,"oml_async_flag":true}'',',
'                out_fmt => ''XML'',',
'                times_num => 3,',
'                scr_name => ''myFitMultiple'',',
'                scr_owner => NULL',
'            )',
'        )',
'    )',
'    loop',
'        l_idx := instr(r.value, C_LOCATOR) + length(C_LOCATOR);',
'        :P1_E19_JOB_ID := substr(r.value, l_idx);',
'        exit submit_job;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28635581001786224)
,p_internal_uid=>9016214950603928
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28636176456786230)
,p_process_sequence=>350
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E19_STATUS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_set PYQSYS.pyqClobSet;',
'begin',
'    <<status_loop>>',
'    for r in (',
'        select * from pyqJobStatus(',
'            job_id => :P1_E19_JOB_ID',
'        )',
'    )',
'    loop',
'        :P1_E19_STATUS := r.value;',
'        exit status_loop;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28635792311786226)
,p_internal_uid=>9016361345603929
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28636306752786231)
,p_process_sequence=>360
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PYQ_E19_RESULT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from pyq_e19;',
'    /* copy SQL API result into the table */',
'    insert into pyq_e19("NAME", "VALUE")',
'    select "NAME", "VALUE" from pyqJobResult(',
'        job_id => :P1_E19_JOB_ID,',
'        out_fmt => ''XML''',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(28635942195786228)
,p_internal_uid=>9016491641603930
);
wwv_flow_imp.component_end;
end;
/
