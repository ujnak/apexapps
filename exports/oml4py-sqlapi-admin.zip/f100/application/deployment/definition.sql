prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880890015302417
,p_default_application_id=>100
,p_default_id_offset=>9817970158658807
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(29243051671569655)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    -- myFitMultiple',
'    begin sys.pyqScriptDrop(''myFitMultiple'',false,true);',
'    exception when others then null; end;',
'    -- computeGradeDiff',
'    begin sys.pyqScriptDrop(''computeGradeDiff'',false,true);',
'    exception when others then null; end;',
'    -- create_iris_table',
'    begin sys.pyqScriptDrop(''create_iris_table'',false,true);',
'    exception when others then null; end;',
'    -- test_seaborn_noinp',
'    begin sys.pyqScriptDrop(''test_seaborn_noinp'',false,true);',
'    exception when others then null; end;',
'    -- sample_iris_table',
'    begin sys.pyqScriptDrop(''sample_iris_table'',false,true);',
'    exception when others then null; end;',
'    -- pyqFun1',
'    begin sys.pyqScriptDrop(''pyqFun1'',false,true);',
'    exception when others then null; end;',
'    -- test_seaborn_inp',
'    begin sys.pyqScriptDrop(''test_seaborn_inp'',false,true);',
'    exception when others then null; end;',
'    -- myLinearRegressionModel',
'    begin sys.pyqScriptDrop(''myLinearRegressionModel'',false,true);',
'    exception when others then null; end;',
'    -- linregrPredict',
'    begin sys.pyqScriptDrop(''linregrPredict'',false,true);',
'    exception when others then null; end;',
'    -- mygroupcount',
'    begin sys.pyqScriptDrop(''mygroupcount'',false,true);',
'    exception when others then null; end;',
'    -- test_seaborn_idx',
'    begin sys.pyqScriptDrop(''test_seaborn_idx'',false,true);',
'    exception when others then null; end;',
'end;',
'/',
'drop table if exists pyq_e01;',
'drop table if exists pyq_e02;',
'drop table if exists pyq_e03;',
'drop table if exists pyq_e04;',
'drop table if exists pyq_e05;',
'drop table if exists pyq_e06;',
'drop table if exists pyq_e07;',
'drop table if exists pyq_e08;',
'drop table if exists pyq_e09;',
'drop table if exists pyq_e10;',
'drop table if exists pyq_e11;',
'drop table if exists pyq_e12;',
'drop table if exists pyq_e13;',
'drop table if exists pyq_e14;',
'drop table if exists pyq_e15;',
'drop table if exists pyq_e16;',
'drop table if exists pyq_e17;',
'drop table if exists pyq_e18;',
'drop table if exists pyq_e18_json;',
'drop table if exists pyq_e19;',
'drop table if exists iris;',
'drop table if exists sample_iris;',
'drop table if exists grade;'))
);
wwv_flow_imp.component_end;
end;
/
