prompt --application/deployment/install/install_tables
begin
--   Manifest
--     INSTALL: INSTALL-tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>8880890015302417
,p_default_application_id=>100
,p_default_id_offset=>9817970158658807
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(29412721555656100)
,p_install_id=>wwv_flow_imp.id(29243051671569655)
,p_name=>'tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table if exists pyq_e01;',
'drop table if exists pyq_e02;',
'drop table if exists pyq_e03;',
'drop table if exists pyq_e04;',
'drop table if exists pyq_e05;',
'drop table if exists pyq_e06;',
'drop table if exists pyq_e07;',
'drop table if exists pyq_e08;',
'drop table if exists pyq_e09;',
'drop table if exists pyq_e10;',
'drop table if exists pyq_e11;',
'drop table if exists pyq_e12;',
'drop table if exists pyq_e13;',
'drop table if exists pyq_e14;',
'drop table if exists pyq_e15;',
'drop table if exists pyq_e16;',
'drop table if exists pyq_e17;',
'drop table if exists pyq_e18;',
'drop table if exists pyq_e18_json;',
'drop table if exists pyq_e19;',
'CREATE TABLE "PYQ_E01"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "PYQ_E02"("ID" NUMBER,"NAME" VARCHAR2(8),"FLOAT" BINARY_DOUBLE);',
'CREATE TABLE "PYQ_E03"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"TITLE" VARCHAR2(128),"IMAGE" BLOB);',
'CREATE TABLE "PYQ_E05"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"TITLE" VARCHAR2(128),"IMAGE" BLOB);',
'CREATE TABLE "PYQ_E06"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "PYQ_E07"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"TITLE" VARCHAR2(128),"IMAGE" BLOB);',
'CREATE TABLE "PYQ_E09"("Species" VARCHAR2(12),"Petal_Length" NUMBER,"Pred_Petal_Width" NUMBER);',
'CREATE TABLE "PYQ_E10"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "PYQ_E11"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"TITLE" VARCHAR2(128),"IMAGE" BLOB);',
'CREATE TABLE "PYQ_E12"("Species" VARCHAR2(10),"CNT" NUMBER);',
'CREATE TABLE "PYQ_E13"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "PYQ_E14"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"TITLE" VARCHAR2(128),"IMAGE" BLOB);',
'CREATE TABLE "PYQ_E15"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"TITLE" VARCHAR2(128),"IMAGE" BLOB);',
'CREATE TABLE "PYQ_E16"("id" NUMBER,"score" NUMBER);',
'CREATE TABLE "PYQ_E17"("NAME" VARCHAR2(7),"SCORE" NUMBER,"FINALGRADE" NUMBER,"DIFF" NUMBER);',
'CREATE TABLE "PYQ_E18"("RID" NUMBER PRIMARY KEY,"ID" NUMBER,"NAME" VARCHAR2(128),"TITLE" VARCHAR2(128),"IMAGE" BLOB);',
'CREATE TABLE "PYQ_E18_JSON"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'CREATE TABLE "PYQ_E19"("NAME" VARCHAR2(128),"VALUE" CLOB);',
'',
'drop table if exists iris;',
'drop table if exists sample_iris;',
'drop table if exists grade;',
'',
'CREATE TABLE "IRIS" ',
'   (	"Species" VARCHAR2(10), ',
'	"Sepal_Length" NUMBER, ',
'	"Sepal_Width" NUMBER, ',
'	"Petal_Length" NUMBER, ',
'	"Petal_Width" NUMBER',
');',
'',
'CREATE TABLE "SAMPLE_IRIS" ',
'(	"Species" VARCHAR2(10), ',
'	"Sepal_Length" NUMBER, ',
'	"Sepal_Width" NUMBER, ',
'	"Petal_Length" NUMBER, ',
'	"Petal_Width" NUMBER',
'); ',
'',
'CREATE TABLE "GRADE"',
'(	"NAME" VARCHAR2(30), ',
'	"GENDER" VARCHAR2(1), ',
'	"STATUS" NUMBER(10,0), ',
'	"YEAR" NUMBER(10,0), ',
'	"SECTION" VARCHAR2(1), ',
'	"SCORE" NUMBER(10,0), ',
'	"FINALGRADE" NUMBER(10,0)',
');',
'',
'insert into GRADE values(''Abbott'', ''F'', 2, 97, ''A'', 90, 87);',
'insert into GRADE values(''Branford'', ''M'', 1, 98, ''A'', 92, 97);',
'insert into GRADE values(''Crandell'', ''M'', 2, 98, ''B'', 81, 71);',
'insert into GRADE values(''Dennison'', ''M'', 1, 97, ''A'', 85, 72);',
'insert into GRADE values(''Edgar'', ''F'', 1, 98, ''B'', 89, 80);',
'insert into GRADE values(''Faust'', ''M'', 1, 97, ''B'', 78, 73);',
'insert into GRADE values(''Greeley'', ''F'', 2, 97, ''A'', 82, 91);',
'insert into GRADE values(''Hart'', ''F'', 1, 98, ''B'', 84, 80);',
'insert into GRADE values(''Isley'', ''M'', 2, 97, ''A'', 88, 86);',
'insert into GRADE values(''Jasper'', ''M'', 1, 97, ''B'', 91, 83);',
'commit;'))
);
wwv_flow_imp.component_end;
end;
/
