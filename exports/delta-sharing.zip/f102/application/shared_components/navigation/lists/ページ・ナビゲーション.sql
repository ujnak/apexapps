prompt --application/shared_components/navigation/lists/ページ・ナビゲーション
begin
--   Manifest
--     LIST: ページ・ナビゲーション
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>8293372102693610
,p_default_application_id=>102
,p_default_id_offset=>11446559919798141
,p_default_owner=>'WKSP_DWAPEX'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(64615590213669840)
,p_name=>unistr('\30DA\30FC\30B8\30FB\30CA\30D3\30B2\30FC\30B7\30E7\30F3')
,p_list_status=>'PUBLIC'
,p_version_scn=>39196040865101
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(64616038667669839)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Provider'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(64616379020669839)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Consumer'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
