prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>8293372102693610
,p_default_application_id=>102
,p_default_id_offset=>11446559919798141
,p_default_owner=>'WKSP_DWAPEX'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'Events'
,p_alias=>'EVENTS'
,p_step_title=>'Events'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55269498637844392)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(64426397146670125)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(64310741599670199)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(64489184231670084)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55270212749844390)
,p_plug_name=>'Events'
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(64404170547670135)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>'select * from user_share_events'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Events'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(55270246104844390)
,p_name=>'Events'
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DWAPEX'
,p_internal_uid=>32532978146403524
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55271042008844388)
,p_db_column_name=>'SHARE_NAME'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Share Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55271366468844388)
,p_db_column_name=>'SHARE_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Share Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55271795302844388)
,p_db_column_name=>'STATUS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55272181466844387)
,p_db_column_name=>'DETAILS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Details'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55272586935844387)
,p_db_column_name=>'TIME'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Time'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55272974352844387)
,p_db_column_name=>'LOG_LEVEL'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Log Level'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55273357709844386)
,p_db_column_name=>'SHARE_JOB_ID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Share Job Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55273749458844386)
,p_db_column_name=>'SCHEDULER_JOB_NAME'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Scheduler Job Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55274194373844386)
,p_db_column_name=>'ACTION'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Action'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55274560897844385)
,p_db_column_name=>'SHARE_VERSION'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Share Version'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55274956574844385)
,p_db_column_name=>'OBJECT_NAME'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Object Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55275401023844385)
,p_db_column_name=>'OBJECT_OWNER'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Object Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55275836135844385)
,p_db_column_name=>'PARTITION_NAME'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Partition Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55276203483844384)
,p_db_column_name=>'SPLIT_ORDER'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Split Order'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55276568283844384)
,p_db_column_name=>'SQL_STATEMENT'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Sql Statement'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(55277039731843482)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'112612'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SHARE_NAME:SHARE_ID:STATUS:DETAILS:TIME:LOG_LEVEL:SHARE_JOB_ID:SCHEDULER_JOB_NAME:ACTION:SHARE_VERSION:OBJECT_NAME:OBJECT_OWNER:PARTITION_NAME:SPLIT_ORDER:SQL_STATEMENT'
,p_sort_column_1=>'TIME'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33385602437107120)
,p_button_sequence=>10
,p_button_name=>'CLEAR_SHARE_EVENTS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(64487665279670085)
,p_button_image_alt=>'Clear Share Events'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33385995392107120)
,p_button_sequence=>20
,p_button_name=>'CLEAR_RECIPIENT_EVENTS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(64487665279670085)
,p_button_image_alt=>'Clear Recipient Events'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(33392995752107113)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear Share Events'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' * clear all share events',
' */',
'begin',
'    for r in (',
'        select share_name from user_shares',
'    )',
'    loop',
'        dbms_share.clear_share_events(',
'            share_name => r.share_name',
'        );',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(33385602437107120)
,p_internal_uid=>10655727793666247
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(33393398661107113)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear Recipient Events'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' * Clear all recipient events',
' */',
'begin',
'    for r in (',
'        select recipient_name from user_share_recipients',
'    )',
'    loop',
'        dbms_share.clear_recipient_events(',
'            recipient_name => r.recipient_name',
'        );',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(33385995392107120)
,p_internal_uid=>10656130702666247
);
wwv_flow_imp.component_end;
end;
/
