prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>8293372102693610
,p_default_application_id=>102
,p_default_id_offset=>11446559919798141
,p_default_owner=>'WKSP_DWAPEX'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Jobs'
,p_alias=>'JOBS'
,p_step_title=>'Jobs'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add(',
'    [',
'        {',
'            name: "open-popup-stop-job",',
'            action: (event, element, args) => {',
'                /*',
unistr('                 * JOB_ID\3092\5F8C\7D9A\3067\5B9F\884C\3059\308BPL/SQL\306B\6E21\3059\305F\3081\3001\30DA\30FC\30B8\30A2\30A4\30C6\30E0\306B\8A2D\5B9A\3059\308B\3002'),
'                 */',
'                apex.items.P14_JOB_ID.setValue(args.id);',
'                /*',
unistr('                 * Inline Popup\304C\8868\793A\3055\308C\308B\4F4D\7F6E\3092\8A2D\5B9A\3057\305F\306E\3061\958B\304F\3002'),
'                 */',
'                let popup = $("#STOP_JOB").data("apexPopup");',
'                popup.options.position = { my: "left center", at: "right center", of: `#JOB-REC-${args.id}`};',
'                popup.options.minHeight = null;',
'                popup.options.minWidth  = null;',
'                popup.options.height = 60;',
'                popup.options.width  = 120;',
'            ',
'                console.log(popup);',
'                popup.open();',
'            }',
'        }',
'    ]',
');'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54842762392915295)
,p_plug_name=>'STOP_JOB'
,p_title=>'Stop Job'
,p_region_name=>'STOP_JOB'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-nosize:js-popup-pos-inside'
,p_plug_template=>wwv_flow_imp.id(64398774368670137)
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55245035764859887)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(64426397146670125)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(64310741599670199)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(64489184231670084)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55245737650859882)
,p_plug_name=>'Jobs'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(64404170547670135)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'select * from user_share_jobs'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Jobs'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(55245860857859882)
,p_name=>'Jobs'
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DWAPEX'
,p_internal_uid=>32508592899419016
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55246566291859876)
,p_db_column_name=>'JOB_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Job Id'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case STATUS/}',
'{when COMPLETED/}',
'<div class="u-flex u-justify-content-center">',
'    <span class="t-Button-label">#JOB_ID#</span>',
'</div>',
'{when STOPPING/}',
'<div class="u-flex u-justify-content-center">',
'    <span class="t-Button-label">#JOB_ID#</span>',
'</div>',
'{when STOPPED/}',
'<div class="u-flex u-justify-content-center">',
'    <span class="t-Button-label">#JOB_ID#</span>',
'</div>',
'{otherwise/}',
'<button type="button" class="t-Button"',
'    id="JOB-REC-#JOB_ID#"',
'    data-action="open-popup-stop-job?id=#JOB_ID#">',
'    <span class="t-Button-label">#JOB_ID#</span>',
'</button>',
'{endcase/}'))
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55246974940859875)
,p_db_column_name=>'JOB_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Job Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55247339500859875)
,p_db_column_name=>'SHARE_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Share Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55247739308859875)
,p_db_column_name=>'PARALLELISM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Parallelism'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55248166790859874)
,p_db_column_name=>'SHARE_NAME'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Share Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55248561507859874)
,p_db_column_name=>'SHARE_VERSION'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Share Version'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55248966759859874)
,p_db_column_name=>'STATUS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55249419162859873)
,p_db_column_name=>'ERROR_MESSAGE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Error Message'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55249810371859873)
,p_db_column_name=>'JOB_TYPE'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Job Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55250169525859873)
,p_db_column_name=>'JOB_CLASS'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Job Class'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55250531402859873)
,p_db_column_name=>'PRIORITY'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Priority'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55251013752859872)
,p_db_column_name=>'SHARE_TYPE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Share Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55251404187859872)
,p_db_column_name=>'SPLIT_SIZE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Split Size'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55251787366859872)
,p_db_column_name=>'STORAGE_URI'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Storage Uri'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55252211940859871)
,p_db_column_name=>'STORAGE_FOLDER'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Storage Folder'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55252554060859871)
,p_db_column_name=>'LOG_LEVEL'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Log Level'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55252992548859871)
,p_db_column_name=>'CREATED'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55253377830859871)
,p_db_column_name=>'UPDATED'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55253801893859870)
,p_db_column_name=>'RUN_DURATION'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Run Duration'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55254133873859870)
,p_db_column_name=>'JOB_ACTION'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Job Action'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(55254587946858948)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'112523'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JOB_ID:JOB_NAME:SHARE_ID:PARALLELISM:SHARE_NAME:SHARE_VERSION:STATUS:ERROR_MESSAGE:JOB_TYPE:JOB_CLASS:PRIORITY:SHARE_TYPE:SPLIT_SIZE:STORAGE_URI:STORAGE_FOLDER:LOG_LEVEL:CREATED:UPDATED:RUN_DURATION:JOB_ACTION'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33372392586111067)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(54842762392915295)
,p_button_name=>'STOP_JOB'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(64487665279670085)
,p_button_image_alt=>'Stop Job'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55270030564343747)
,p_name=>'P14_JOB_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54842762392915295)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33381244741111058)
,p_name=>'onClick STOP_JOB'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(33372392586111067)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33381750376111056)
,p_event_id=>wwv_flow_imp.id(33381244741111058)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    dbms_share.stop_job(',
'        share_job_id => :P14_JOB_ID',
'    );',
'end;'))
,p_attribute_02=>'P14_JOB_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33382171909111056)
,p_event_id=>wwv_flow_imp.id(33381244741111058)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(54842762392915295)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33382766200111056)
,p_event_id=>wwv_flow_imp.id(33381244741111058)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(55245737650859882)
);
wwv_flow_imp.component_end;
end;
/
