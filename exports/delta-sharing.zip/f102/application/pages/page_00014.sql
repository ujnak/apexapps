prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>8293372102693610
,p_default_application_id=>102
,p_default_id_offset=>11290708038642725
,p_default_owner=>'WKSP_DWAPEX'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Jobs'
,p_alias=>'JOBS'
,p_step_title=>'Jobs'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add(',
'    [',
'        {',
'            name: "open-popup-stop-job",',
'            action: (event, element, args) => {',
'                apex.items.P14_JOB_ID.setValue(args.jobId);',
'                apex.theme.openRegion("STOP_JOB");',
'            }',
'        }',
'    ]',
');'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43396202473117154)
,p_plug_name=>'STOP_JOB'
,p_title=>'Stop Job'
,p_region_name=>'STOP_JOB'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-popup-noOverlay:js-popup-callout:js-dialog-nosize'
,p_plug_template=>wwv_flow_imp.id(52952214448871996)
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43798475845061746)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(52979837226871984)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(52864181679872058)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(53042624311871943)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43799177731061741)
,p_plug_name=>'Jobs'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(52957610627871994)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'select * from user_share_jobs'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Jobs'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(43799300938061741)
,p_name=>'Jobs'
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DWAPEX'
,p_internal_uid=>32508592899419016
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43800006372061735)
,p_db_column_name=>'JOB_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Job Id'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{case STATUS/}',
'{when COMPLETED/}',
'#JOB_ID#',
'{when STOPPED/}',
'#JOB_ID#',
'{when STOPPING/}',
'#JOB_ID#',
'{otherwise/}',
'<button type="button" class="t-Button" ',
'    data-action="open-popup-stop-job?jobId=#JOB_ID#">',
'    <span class="t-Button-label">#JOB_ID#</span>',
'</button>',
'{endcase/}'))
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43800415021061734)
,p_db_column_name=>'JOB_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Job Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43800779581061734)
,p_db_column_name=>'SHARE_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Share Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43801179389061734)
,p_db_column_name=>'PARALLELISM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Parallelism'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43801606871061733)
,p_db_column_name=>'SHARE_NAME'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Share Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43802001588061733)
,p_db_column_name=>'SHARE_VERSION'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Share Version'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43802406840061733)
,p_db_column_name=>'STATUS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43802859243061732)
,p_db_column_name=>'ERROR_MESSAGE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Error Message'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43803250452061732)
,p_db_column_name=>'JOB_TYPE'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Job Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43803609606061732)
,p_db_column_name=>'JOB_CLASS'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Job Class'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43803971483061732)
,p_db_column_name=>'PRIORITY'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Priority'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43804453833061731)
,p_db_column_name=>'SHARE_TYPE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Share Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43804844268061731)
,p_db_column_name=>'SPLIT_SIZE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Split Size'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43805227447061731)
,p_db_column_name=>'STORAGE_URI'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Storage Uri'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43805652021061730)
,p_db_column_name=>'STORAGE_FOLDER'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Storage Folder'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43805994141061730)
,p_db_column_name=>'LOG_LEVEL'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Log Level'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43806432629061730)
,p_db_column_name=>'CREATED'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43806817911061730)
,p_db_column_name=>'UPDATED'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43807241974061729)
,p_db_column_name=>'RUN_DURATION'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Run Duration'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43807573954061729)
,p_db_column_name=>'JOB_ACTION'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Job Action'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(43808028027060807)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'112523'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JOB_ID:JOB_NAME:SHARE_ID:PARALLELISM:SHARE_NAME:SHARE_VERSION:STATUS:ERROR_MESSAGE:JOB_TYPE:JOB_CLASS:PRIORITY:SHARE_TYPE:SPLIT_SIZE:STORAGE_URI:STORAGE_FOLDER:LOG_LEVEL:CREATED:UPDATED:RUN_DURATION:JOB_ACTION'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21925832666312926)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(43396202473117154)
,p_button_name=>'STOP_JOB'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(53041105359871944)
,p_button_image_alt=>'Stop Job'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43823470644545606)
,p_name=>'P14_JOB_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(43396202473117154)
,p_prompt=>'Job ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(53038567150871947)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21934684821312917)
,p_name=>'onClick STOP_JOB'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(21925832666312926)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21935190456312915)
,p_event_id=>wwv_flow_imp.id(21934684821312917)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    dbms_share.stop_job(',
'        share_job_id => :P14_JOB_ID',
'    );',
'end;'))
,p_attribute_02=>'P14_JOB_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21935611989312915)
,p_event_id=>wwv_flow_imp.id(21934684821312917)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43396202473117154)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21936206280312915)
,p_event_id=>wwv_flow_imp.id(21934684821312917)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43799177731061741)
);
wwv_flow_imp.component_end;
end;
/
