prompt --application/shared_components/navigation/listentry
begin
--   Manifest
--     LIST ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>8693305840288544
,p_default_application_id=>101
,p_default_id_offset=>9293655683316758
,p_default_owner=>'WKSP_DWAPEX'
);
null;
wwv_flow_imp.component_end;
end;
/
