prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>8693305840288544
,p_default_application_id=>101
,p_default_id_offset=>9293655683316758
,p_default_owner=>'WKSP_DWAPEX'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Share Provider'
,p_alias=>'SHARE-PROVIDER'
,p_page_mode=>'MODAL'
,p_step_title=>'Share Provider'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(19716435709600014)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9342670485828602)
,p_plug_name=>'Share Provider'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19752281518599986)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    provider_id,',
'    provider_name,',
'    '''' delta_sharing_profile',
'from user_share_providers'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9345000651828592)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(19755080887599985)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9345406799828592)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9345000651828592)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19892554825599909)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9346852402828590)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9345000651828592)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19892554825599909)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P9_PROVIDER_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9347270121828589)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(9345000651828592)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19892554825599909)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P9_PROVIDER_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9347617523828589)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9345000651828592)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(19892554825599909)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P9_PROVIDER_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9343064743828600)
,p_name=>'P9_PROVIDER_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9342670485828602)
,p_item_source_plug_id=>wwv_flow_imp.id(9342670485828602)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Provider Id'
,p_source=>'PROVIDER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(19890016616599912)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9343494694828596)
,p_name=>'P9_PROVIDER_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9342670485828602)
,p_item_source_plug_id=>wwv_flow_imp.id(9342670485828602)
,p_prompt=>'Provider Name'
,p_source=>'PROVIDER_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_imp.id(19891273248599911)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9343763364828594)
,p_name=>'P9_DELTA_SHARING_PROFILE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9342670485828602)
,p_item_source_plug_id=>wwv_flow_imp.id(9342670485828602)
,p_prompt=>'Delta Sharing Profile'
,p_source=>'DELTA_SHARING_PROFILE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>32
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(19890016616599912)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9345534221828592)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9345406799828592)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9346312495828590)
,p_event_id=>wwv_flow_imp.id(9345534221828592)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9348492368828588)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(9342670485828602)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0Share Provider')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_required_patch=>wwv_flow_imp.id(19715013760600025)
,p_internal_uid=>9348492368828588
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9328729263916523)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    credential_names clob;',
'    jo json_object_t;',
'    l_endpoint varchar2(4000);',
'begin',
'    /*',
unistr('     * \3059\3067\306B"ProviderName$SHARED_CRED", "ProviderName$SHARED_CRED$TOKEN_REFRESH_CRED"\304C'),
unistr('     * \5B58\5728\3059\308B\5834\5408\3001\3042\3089\304B\3058\3081\524A\9664\3057\3066\304A\304F\3002\305D\3046\3057\306A\3044\3068\3001\81EA\52D5\7684\306B\4E00\610F\306E\540D\524D\304C\4ED8\3051\3089\308C\305F\30AF\30EA\30C7\30F3\30B7\30E3\30EB\304C'),
unistr('     * \65B0\898F\306B\4F5C\6210\3055\308C\308B\3002'),
'     */',
'    for c in (',
'        select credential_name from user_credentials',
'        where credential_name in (',
'            upper(:P9_PROVIDER_NAME) || ''$SHARE_CRED'',',
'            upper(:P9_PROVIDER_NAME) || ''$SHARE_CRED$TOKEN_REFRESH_CRED''',
'        )',
'    )',
'    loop',
'        dbms_cloud.drop_credential(c.credential_name);',
'    end loop;',
'    /*',
unistr('     * Delta Sharing\30D7\30ED\30D5\30A1\30A4\30EB\3092\5143\306B\3001\30AF\30EA\30C7\30F3\30B7\30E3\30EB\3092\4F5C\6210\3059\308B\3002\30AF\30EA\30C7\30F3\30B7\30E3\30EB\306F'),
unistr('     * \524A\9664\6E08\307F\306A\306E\3067\3001\4F5C\6210\3055\308C\308B\30AF\30EA\30C7\30F3\30B7\30E3\30EB\306E\540D\524D\306F\6C7A\307E\3063\3066\3044\308B\3002'),
'     */',
'    credential_names := dbms_share.create_credentials(',
'        credential_base_name => :P9_PROVIDER_NAME',
'        ,delta_profile => :P9_DELTA_SHARING_PROFILE',
'    );',
'    /*',
unistr('     * \30D7\30ED\30D5\30A1\30A4\30EB\306B\542B\307E\308C\3066\3044\308B\30A8\30F3\30C9\30DD\30A4\30F3\30C8\3092\53D6\308A\51FA\3059\3002'),
'     */',
'    jo := json_object_t(:P9_DELTA_SHARING_PROFILE);',
'    l_endpoint := jo.get_string(''endpoint'');',
'    /*',
unistr('     * Provider\3092\4F5C\6210\3059\308B\3002'),
'     */',
'    dbms_share.create_share_provider(',
'        provider_name => :P9_PROVIDER_NAME',
'        ,endpoint => l_endpoint',
'    );',
'    /*',
unistr('     * \4F5C\6210\3057\305FProvider\306B\30AF\30EA\30C7\30F3\30B7\30E3\30EB\3092\7D10\3065\3051\308B\3002'),
'     */',
'    dbms_share.set_share_provider_credential(',
'        provider_name => :P9_PROVIDER_NAME',
'        ,share_credential => :P9_PROVIDER_NAME || ''$SHARE_CRED''',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9347617523828589)
,p_internal_uid=>9328729263916523
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9328808160916524)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    dbms_share.drop_share_provider(',
'        provider_name => :P9_PROVIDER_NAME',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9346852402828590)
,p_internal_uid=>9328808160916524
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9348886669828588)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>9348886669828588
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9348086572828589)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(9342670485828602)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0Share Provider')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>9348086572828589
);
wwv_flow_imp.component_end;
end;
/
