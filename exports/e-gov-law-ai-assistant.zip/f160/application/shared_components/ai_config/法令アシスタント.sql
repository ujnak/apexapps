prompt --application/shared_components/ai_config/法令アシスタント
begin
--   Manifest
--     AI CONFIG: 法令アシスタント
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>160
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_ai_config(
 p_id=>wwv_flow_imp.id(48178461571037793)
,p_name=>unistr('\6CD5\4EE4\30A2\30B7\30B9\30BF\30F3\30C8')
,p_static_id=>'LAW_ASSISTANT'
,p_remote_server_id=>wwv_flow_imp.id(47961956100331705)
,p_system_prompt=>unistr('\3042\306A\305F\306F\65E5\672C\306E\6CD5\4EE4\306E\5C02\9580\5BB6\3067\3059\3002')
,p_welcome_message=>unistr('\6CD5\5F8B\306B\3064\3044\3066\805E\3044\3066')
,p_version_scn=>27931985
);
wwv_flow_imp_shared.create_ai_config_rag_source(
 p_id=>wwv_flow_imp.id(48178650065042153)
,p_name=>unistr('\6CD5\4EE4\306E\53C2\7167')
,p_description=>unistr('\95A2\9023\3059\308B\6CD5\4EE4\306E\6761\6587\3067\3059\3002')
,p_rag_type=>'DATA_SOURCE'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select description from table ( apex_search.search(',
'    p_search_static_ids => apex_t_varchar2(''LAW_VECTOR'',''LAW_TEXT'')',
'    ,p_search_expression => :APEX$AI_LAST_USER_PROMPT',
'))'))
,p_condition_type=>'LAST_AI_USER_PROMPT_CONTAINS'
,p_condition_expr1=>unistr('\691C\7D22\3057\3066')
);
wwv_flow_imp.component_end;
end;
/
