prompt --application/shared_components/navigation/search_config/e_gov法令テキスト検索
begin
--   Manifest
--     SEARCH CONFIG: E-Gov法令テキスト検索
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>160
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(47459153840215946)
,p_label=>unistr('E-Gov\6CD5\4EE4\30C6\30AD\30B9\30C8\691C\7D22')
,p_static_id=>'LAW_TEXT'
,p_search_type=>'TEXT_MANUAL'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'JLAW_LAW_SENTENCES'
,p_oratext_index_column_name=>'Sentence'
,p_return_max_results=>10
,p_pk_column_name=>'SID'
,p_title_column_name=>'LawTitle'
,p_description_column_name=>'Sentence'
,p_custom_01_column_name=>'SectionTitle'
,p_custom_02_column_name=>'SubsectionTitle'
,p_custom_03_column_name=>'ArticleTitle'
,p_version_scn=>27941718
);
wwv_flow_imp.component_end;
end;
/
