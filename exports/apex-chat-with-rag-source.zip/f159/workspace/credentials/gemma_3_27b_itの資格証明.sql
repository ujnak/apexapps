prompt --workspace/credentials/gemma_3_27b_itの資格証明
begin
--   Manifest
--     CREDENTIAL: gemma-3-27b-itの資格証明
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>159
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(47961676571331704)
,p_name=>unistr('gemma-3-27b-it\306E\8CC7\683C\8A3C\660E')
,p_static_id=>'gemma_3_27b_it_'
,p_authentication_type=>'HTTP_HEADER'
,p_valid_for_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'http://host.containers.internal:8080/v1',
''))
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
