prompt --workspace/remote_servers/gemma_3_27b_it
begin
--   Manifest
--     REMOTE SERVER: Gemma-3-27b-it
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>159
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(47961956100331705)
,p_name=>'Gemma-3-27b-it'
,p_static_id=>'GEMMA3_27B_IT'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('GEMMA3_27B_IT'),'http://host.containers.internal:8080/v1')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('GEMMA3_27B_IT'),'')
,p_server_type=>'GENERATIVE_AI'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('GEMMA3_27B_IT'),'')
,p_credential_id=>wwv_flow_imp.id(47961676571331704)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('GEMMA3_27B_IT'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('GEMMA3_27B_IT'),'')
,p_prompt_on_install=>true
,p_ai_provider_type=>'OPENAI'
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('GEMMA3_27B_IT'),'gemma-3-27b-it')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('GEMMA3_27B_IT'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('GEMMA3_27B_IT'),'')
);
wwv_flow_imp.component_end;
end;
/
