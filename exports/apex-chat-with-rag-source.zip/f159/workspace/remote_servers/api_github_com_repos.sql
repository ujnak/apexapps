prompt --workspace/remote_servers/api_github_com_repos
begin
--   Manifest
--     REMOTE SERVER: api-github-com-repos
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>159
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(48001225079353451)
,p_name=>'api-github-com-repos'
,p_static_id=>'api_github_com_repos'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('api_github_com_repos'),'https://api.github.com/repos/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('api_github_com_repos'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('api_github_com_repos'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('api_github_com_repos'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('api_github_com_repos'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('api_github_com_repos'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('api_github_com_repos'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('api_github_com_repos'),'')
);
wwv_flow_imp.component_end;
end;
/
