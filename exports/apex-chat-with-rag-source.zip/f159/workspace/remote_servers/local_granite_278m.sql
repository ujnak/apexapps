prompt --workspace/remote_servers/local_granite_278m
begin
--   Manifest
--     REMOTE SERVER: Local Granite 278m
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>159
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(47433837811914208)
,p_name=>'Local Granite 278m'
,p_static_id=>'LOCAL_GRANITE_278M'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('LOCAL_GRANITE_278M'),'https://localhost')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('LOCAL_GRANITE_278M'),'')
,p_server_type=>'VECTOR'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('LOCAL_GRANITE_278M'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('LOCAL_GRANITE_278M'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('LOCAL_GRANITE_278M'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('LOCAL_GRANITE_278M'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('LOCAL_GRANITE_278M'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('LOCAL_GRANITE_278M'),'')
,p_embedding_type=>'PLSQL'
,p_emb_function=>'GENERATE_EMBEDDING'
);
wwv_flow_imp.component_end;
end;
/
