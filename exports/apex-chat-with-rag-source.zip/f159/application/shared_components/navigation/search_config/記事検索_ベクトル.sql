prompt --application/shared_components/navigation/search_config/記事検索_ベクトル
begin
--   Manifest
--     SEARCH CONFIG: 記事検索 - ベクトル
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>159
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(48151590974280300)
,p_label=>unistr('\8A18\4E8B\691C\7D22 - \30D9\30AF\30C8\30EB')
,p_static_id=>'CHUNK_VECTOR_SEARCH'
,p_search_type=>'VECTOR'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBAJ_DOCUMENT_CHUNKS'
,p_oratext_index_column_name=>'CHUNK_VECTOR'
,p_vector_provider_id =>wwv_flow_imp.id(47433837811914208)
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'COSINE'
,p_vector_maximum_distance=>.3
,p_return_max_results=>6
,p_pk_column_name=>'ID'
,p_title_column_name=>'URL'
,p_description_column_name=>'CHUNK'
,p_icon_source_type=>'INITIALS'
,p_version_scn=>27881622
);
wwv_flow_imp.component_end;
end;
/
