prompt --application/shared_components/ai_config/apex問合せ
begin
--   Manifest
--     AI CONFIG: APEX問合せ
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>159
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_ai_config(
 p_id=>wwv_flow_imp.id(48166259090843083)
,p_name=>unistr('APEX\554F\5408\305B')
,p_static_id=>'APEX_QA'
,p_remote_server_id=>wwv_flow_imp.id(47961956100331705)
,p_system_prompt=>unistr('\3042\306A\305F\306FOracle APEX\306E\5C02\9580\5BB6\3067\3059\3002')
,p_welcome_message=>unistr('Oracle APEX\306B\95A2\3059\308B\8CEA\554F\3092\53D7\3051\4ED8\3051\307E\3059\3002')
,p_version_scn=>27874983
);
wwv_flow_imp_shared.create_ai_config_rag_source(
 p_id=>wwv_flow_imp.id(48166477096860475)
,p_name=>unistr('PDF\30C9\30AD\30E5\30E1\30F3\30C8')
,p_description=>unistr('Oracle APEX\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\4F5C\6210\624B\9806\3092\89E3\8AAC\3057\3066\3044\308B\30C9\30AD\30E5\30E1\30F3\30C8\3067\3059\3002')
,p_rag_type=>'DATA_SOURCE'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select description from table ( apex_search.search(',
'    p_search_static_ids => apex_t_varchar2(''CHUNK_VECTOR_SEARCH'')',
'    ,p_search_expression => :APEX$AI_LAST_USER_PROMPT',
'))'))
);
wwv_flow_imp.component_end;
end;
/
