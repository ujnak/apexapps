prompt --application/shared_components/web_sources/github_apexkb
begin
--   Manifest
--     WEB SOURCE: GitHub APEXKB
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>159
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(48099294618586383)
,p_name=>'GitHub APEXKB'
,p_static_id=>'github_apexkb'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(48095466389586379)
,p_remote_server_id=>wwv_flow_imp.id(48001225079353451)
,p_url_path_prefix=>'ujnak/APEXKB/contents/'
,p_version_scn=>27626050
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(48099494424586383)
,p_web_src_module_id=>wwv_flow_imp.id(48099294618586383)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
