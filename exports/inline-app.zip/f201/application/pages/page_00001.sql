prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>201
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Inline App'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230519091817'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(88791760330095142)
,p_plug_name=>'Inline DEPT'
,p_region_template_options=>'#DEFAULT#:i-h640:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(89371332970468666)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'NATIVE_URL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'&G_APEX_PATH.r/apexdev/source-app/home?session=&APP_SESSION.'
,p_attribute_02=>'NOESC_INLINE'
,p_attribute_04=>'<!-- start:report-dept -->'
,p_attribute_05=>'<!-- end:report-dept -->'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(88791863783095143)
,p_plug_name=>'Inline EMP'
,p_region_template_options=>'#DEFAULT#:i-h640:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(89371332970468666)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_URL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'&G_APEX_PATH.r/apexdev/source-app/home?session=&APP_SESSION.'
,p_attribute_02=>'NOESC_INLINE'
,p_attribute_04=>'<!-- start:report-emp -->'
,p_attribute_05=>'<!-- end:report-emp -->'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(88791996364095144)
,p_plug_name=>'Dynamic Inline DEPT'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(89371332970468666)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'    l_begin pls_integer;',
'    l_end   pls_integer;',
'    C_START constant varchar2(40) := ''<!-- start:report-dept -->'';',
'    C_END   constant varchar2(40) := ''<!-- end:report-dept -->'';',
'begin',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => :G_APEX_PATH || ''r/apexdev/source-app/home?session='' || :APP_SESSION',
'        ,p_http_method => ''GET''',
'    );',
'    l_begin := instr(l_response, C_START) + length(C_START);',
'    l_response := substr(l_response,l_begin);',
'    l_end   := instr(l_response, C_END) - 1;',
'    l_response := substr(l_response, 1, l_end);',
unistr('    -- return apex_escape.html(l_response); -- \30A8\30B9\30B1\30FC\30D7\3042\308A'),
unistr('    return l_response; -- \30A8\30B9\30B1\30FC\30D7\306A\3057'),
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_required_patch=>wwv_flow_imp.id(89268013782468579)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(89480292295468749)
,p_plug_name=>'Inline App'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(89338354056468642)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
