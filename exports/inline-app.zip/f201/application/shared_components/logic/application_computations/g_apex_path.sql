prompt --application/shared_components/logic/application_computations/g_apex_path
begin
--   Manifest
--     APPLICATION COMPUTATION: G_APEX_PATH
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>201
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(89494731363635631)
,p_computation_sequence=>10
,p_computation_item=>'G_APEX_PATH'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'apex_util.host_url(''APEX_PATH'')'
);
wwv_flow_imp.component_end;
end;
/
