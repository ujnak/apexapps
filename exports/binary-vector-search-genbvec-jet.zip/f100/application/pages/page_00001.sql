prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Genbvec'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32338177760195079)
,p_plug_name=>'Data'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32338255047195080)
,p_plug_name=>'Range'
,p_parent_plug_id=>wwv_flow_imp.id(32338177760195079)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98208779912375164)
,p_plug_name=>'Genbvec'
,p_region_name=>'CHART'
,p_parent_plug_id=>wwv_flow_imp.id(32338177760195079)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(32336551060195063)
,p_region_id=>wwv_flow_imp.id(98208779912375164)
,p_chart_type=>'scatter'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'none'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(config) {',
'    minVal = Number(apex.item("P1_MIN_VALUE").getValue());',
'    maxVal = Number(apex.item("P1_MAX_VALUE").getValue());',
'    config.xAxis.min = minVal;',
'    config.xAxis.max = maxVal;',
'    config.yAxis.min = minVal;',
'    config.yAxis.max = maxVal;',
'    return config;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(32336661228195064)
,p_chart_id=>wwv_flow_imp.id(32336551060195063)
,p_seq=>10
,p_name=>'binary vector'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select REGEXP_SUBSTR(name, ''^[^-]+'') series, name, x, y from genbvec_tsne',
'where name in (select column_value from apex_string.split(:P1_ALL_VECTORS,'',''))'))
,p_series_name_column_name=>'SERIES'
,p_items_x_column_name=>'X'
,p_items_y_column_name=>'Y'
,p_items_label_column_name=>'NAME'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(32336798019195065)
,p_chart_id=>wwv_flow_imp.id(32336551060195063)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(32336864589195066)
,p_chart_id=>wwv_flow_imp.id(32336551060195063)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80614400332490856)
,p_plug_name=>'Vectors'
,p_region_name=>'VECTORS'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>'select * from genbvec where name in (select column_value from apex_string.split(:P1_ALL_VECTORS,'',''))'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(80614499436490857)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>15631794892756141
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80614599461490858)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80614646713490859)
,p_db_column_name=>'V'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'V'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80614719689490860)
,p_db_column_name=>'NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80614981173490862)
,p_db_column_name=>'LY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Ly'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(32336941107195067)
,p_db_column_name=>'BV'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Bv'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(81230905022741613)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'162483'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:V:NAME:LY'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94418357653582869)
,p_plug_name=>'Genbvec'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98209364621375170)
,p_plug_name=>'Selection'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98209967177375176)
,p_plug_name=>'PLAN'
,p_region_name=>'PLAN'
,p_parent_plug_id=>wwv_flow_imp.id(98209364621375170)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>80
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_plan clob;',
'begin',
'    l_plan := ''<pre><code>'';',
'    for r in (',
'        select * from table(dbms_xplan.display_cursor(:P1_SQL_ID, :P1_CHILD_NUMBER))',
'    )',
'    loop',
'        l_plan := l_plan || r.plan_table_output || apex_application.LF;',
'    end loop;',
'    l_plan := l_plan || ''</code></pre>'';',
'    return l_plan;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98209671499375173)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(98209364621375170)
,p_button_name=>'SEARCH'
,p_button_static_id=>'SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Search'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(80613340367490846)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(98209364621375170)
,p_button_name=>'RESET'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Reset'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32338341305195081)
,p_name=>'P1_MIN_VALUE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(32338255047195080)
,p_prompt=>'Min Value'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32338472583195082)
,p_name=>'P1_MAX_VALUE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(32338255047195080)
,p_prompt=>'Max Value'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80614217007490855)
,p_name=>'P1_ALL_VECTORS'
,p_data_type=>'CLOB'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(95000731007405642)
,p_name=>'P1_VECTOR_VALUE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(98209364621375170)
,p_prompt=>'Vector Value'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98209481976375171)
,p_name=>'P1_VECTOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(98209364621375170)
,p_prompt=>'Vector Name'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_BINARY_VECTOR'
,p_lov=>'select name d, json(v) r, bv from genbvec order by 1 asc'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_outputs', 'R:P1_VECTOR_VALUE',
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98209588989375172)
,p_name=>'P1_ROWS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(98209364621375170)
,p_prompt=>'Rows'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98209752207375174)
,p_name=>'P1_SQL_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98209857276375175)
,p_name=>'P1_CHILD_NUMBER'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80613121362490844)
,p_name=>'onClick SEARCH'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(98209671499375173)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7984401547248231)
,p_event_id=>wwv_flow_imp.id(80613121362490844)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'GET_DATA'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_BULK_LIMIT    constant pls_integer := 1000;',
unistr('    /* \30D0\30AF\30EB\30D5\30A7\30C3\30C1\306B\4F7F\7528\3059\308B */'),
'    type t_vector_array is table of genbvec.v%type;',
'    type t_name_array   is table of genbvec.name%type;',
'    l_vectors t_vector_array;',
'    l_names   t_name_array;',
unistr('    /* \691C\7D22\3055\308C\305F\30D9\30AF\30C8\30EB\306E\540D\524D\3092\4FDD\5B58\3059\308B */'),
'    l_all_vectors apex_t_varchar2;',
unistr('    /* \5B9F\884C\3059\308BSELECT\6587\3068\30D7\30E9\30F3\306E\8868\793A */'),
'    l_cursor        sys_refcursor;',
'    l_select        varchar2(32767);',
'    l_sql_id        v$sql.sql_id%type;',
'    l_child_number  number;',
'    l_vector_value  genbvec.v%type;',
'    l_rows          number;',
'begin',
'    /*',
unistr('     * \5B9F\884C\3059\308BSELECT\6587\3092\6C7A\3081\308B\3002'),
unistr('     * \691C\7D22\6761\4EF6\306E\6307\5B9A\304C\7121\3051\308C\3070\30AF\30EA\30C3\30AF\3057\305F\30DC\30BF\30F3\306B\95A2\308F\3089\305A\30C7\30D5\30A9\30EB\30C8\306E\691C\7D22\3002'),
'     */',
unistr('    /* P1_VECTOR_VALUE\3068P1_ROWS\306E\30D5\30A9\30FC\30DE\30C3\30C8\30C1\30A7\30C3\30AF\3002\5931\6557\6642\306Fnull\306B\623B\3059\3002 */'),
'    begin',
'        -- apex_debug.info(:P1_VECTOR_VALUE);',
'        l_vector_value := to_vector(:P1_VECTOR_VALUE,*, binary);',
'        apex_debug.info(''Vector Value of P1_VECTOR_VALUE = %s'', from_vector(l_vector_value));',
'    exception',
'        when others then',
'            l_vector_value := null;',
'            apex_debug.warn(''Failed to convert vector %s'', :P1_VECTOR_VALUE);',
'            apex_session_state.set_value(''P1_VECTOR_VALUE'', '''');',
'            apex_session_state.set_value(''P1_VECTOR'', '''');',
'    end;',
'    begin',
'        l_rows := to_number(:P1_ROWS);',
'    exception',
'        when others then',
'            l_rows := null;',
'            apex_debug.warn(''Failed to convert rows %s'', :P1_ROWS);',
'            apex_session_state.set_value(''P1_ROWS'', '''');',
'    end;',
unistr('    /* \30D9\30AF\30C8\30EB\985E\4F3C\691C\7D22\3092\884C\3046 */'),
'    if l_vector_value is not null and l_rows is not null then',
'        l_select := :SELECT_EXACT;',
'        open l_cursor for l_select using l_vector_value, l_rows;',
'    else',
unistr('        /* \691C\7D22\6761\4EF6\304C\306A\3044\6642\306F\30C7\30D5\30A9\30EB\30C8\306ESELECT\6587\3092\5B9F\884C\3059\308B\3002 */'),
'        l_select := :SELECT_DEFAULT;',
'        open l_cursor for l_select;',
'    end if;',
'    /*',
unistr('     * \691C\7D22\3055\308C\305F\30D9\30AF\30C8\30EB\306E\540D\524D\3092l_all_vectors\306B\4FDD\5B58\3059\308B\3002'),
'     */',
'    begin',
'        loop',
'            fetch l_cursor bulk collect into l_vectors, l_names limit C_BULK_LIMIT;',
'            for i in 1..l_vectors.count loop',
unistr('                /* \691C\7D22\3055\308C\305F\30D9\30AF\30C8\30EB\306E\540D\524D\3092\4FDD\5B58\3059\308B\3002 */'),
'                apex_string.push(l_all_vectors, l_names(i));',
'            end loop;',
'            exit when l_vectors.count < C_BULK_LIMIT;',
'        end loop;',
'    exception',
'        when others then',
'            if l_cursor%ISOPEN then',
'                close l_cursor;',
'            end if;',
'            raise;',
'    end;',
unistr('    /* \691C\7D22\7D50\679C\3092P1_ALL_VECTORS\306B\4FDD\5B58\3059\308B\3002 */'),
'    apex_session_state.set_value(''P1_ALL_VECTORS'', apex_string.join(l_all_vectors,'',''), true);',
'    /*',
unistr('     * \5B9F\884C\8A08\753B\3092\8868\793A\3059\308B\305F\3081\3001\5B9F\884C\3057\305FSELECT\6587\306ESQL_ID\3068CHILD_NUMBER\3092\898B\3064\3051\308B\3002'),
'     */',
'    begin',
'        select sql_id, child_number into l_sql_id, l_child_number',
unistr('        -- \5148\982D30\6587\5B57\307E\3067\4E00\81F4\3059\308BSELECT\6587\3092\63A2\3059\3002'),
'        from v$sql where sql_text like substr(l_select,1,30) || ''%''',
'        order by last_active_time desc fetch first 1 rows only;',
'        apex_session_state.set_value(''P1_SQL_ID'', l_sql_id);',
'        apex_session_state.set_value(''P1_CHILD_NUMBER'', l_child_number);',
'    exception',
'        when no_data_found then',
'            apex_session_state.set_value(''P1_SQL_ID'', '''');',
'            apex_session_state.set_value(''P1_CHILD_NUMBER'', '''');',
'            apex_debug.info(''SQL_ID not found for query.'');',
'    end;',
'end;'))
,p_attribute_02=>'P1_VECTOR_VALUE,P1_ROWS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7984562724248232)
,p_event_id=>wwv_flow_imp.id(80613121362490844)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Chart'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(98208779912375164)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7984655721248233)
,p_event_id=>wwv_flow_imp.id(80613121362490844)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Plan'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(98209967177375176)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7984700668248234)
,p_event_id=>wwv_flow_imp.id(80613121362490844)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Vectors'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(80614400332490856)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80613887677490851)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Session State'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(80613340367490846)
,p_internal_uid=>15631183133756135
);
wwv_flow_imp.component_end;
end;
/
