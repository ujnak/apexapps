prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'OML'
,p_alias=>'OML'
,p_step_title=>'OML'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107603139816754889)
,p_plug_name=>'OML4Py SQL API Admin'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32393818131130812)
,p_button_sequence=>50
,p_button_name=>'GET_TOKEN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Get Token / Set Auth Token'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32394162216130815)
,p_button_sequence=>60
,p_button_name=>'UNSET_TOKEN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Unset Token'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79088043187340548)
,p_name=>'P2_IS_TOKEN_SET'
,p_item_sequence=>10
,p_prompt=>'Is Token Set'
,p_source=>'to_char(sys.pyqIsTokenSet())'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98707100329522841)
,p_name=>'P2_ACCESS_TOKEN'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107621408322704419)
,p_name=>'P2_HOST'
,p_item_sequence=>20
,p_item_default=>'owa_util.get_cgi_env(''HTTP_HOST'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'SQL'
,p_prompt=>'Host'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107621544457704420)
,p_name=>'P2_USERNAME'
,p_item_sequence=>30
,p_item_default=>'SYS_CONTEXT(''USERENV'', ''CURRENT_USER'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'SQL'
,p_prompt=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107621667836704421)
,p_name=>'P2_PASSWORD'
,p_item_sequence=>40
,p_prompt=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32417051050130884)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Token'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_token_url     varchar2(4000);',
'    l_request       clob;',
'    l_request_json  json_object_t;',
'    l_response      clob;',
'    l_response_json json_object_t;',
'    e_get_token_failed exception;',
'begin',
'    /* construct the token url for OML4Py */',
'    l_token_url := apex_string.format(''https://%s/omlusers/api/oauth2/v1/token'', :P2_HOST);',
'    apex_debug.info(''toekn url = %s'', l_token_url);',
'    /* prepare request body */',
'    l_request_json := json_object_t();',
'    l_request_json.put(''grant_type'', ''password'');',
'    l_request_json.put(''username'', :P2_USERNAME);',
'    l_request_json.put(''password'', :P2_PASSWORD);',
'    l_request := l_request_json.to_clob();',
'    /* get token */',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', ''Accept'', ''application/json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_token_url',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'    );',
'    if not apex_web_service.g_status_code between 200 and 300 then',
'        raise e_get_token_failed;',
'    end if;',
'    /* get token from the response */',
'    apex_debug.info(l_response);',
'    l_response_json := json_object_t.parse(l_response);',
'    /* tokenType is always Bearer and expiresIn is always in 3600 */',
'    :P2_ACCESS_TOKEN := l_response_json.get_string(''accessToken'');',
'    /* once access token is taken, set it to token store */',
'    if :P2_ACCESS_TOKEN is not null then',
'        apex_debug.info(''Set Access Token: %s'', substr(:P2_ACCESS_TOKEN,1,10));',
'        sys.pyqSetAuthToken(:P2_ACCESS_TOKEN);',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32393818131130812)
,p_internal_uid=>8062424477184027
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32409916490130870)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Unset Token'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :P2_ACCESS_TOKEN := '''';',
'    sys.pyqSetAuthToken(:P2_ACCESS_TOKEN);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32394162216130815)
,p_internal_uid=>8055289917184013
);
wwv_flow_imp.component_end;
end;
/
