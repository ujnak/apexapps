prompt --application/shared_components/logic/application_computations/select_default
begin
--   Manifest
--     APPLICATION COMPUTATION: SELECT_DEFAULT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(97217835383409155)
,p_computation_sequence=>10
,p_computation_item=>'SELECT_DEFAULT'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select /* my_vector_query */ v, name from genbvec ',
'order by name asc fetch first 100 rows only'))
,p_version_scn=>41805999404665
);
wwv_flow_imp.component_end;
end;
/
