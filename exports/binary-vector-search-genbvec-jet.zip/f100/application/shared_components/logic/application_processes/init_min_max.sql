prompt --application/shared_components/logic/application_processes/init_min_max
begin
--   Manifest
--     APPLICATION PROCESS: init_min_max
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(8131616643269014)
,p_process_sequence=>1
,p_process_point=>'ON_NEW_INSTANCE'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'init_min_max'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_min_value number;',
'    l_max_value number;',
'    l_margin    number;',
'begin',
unistr('    /* \30C1\30E3\30FC\30C8\306E\8868\793A\9AD8\3055\3001\5E45\3092\6C7A\3081\308B\6700\5927\5024\3068\6700\5C0F\5024\3092\898B\3064\3051\308B */'),
'    select min(v), max(v) into l_min_value, l_max_value',
'    from',
'    (',
'        select x v from genbvec_tsne',
'        union all',
'        select y v from genbvec_tsne',
'    );',
'    if l_max_value is not null and l_min_value is not null then',
'        l_margin := (l_max_value - l_min_value) * 0.1;',
'        apex_session_state.set_value(''P1_MIN_VALUE'', trunc(l_min_value - l_margin));',
'        apex_session_state.set_value(''P1_MAX_VALUE'', trunc(l_max_value - l_margin));',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>41806005100827
);
wwv_flow_imp.component_end;
end;
/
