prompt --application/deployment/install/install_generate_random_binary_vector
begin
--   Manifest
--     INSTALL: INSTALL-generate_random_binary_vector
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(32391783038075357)
,p_install_id=>wwv_flow_imp.id(96814346129438052)
,p_name=>'generate_random_binary_vector'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE PROCEDURE generate_random_binary_vector(',
'dimensions IN NUMBER,',
'result_int OUT VECTOR,',
'result_binary OUT VARCHAR2',
') IS',
'    binary_vector VARCHAR2(40);',
'    int8_value NUMBER;',
'    number_of_bits NUMBER;',
'    char_vector VARCHAR2(40);',
'BEGIN',
'  -- Validate dimension is a multiple of 8',
'  IF MOD(dimensions, 8) != 0 THEN',
'    RAISE_APPLICATION_ERROR(-20001, ''Number of dimensions must be a multiple of 8'');',
'  END IF;',
'',
'  -- Generate the random binary vector',
'  binary_vector := '''';',
'  FOR i IN 1 .. dimensions LOOP',
'    IF DBMS_RANDOM.VALUE(0, 1) < 0.5 THEN',
'      binary_vector := binary_vector || ''0'';',
'    ELSE',
'      binary_vector := binary_vector || ''1'';',
'    END IF;',
'  END LOOP;',
'',
'  -- Convert 8-bit packets to their int8 values and build the result string',
'  number_of_bits := dimensions/8;',
'  char_vector := ''['';',
'  FOR i IN 0 .. number_of_bits - 1 LOOP',
'    int8_value := 0;',
'    FOR j IN 0 .. 7 LOOP',
'      int8_value := int8_value + TO_NUMBER(SUBSTR(binary_vector, i*8+j+1, 1)) * POWER(2, j);',
'    END LOOP;',
'    char_vector := char_vector || int8_value;',
'    IF i < number_of_bits - 1 THEN',
'      char_vector := char_vector || '','';',
'    END IF;',
'  END LOOP;',
'  char_vector := char_vector || '']'';',
'  ',
'  -- Return the generated vector value',
'  result_int := to_vector(char_vector, dimensions, BINARY);',
'  result_binary := binary_vector;',
'END generate_random_binary_vector;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
