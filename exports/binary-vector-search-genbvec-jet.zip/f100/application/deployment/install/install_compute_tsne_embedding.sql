prompt --application/deployment/install/install_compute_tsne_embedding
begin
--   Manifest
--     INSTALL: INSTALL-compute_tsne_embedding
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(32392306204118409)
,p_install_id=>wwv_flow_imp.id(96814346129438052)
,p_name=>'compute_tsne_embedding'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  sys.pyqScriptCreate(''compute_tsne_embedding'',',
'q''~def compute_tsne_embedding(dat, random_state=42, perplexity=30,',
'                           learning_rate=200, n_iter=1000):',
'    """',
unistr('    \30D0\30A4\30CA\30EA\6587\5B57\5217\304B\3089t-SNE\57CB\3081\8FBC\307F\3092\8A08\7B97\3057\3001NAME, X, Y\5217\3092\8FD4\3059'),
'',
'    Parameters:',
'        dat : pandas.DataFrame',
unistr('            ''BV'' \5217\306B\30D0\30A4\30CA\30EA\6587\5B57\5217\FF08"0101..."\5F62\5F0F\FF09\3068 ''NAME'' \5217\3092\542B\3080DataFrame'),
'',
'    Returns:',
'        pandas.DataFrame',
unistr('            NAME, X, Y \306E3\5217\3092\6301\3064t-SNE\57CB\3081\8FBC\307F\7D50\679C'),
'    """',
'    import pandas as pd',
'    import numpy as np',
'    from sklearn.manifold import TSNE',
'',
unistr('    # \30D0\30A4\30CA\30EA\6587\5B57\5217\3092\6570\5024\30D9\30AF\30C8\30EB\306B\5909\63DB'),
'    X = np.array([[int(bit) for bit in bv] for bv in dat[''BV'']])',
'',
unistr('    # perplexity\8ABF\6574\FF08n_samples\672A\6E80\306B\5236\9650\FF09'),
'    perplexity = min(perplexity, len(X) - 1)',
'',
unistr('    # t-SNE\306E\8A08\7B97'),
'    tsne = TSNE(',
'        n_components=2,',
'        random_state=random_state,',
'        perplexity=perplexity,',
'        learning_rate=learning_rate,',
'        n_iter=n_iter,',
'        init=''random'',',
'        method=''barnes_hut''',
'    )',
'    embedding = tsne.fit_transform(X)',
'',
unistr('    # \7D50\679CDataFrame\3092\69CB\7BC9'),
'    result = pd.DataFrame({',
'        "NAME": dat["NAME"].values,',
'        "X": embedding[:, 0],',
'        "Y": embedding[:, 1]',
'    })',
'',
'    return result~'', false, true);',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
