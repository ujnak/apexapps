prompt --application/deployment/install/install_genbvec_v
begin
--   Manifest
--     INSTALL: INSTALL-genbvec_v
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(24356633886951947)
,p_install_id=>wwv_flow_imp.id(96814346129438052)
,p_name=>'genbvec_v'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace view genbvec_v',
'as',
'select name, bv from genbvec;'))
);
wwv_flow_imp.component_end;
end;
/
