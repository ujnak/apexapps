prompt --application/deployment/install/install_generate_binary_cluster
begin
--   Manifest
--     INSTALL: INSTALL-generate_binary_cluster
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(32391869690077577)
,p_install_id=>wwv_flow_imp.id(96814346129438052)
,p_name=>'generate_binary_cluster'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE PROCEDURE generate_binary_cluster(',
'  centroid IN VARCHAR2,            -- a string of 1 and 0',
'  spread IN NUMBER,                -- Maximum Hamming distance between centroid and other vectors in the same cluster',
'  cluster_size IN NUMBER,          -- Number of vectors to generate in addition to the centroid',
'  result_binary OUT SYS_REFCURSOR,',
'  result_int8 OUT SYS_REFCURSOR',
') IS',
'    dimension NUMBER;',
'    max_spread NUMBER;',
'    vector VARCHAR2(40);',
'    char_vector VARCHAR2(40);',
'    flip_positions DBMS_SQL.VARCHAR2_TABLE;',
'    random_position NUMBER;',
'    tresult_binary DBMS_SQL.VARCHAR2_TABLE;',
'    tresult_int8 DBMS_SQL.VARCHAR2_TABLE;',
'    binary_vector VARCHAR2(40);',
'    cluster_index NUMBER := 1;',
'    number_of_bits NUMBER;',
'    int8_value NUMBER;',
'BEGIN',
'  -- Determine the dimension of the centroid vector',
'  dimension := LENGTH(centroid);',
'',
'  -- Ensure dimension is a multiple of 8',
'  IF MOD(dimension, 8) != 0 THEN',
'    RAISE_APPLICATION_ERROR(-20001, ''Number of dimensions must be a multiple of 8'');',
'  END IF;',
'',
'  -- Generate the cluster of binary vectors',
'  WHILE cluster_index <= cluster_size LOOP',
'    binary_vector := centroid;',
'',
'    -- Randomly flip bits in the centroid vector with a max of spread bits',
'    max_spread := TRUNC(DBMS_RANDOM.VALUE(1, spread+1));',
'    flip_positions.DELETE;',
'    FOR i IN 1 .. max_spread LOOP',
'      random_position := TRUNC(DBMS_RANDOM.VALUE(1, dimension+1));',
'      -- Ensure no duplicates',
'      WHILE flip_positions.EXISTS(random_position) LOOP',
'        random_position := TRUNC(DBMS_RANDOM.VALUE(1, dimension+1));',
'      END LOOP;',
'      flip_positions(random_position) := ''1'';',
'    END LOOP;',
'',
'    -- Apply flips to binary vector',
'    FOR i IN 1 .. dimension LOOP',
'      IF flip_positions.EXISTS(i) THEN',
'        IF SUBSTR(binary_vector, i, 1) = ''0'' THEN',
'          binary_vector := SUBSTR(binary_vector, 1, i-1) || ''1'' || SUBSTR(binary_vector, i+1);',
'        ELSE',
'          binary_vector := SUBSTR(binary_vector, 1, i-1) || ''0'' || SUBSTR(binary_vector, i+1);',
'        END IF;',
'      END IF;',
'    END LOOP;',
'',
'    -- Convert binary vector to int8 values',
'    number_of_bits := dimension/8;',
'    char_vector := ''['';',
'    FOR i IN 0 .. number_of_bits-1 LOOP',
'      int8_value := 0;',
'      FOR j IN 0 .. 7 LOOP',
'        int8_value := int8_value + TO_NUMBER(SUBSTR(binary_vector, i*8+j+1, 1)) * POWER(2, j);',
'      END LOOP;',
'      char_vector := char_vector || int8_value;',
'      IF i < number_of_bits-1 THEN',
'        char_vector := char_vector || '','';',
'      END IF;',
'    END LOOP;',
'    char_vector := char_vector || '']'';',
'',
'    -- Add generated vectors to result tables',
'    tresult_binary(cluster_index) := binary_vector;',
'    tresult_int8(cluster_index) := char_vector;',
'',
'    cluster_index := cluster_index + 1;',
'    END LOOP;',
'',
'    -- Open cursor for binary result set',
'    OPEN result_binary FOR',
'      SELECT COLUMN_VALUE AS binary_vector',
'      FROM TABLE(tresult_binary);',
'    ',
'    -- Open cursor for int8 result set',
'    OPEN result_int8 FOR',
'      SELECT COLUMN_VALUE AS int8_vector',
'      FROM TABLE(tresult_int8);',
'',
'END generate_binary_cluster;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
