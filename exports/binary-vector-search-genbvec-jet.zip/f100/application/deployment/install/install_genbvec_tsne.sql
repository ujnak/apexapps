prompt --application/deployment/install/install_genbvec_tsne
begin
--   Manifest
--     INSTALL: INSTALL-genbvec_tsne
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(32392041392086557)
,p_install_id=>wwv_flow_imp.id(96814346129438052)
,p_name=>'genbvec_tsne'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table genbvec_tsne(',
'    name varchar2(500),',
'    x number,',
'    y number',
');'))
);
wwv_flow_imp.component_end;
end;
/
