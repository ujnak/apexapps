prompt --application/deployment/install/install_genbvec
begin
--   Manifest
--     INSTALL: INSTALL-genbvec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(32391672093073066)
,p_install_id=>wwv_flow_imp.id(96814346129438052)
,p_name=>'genbvec'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE genbvec (',
'  id NUMBER,            -- id of the generated vector',
'  v VECTOR(*, BINARY),  -- generated vector',
'  name VARCHAR2(500),   -- name for the generated vector: C1 to Cn are centroids, Cx_y is vector number y in cluster number x',
'  bv VARCHAR2(40),      -- bit version of the generated vector',
'  ly NUMBER             -- random number you can use to filter out rows in addiion to similarity search on vectors',
');'))
);
wwv_flow_imp.component_end;
end;
/
