prompt --application/deployment/install/install_generate_binary_vectors
begin
--   Manifest
--     INSTALL: INSTALL-generate_binary_vectors
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7964335769078855
,p_default_application_id=>100
,p_default_id_offset=>8121095954339177
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(32392006994079940)
,p_install_id=>wwv_flow_imp.id(96814346129438052)
,p_name=>'generate_binary_vectors'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE PROCEDURE generate_binary_vectors(',
'  num_vectors NUMBER,   -- If numbers of vector is not a multiple of num_clusters, remaining vectors are not generated',
'  num_clusters NUMBER,  -- Must be greater than 0',
'  dimensions NUMBER,    -- Must be a multiple of 8',
'  cluster_spread NUMBER -- Maximum Hamming distance between centroid and other vectors in the same cluster: max number of bits flipped',
') IS',
'    vectors_per_cluster NUMBER;',
'    remaining_vectors NUMBER;',
'    i NUMBER := 1;',
'    j NUMBER := 1;',
'    idx NUMBER := 1;',
'    max_id NUMBER;',
'    ri VECTOR(*, BINARY);',
'    rb VARCHAR2(40);',
'    result_binary SYS_REFCURSOR;',
'    result_int8 SYS_REFCURSOR;',
'    vb VARCHAR2(40);',
'    vi VARCHAR2(40);    ',
'BEGIN',
'',
'  IF (num_vectors) <=0 OR (num_clusters < 1) OR (num_vectors < num_clusters) ',
'        OR (dimensions <= 0) OR (dimensions > 504) OR (cluster_spread <= 0) THEN',
'    RAISE_APPLICATION_ERROR(-20001, ''Issues with arguments provided'');',
'  END IF;',
'',
'  SELECT MAX(id) INTO max_id FROM genbvec;',
'  IF max_id IS NULL THEN max_id := 0;',
'  END IF;',
'',
'  -- Calculate vectors per cluster',
'  vectors_per_cluster := TRUNC(num_vectors / num_clusters);',
'  remaining_vectors := num_vectors MOD num_clusters; -- remaining vectors are not generated',
'',
'  -- Generate cluster centroids',
'  FOR i IN 1..num_clusters LOOP',
'    generate_random_binary_vector(dimensions, ri, rb);',
'    INSERT INTO genbvec VALUES (max_id + idx, ri, ''C''||i, rb, DBMS_RANDOM.VALUE(3,600000000));',
'    idx := idx + 1;',
'',
'    -- Generate vectors for each cluster',
'    IF vectors_per_cluster > 1 THEN',
'      generate_binary_cluster(rb, cluster_spread, vectors_per_cluster, result_binary, result_int8);',
'',
'      -- Output the binary result',
'      j:= 1;',
'      LOOP',
'        FETCH result_binary INTO vb;',
'        FETCH result_int8 INTO vi;',
'        EXIT WHEN result_binary%NOTFOUND;',
'        ri := TO_VECTOR(vi, dimensions, BINARY);',
'        INSERT INTO genbvec VALUES (max_id + idx, ri, ''C''||i||''-''||j, vb, DBMS_RANDOM.VALUE(3,600000000));',
'        j := j+1;',
'        idx := idx + 1;',
'      END LOOP;',
'      CLOSE result_binary; ',
'      CLOSE result_int8;',
'    END IF;',
'  END LOOP;',
'  COMMIT;     ',
'',
'END generate_binary_vectors;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
