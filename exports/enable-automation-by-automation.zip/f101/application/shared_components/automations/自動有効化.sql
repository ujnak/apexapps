prompt --application/shared_components/automations/自動有効化
begin
--   Manifest
--     AUTOMATION: 自動有効化
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_automation(
 p_id=>wwv_flow_imp.id(20518201319223000)
,p_name=>unistr('\81EA\52D5\6709\52B9\5316')
,p_static_id=>unistr('\81EA\52D5\6709\52B9\5316')
,p_trigger_type=>'POLLING'
,p_polling_interval=>'FREQ=MINUTELY;INTERVAL=15'
,p_polling_status=>'ACTIVE'
,p_result_type=>'ROWS'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_type=>'SQL'
,p_query_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select automation_id, application_id, static_id from apex_appl_automations',
'where static_id like ''auto-enable-%''',
'and polling_status_code = ''DISABLED'''))
,p_include_rowid_column=>false
,p_pk_column_name=>'AUTOMATION_ID'
,p_max_rows_to_process=>1
,p_commit_each_row=>false
,p_error_handling_type=>'DISABLE'
);
wwv_flow_imp_shared.create_automation_action(
 p_id=>wwv_flow_imp.id(20518581563223001)
,p_automation_id=>wwv_flow_imp.id(20518201319223000)
,p_name=>unistr('\81EA\52D5\5316\3092\30A2\30AF\30C6\30A3\30D6\306B\3059\308B')
,p_execution_sequence=>10
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
unistr('    apex_automation.log_info(''\81EA\52D5\5316\89AA\30A2\30D7\30EA APPLICATION_ID = '' || :APPLICATION_ID || '' STATIC_ID = '' || :STATIC_ID);'),
'    apex_automation.enable(:APPLICATION_ID, :STATIC_ID);',
'end;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp.component_end;
end;
/
