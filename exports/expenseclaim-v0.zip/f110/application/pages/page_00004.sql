prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>110
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>unistr('\4E0A\53F8')
,p_alias=>unistr('\4E0A\53F8')
,p_step_title=>unistr('\4E0A\53F8')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221220023448'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24738185342229065)
,p_plug_name=>unistr('\4E0A\53F8')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(24249516144717548)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    expe.expe_id',
'    , expe.expe_justification',
'    , expe.expe_amount',
'    , expe.expe_status',
'    , expe.expe_submitted_by',
'    , expe.expe_submitted_on',
'    , expe.expe_invoice_dd',
'    , expe.expe_purpose',
'    , tibx.link_text',
'    , tibx.sbfl_prcs_id',
'from tuto_expenses expe ',
'    join flow_task_inbox_vw tibx on expe.expe_id = tibx.sbfl_business_ref ',
'where expe.expe_status = ''submitted''',
'    and tibx.sbfl_current = ''review_expense_mgr''',
unistr('    and tibx.sbfl_dgrm_name = ''\7D4C\8CBB\7CBE\7B97''')))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>unistr('\4E0A\53F8')
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(24738294047229065)
,p_name=>unistr('\4E0A\53F8')
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'#LINK_TEXT#'
,p_detail_link_text=>'<span aria-label="&#x7DE8;&#x96C6;"><span class="fa fa-edit" aria-hidden="true" title="&#x7DE8;&#x96C6;"></span></span>'
,p_owner=>'APEXDEV'
,p_internal_uid=>24738294047229065
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24738660777229066)
,p_db_column_name=>'EXPE_ID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'Expe Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24739057356229067)
,p_db_column_name=>'EXPE_JUSTIFICATION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Expe Justification'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24739496125229067)
,p_db_column_name=>'EXPE_AMOUNT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Expe Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24739833464229067)
,p_db_column_name=>'EXPE_STATUS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Expe Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24740267307229068)
,p_db_column_name=>'EXPE_SUBMITTED_BY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Expe Submitted By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24740696605229068)
,p_db_column_name=>'EXPE_SUBMITTED_ON'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Expe Submitted On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24741003558229069)
,p_db_column_name=>'EXPE_INVOICE_DD'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Expe Invoice Dd'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24741441217229069)
,p_db_column_name=>'EXPE_PURPOSE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Expe Purpose'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24741852350229069)
,p_db_column_name=>'LINK_TEXT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Link Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24742221847229070)
,p_db_column_name=>'SBFL_PRCS_ID'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Sbfl Prcs Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(24762578216834699)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'247626'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EXPE_ID:EXPE_JUSTIFICATION:EXPE_AMOUNT:EXPE_STATUS:EXPE_SUBMITTED_BY:EXPE_SUBMITTED_ON:EXPE_INVOICE_DD:EXPE_PURPOSE:LINK_TEXT:SBFL_PRCS_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24744407932229074)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(24271734970717559)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(24156676454717484)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(24333812928717599)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(24743093678229071)
,p_name=>unistr('\30EC\30DD\30FC\30C8\306E\7DE8\96C6 - \30C0\30A4\30A2\30ED\30B0\306E\30AF\30ED\30FC\30BA')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(24738185342229065)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(24743563305229072)
,p_event_id=>wwv_flow_imp.id(24743093678229071)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(24738185342229065)
);
wwv_flow_imp.component_end;
end;
/
