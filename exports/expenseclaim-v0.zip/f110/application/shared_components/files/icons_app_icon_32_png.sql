prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>110
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000BA49444154584763D4DBBFE73FC30002C651078C86C068088C86C0A00F01EE0F1F19A4787918587EFD66309094C428332F3C7F';
wwv_flow_imp.g_varchar2_table(2) := 'CEF0878D156B59FAECDB3786AFBCBC78CB59822521DF9BB70CE282026007184A4A611876FEF9339C0E78F9FE03C3271161CA1CA0FAF72F839EB40C03FB8F9F0CF1AA6A18862DBC7D8BE127073B564B2E3D7DC2709B9979883B00390A484D03C3230A4613';
wwv_flow_imp.g_varchar2_table(3) := 'E180E782D144885C14935A1252A528A6758399605D30EA80D110180D81D110A0750800005A6CE52135C11DEB0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(24358489168717641)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
