prompt --application/shared_components/user_interface/lovs/plan_type_name
begin
--   Manifest
--     PLAN_TYPE.NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>171
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(44417483837771948)
,p_lov_name=>'PLAN_TYPE.NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'PLAN_TYPE'
,p_return_column_name=>'ID'
,p_display_column_name=>'NAME'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
