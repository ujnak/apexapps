prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>171
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Pretius Drawing'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240202075229'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39979580891956240)
,p_plug_name=>'Data in Collection'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(44163571496770098)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'	C001 as width,',
'	C002 as height,',
'	C003 as top,',
'	C004 as left,',
'	C005 as class,',
'	C006 as text,',
'	C007 as available,',
'	C008 as spot_id,',
'	C009 as rotate,',
'	case  ',
'		when C005 like  ''%workspace-seat%''  then  ''selectSpot(''|| C008 ||'')''',
'		else ''alert(''||C008||'')''',
'	end  as onClick,',
'	c010 as innerHtml',
'from apex_collections',
'where collection_name = :G_COLLECTION',
'order by seq_id;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Data in Collection'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(39979672326956241)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>39979672326956241
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39979745391956242)
,p_db_column_name=>'WIDTH'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Width'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39979861534956243)
,p_db_column_name=>'HEIGHT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Height'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39979987809956244)
,p_db_column_name=>'TOP'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Top'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39980016556956245)
,p_db_column_name=>'LEFT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Left'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39980124490956246)
,p_db_column_name=>'CLASS'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Class'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39980263638956247)
,p_db_column_name=>'TEXT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39980390354956248)
,p_db_column_name=>'AVAILABLE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Available'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39980402411956249)
,p_db_column_name=>'SPOT_ID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Spot Id'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39980517864956250)
,p_db_column_name=>'ROTATE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Rotate'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44477519203061001)
,p_db_column_name=>'ONCLICK'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Onclick'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44477629167061002)
,p_db_column_name=>'INNERHTML'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Innerhtml'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(44486341572079955)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'444864'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WIDTH:HEIGHT:TOP:LEFT:CLASS:TEXT:AVAILABLE:SPOT_ID:ROTATE:ONCLICK:INNERHTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44383725310770484)
,p_plug_name=>'Sample Pretius Drawing'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(44139854743770082)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44470856109772022)
,p_plug_name=>'Draw'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(44117178208770069)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'	C001 as width,',
'	C002 as height,',
'	C003 as top,',
'	C004 as left,',
'	C005 as class,',
'	C006 as text,',
'	C007 as available,',
'	C008 as spot_id,',
'	C009 as rotate,',
'	case  ',
'		when C005 like  ''%workspace-seat%''  then  ''selectSpot(''|| C008 ||'')''',
'		else ''alert(''||C008||'')''',
'	end  as onClick,',
'	c010 as innerHtml',
'from apex_collections',
'where collection_name = :G_COLLECTION',
'order by seq_id;'))
,p_plug_source_type=>'PLUGIN_PRETIUS_DRAWING_PLUGIN'
,p_plug_query_num_rows=>15
,p_attribute_01=>'&G_COLLECTION.'
,p_attribute_02=>'Y'
,p_attribute_03=>'1'
,p_attribute_04=>'0'
,p_attribute_05=>'0'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44477754785061003)
,p_plug_name=>'Controls'
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--alignStretch'
,p_plug_template=>wwv_flow_imp.id(44176099216770104)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44478430005061010)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(44477754785061003)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(44256903422770155)
,p_button_image_alt=>'Save'
,p_button_position=>'BUTTON_END'
,p_confirm_message=>'Are you sure?'
,p_confirm_style=>'danger'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44478586598061011)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(44477754785061003)
,p_button_name=>'CLEAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(44256903422770155)
,p_button_image_alt=>'Clear'
,p_button_position=>'BUTTON_END'
,p_confirm_message=>'Are you sure?'
,p_confirm_style=>'danger'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44478380269061009)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(44477754785061003)
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(44256903422770155)
,p_button_image_alt=>'Load'
,p_button_position=>'BUTTON_START'
,p_confirm_message=>'Are you sure?'
,p_confirm_style=>'danger'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44478253071061008)
,p_name=>'P1_SHEET'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(44477754785061003)
,p_prompt=>'Sheet'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select sheet_name d, id r from pdp_sheets'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select Sheet --'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(44254405067770153)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44478621464061012)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_SQL constant varchar2(400) := q''~select',
'        width',
'        ,height',
'        ,top',
'        ,left',
'        ,class',
'        ,text',
'        ,available',
'        ,spot_id',
'        ,rotate',
'        ,innerhtml',
'from pdp_sheet_components',
'where sheet_id = &P1_SHEET.',
'order by seq_id~'';',
'    l_sql varchar2(4000);',
'begin',
'    l_sql := replace(C_SQL, ''&P1_SHEET.'', :P1_SHEET);',
'    apex_collection.create_collection_from_query(',
'        p_collection_name => :G_COLLECTION',
'        ,p_query => l_sql',
'        ,p_truncate_if_exists => ''YES''',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(44478380269061009)
,p_internal_uid=>44478621464061012
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44478786706061013)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    /* delete all components tied to the sheet */',
'    delete from pdp_sheet_components where sheet_id = :P1_SHEET;',
'    /* copy all components in apex collection to the table */',
'    insert into pdp_sheet_components(',
'        sheet_id',
'        ,seq_id',
'        ,width',
'        ,height',
'        ,top',
'        ,left',
'        ,class',
'        ,text',
'        ,available',
'        ,spot_id',
'        ,rotate',
'        ,innerhtml',
'    )',
'    select',
'        :P1_SHEET as sheet_id',
'        ,seq_id',
'        ,c001 as width',
'        ,c002 as height',
'	    ,c003 as top',
'	    ,c004 as left',
'	    ,c005 as class',
'	    ,c006 as text',
'	    ,c007 as available',
'        ,c008 as spot_id',
'	    ,c009 as rotate',
'	    ,c010 as innerHtml',
'    from apex_collections',
'    where collection_name = :G_COLLECTION',
'    order by seq_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(44478430005061010)
,p_internal_uid=>44478786706061013
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44478816455061014)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear'
,p_process_sql_clob=>'apex_collection.create_or_truncate_collection(:G_COLLECTION);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(44478586598061011)
,p_internal_uid=>44478816455061014
);
wwv_flow_imp.component_end;
end;
/
