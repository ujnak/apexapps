prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>171
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'View Drawing'
,p_alias=>'VIEW-DRAWING'
,p_step_title=>'View Drawing'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240202080548'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44385048701770490)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(44196114316770116)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(44080410906770041)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(44258585289770156)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44479290169061018)
,p_plug_name=>'Draw'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(44117178208770069)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'	width',
'	,height',
'	,top',
'	,left',
'	,class',
'	,text',
'	,available',
'	,spot_id',
'	,rotate',
'	,case  ',
'		when class like  ''%workspace-seat%''  then  ''selectSpot(''|| spot_id ||'')''',
'		else  ''alert(''||spot_id||'')''',
'	end as onClick',
'	,innerHtml',
'from pdp_sheet_components',
'where sheet_id = :P2_SHEET',
'order by seq_id;'))
,p_plug_source_type=>'PLUGIN_PRETIUS_DRAWING_PLUGIN'
,p_plug_query_num_rows=>15
,p_attribute_01=>'&G_COLLECTION.'
,p_attribute_02=>'N'
,p_attribute_03=>'1'
,p_attribute_04=>'0'
,p_attribute_05=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44478945256061015)
,p_name=>'P2_SHEET'
,p_item_sequence=>10
,p_prompt=>'Sheet'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sheet_name d, id r from pdp_sheets',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Select Sheet --'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(44254405067770153)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'REDIRECT_SET_VALUE'
);
wwv_flow_imp.component_end;
end;
/
