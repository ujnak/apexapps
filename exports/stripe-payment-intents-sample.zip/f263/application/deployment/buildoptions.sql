prompt --application/deployment/buildoptions
begin
--   Manifest
--     INSTALL BUILD OPTIONS: 263
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>263
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
