prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>263
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Pay'
,p_alias=>'PAY'
,p_page_mode=>'MODAL'
,p_step_title=>'Pay'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://js.stripe.com/v3/'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const stripe = Stripe(''&STRIPE_PUBLISHABLE_KEY.'');',
'const elements = stripe.elements();',
'const card = elements.create("card", {',
'    hidePostalCode: true,',
'    style: {',
'        base: {',
'            color: "#32325d"',
'        }',
'    }',
'});',
'',
'document.addEventListener(''DOMContentLoaded'', async function () {',
'    card.mount("#card-element");',
'',
'    card.on(''change'', ({error}) => {',
'        let displayError = document.getElementById(''card-errors'');',
'        if (error) {',
'            displayError.textContent = error.message;',
'        } else {',
'            displayError.textContent = '''';',
'        }',
'    });    ',
'});'))
,p_step_template=>wwv_flow_imp.id(70642578113905945)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230824062308'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(69655684268333248)
,p_plug_name=>'payment-form'
,p_region_name=>'payment-form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(70679812459905973)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(69655867576333250)
,p_plug_name=>'card-element'
,p_region_name=>'card-element'
,p_parent_plug_id=>wwv_flow_imp.id(69655684268333248)
,p_region_template_options=>'#DEFAULT#:margin-top-lg:margin-bottom-lg'
,p_plug_template=>wwv_flow_imp.id(70679812459905973)
,p_plug_display_sequence=>50
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(70951120579216702)
,p_plug_name=>'card-errors'
,p_region_name=>'card-errors'
,p_parent_plug_id=>wwv_flow_imp.id(69655684268333248)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(70679812459905973)
,p_plug_display_sequence=>60
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(70951073425216701)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(69655684268333248)
,p_button_name=>'PAY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(70818262262906063)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Pay'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69655509730333247)
,p_name=>'P2_CLIENT_SECRET'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(69655684268333248)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70952337278216714)
,p_name=>'P2_HOLDER_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(69655684268333248)
,p_prompt=>'Holder Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(70815706529906059)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(70951226679216703)
,p_name=>'onClick SUBMIT'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(70951073425216701)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(70951341979216704)
,p_event_id=>wwv_flow_imp.id(70951226679216703)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.browserEvent.preventDefault();',
'stripe.confirmCardPayment(apex.items.P2_CLIENT_SECRET.value, {',
'    payment_method: {',
'        card: card,',
'        billing_details: {',
'            name: apex.items.P2_HOLDER_NAME.value',
'        }',
'    }',
'}).then(function(result) {',
'    if (result.error) {',
'        // Show error to your customer (for example, insufficient funds)',
'        console.log(result.error.message);',
'    } else {',
'        // The payment has been processed!',
'        if (result.paymentIntent.status === ''succeeded'') {',
'            apex.navigation.dialog.close(true);',
'            // Show a success message to your customer',
'            // There''s a risk of the customer closing the window before callback',
'            // execution. Set up a webhook or plugin to listen for the',
'            // payment_intent.succeeded event that handles any business critical',
'            // post-payment actions.',
'        }',
'    }',
'});'))
);
wwv_flow_imp.component_end;
end;
/
