prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>263
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Stripe'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230824061138'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(70951444306216705)
,p_plug_name=>'Payment Intent'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(70727312186906002)
,p_plug_display_sequence=>60
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'begin',
'    if :P1_PAYMENT_INTENT_ID is null then',
'        return '''';',
'    end if;',
'    apex_web_service.clear_request_headers();',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => :STRIPE_ENDPOINT || ''/v1/payment_intents/'' || :P1_PAYMENT_INTENT_ID',
'        ,p_http_method => ''GET''',
'        ,p_credential_static_id => ''STRIPE_CRED''',
'    );',
'    return l_response;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69654885247333240)
,p_button_sequence=>20
,p_button_name=>'CONFIRM'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(70818262262906063)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Confirm'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(70951505209216706)
,p_button_sequence=>70
,p_button_name=>'REFRESH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(70818262262906063)
,p_button_image_alt=>'Refresh'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(70951814281216709)
,p_button_sequence=>80
,p_button_name=>'CLEAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(70818262262906063)
,p_button_image_alt=>'Clear'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(69655358952333245)
,p_branch_name=>'Open Drawer'
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::P2_CLIENT_SECRET:&P1_CLIENT_SECRET.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(69654885247333240)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69654710013333239)
,p_name=>'P1_AMOUNT'
,p_item_sequence=>10
,p_prompt=>'Amount'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(70815706529906059)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69655405132333246)
,p_name=>'P1_CLIENT_SECRET'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70952259551216713)
,p_name=>'P1_PAYMENT_INTENT_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(70951651383216707)
,p_name=>'onClick REFRESH'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(70951505209216706)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(70951771154216708)
,p_event_id=>wwv_flow_imp.id(70951651383216707)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(70951444306216705)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(69654931775333241)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Payment Intent'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'    l_response_json json_object_t;',
'    e_create_charge_failed exception;',
'begin',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/x-www-form-urlencoded'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => :STRIPE_ENDPOINT || ''/v1/payment_intents''',
'        ,p_http_method => ''POST''',
'        ,p_parm_name => apex_util.string_to_table(''amount:currency:automatic_payment_methods[enabled]'')',
'        ,p_parm_value => apex_util.string_to_table(:P1_AMOUNT || '':jpy:true'')',
'        ,p_credential_static_id => ''STRIPE_CRED''',
'    );',
'    apex_debug.info(l_response);',
'    if apex_web_service.g_status_code <> 200 then',
'        apex_debug.info(l_response);',
'        raise e_create_charge_failed;',
'    end if;',
'    l_response_json := json_object_t(l_response);',
'    :P1_PAYMENT_INTENT_ID := l_response_json.get_string(''id'');',
'    :P1_CLIENT_SECRET := l_response_json.get_string(''client_secret'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(69654885247333240)
,p_internal_uid=>69654931775333241
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(70951985470216710)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Session State'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(70951814281216709)
,p_internal_uid=>70951985470216710
);
wwv_flow_imp.component_end;
end;
/
