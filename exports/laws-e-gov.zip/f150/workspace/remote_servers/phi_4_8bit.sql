prompt --workspace/remote_servers/phi_4_8bit
begin
--   Manifest
--     REMOTE SERVER: phi-4@8bit
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>150
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(46617680797603649)
,p_name=>'phi-4@8bit'
,p_static_id=>'PHI4'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('PHI4'),'http://host.containers.internal:8080/v1')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('PHI4'),'')
,p_server_type=>'GENERATIVE_AI'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('PHI4'),'')
,p_credential_id=>wwv_flow_imp.id(46616569731452176)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('PHI4'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('PHI4'),'')
,p_prompt_on_install=>true
,p_ai_provider_type=>'OPENAI'
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('PHI4'),'phi-4@8bit')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('PHI4'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('PHI4'),'')
);
wwv_flow_imp.component_end;
end;
/
