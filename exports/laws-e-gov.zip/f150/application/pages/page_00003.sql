prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>150
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>unistr('\8AAC\660E')
,p_alias=>unistr('\8AAC\660E')
,p_step_title=>unistr('\8AAC\660E')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46532022906254923)
,p_plug_name=>unistr('\30EA\30FC\30B8\30E7\30F3\9078\629E')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46532126371254924)
,p_plug_name=>unistr('\524D\6587')
,p_region_css_classes=>'law-Report'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ID,',
'    LAW_ID,',
'    "LawType",',
'    "LawNum",',
'    to_number("Root_Num" default -1 on conversion error) "Root_Num",',
'    "LawTitle",',
'    "LawTitle_Kana",',
'    to_number("Paragraph_Num" default -1 on conversion error) "Paragraph_Num",',
'    to_number("Sentence_Num" default -1 on conversion error)  "Sentence_Num",',
'    "Sentence"',
'from JLAW_Law_Preamble_XV',
'order by ',
'    "Root_Num" asc nulls first,',
'    "Paragraph_Num" asc nulls first,',
'    "Sentence_Num" asc nulls first'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(46534645112254949)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_sort=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>46534645112254949
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46534705459254950)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46583377788926601)
,p_db_column_name=>'LAW_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Law Id'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46583440090926602)
,p_db_column_name=>'LawType'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Lawtype'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46583590796926603)
,p_db_column_name=>'LawNum'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Lawnum'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46583691067926604)
,p_db_column_name=>'Root_Num'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Root Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46583796403926605)
,p_db_column_name=>'LawTitle'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Lawtitle'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46583891218926606)
,p_db_column_name=>'LawTitle_Kana'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Lawtitle Kana'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46583999515926607)
,p_db_column_name=>'Paragraph_Num'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Paragraph Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46584070584926608)
,p_db_column_name=>'Sentence_Num'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Sentence Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46584162097926609)
,p_db_column_name=>'Sentence'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Sentence'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_static_id=>'SENTENCE_COLUMN'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(46600801039933922)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'466009'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LAW_ID:LawNum:LawTitle:Sentence_Num:Sentence:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46532205681254925)
,p_plug_name=>unistr('\672C\5247')
,p_region_css_classes=>'law-Report'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ID,',
'    LAW_ID,',
'    "LawType",',
'    "LawNum",',
'    to_number("Root_Num" default -1 on conversion error) "Root_Num",',
'    "LawTitle",',
'    "LawTitle_Kana",',
'    to_number("Part_Num" default -1 on conversion error) "Part_Num",',
'    "PartTitle",',
'    to_number("Chapter_Num" default -1 on conversion error) "Chapter_Num",',
'    "ChapterTitle",',
'    to_number("Section_Num" default -1 on conversion error) "Section_Num",',
'    "SectionTitle",',
'    to_number("Subsection_Num" default -1 on conversion error) "Subsection_Num",',
'    "SubsectionTitle",',
'    to_number("Division_Num" default -1 on conversion error) "Division_Num",',
'    "DivisionTitle",',
'    to_number("Article_Num" default -1 on conversion error) "Article_Num",',
'    "ArticleTitle",',
'    to_number("Paragraph_Num" default -1 on conversion error) "Paragraph_Num",',
'    to_number("Sentence_Num" default -1 on conversion error) "Sentence_Num",',
'    "Sentence"',
'from JLAW_Law_MainProvision_XV',
'order by',
'    "Root_Num" asc nulls first,',
'    "Part_Num" asc nulls first,',
'    "Chapter_Num" asc nulls first,',
'    "Section_Num" asc nulls first,',
'    "Subsection_Num" asc nulls first,',
'    "Division_Num" asc nulls first,',
'    "Article_Num" asc nulls first,',
'    "Paragraph_Num" asc nulls first,',
'    "Sentence_Num" asc nulls first'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(46584275666926610)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_sort=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>46584275666926610
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46584383366926611)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46584494985926612)
,p_db_column_name=>'LAW_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Law Id'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46584577519926613)
,p_db_column_name=>'LawType'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Lawtype'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46584676179926614)
,p_db_column_name=>'LawNum'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Lawnum'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46584766848926615)
,p_db_column_name=>'Root_Num'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Root Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46584828219926616)
,p_db_column_name=>'LawTitle'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Lawtitle'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46584904912926617)
,p_db_column_name=>'LawTitle_Kana'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Lawtitle Kana'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46585083774926618)
,p_db_column_name=>'Part_Num'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Part Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46585111732926619)
,p_db_column_name=>'PartTitle'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Parttitle'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46585211602926620)
,p_db_column_name=>'Chapter_Num'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Chapter Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46585365920926621)
,p_db_column_name=>'ChapterTitle'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Chaptertitle'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46585432572926622)
,p_db_column_name=>'Section_Num'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Section Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46585503570926623)
,p_db_column_name=>'SectionTitle'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Sectiontitle'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46585694761926624)
,p_db_column_name=>'Subsection_Num'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Subsection Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46585796126926625)
,p_db_column_name=>'SubsectionTitle'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Subsectiontitle'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46585895181926626)
,p_db_column_name=>'Division_Num'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Division Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46585929712926627)
,p_db_column_name=>'DivisionTitle'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Divisiontitle'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46586035791926628)
,p_db_column_name=>'Article_Num'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Article Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46586123655926629)
,p_db_column_name=>'ArticleTitle'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Articletitle'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46586228124926630)
,p_db_column_name=>'Paragraph_Num'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Paragraph Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46586393445926631)
,p_db_column_name=>'Sentence_Num'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Sentence Num'
,p_allow_sorting=>'N'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46586402898926632)
,p_db_column_name=>'Sentence'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Sentence'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_static_id=>'SENTENCE_COLUMN'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(46601308155933927)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'466014'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LAW_ID:LawType:LawNum:LawTitle:PartTitle:ChapterTitle:SectionTitle:SubsectionTitle:DivisionTitle:ArticleTitle:Sentence_Num:Sentence:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46550521818809903)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(46471061128150087)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46586787742926635)
,p_button_sequence=>20
,p_button_name=>'EXPLAIN_ELEMENTARY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\5C0F\5B66\751F\306B\8AAC\660E\3059\308B')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46586882998926636)
,p_button_sequence=>30
,p_button_name=>'EXPLAIN_JUNIOR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\4E2D\5B66\751F\306B\8AAC\660E\3059\308B')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46586538544926633)
,p_name=>'P3_TEXT'
,p_data_type=>'CLOB'
,p_item_sequence=>10
,p_prompt=>unistr('\6CD5\4EE4')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46586663635926634)
,p_name=>'P3_EXPLAIN'
,p_data_type=>'CLOB'
,p_item_sequence=>50
,p_prompt=>unistr('\8A00\3044\63DB\3048')
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_custom_html', 'N',
  'format', 'MARKDOWN',
  'min_height', '180')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46586901397926637)
,p_name=>'onClick EXPLAIN_ELEMENTARY'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46586787742926635)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46587185361926639)
,p_event_id=>wwv_flow_imp.id(46586901397926637)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_EXPLAIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46587026886926638)
,p_event_id=>wwv_flow_imp.id(46586901397926637)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_GENERATE_TEXT_AI'
,p_attribute_01=>'ITEM'
,p_attribute_02=>'P3_TEXT'
,p_attribute_04=>'ITEM'
,p_attribute_05=>'P3_EXPLAIN'
,p_attribute_07=>'Y'
,p_wait_for_result=>'Y'
,p_ai_config_id=>wwv_flow_imp.id(46618742281684350)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46587362208926641)
,p_name=>'onClick EXPLAIN_JUNIOR'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46586882998926636)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46587476268926642)
,p_event_id=>wwv_flow_imp.id(46587362208926641)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_EXPLAIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46587543295926643)
,p_event_id=>wwv_flow_imp.id(46587362208926641)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_GENERATE_TEXT_AI'
,p_attribute_01=>'ITEM'
,p_attribute_02=>'P3_TEXT'
,p_attribute_04=>'ITEM'
,p_attribute_05=>'P3_EXPLAIN'
,p_attribute_07=>'Y'
,p_wait_for_result=>'Y'
,p_ai_config_id=>wwv_flow_imp.id(46619099031730248)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46587629393926644)
,p_name=>'Click to Copy'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'td[headers="SENTENCE_COLUMN"]'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'.law-Report'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46587704407926645)
,p_event_id=>wwv_flow_imp.id(46587629393926644)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_TEXT'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.innerText'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
