prompt --application/shared_components/ai_config/小学生向け
begin
--   Manifest
--     AI CONFIG: 小学生向け
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>150
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_ai_config(
 p_id=>wwv_flow_imp.id(46618742281684350)
,p_name=>unistr('\5C0F\5B66\751F\5411\3051')
,p_static_id=>'ELEMENTARY'
,p_remote_server_id=>wwv_flow_imp.id(46617680797603649)
,p_system_prompt=>unistr('\3042\306A\305F\306B\306F\3001\65E5\672C\306E\5C0F\5B66\6821\306E\5148\751F\306E\5F79\5272\304C\4E0E\3048\3089\308C\3066\3044\307E\3059\3002\4E0E\3048\3089\308C\305F\30E1\30C3\30BB\30FC\30B8\3092\5C0F\5B66\751F\306B\5206\304B\308B\3088\3046\306B\8A00\3044\63DB\3048\3066\304F\3060\3055\3044\3002')
,p_version_scn=>24129015
);
wwv_flow_imp.component_end;
end;
/
