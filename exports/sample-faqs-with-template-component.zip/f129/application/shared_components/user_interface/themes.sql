prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 129
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>129
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(20343533112689148)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'24.1'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(20103255057688506)
,p_default_dialog_template=>wwv_flow_imp.id(20098043807688496)
,p_error_template=>wwv_flow_imp.id(20088007020688476)
,p_printer_friendly_template=>wwv_flow_imp.id(20103255057688506)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(20088007020688476)
,p_default_button_template=>wwv_flow_imp.id(20253512295688827)
,p_default_region_template=>wwv_flow_imp.id(20179995414688664)
,p_default_chart_template=>wwv_flow_imp.id(20179995414688664)
,p_default_form_template=>wwv_flow_imp.id(20179995414688664)
,p_default_reportr_template=>wwv_flow_imp.id(20179995414688664)
,p_default_tabform_template=>wwv_flow_imp.id(20179995414688664)
,p_default_wizard_template=>wwv_flow_imp.id(20179995414688664)
,p_default_menur_template=>wwv_flow_imp.id(20192396166688692)
,p_default_listr_template=>wwv_flow_imp.id(20179995414688664)
,p_default_irr_template=>wwv_flow_imp.id(20170182471688644)
,p_default_report_template=>wwv_flow_imp.id(20218311596688747)
,p_default_label_template=>wwv_flow_imp.id(20251046922688821)
,p_default_menu_template=>wwv_flow_imp.id(20255131051688831)
,p_default_calendar_template=>wwv_flow_imp.id(20255249812688831)
,p_default_list_template=>wwv_flow_imp.id(20234943696688785)
,p_default_nav_list_template=>wwv_flow_imp.id(20246788305688811)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(20246788305688811)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(20241365955688799)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(20116150592688532)
,p_default_dialogr_template=>wwv_flow_imp.id(20113368030688526)
,p_default_option_label=>wwv_flow_imp.id(20251046922688821)
,p_default_required_label=>wwv_flow_imp.id(20252347773688824)
,p_default_navbar_list_template=>wwv_flow_imp.id(20240983193688798)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/24.1/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
