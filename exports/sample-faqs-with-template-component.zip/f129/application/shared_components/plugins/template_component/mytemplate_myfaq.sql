prompt --application/shared_components/plugins/template_component/mytemplate_myfaq
begin
--   Manifest
--     PLUGIN: MYTEMPLATE.MYFAQ
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>129
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(20415843358938454)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '')
,p_name=>'MYTEMPLATE.MYFAQ'
,p_display_name=>'MYFAQ'
,p_supported_component_types=>'REPORT'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','MYTEMPLATE.MYFAQ'),'')
,p_javascript_file_urls=>'#PLUGIN_FILES#index#MIN#.js'
,p_css_file_urls=>'#PLUGIN_FILES#index#MIN#.css'
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="cs-container">',
'  <div class="cs-header">',
'    <span>#QUESTION#</span>',
'    <span class="cs-info-item">#CATEGORIES#</span>',
'    <span class="cs-info-item">#OWNER#</span>',
'    <span class="cs-info-item">#POST_DATE#</span>',
'  </div>',
'',
'  <hr> ',
'  <div class="cs-answer-section">',
'    <div id="answer">#ANSWER#</div>',
'    <span class="cs-expand-button">+</span>',
'  </div>',
'</div>'))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>1
,p_report_body_template=>'<ul>#APEX$ROWS#</ul>'
,p_report_row_template=>'<li #APEX$ROW_IDENTIFICATION#>#APEX$PARTIAL#</li>'
,p_report_placeholder_count=>3
,p_standard_attributes=>'REGION_TEMPLATE'
,p_substitute_attributes=>true
,p_version_scn=>41125610772371
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_files_version=>9
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(20416173192938484)
,p_plugin_id=>wwv_flow_imp.id(20415843358938454)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_static_id=>'ANSWER'
,p_prompt=>'Answer'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(20416557227938485)
,p_plugin_id=>wwv_flow_imp.id(20415843358938454)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_static_id=>'CATEGORIES'
,p_prompt=>'Categories'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(20416947955938486)
,p_plugin_id=>wwv_flow_imp.id(20415843358938454)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_static_id=>'OWNER'
,p_prompt=>'Owner'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(20417324911938486)
,p_plugin_id=>wwv_flow_imp.id(20415843358938454)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_static_id=>'POST_DATE'
,p_prompt=>'Post Date'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(20417724926938487)
,p_plugin_id=>wwv_flow_imp.id(20415843358938454)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>50
,p_static_id=>'QUESTION'
,p_prompt=>'Question'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '636F6E737420657870616E64427574746F6E203D20646F63756D656E742E717565727953656C6563746F7228272E63732D657870616E642D627574746F6E27293B0A636F6E737420616E73776572203D20646F63756D656E742E676574456C656D656E74';
wwv_flow_imp.g_varchar2_table(2) := '427949642827616E7377657227293B0A0A657870616E64427574746F6E2E6164644576656E744C697374656E65722827636C69636B272C202829203D3E207B0A2020616E737765722E636C6173734C6973742E746F67676C652827656E6C617267656427';
wwv_flow_imp.g_varchar2_table(3) := '293B202F2F20E4BBAEE381AEE382AFE383A9E382B9E5908D0A7D293B';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(20418428729985485)
,p_plugin_id=>wwv_flow_imp.id(20415843358938454)
,p_file_name=>'index.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '636F6E737420657870616E64427574746F6E3D646F63756D656E742E717565727953656C6563746F7228222E63732D657870616E642D627574746F6E22292C616E737765723D646F63756D656E742E676574456C656D656E74427949642822616E737765';
wwv_flow_imp.g_varchar2_table(2) := '7222293B657870616E64427574746F6E2E6164644576656E744C697374656E65722822636C69636B222C2828293D3E7B616E737765722E636C6173734C6973742E746F67676C652822656E6C617267656422297D29293B';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(20419928882995594)
,p_plugin_id=>wwv_flow_imp.id(20415843358938454)
,p_file_name=>'index.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E63732D636F6E7461696E6572207B0A2020626F726465723A2031707820736F6C696420236363633B0A202070616464696E673A20313070783B0A7D0A0A2E63732D686561646572207B0A2020646973706C61793A20666C65783B0A20206A7573746966';
wwv_flow_imp.g_varchar2_table(2) := '792D636F6E74656E743A2073706163652D6265747765656E3B0A20206D617267696E2D626F74746F6D3A20313070783B0A7D0A0A2E63732D696E666F2D6974656D207B0A20206261636B67726F756E642D636F6C6F723A20236630663066303B202F2A20';
wwv_flow_imp.g_varchar2_table(3) := '4C696768742067726179206261636B67726F756E64202A2F0A202070616464696E673A2035707820313070783B0A2020626F726465722D7261646975733A203570783B0A7D0A0A2E63732D616E737765722D73656374696F6E207B0A2020646973706C61';
wwv_flow_imp.g_varchar2_table(4) := '793A20666C65783B0A2020616C69676E2D6974656D733A2063656E7465723B0A20206D617267696E2D746F703A20313070783B202F2A20416464206D617267696E20746F2073657061726174652066726F6D20746865206C696E65202A2F0A7D0A0A2E63';
wwv_flow_imp.g_varchar2_table(5) := '732D657870616E642D627574746F6E207B0A20206D617267696E2D6C6566743A206175746F3B202F2A205075736820746F20746865207269676874202A2F0A2020637572736F723A20706F696E7465723B0A7D0A0A6872207B202F2A205374796C652066';
wwv_flow_imp.g_varchar2_table(6) := '6F722074686520686F72697A6F6E74616C206C696E65202A2F0A2020626F726465723A206E6F6E653B0A2020626F726465722D746F703A2031707820736F6C696420236363633B0A20206D617267696E3A203130707820303B0A7D';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(20420337256026618)
,p_plugin_id=>wwv_flow_imp.id(20415843358938454)
,p_file_name=>'index.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E63732D636F6E7461696E65727B626F726465723A31707820736F6C696420236363633B70616464696E673A313070787D2E63732D6865616465727B646973706C61793A666C65783B6A7573746966792D636F6E74656E743A73706163652D6265747765';
wwv_flow_imp.g_varchar2_table(2) := '656E3B6D617267696E2D626F74746F6D3A313070787D2E63732D696E666F2D6974656D7B6261636B67726F756E642D636F6C6F723A236630663066303B70616464696E673A35707820313070783B626F726465722D7261646975733A3570787D2E63732D';
wwv_flow_imp.g_varchar2_table(3) := '616E737765722D73656374696F6E7B646973706C61793A666C65783B616C69676E2D6974656D733A63656E7465723B6D617267696E2D746F703A313070787D2E63732D657870616E642D627574746F6E7B6D617267696E2D6C6566743A6175746F3B6375';
wwv_flow_imp.g_varchar2_table(4) := '72736F723A706F696E7465727D68727B626F726465723A303B626F726465722D746F703A31707820736F6C696420236363633B6D617267696E3A3130707820307D';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(20421808032035974)
,p_plugin_id=>wwv_flow_imp.id(20415843358938454)
,p_file_name=>'index.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
