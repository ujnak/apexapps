prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 129
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>129
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE90000010B494441545847637CDB68F79F610001E3A80346436034044643809810F82DA1C9C020A50D2FAEDEDEB9C8C0C3C78F527CBDBD';
wwv_flow_imp.g_varchar2_table(2) := '7F9D815F580C2EF6E3E94D06095E3682451C5105D16FA3100651FB28B861AF0F2E63E013974531FCF9D10D0C62CA5A70B15777AF31087CBA3FEA00EA84C00B3E550661157D92D2C0C7B7AF18E459BF52C7015F644C1844756D1169E0F2610621517114C3';
wwv_flow_imp.g_varchar2_table(3) := 'BF327262A413D6736B461D304C42E0E16F6E94420694C0A4CC3D517CF7F2C24106012979B8D887670F1964FEBDA64E087CE053C4286414927B510C7FB2BA0D23A1F23C3933EA00EA84C0777601869FEC8270C38849035FAE1FA35E6544D01B142820AA36';
wwv_flow_imp.g_varchar2_table(4) := 'A4C07C825A471D301A02A32130E021000087A9F281AA5302DB0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(20367356657689210)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
