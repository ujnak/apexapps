prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>168
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Gradio Client'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "@gradio/client": "https://cdn.jsdelivr.net/npm/@gradio/client/+esm"',
'        }',
'    }',
'</script>'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47904131351861213)
,p_plug_name=>'Whisper'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(54150170492569996)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="module">',
'import { Client, handle_file } from "@gradio/client";',
'',
'const response = await fetch(',
'	"https://audio-samples.github.io/samples/mp3/blizzard_unconditional/sample-0.mp3"',
');',
'const audio_file = await response.blob();',
'',
'const app = await Client.connect("abidlabs/whisper");',
'const result = await app.predict("/predict", [handle_file(audio_file)]);',
'// ',
'let text = result.data[0];',
'apex.item("P1_RESULT").setValue(text);',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47904346804861215)
,p_plug_name=>'Event'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(54150170492569996)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="module">',
'import { Client } from "@gradio/client";',
'',
'function log_result(payload) {',
'	const {',
'		data: [translation]',
'	} = payload;',
'',
'	apex.item("P1_RESULT").setValue(`The translated result is: ${translation}`);',
'}',
'',
'const app = await Client.connect("abidlabs/en2fr");',
'const job = app.submit("/predict", ["Hello"]);',
'',
'for await (const message of job) {',
'	log_result(message);',
'}',
'</script>'))
,p_required_patch=>wwv_flow_imp.id(54046202041569787)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47904471008861216)
,p_plug_name=>'Generator'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(54150170492569996)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="module">',
'import { Client } from "@gradio/client";',
'',
'const app = await Client.connect("gradio/count_generator");',
'const job = app.submit(0, [9]);',
'',
'for await (const message of job) {',
'    console.log(message.data);',
'    apex.item("P1_RESULT").setValue(JSON.stringify(message.data));',
'}',
'',
'setTimeout(() => {',
'	job.cancel();',
'}, 3000);',
'</script>'))
,p_required_patch=>wwv_flow_imp.id(54046202041569787)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47904571972861217)
,p_plug_name=>'Status'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(54150170492569996)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="module">',
'import { Client } from "@gradio/client";',
'',
'function log_status(status) {',
'	apex.item("P1_RESULT").setValue(',
'		`The current status for this job is: ${JSON.stringify(status, null, 2)}.`',
'	);',
'}',
'',
'const app = await Client.connect("abidlabs/en2fr", {',
'	events: ["status", "data"]',
'});',
'const job = app.submit("/predict", ["Hello"]);',
'',
'for await (const message of job) {',
'	if (message.type === "status") {',
'		log_status(message);',
'	}',
'}',
'</script>'))
,p_required_patch=>wwv_flow_imp.id(54046202041569787)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54348025279570594)
,p_plug_name=>'Gradio Client'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(54116837464569928)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47904261085861214)
,p_name=>'P1_RESULT'
,p_item_sequence=>60
,p_prompt=>'Result'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>10
,p_field_template=>wwv_flow_imp.id(54221258275570151)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
