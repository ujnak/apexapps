prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>176
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Accessibility Check'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77918237431257593)
,p_plug_name=>'Accessibility Check'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(77687159513256833)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77937700437203903)
,p_plug_name=>'Log'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(77720460505256902)
,p_plug_display_sequence=>170
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="log"></div>',
'<script defer>',
'    const logArea = document.getElementById("log");',
'    const items = ["P1_COLOR", "P1_COMBO", "P1_DATE", "P1_NUM", "P1_POPUPLOV", "P1_SELECT_LIST", "P1_SELECT_ONE", "P1_SELECT_MANY", "P1_SWITCH", "P1_TEXT", "P1_TEXTAREA", "P1_TEXT_AUTO", "P1_DISPLAY_ONLY1", "P1_DISPLAY_ONLY2" ];',
'    items.forEach( (item) => {',
'        const e = document.getElementById(item);',
'        logArea.innerHTML += `<span>${item} is ${e.tagName} type="${e.type}" class="${e.className}" value="${e.value}"</span> : `;',
'        /*',
unistr('         * \8868\793A\7528\306ESPAN\8981\7D20\304C\4F5C\6210\3055\308C\3066\3044\308B\304B\3069\3046\304B\78BA\8A8D\3059\308B\3002'),
unistr('         * \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\5B9A\7FA9\306E\30A2\30AF\30BB\30B9\53EF\80FD\306A\8AAD\307F\53D6\308A\5C02\7528\30A2\30A4\30C6\30E0\304C\30AA\30F3\306E\5834\5408\306F\3001'),
unistr('         * _DISPLAY\304C\4ED8\3044\305FSPAN\8981\7D20\306F\4F5C\6210\3055\308C\308C\306A\3044\3002'),
'         */',
'        const item_d = item + "_DISPLAY";',
'        const d = document.getElementById(item_d);',
'        if (d) {',
'            logArea.innerHTML += `<span>${item_d} is ${d.tagName}</span><br>`;',
'        }',
'        else',
'        {',
'            logArea.innerHTML += `<span>${item_d} does not exist.</span><br>`;',
'        }',
'    });',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72928249183411135)
,p_name=>'P1_COLOR'
,p_item_sequence=>10
,p_item_default=>'#ffff00'
,p_prompt=>'Color Picker'
,p_display_as=>'NATIVE_COLOR_PICKER'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72928416591411137)
,p_name=>'P1_COMBO'
,p_item_sequence=>20
,p_item_default=>'Return1:Return2'
,p_prompt=>'Combo Box'
,p_display_as=>'NATIVE_COMBOBOX'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_04=>'N'
,p_attribute_07=>'Y'
,p_attribute_09=>'0'
,p_attribute_11=>'P1_COMBO_IN'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72928583563411138)
,p_name=>'P1_COMBO_IN'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72928633874411139)
,p_name=>'P1_DATE'
,p_item_sequence=>40
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'SQL'
,p_prompt=>'Date Picker'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72928743711411140)
,p_name=>'P1_NUM'
,p_item_sequence=>50
,p_item_default=>'23115023'
,p_prompt=>'Number'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72928947952411142)
,p_name=>'P1_POPUPLOV'
,p_item_sequence=>70
,p_item_default=>'Return1:Return2'
,p_prompt=>'Popup LOV'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72929011004411143)
,p_name=>'P1_SELECT_LIST'
,p_item_sequence=>80
,p_item_default=>'Return1:Return2'
,p_prompt=>'Select List'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_lov_display_null=>'YES'
,p_cHeight=>5
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72929131427411144)
,p_name=>'P1_SELECT_ONE'
,p_item_sequence=>90
,p_item_default=>'Return1'
,p_prompt=>'Select One'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_04=>'N'
,p_attribute_09=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72929281659411145)
,p_name=>'P1_SELECT_MANY'
,p_item_sequence=>100
,p_item_default=>'Return1:Return2'
,p_prompt=>'Select Many'
,p_display_as=>'NATIVE_SELECT_MANY'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_04=>'N'
,p_attribute_09=>'0'
,p_attribute_13=>'Y'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72929366161411146)
,p_name=>'P1_SWITCH'
,p_item_sequence=>110
,p_item_default=>'Y'
,p_prompt=>'Switch'
,p_display_as=>'NATIVE_YES_NO'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72929477730411147)
,p_name=>'P1_TEXT'
,p_item_sequence=>120
,p_item_default=>unistr('\8868\793A\3055\308C\308B\30C6\30AD\30B9\30C8')
,p_prompt=>'Text Field'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72929562552411148)
,p_name=>'P1_TEXTAREA'
,p_item_sequence=>130
,p_item_default=>unistr('\8868\793A\3055\308C\308B\30C6\30AD\30B9\30C8')
,p_prompt=>'Text Area'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72929677148411149)
,p_name=>'P1_TEXT_AUTO'
,p_item_sequence=>140
,p_item_default=>unistr('\8868\793A\3055\308C\308B\30C6\30AD\30B9\30C8')
,p_prompt=>'Text Field with Auto Complete'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77937872553203904)
,p_name=>'P1_DISPLAY_ONLY1'
,p_item_sequence=>150
,p_item_default=>unistr('\8868\793A\306E\307F\306E\30C6\30AD\30B9\30C8')
,p_prompt=>'Display Only - Send On'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77937928696203905)
,p_name=>'P1_DISPLAY_ONLY2'
,p_item_sequence=>160
,p_item_default=>unistr('\8868\793A\306E\307F\306E\30C6\30AD\30B9\30C8')
,p_prompt=>'Display Only - Send Off'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(77791582058257067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
