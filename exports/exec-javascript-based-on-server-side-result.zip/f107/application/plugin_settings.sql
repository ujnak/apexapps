prompt --application/plugin_settings
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7216617235130697
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(27194087685347428)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'Y'
,p_version_scn=>41116244184369
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(27194382395347431)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_APEX'
,p_attribute_01=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_02=>'VISIBLE'
,p_attribute_03=>'15'
,p_attribute_04=>'FOCUS'
,p_version_scn=>41116244184377
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(27194609002347431)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attribute_01=>'FULL'
,p_attribute_02=>'POPUP'
,p_version_scn=>41116244184377
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(27194991350347432)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_version_scn=>41116244184380
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(27195231996347433)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attribute_01=>'IG'
,p_version_scn=>41116244184383
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(27195532732347433)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attribute_01=>'fa-star'
,p_attribute_04=>'#VALUE#'
,p_version_scn=>41116244184383
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(27195884332347434)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_MAP_REGION'
,p_attribute_01=>'Y'
,p_version_scn=>41116244184386
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(27196153341347435)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_ADFBC'
,p_version_scn=>41116244184389
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(27196453273347435)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attribute_01=>'Y'
,p_attribute_03=>'N'
,p_attribute_05=>'SWITCH_CB'
,p_version_scn=>41116244184389
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(27196765163347436)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_GEOCODED_ADDRESS'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_attribute_02=>'N'
,p_attribute_03=>'POPUP:ITEM'
,p_attribute_04=>'default'
,p_attribute_06=>'LIST'
,p_version_scn=>41116244184392
);
wwv_flow_imp.component_end;
end;
/
