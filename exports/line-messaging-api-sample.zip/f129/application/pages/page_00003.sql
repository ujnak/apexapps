prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>129
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>unistr('\53D7\4FE1\30E1\30C3\30BB\30FC\30B8')
,p_alias=>unistr('\53D7\4FE1\30E1\30C3\30BB\30FC\30B8')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\53D7\4FE1\30E1\30C3\30BB\30FC\30B8')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230228005309'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56769366996367232)
,p_plug_name=>unistr('\53D7\4FE1\30E1\30C3\30BB\30FC\30B8')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(56560474168107537)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'LINE_MESSAGES_V'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56778006314367240)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(56563255265107539)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56778410120367241)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56778006314367240)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(56699386596107616)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56780212069367242)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(56778006314367240)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(56699386596107616)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4FDD\5B58')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_CONTENT_PROVIDER_TYPE'
,p_button_condition2=>'line'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56780644421367242)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(56778006314367240)
,p_button_name=>'REPLY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(56699386596107616)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\8FD4\4FE1')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_MESSAGE_TYPE'
,p_button_condition2=>'text'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54893728398513331)
,p_name=>'P3_REPLY_TEXT'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Reply Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_display_when=>'P3_MESSAGE_TYPE'
,p_display_when2=>'text'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(56696868636107614)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56769697873367233)
,p_name=>'P3_MESSAGE_ID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_source=>'MESSAGE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56770092259367234)
,p_name=>'P3_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(56698155819107615)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56770426935367234)
,p_name=>'P3_IS_VALID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Is Valid'
,p_source=>'IS_VALID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(56698155819107615)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56770830319367235)
,p_name=>'P3_RECEIVED_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Received Date'
,p_source=>'RECEIVED_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(56696868636107614)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56771261526367235)
,p_name=>'P3_SOURCE_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Source Type'
,p_source=>'SOURCE_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(56696868636107614)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56771652074367235)
,p_name=>'P3_SOURCE_USER_ID'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Source User Id'
,p_source=>'SOURCE_USER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(56696868636107614)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56772049810367236)
,p_name=>'P3_REPLY_TOKEN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Reply Token'
,p_source=>'REPLY_TOKEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(56696868636107614)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56772480338367236)
,p_name=>'P3_MESSAGE_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Message Type'
,p_source=>'MESSAGE_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(56696868636107614)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56772808600367236)
,p_name=>'P3_MESSAGE_TEXT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Message Text'
,p_source=>'MESSAGE_TEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(56696868636107614)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56773299652367236)
,p_name=>'P3_CONTENT_PROVIDER_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Content Provider Type'
,p_source=>'CONTENT_PROVIDER_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(56696868636107614)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56773649472367237)
,p_name=>'P3_CONTENT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Content'
,p_source=>'CONTENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(56696868636107614)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56774004172367237)
,p_name=>'P3_CONTENT_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_item_source_plug_id=>wwv_flow_imp.id(56769366996367232)
,p_prompt=>'Content Type'
,p_source=>'CONTENT_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(56696868636107614)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56778587054367241)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56778410120367241)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56779340521367241)
,p_event_id=>wwv_flow_imp.id(56778587054367241)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54893901609513333)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_ENDPOINT constant varchar2(80) := ''https://api-data.line.me/v2/bot/message/{messageId}/content'';',
'    l_url varchar2(200);',
'    l_response_blob blob;',
'    l_count number;',
'    l_content_type varchar2(80);',
'begin',
'    select count(*) into l_count from line_images where message_id = :P3_MESSAGE_ID;',
'    if l_count > 0 then',
unistr('        return; -- \3059\3067\306B\4FDD\5B58\6E08\307F\3067\3042\308C\3070\4F55\3082\3057\306A\3044\3002'),
'    end if;',
unistr('    /* \30C7\30FC\30BF\3092\53D6\5F97\3059\308B */'),
'    l_url := replace(C_ENDPOINT, ''{messageId}'', :P3_MESSAGE_ID);',
'    -- apex_debug.info(l_url);',
'    apex_web_service.clear_request_headers();',
'    l_response_blob := apex_web_service.make_rest_request_b(',
'        p_url => l_url',
'        ,p_http_method => ''GET''',
'        ,p_credential_static_id => ''LINE_CHANNEL_ACCESS_TOKEN''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise_application_error(-20001, ''LINE Content Error = '' || apex_web_service.g_status_code);',
'    end if;',
unistr('    /* Content-Type\30D8\30C3\30C0\30FC\3092\53D6\5F97\3059\308B */'),
'    for i in 1..apex_web_service.g_headers.count',
'    loop',
'        if apex_web_service.g_headers(i).name = ''Content-Type'' then',
'            l_content_type := apex_web_service.g_headers(i).value;',
'            exit;',
'        end if;',
'    end loop;',
unistr('    /* \53D6\5F97\3057\305F\30A4\30E1\30FC\30B8\3092\8868LINE_IMAGES\306B\4FDD\5B58\3059\308B\3002 */'),
'    insert into line_images(message_id, content, content_type)',
'    values(:P3_MESSAGE_ID, l_response_blob, l_content_type);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56780212069367242)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54893876324513332)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reply'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_ENDPOINT constant varchar2(80) := ''https://api.line.me/v2/bot/message/reply'';',
'    l_request json_object_t;',
'    l_request_clob clob;',
'    l_messages json_array_t;',
'    l_message json_object_t;',
'    l_response_clob clob;',
'begin',
'    l_request := json_object_t();',
'    l_request.put(''replyToken'', :P3_REPLY_TOKEN);',
'    l_message := json_object_t();',
'    l_message.put(''type'',''text'');',
'    l_message.put(''text'', :P3_REPLY_TEXT);',
'    l_messages := json_array_t();',
'    l_messages.append(l_message);',
'    l_request.put(''messages'', l_messages);',
'    l_request_clob := l_request.to_clob();',
unistr('    /* \8FD4\4FE1 */'),
'    apex_debug.info(l_request_clob);',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'');',
'    l_response_clob := apex_web_service.make_rest_request(',
'        p_url => C_ENDPOINT',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'        ,p_credential_static_id => ''LINE_CHANNEL_ACCESS_TOKEN''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise_application_error(-20001, ''LINE Reply Error = '' || apex_web_service.g_status_code);',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56780644421367242)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56781833689367244)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,REPLY'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56781069429367243)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(56769366996367232)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0\53D7\4FE1\30E1\30C3\30BB\30FC\30B8')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
