prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>233
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'FullCalendar Cell Highlight'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \56FD\6C11\306E\795D\65E5\3092\4FDD\6301\3059\308B\3002'),
' */',
'var g_HOLIDAYS = {};',
'',
'/*',
unistr(' * \65E5\4ED8\30BB\30EB\306E\8981\7D20\3068\65E5\4ED8\30C7\30FC\30BF\3092\53D7\3051\53D6\308A\3001\795D\65E5\304C\8A2D\5B9A\3055\308C\3066\3044\308C\3070'),
unistr(' * \65E5\4ED8\30BB\30EB\3092\5909\66F4\3059\308B\3002'),
' * ',
unistr(' * \4EE5\4E0B\306F\4F8B\3068\3057\3066CSS\30AF\30E9\30B9\3068\3057\3066u-color-18-bg\3092\8A2D\5B9A\3057\3066\3044\308B\3002'),
' */',
'const modifyDayIfHoliday = (elem, date) => {',
'    const year  = date.getFullYear();',
'    const month = String(date.getMonth()).padStart(2, ''0'');',
'    const day   = String(date.getDate()).padStart(2, ''0'');',
'    const key   = `${year}-${month}-${day}`;',
'    if ( g_HOLIDAYS[key] !== undefined ) {',
'        elem.classList.add(''u-color-18-bg'');',
'    }',
'};'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \4F11\65E5\306E\30C7\30FC\30BF\3092HOLIDAYS\306B\30AD\30E3\30C3\30B7\30E5\3057\305F\5F8C\306B\3001'),
unistr(' * \65E5\4ED8\30BB\30EB\306B\795D\65E5\51E6\7406\3092\9069\7528\3059\308B\3002'),
' */',
'apex.server.process( "GET_HOLIDAYS", {}, ',
'    {',
'        success: (data) => {',
'            g_HOLIDAYS = data;',
unistr('            /* \8868\793A\3055\308C\3066\3044\308B\30AB\30EC\30F3\30C0\306B\8272\4ED8\3051\3092\3059\308B */'),
'            const calEl = document.getElementById("CALENDAR");',
'            const cells = calEl.querySelectorAll(''td[role="gridcell"]'');',
'            cells.forEach( (e) => {',
'                const date = e.getAttribute(''data-date'');',
'                modifyDayIfHoliday(e, new Date(date));',
'            });',
'        }',
'    }',
');'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123377588618885203)
,p_plug_name=>'Calendar'
,p_region_name=>'CALENDAR'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(123495273156104621)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'select ''TITLE'' as title, date''2001-01-01'' as start_date from dual where 1<>1'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ) {',
'    options.dayCellDidMount = (e) => {',
'        modifyDayIfHoliday(e.el, e.date);',
'    }',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_calendar_views', 'list:navigation',
  'display_column', 'TITLE',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'START_DATE')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123693085739105283)
,p_plug_name=>'FullCalendar Cell Highlight'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(123461932464104546)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(123377405762885202)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_HOLIDAYS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_holidays clob;',
'begin',
'    select ',
'        json_objectagg(to_char(holiday_date,''YYYY-MM-DD'') value holiday_name returning clob)',
'        into l_holidays',
'    from cal_national_holidays;',
'    htp.p(l_holidays);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>123377405762885202
);
wwv_flow_imp.component_end;
end;
/
