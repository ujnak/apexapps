prompt --workspace/remote_servers/ms_ai_foundry_local_custom_api_ep
begin
--   Manifest
--     REMOTE SERVER: MS AI Foundry Local Custom API EP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>104
,p_default_id_offset=>12834976290504986
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(12659199060781943)
,p_name=>'MS AI Foundry Local Custom API EP'
,p_static_id=>'MS_AI_FOUNDRY_LOCAL_CUSTOM_API_EP'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('MS_AI_FOUNDRY_LOCAL_CUSTOM_API_EP'),'#endpoint_url#')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('MS_AI_FOUNDRY_LOCAL_CUSTOM_API_EP'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('MS_AI_FOUNDRY_LOCAL_CUSTOM_API_EP'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('MS_AI_FOUNDRY_LOCAL_CUSTOM_API_EP'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('MS_AI_FOUNDRY_LOCAL_CUSTOM_API_EP'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('MS_AI_FOUNDRY_LOCAL_CUSTOM_API_EP'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('MS_AI_FOUNDRY_LOCAL_CUSTOM_API_EP'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('MS_AI_FOUNDRY_LOCAL_CUSTOM_API_EP'),'')
,p_configuration_procedure=>'config_remote_server'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure config_remote_server( ',
'    p_info    in  apex_plugin.t_remote_server_info',
'    ,p_config out apex_plugin.t_remote_server_config',
')',
'is',
'begin',
'    p_config.base_url := ''#endpoint_url#'';',
'    p_config.substitutions := apex_t_varchar2();',
'    apex_string.plist_put(p_config.substitutions, ''endpoint_url'', nvl(v(''P1_ENDPOINT_URL''),''http://host.containers.internal:5273/''));',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
