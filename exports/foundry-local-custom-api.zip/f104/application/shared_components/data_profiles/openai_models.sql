prompt --application/shared_components/data_profiles/openai_models
begin
--   Manifest
--     DATA PROFILE: OpenAI Models
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>104
,p_default_id_offset=>12834976290504986
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(25502879865313095)
,p_name=>'OpenAI Models'
,p_format=>'JSON'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(25503098150313097)
,p_data_profile_id=>wwv_flow_imp.id(25502879865313095)
,p_name=>'ATTRIBUTE_001'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'[0]'
);
wwv_flow_imp.component_end;
end;
/
