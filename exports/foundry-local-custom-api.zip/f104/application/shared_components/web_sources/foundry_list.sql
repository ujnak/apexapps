prompt --application/shared_components/web_sources/foundry_list
begin
--   Manifest
--     WEB SOURCE: Foundry List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>104
,p_default_id_offset=>12834976290504986
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(25501665726286936)
,p_name=>'Foundry List'
,p_static_id=>'foundry_list'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(25494311253286930)
,p_remote_server_id=>wwv_flow_imp.id(12659199060781943)
,p_url_path_prefix=>'/foundry/list'
,p_version_scn=>3553539
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(25501779636286941)
,p_web_src_module_id=>wwv_flow_imp.id(25501665726286936)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
