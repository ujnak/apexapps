prompt --application/shared_components/web_sources/openai_models
begin
--   Manifest
--     WEB SOURCE: OpenAI Models
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>104
,p_default_id_offset=>12834976290504986
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(25503472532313098)
,p_name=>'OpenAI Models'
,p_static_id=>'openai_models'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(25502879865313095)
,p_remote_server_id=>wwv_flow_imp.id(12659199060781943)
,p_url_path_prefix=>'openai/models'
,p_version_scn=>3553909
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(25503640088313099)
,p_web_src_module_id=>wwv_flow_imp.id(25503472532313098)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
