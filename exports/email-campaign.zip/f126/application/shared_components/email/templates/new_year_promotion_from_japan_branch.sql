prompt --application/shared_components/email/templates/new_year_promotion_from_japan_branch
begin
--   Manifest
--     REPORT LAYOUT: New Year Promotion from Japan Branch
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>126
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(37447579465096746)
,p_name=>'New Year Promotion from Japan Branch'
,p_static_id=>'NEW_YEAR_PROMOTION_FROM_JAPAN_BRANCH'
,p_version_number=>2
,p_subject=>unistr('\65B0\6625\30D7\30ED\30E2\30FC\30B7\30E7\30F3 - \6771\4EAC')
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<b>\3053\3093\306B\3061\306F #CUSTOMER#\3055\3093</b><br>'),
'<br>',
unistr('<b>\305F\3060\3044\307E\79C1\305F\3061\306E\30AA\30F3\30E9\30A4\30F3\30B7\30E7\30C3\30D7\304B\3089\306E\8CFC\5165\306B\9650\308A\3001\6700\5927<span style="color: red;">75%</span>\306E\5272\5F15\3092\5B9F\65BD\3057\3066\304A\308A\307E\3059:</b><br>'),
'<br>',
'<table width="100%">  ',
'  <tr>',
unistr('    <th align="left">\30BB\30FC\30EB\671F\9593\306E\958B\59CB</th>'),
'    <td>#START_DATE#</td>',
'  </tr>',
'  <tr>',
unistr('    <th align="left">\30BB\30FC\30EB\671F\9593\306E\7D42\4E86</th>'),
'    <td>#END_DATE#</td>',
'  </tr>  ',
'  <tr>',
unistr('    <th align="left" valign="top">\5BFE\8C61\5E97\8217</th>'),
'    <td>#LOCATION#</td>',
'  </tr>  ',
'  <tr>',
unistr('    <th align="left" valign="top">\3054\6848\5185</th>'),
'    <td>#NOTES#</td>',
'  </tr>',
'    <tr>',
unistr('    <th align="left" valign="top">\5BFE\8C61\88FD\54C1</th>'),
'    <td>#ITEMS!RAW#</td>',
'  </tr>',
'</table>',
'<br>',
unistr('<b>\6570\91CF\306B\9650\308A\304C\3053\3056\3044\307E\3059\306E\3067\3001\3054\8CFC\5165\306F\304A\65E9\3081\306B\3002</b><br>'),
'<br>'))
,p_html_header=>'<b style="font-size: 24px;">New Year Promotion!</b>'
,p_html_footer=>'<a href="#MY_APPLICATION_LINK#">This App created proudly using Oracle APEX</a>.'
,p_text_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Hello #CUSTOMER#,',
'This email is to remind you of an upcoming event you are associated with.',
'Sale Starts: #START_DATE#',
'Sale Ends:   #END_DATE#',
'Location:    #LOCATION#',
'Notes:       #NOTES#',
'Items:       #ITEMS!STRIPHTML#',
'View additional details at: #MY_APPLICATION_LINK#'))
);
wwv_flow_imp.component_end;
end;
/
