prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>256
,p_default_id_offset=>84739216453425816
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'JET Diagram Sankey'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code=>'var diagram;'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'requirejs.config({',
'   paths: {',
'        ''diagramLayouts'': "&APEX_PATH!RAW.#APP_FILES#layouts",',
'    }',
'});',
'',
'require(["require", "exports", "knockout", "diagramLayouts/DemoSankeyLayout", "ojs/ojbootstrap", "ojs/ojarraydataprovider", "ojs/ojattributegrouphandler", "ojs/ojknockout", "ojs/ojdiagram"], function (require, exports, ko, layout, ojbootstrap_1, Arra'
||'yDataProvider, ojattributegrouphandler_1) {',
'      "use strict";',
'      ',
'    class DiagramModel {',
'        /*',
unistr('         * Diagram\3067\8868\793A\3059\308B\30C7\30FC\30BF\3092\66F4\65B0\3059\308B\3002'),
'         */',
'        update(data) {',
unistr('            /* \30E2\30C7\30EB\3092\30EA\30BB\30C3\30C8\3059\308B */'),
'            this.nodesMap = {};',
'            this.nodes = [];',
'            this.links = [];',
'',
unistr('            /* \30CE\30FC\30C9\3068\30EA\30F3\30AF\306E\30C7\30FC\30BF\3092\66F4\65B0\3059\308B\3002 */'),
'            this.data = data;',
'            ',
'            for (let i = 0; i < this.data.nodes.length; i++) {',
'                this.nodesMap[this.data.nodes[i][''id'']] = this.data.nodes[i];',
'            }',
'            for (let i = 0; i < this.data.links.length; i++) {',
'                this.links.push(this.createLink(this.data.links[i]));',
'            }',
'            for (let nodeId in this.nodesMap) {',
'                this.nodes.push(this.createNode(this.nodesMap[nodeId]));',
'            }',
'',
'            this.nodeDataProvider(new ArrayDataProvider(this.nodes, {',
'                keyAttributes: "id",',
'            }));',
'            this.linkDataProvider(new ArrayDataProvider(this.links, {',
'                keyAttributes: "id",',
'            }));',
'        }',
'',
'        createLink(o) {',
'            this.updateNodesWeight(o);',
'            const source = o.source, target = o.target;',
'            return {',
'                id: o.id,',
'                startNode: source,',
'                endNode: target,',
'                width: o.items * 3,',
'                shortDesc: this.nodesMap[source][''category''] === ''award''',
'                    ? o.items + '' '' + source + '' medals for '' + this.nodesMap[target][''name'']',
'                    : this.nodesMap[source][''name''] +',
'                        '' won '' +',
'                        o[''items''] +',
'                        '' medals in '' +',
'                        this.nodesMap[target][''name'']',
'            };',
'        }',
'',
'        constructor() {',
'            this.nodes = [];',
'            this.links = [];',
'            this.colorHandler = new ojattributegrouphandler_1.ColorAttributeGroupHandler();',
'            this.nodesMap = {};',
'            ',
'            this.updateNodesWeight = (link) => {',
'                const s = link.source, t = link.target;',
'                if (s === ''Gold'' || s === ''Silver'' || s === ''Bronze'')',
'                    this.nodesMap[s][''weight''] = this.nodesMap[s][''weight'']',
'                        ? this.nodesMap[s][''weight''] + link[''items'']',
'                        : link[''items''];',
'                this.nodesMap[t][''weight''] = this.nodesMap[t][''weight'']',
'                    ? this.nodesMap[t][''weight''] + link.items',
'                    : link.items;',
'            };',
'',
'            // this.data = JSON.parse(jsonData);',
'',
'            this.createNode = (o) => {',
'                const id = o[''id''];',
'                const weight = this.nodesMap[id][''weight''];',
'                return {',
'                    id: id,',
'                    label: id,',
'                    shortDesc: o[''name''],',
'                    icon: { color: this.colorHandler.getValue(id), height: weight * 3 }',
'                };',
'            };',
'',
'            this.layoutFunc = layout.layout;',
'',
'            this.nodeDataProvider = ko.observableArray();',
'            this.linkDataProvider = ko.observableArray();',
'            /*',
'            this.nodeDataProvider = new ArrayDataProvider(this.nodes, {',
'                keyAttributes: ''id''',
'            });',
'            this.linkDataProvider = new ArrayDataProvider(this.links, {',
'                keyAttributes: ''id''',
'            });',
'            */',
'',
'            this.styleDefaults = {',
'                nodeDefaults: {',
'                    labelStyle: { fontSize: ''30px'', fontWeight: ''bold'' },',
'                    icon: { width: 70, shape: ''rectangle'' }',
'                },',
'                linkDefaults: { svgStyle: { strokeOpacity: 0.5, vectorEffect: ''none'' } }',
'            };',
'',
'            /*',
'            for (let i = 0; i < this.data.nodes.length; i++) {',
'                this.nodesMap[this.data.nodes[i][''id'']] = this.data.nodes[i];',
'            }',
'            for (let i = 0; i < this.data.links.length; i++) {',
'                this.links.push(this.createLink(this.data.links[i]));',
'            }',
'            for (let nodeId in this.nodesMap) {',
'                this.nodes.push(this.createNode(this.nodesMap[nodeId]));',
'            }',
'            */',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        diagram = new DiagramModel();',
'        ko.applyBindings(diagram, document.getElementById(''diagram-container''));',
unistr('        /* \30DA\30FC\30B8\30FB\30ED\30FC\30C9\6642\306E\8868\793A */'),
'        apex.actions.invoke("update-diagram");',
'    });',
'});',
'',
'/*',
unistr(' * Diagram\3092\66F4\65B0\3059\308B\3002'),
' */',
'apex.actions.add([',
'    {',
'        name: "update-diagram",',
'        action: () => {',
'            apex.server.process ( "GET_DATA", {},',
'                {',
'                    success: (data) =>  {',
'                        // console.log(data);',
'                        diagram.update(data);',
'                    }',
'                }',
'            );',
'        }',
'    }',
']);'))
,p_css_file_urls=>'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.demo-diagram-sankeylayout-height-style {',
'    height: 37.5rem;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230907215748'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(162682447890145446)
,p_plug_name=>'Nodes'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(163135239453262711)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'DG_SANKEY_NODES'
,p_include_rowid_column=>true
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Nodes'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162682782985145449)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162682837592145450)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>40
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162682956445145451)
,p_name=>'CATEGORY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATEGORY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Category'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162683125222145453)
,p_name=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROWID'
,p_data_type=>'ROWID'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162683271632145454)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162683380043145455)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(162682691663145448)
,p_internal_uid=>77943475209719632
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>300
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(163345744210306648)
,p_interactive_grid_id=>wwv_flow_imp.id(162682691663145448)
,p_static_id=>'786066'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(163346011483306649)
,p_report_id=>wwv_flow_imp.id(163345744210306648)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163346491757306651)
,p_view_id=>wwv_flow_imp.id(163346011483306649)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(162682782985145449)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163347351967306653)
,p_view_id=>wwv_flow_imp.id(163346011483306649)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(162682837592145450)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163348278733306656)
,p_view_id=>wwv_flow_imp.id(163346011483306649)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(162682956445145451)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163349153180306659)
,p_view_id=>wwv_flow_imp.id(163346011483306649)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(162683125222145453)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163350097535306661)
,p_view_id=>wwv_flow_imp.id(163346011483306649)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(162683271632145454)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(162683536532145457)
,p_plug_name=>'Links'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(163135239453262711)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'DG_SANKEY_LINKS'
,p_include_rowid_column=>true
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Links'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162683793004145459)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162683911933145460)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162684002978145461)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>4
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162684222626145464)
,p_name=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROWID'
,p_data_type=>'ROWID'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162684404723145465)
,p_name=>'SOURCE_NODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SOURCE_NODE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Source Node'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>40
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(162684425735145466)
,p_name=>'TARGET_NODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TARGET_NODE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Target Node'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>40
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(163351567992308117)
,p_name=>'ITEMS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEMS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Items'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(162683698820145458)
,p_internal_uid=>77944482366719642
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>300
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(163357209540308953)
,p_interactive_grid_id=>wwv_flow_imp.id(162683698820145458)
,p_static_id=>'786180'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(163357318173308953)
,p_report_id=>wwv_flow_imp.id(163357209540308953)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163358245305308957)
,p_view_id=>wwv_flow_imp.id(163357318173308953)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(162683911933145460)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163359166057308960)
,p_view_id=>wwv_flow_imp.id(163357318173308953)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(162684002978145461)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163360108935308963)
,p_view_id=>wwv_flow_imp.id(163357318173308953)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(162684222626145464)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163360940290308966)
,p_view_id=>wwv_flow_imp.id(163357318173308953)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(162684404723145465)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163361869476308969)
,p_view_id=>wwv_flow_imp.id(163357318173308953)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(162684425735145466)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(163362795328308971)
,p_view_id=>wwv_flow_imp.id(163357318173308953)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(163351567992308117)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(163352355909308125)
,p_plug_name=>'Diagram'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(163079859454262684)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="diagram-container">',
'    <oj-diagram',
'        id="diagram1"',
'        node-data="[[nodeDataProvider]]"',
'        link-data="[[linkDataProvider]]"',
'        layout="[[layoutFunc]]"',
'        style-defaults="[[styleDefaults]]"',
'        class="demo-diagram-sankeylayout-height-style">',
'    </oj-diagram>',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(163351650939308118)
,p_button_sequence=>10
,p_button_name=>'INIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(163218275790262758)
,p_button_image_alt=>'Init'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(163352158897308123)
,p_name=>'onSave Nodes'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(162682447890145446)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(163352248218308124)
,p_event_id=>wwv_flow_imp.id(163352158897308123)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(162683536532145457)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(163352609171308127)
,p_event_id=>wwv_flow_imp.id(163352158897308123)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.invoke("update-diagram");        '
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(163352632107308128)
,p_name=>'onSave Links'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(162683536532145457)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(163352814100308129)
,p_event_id=>wwv_flow_imp.id(163352632107308128)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.invoke("update-diagram");'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(163351718160308119)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>unistr('\521D\671F\5316')
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(163351650939308118)
,p_internal_uid=>78612501706882303
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(162683420310145456)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(162682447890145446)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Nodes - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>77944203856719640
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(163352071627308122)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(162683536532145457)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Links - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>78612855173882306
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(163352485959308126)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response_json json_object_t;',
'    l_nodes json_array_t;',
'    l_links json_array_t;',
'begin',
'    /* create node array */',
'    l_nodes := json_array_t();',
'    for r in (',
'        select json_object(',
'            key ''id'' value id',
'            ,key ''name'' value name',
'            ,key ''category'' value category',
'        ) as jo from dg_sankey_nodes',
'    )',
'    loop',
'        l_nodes.append(json_object_t(r.jo));',
'    end loop;',
'    /* create link array */',
'    l_links := json_array_t();',
'    for r in (',
'        select json_object(',
'            key ''id'' value id',
'            ,key ''source'' value source_node',
'            ,key ''target'' value target_node',
'            ,key ''items'' value items',
'        ) as jo from dg_sankey_links',
'    )',
'    loop',
'        l_links.append(json_object_t(r.jo));',
'    end loop;',
'    /* create reponse */',
'    l_response_json := json_object_t();',
'    l_response_json.put(''nodes'', l_nodes);',
'    l_response_json.put(''links'', l_links);',
'    htp.p(l_response_json.to_clob());',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>78613269505882310
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(163351892576308120)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(163351718160308119)
,p_process_type=>'NATIVE_DATA_LOADING'
,p_process_name=>unistr('\30CE\30FC\30C9')
,p_attribute_01=>wwv_flow_imp.id(163340211618267938)
,p_attribute_02=>'SQL_QUERY'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    apex_web_service.make_rest_request_b(',
'        p_url => :G_DATA_SOURCE_URL',
'        ,p_http_method => ''GET''',
'    ) as blob_content',
'from dual;'))
,p_internal_uid=>78612676122882304
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(163352007085308121)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(163351718160308119)
,p_process_type=>'NATIVE_DATA_LOADING'
,p_process_name=>unistr('\30EA\30F3\30AF')
,p_attribute_01=>wwv_flow_imp.id(163342639443280199)
,p_attribute_02=>'SQL_QUERY'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    apex_web_service.make_rest_request_b(',
'        p_url => :G_DATA_SOURCE_URL',
'        ,p_http_method => ''GET''',
'    ) as blob_content',
'from dual;'))
,p_internal_uid=>78612790631882305
);
wwv_flow_imp.component_end;
end;
/
