prompt --application/shared_components/data_loads/graph_nodes
begin
--   Manifest
--     DATA LOAD: Graph Nodes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>256
,p_default_id_offset=>84739216453425816
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(163339625911267937)
,p_name=>'Graph Nodes'
,p_format=>'JSON'
,p_encoding=>'utf-8'
,p_has_header_row=>false
,p_row_selector=>'nodes'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(163339971009267938)
,p_data_profile_id=>wwv_flow_imp.id(163339625911267937)
,p_name=>'ID'
,p_sequence=>10
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>160
,p_selector=>'id'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(163340571936271341)
,p_data_profile_id=>wwv_flow_imp.id(163339625911267937)
,p_name=>'NAME'
,p_sequence=>20
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>40
,p_has_time_zone=>true
,p_selector=>'name'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(163340851152273018)
,p_data_profile_id=>wwv_flow_imp.id(163339625911267937)
,p_name=>'CATEGORY'
,p_sequence=>30
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>20
,p_has_time_zone=>true
,p_selector=>'category'
);
wwv_flow_imp_shared.create_load_table(
 p_id=>wwv_flow_imp.id(163340211618267938)
,p_name=>'Graph Nodes'
,p_static_id=>'GRAPH_NODES'
,p_target_type=>'TABLE'
,p_table_name=>'DG_SANKEY_NODES'
,p_data_profile_id=>wwv_flow_imp.id(163339625911267937)
,p_loading_method=>'REPLACE'
,p_commit_interval=>200
,p_error_handling=>'ABORT'
,p_skip_validation=>'N'
);
wwv_flow_imp.component_end;
end;
/
