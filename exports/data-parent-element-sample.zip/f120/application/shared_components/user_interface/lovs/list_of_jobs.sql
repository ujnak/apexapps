prompt --application/shared_components/user_interface/lovs/list_of_jobs
begin
--   Manifest
--     LIST_OF_JOBS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(36481573940010985)
,p_lov_name=>'LIST_OF_JOBS'
,p_lov_query=>'select distinct job from emp'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'JOB'
,p_display_column_name=>'JOB'
,p_default_sort_column_name=>'JOB'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
