prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 329
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>329
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>329
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(59347926109492681)
,p_name=>'CUSTOM_HELP_R1_HELP'
,p_message_language=>'ja'
,p_message_text=>unistr('<b>\30D8\30EB\30D7</b>\672C\65871')
,p_is_js_message=>true
,p_version_scn=>40542364221577
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(59347768673490978)
,p_name=>'CUSTOM_HELP_R1_TITLE'
,p_message_language=>'ja'
,p_message_text=>unistr('\30EA\30FC\30B8\30E7\30F31\306E\30D8\30EB\30D7')
,p_is_js_message=>true
,p_version_scn=>40542355575421
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(59348368896496327)
,p_name=>'CUSTOM_HELP_R2_HELP'
,p_message_language=>'ja'
,p_message_text=>unistr('\30D8\30EB\30D7\672C\65872')
,p_is_js_message=>true
,p_version_scn=>40542355627152
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(59348110371494626)
,p_name=>'CUSTOM_HELP_R2_TITLE'
,p_message_language=>'ja'
,p_message_text=>unistr('\30EA\30FC\30B8\30E7\30F32\306E\30D8\30EB\30D7')
,p_is_js_message=>true
,p_version_scn=>40542355595983
);
wwv_flow_imp.component_end;
end;
/
