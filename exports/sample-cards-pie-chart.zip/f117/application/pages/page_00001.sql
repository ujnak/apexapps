prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(22145832698888486)
,p_name=>unistr('\90FD\9053\5E9C\770C\5225\5E74\9F62\FF13\533A\5206\4EBA\53E3')
,p_alias=>'HOME'
,p_step_title=>unistr('\90FD\9053\5E9C\770C\5225\5E74\9F62\FF13\533A\5206\4EBA\53E3')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>'require(["ojs/ojchart"], function() {});'
,p_css_file_urls=>'#JET_CSS_DIRECTORY#alta/oj-alta-notag-min.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20220831071623'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22154997353888512)
,p_plug_name=>unistr('\90FD\9053\5E9C\770C\5225\5E74\9F62\FF13\533A\5206\4EBA\53E3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(21994727321888405)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'CCB_POPULATIONS'
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{"orderBys":[{"key":"PREFECTURE_NAME","expr":"\"ID\" asc"},{"key":"TOTAL","expr":"\"TOTAL\" asc"}],"itemName":"P1_ORDER_BY"}'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(22155424170888513)
,p_region_id=>wwv_flow_imp.id(22154997353888512)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'PREFECTURE_NAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>unistr('<b>\7DCF\6570:</b> &TOTAL.')
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>true
,p_media_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<oj-chart',
'id="pieChart"',
'type="pie"',
'animation-on-data-change="auto"',
unistr('series=''[{"name": "0\FF5E14\6B73", "items": [&AGE00TO14.]},{"name": "15\FF5E64", "items": [&AGE15TO64.]},{"name": "65\6B73\4EE5\4E0A", "items": [&AGE65.]}]'''),
'>',
'</oj-chart>'))
,p_media_display_position=>'BODY'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22156420827888516)
,p_plug_name=>unistr('\90FD\9053\5E9C\770C\5225\5E74\9F62\FF13\533A\5206\4EBA\53E3')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(22020251219888417)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22155915397888515)
,p_name=>'P1_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(22154997353888512)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_item_default=>'PREFECTURE_NAME'
,p_prompt=>unistr('\4E26\66FF\3048\57FA\6E96')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Prefecture Name;PREFECTURE_NAME,Total;TOTAL'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(22118428936888466)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
