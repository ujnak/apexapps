prompt --application/deployment/install/install_sample
begin
--   Manifest
--     INSTALL: INSTALL-sample
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(22161757196056185)
,p_install_id=>wwv_flow_imp.id(22160062082047825)
,p_name=>'sample'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
unistr('    --CCB_POPULATIONS: 48/10000 \884C\304C\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\307E\3057\305F, APEX$DATA$PKG/CCB_POPULATIONS$456960'),
'    apex_data_install.load_supporting_object_data(p_table_name => ''CCB_POPULATIONS'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
