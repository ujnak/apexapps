prompt --application/shared_components/navigation/breadcrumbs/ブレッドクラム
begin
--   Manifest
--     MENU: ブレッドクラム
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>117
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(21950973499888379)
,p_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21951156845888380)
,p_short_name=>unistr('\90FD\9053\5E9C\770C\5225\5E74\9F62\FF13\533A\5206\4EBA\53E3')
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp.component_end;
end;
/
