begin
    --CCB_POPULATIONS: 48/10000 行がエクスポートされました, APEX$DATA$PKG/CCB_POPULATIONS$456960
    apex_data_install.load_supporting_object_data(p_table_name => 'CCB_POPULATIONS', p_delete_after_install => true );
end;