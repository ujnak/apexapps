prompt --application/shared_components/user_interface/lovs/ir_reports
begin
--   Manifest
--     IR_REPORTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>101
,p_default_id_offset=>25759520019477867
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(25619779940382961)
,p_lov_name=>'IR_REPORTS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    report_id',
'    ,report_name',
'    ,report_type',
'from apex_application_page_ir_rpt',
'where application_id = :APP_ID and page_id = :APP_PAGE_ID',
'and (',
'    status = ''PUBLIC''',
'    or /* status = ''PRIVATE'' and */',
'    report_type = ''PRIVATE'' and application_user = :APP_USER',
')'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'REPORT_ID'
,p_display_column_name=>'REPORT_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>8430007
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(25620109917384160)
,p_query_column_name=>'REPORT_ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(25620543171384160)
,p_query_column_name=>'REPORT_NAME'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(25620961162384160)
,p_query_column_name=>'REPORT_TYPE'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
