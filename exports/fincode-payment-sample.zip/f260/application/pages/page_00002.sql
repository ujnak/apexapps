prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>260
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Pay'
,p_alias=>'PAY'
,p_page_mode=>'MODAL'
,p_step_title=>'Pay'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://js.test.fincode.jp/v1/fincode.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const fincode = Fincode(''&FINCODE_PUBLIC_KEY.'');',
'fincode.setIdempotentKey(crypto.randomUUID());',
'const ui = fincode.ui({layout: "vertical"});',
'ui.create("payments",{layout: "vertical"});',
'',
'document.addEventListener(''DOMContentLoaded'', async function () {',
'    ui.mount("fincode",''400'');',
'});'))
,p_step_template=>wwv_flow_imp.id(69975822754774852)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230824014323'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(69652621314333218)
,p_plug_name=>'fincode-form'
,p_region_name=>'fincode-form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(70013169653774886)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(69652713503333219)
,p_plug_name=>'fincode'
,p_region_name=>'fincode'
,p_parent_plug_id=>wwv_flow_imp.id(69652621314333218)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(70013169653774886)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69652860236333220)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(69652621314333218)
,p_button_name=>'SUBMIT'
,p_button_static_id=>'submit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(70151532314774973)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\652F\6255\3044')
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69652939838333221)
,p_name=>'P2_ACCESS_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(69652621314333218)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(69653804088333230)
,p_name=>'P2_ORDER_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(69652621314333218)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(69653921724333231)
,p_name=>'onClick SUBMIT'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(69652860236333220)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(69654010734333232)
,p_event_id=>wwv_flow_imp.id(69653921724333231)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ui.getFormData().then(',
'    (card) => {',
'        const transaction = {',
'            id: apex.items.P2_ORDER_ID.value,',
'            pay_type: "Card",',
'            access_id: apex.items.P2_ACCESS_ID.value,',
'            method: card.method,',
'            card_no: card.cardNo,',
'            expire: card.expire,',
'            holder_name: card.holderName,',
'            security_code: card.CVC',
'        };',
'        fincode.payments(',
'            transaction,',
'            function(status, response) {',
'                if (status === 200) {',
'                    console.log("payments succeed", response);',
unistr('                    // \30C9\30ED\30EF\30FC\3092\9589\3058\308B\3002'),
'                    apex.navigation.dialog.close(true);',
'                } else {',
'                    console.log("payments failed", response);',
'                }',
'            },',
'            function() {',
'                console.log("ERROR");',
'            }',
'        );',
'    }',
');'))
);
wwv_flow_imp.component_end;
end;
/
