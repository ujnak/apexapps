prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>297
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'OpenAI Files'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231108074250'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(128675800674638446)
,p_plug_name=>'OpenAI Files'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(128467548927638119)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(128692658984975802)
,p_name=>'OpenAI Files'
,p_template=>wwv_flow_imp.id(128416798545638083)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(128692009531971788)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(128509991431638150)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(128692725839975803)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(128692896795975804)
,p_query_column_id=>2
,p_column_alias=>'BYTES'
,p_column_display_sequence=>20
,p_column_heading=>'Bytes'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(128692924218975805)
,p_query_column_id=>3
,p_column_alias=>'OBJECT'
,p_column_display_sequence=>30
,p_column_heading=>'Object'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(128693002890975806)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>40
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(128693162945975807)
,p_query_column_id=>5
,p_column_alias=>'PURPOSE'
,p_column_display_sequence=>50
,p_column_heading=>'Purpose'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(128693263964975808)
,p_query_column_id=>6
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>60
,p_column_heading=>'Filename'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(128693317726975809)
,p_query_column_id=>7
,p_column_alias=>'CREATED_AT'
,p_column_display_sequence=>70
,p_column_heading=>'Created At'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(128693412602975810)
,p_query_column_id=>8
,p_column_alias=>'STATUS_DETAILS'
,p_column_display_sequence=>80
,p_column_heading=>'Status Details'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(128694077776975816)
,p_query_column_id=>9
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>90
,p_column_heading=>'&nbsp;'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:1:&SESSION.:DOWNLOAD:&DEBUG.::P1_ID:#ID#'
,p_column_linktext=>'Download'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(128694180095975817)
,p_query_column_id=>10
,p_column_alias=>'DERIVED$02'
,p_column_display_sequence=>100
,p_column_heading=>'&nbsp;'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:1:&SESSION.:DELETE:&DEBUG.::P1_ID:#ID#'
,p_column_linktext=>'Delete'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125020332143106838)
,p_button_sequence=>20
,p_button_name=>'UPLOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(128556521530638196)
,p_button_image_alt=>'Upload'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125020212446106837)
,p_name=>'P1_FILE'
,p_item_sequence=>10
,p_prompt=>'File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(128554096181638191)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125020601356106841)
,p_name=>'P1_RESPONSE'
,p_item_sequence=>40
,p_prompt=>'Response'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(128554096181638191)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128693876876975814)
,p_name=>'P1_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(125020508141106840)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Upload file'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_file clob;',
'begin',
'    for r in (',
'        select * from apex_application_temp_files',
'        where name = :P1_FILE',
'    )',
'    loop',
'        utl_openai_files.upload_file(',
'            p_filename => r.filename',
'            ,p_content_type => r.mime_type',
'            ,p_file_content => r.blob_content',
'            ,p_file => l_file',
'        );',
'        :P1_RESPONSE := l_file;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(125020332143106838)
,p_internal_uid=>125020508141106840
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(128693710063975813)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Retrieve file'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_filename     varchar2(400);',
'    l_file         clob;',
'    l_file_content blob;',
'    l_file_json    json_object_t;',
'    l_download apex_data_export.t_export;',
'begin',
'    utl_openai_files.retrieve_file(',
'        p_file_id => :P1_ID',
'        ,p_file    => l_file',
'        ,p_file_content => l_file_content',
'    );',
'    l_file_json := json_object_t(l_file);',
'    l_filename := l_file_json.get_string(''filename'');',
'    /* download */',
'    l_download.file_name := l_filename;',
'    l_download.as_clob := FALSE;',
'    l_download.content_blob := l_file_content;',
'    apex_data_export.download( p_export => l_download );',
'    apex_application.stop_apex_engine;    ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'DOWNLOAD'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>128693710063975813
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(128693970225975815)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete file'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_filename     varchar2(400);',
'    l_file         clob;',
'begin',
'    utl_openai_files.delete_file(',
'        p_file_id => :P1_ID',
'        ,p_file    => l_file',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>128693970225975815
);
wwv_flow_imp.component_end;
end;
/
