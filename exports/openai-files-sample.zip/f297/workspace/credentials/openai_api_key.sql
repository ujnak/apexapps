prompt --workspace/credentials/openai_api_key
begin
--   Manifest
--     CREDENTIAL: OpenAI API Key
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>297
,p_default_id_offset=>13694485959642109
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(59103911961121450)
,p_name=>'OpenAI API Key'
,p_static_id=>'OPENAI_API_KEY'
,p_authentication_type=>'HTTP_HEADER'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
