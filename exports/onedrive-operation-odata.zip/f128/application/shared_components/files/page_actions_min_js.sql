prompt --application/shared_components/files/page_actions_min_js
begin
--   Manifest
--     APP STATIC FILES: 128
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>128
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '636F6E737420434F50595F42595F425554544F4E3D7B6E616D653A22636F70792D62792D627574746F6E222C616374696F6E3A66756E6374696F6E28742C6E2C65297B6C6574206F3D646F63756D656E742E676574456C656D656E744279496428652E69';
wwv_flow_imp.g_varchar2_table(2) := '64292E74657874436F6E74656E743B6E6176696761746F722E636C6970626F6172642E777269746554657874286F297D7D3B';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(34072120201223385)
,p_file_name=>'page-actions.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
