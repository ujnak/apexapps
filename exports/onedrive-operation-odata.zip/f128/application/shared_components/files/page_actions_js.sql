prompt --application/shared_components/files/page_actions_js
begin
--   Manifest
--     APP STATIC FILES: 128
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>128
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '636F6E737420434F50595F42595F425554544F4E203D0A7B0A202020206E616D653A2022636F70792D62792D627574746F6E222C0A20202020616374696F6E3A2066756E6374696F6E28206576656E742C20656C656D656E742C20617267732029207B0A';
wwv_flow_imp.g_varchar2_table(2) := '20202020202020206C65742074657874203D20646F63756D656E742E676574456C656D656E744279496428617267732E6964292E74657874436F6E74656E743B0A20202020202020202F2F20E382AFE383AAE38383E38397E3839CE383BCE38389E381AB';
wwv_flow_imp.g_varchar2_table(3) := 'E382B3E38394E383BCE380820A20202020202020206E6176696761746F722E636C6970626F6172642E7772697465546578742874657874293B0A202020207D0A7D3B';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(34070084925168231)
,p_file_name=>'page-actions.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
