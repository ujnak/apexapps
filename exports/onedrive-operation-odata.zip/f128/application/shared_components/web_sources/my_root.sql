prompt --application/shared_components/web_sources/my_root
begin
--   Manifest
--     WEB SOURCE: My Root
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>128
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(33337913361703310)
,p_name=>'My Root'
,p_static_id=>'My_Root'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(33336881684703309)
,p_remote_server_id=>wwv_flow_imp.id(32930591610624372)
,p_url_path_prefix=>'drive/root/children'
,p_auth_remote_server_id=>wwv_flow_imp.id(32950416322761515)
,p_auth_url_path_prefix=>'common/oauth2/v2.0/token'
,p_credential_id=>wwv_flow_imp.id(33099546120120319)
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(33338120486703311)
,p_web_src_module_id=>wwv_flow_imp.id(33337913361703310)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
