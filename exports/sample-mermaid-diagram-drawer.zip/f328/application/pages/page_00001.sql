prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>328
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Mermaid Diagram Drawer'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid#MIN#.js'
,p_javascript_code_onload=>'mermaid.initialize({ startOnLoad: false });'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240215024417'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55099184533640933)
,p_plug_name=>'Mermaid Diagram'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(58562743253305328)
,p_plug_display_sequence=>30
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob clob;',
'begin',
'    l_clob := ''<pre id="DIAGRAM">'' || :P1_DIAGRAM_DEFINITION || ''</pre>'';',
'    return l_clob;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_DIAGRAM_DEFINITION'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59026646083305776)
,p_plug_name=>'Sample Mermaid Diagram Drawer'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(58596061717305348)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(55099237820640934)
,p_button_sequence=>20
,p_button_name=>'RENDER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(58702559723305415)
,p_button_image_alt=>'Render'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55099529765640937)
,p_name=>'P1_DIAGRAM_DEFINITION'
,p_item_sequence=>10
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'graph LR;',
'    A--> B & C & D;',
'    B--> A & E;',
'    C--> A & E;',
'    D--> A & E;',
'    E--> B & C & D;'))
,p_prompt=>'Diagram Definition'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(58700034864305413)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(55099307082640935)
,p_name=>'onClick Render'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(55099237820640934)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55099690423640938)
,p_event_id=>wwv_flow_imp.id(55099307082640935)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(55099184533640933)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(55099779928640939)
,p_name=>'Draw Diagram by Mermaid'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(55099184533640933)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55099485575640936)
,p_event_id=>wwv_flow_imp.id(55099779928640939)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mermaid.run({',
'  nodes: [document.getElementById("DIAGRAM")],',
'});'))
);
wwv_flow_imp.component_end;
end;
/
