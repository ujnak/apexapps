prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>219
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Clothes'
,p_alias=>'HOME'
,p_step_title=>unistr('JSON\5217\3092\542B\3080\5BFE\8A71\30B0\30EA\30C3\30C9')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>\3053\306E\5BFE\8A71\30B0\30EA\30C3\30C9\5185\3067\30C7\30FC\30BF\3092\76F4\63A5\633F\5165\3001\66F4\65B0\304A\3088\3073\524A\9664\3067\304D\307E\3059\3002<br>'),
unistr('  \300C\884C\306E\8FFD\52A0\300D\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\65B0\3057\3044\884C\3092\633F\5165\3067\304D\307E\3059\3002<br>'),
unistr('  \30BB\30EB\5185\3092\30C0\30D6\30EB\30AF\30EA\30C3\30AF\3059\308B\304B\3001<strong>\300C\7DE8\96C6\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\30B9\30D7\30EC\30C3\30C9\30B7\30FC\30C8\3067\30C7\30FC\30BF\3092\7DE8\96C6\3059\308B\5834\5408\3068\540C\3058\3088\3046\306B\30C7\30FC\30BF\5024\3092\66F4\65B0\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30EC\30DD\30FC\30C8\306E\4E00\756A\4E0A\306B\3042\308B\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC(<span class="fa fa-bars" aria-hidden="true"></span>)\3092\4F7F\7528\3057\3066\3001\9078\629E\3057\305F\884C\3092\8907\88FD\3001\524A\9664\3001\30EA\30D5\30EC\30C3\30B7\30E5\307E\305F\306F\56DE\5FA9\3057\307E\3059\3002<br>'),
unistr('  \500B\3005\306E\884C\306E\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\3092\4F7F\7528\3057\3066\3001\5358\4E00\884C\30D3\30E5\30FC\306B\30A2\30AF\30BB\30B9\3057\305F\308A\3001\65B0\3057\3044\884C\3092\8FFD\52A0\3057\305F\308A\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30C7\30FC\30BF\3092\898B\3064\3051\308B\306B\306F\3001\691C\7D22\30C0\30A4\30A2\30ED\30B0\306B\691C\7D22\6587\5B57\5217\3092\5165\529B\3059\308B\304B\3001\5217\30D8\30C3\30C0\30FC\3092\30AF\30EA\30C3\30AF\3057\3066\623B\3055\308C\308B\30EC\30B3\30FC\30C9\3092\5236\9650\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30A2\30AF\30B7\30E7\30F3\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\591A\304F\306E\6A5F\80FD\3092\5B9F\884C\3067\304D\307E\3059\3002\3053\308C\306B\306F\3001\8868\793A\5217\307E\305F\306F\975E\8868\793A\5217\306E\9078\629E\3068\305D\306E\8868\793A\9806\5E8F\306B\52A0\3048\3001\591A\304F\306E\30C7\30FC\30BF\304A\3088\3073\66F8\5F0F\8A2D\5B9A\6A5F\80FD\304C\542B\307E\308C\307E\3059\3002\30C1\30E3\30FC\30C8\30FB\30AA\30D7\30B7\30E7\30F3\3092\4F7F\7528\3057\3066\3001\30C7\30FC\30BF\306E\8FFD\52A0\30D3\30E5\30FC\3092\5B9A\7FA9\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\72EC\81EA\306E\30AB\30B9\30BF\30DE\30A4\30BA\5185\5BB9\3092\4FDD\5B58\3059\308B\5834\5408\3001\30EC\30DD\30FC\30C8\3092\9078\629E\3059\308B\304B\3001\300C\30C0\30A6\30F3\30ED\30FC\30C9\300D\3092\30AF\30EA\30C3\30AF\3057\3066\30C7\30FC\30BF\3092\30A2\30F3\30ED\30FC\30C9\3057\307E\3059\3002<p>'),
'',
unistr('<p>\8FFD\52A0\60C5\5831\3092\5165\624B\3059\308B\306B\306F\3001\300C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\306E\4E00\756A\4E0B\306E\300C\30D8\30EB\30D7\300D\3092\30AF\30EA\30C3\30AF\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30EA\30BB\30C3\30C8\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\5BFE\8A71\30B0\30EA\30C3\30C9\3092\30C7\30D5\30A9\30EB\30C8\8A2D\5B9A\306B\623B\3059\3053\3068\304C\3067\304D\307E\3059\3002</p>')))
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230615005235'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24018094199792318)
,p_plug_name=>'Jig Clothes'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(23797559940792114)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    c.id',
'    ,name',
'    -- ,features',
'    ,jc.color',
'    ,jc."SIZE"',
'    ,price',
'from',
'    jig_clothes c',
'    ,json_table(c.features, ''$''',
'        columns(',
'            color varchar2(16) path ''$.color''',
'            ,"SIZE" varchar2(6)  path ''$.size''',
'        )',
'    ) as jc;'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Clothes'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22864842102766538)
,p_name=>'COLOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COLOR'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Color'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>16
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22865016055766540)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>true
,p_max_length=>320
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22865109854766541)
,p_name=>'SIZE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SIZE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Size'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>6
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24019375046792326)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24019803805792327)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>unistr('\30A2\30AF\30B7\30E7\30F3')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24020864725792330)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'ID'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(24022881706792332)
,p_name=>'PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRICE'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Price'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(24018542659792320)
,p_internal_uid=>24018542659792320
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(24018989213792322)
,p_interactive_grid_id=>wwv_flow_imp.id(24018542659792320)
,p_static_id=>'240190'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(24019176050792323)
,p_report_id=>wwv_flow_imp.id(24018989213792322)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(24020295031792328)
,p_view_id=>wwv_flow_imp.id(24019176050792323)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(24019803805792327)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(24021268107792330)
,p_view_id=>wwv_flow_imp.id(24019176050792323)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(24020864725792330)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(24023246427792332)
,p_view_id=>wwv_flow_imp.id(24019176050792323)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(24022881706792332)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(24029536574831417)
,p_view_id=>wwv_flow_imp.id(24019176050792323)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(22864842102766538)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(24033092513861001)
,p_view_id=>wwv_flow_imp.id(24019176050792323)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(22865016055766540)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(24035623765885056)
,p_view_id=>wwv_flow_imp.id(24019176050792323)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(22865109854766541)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24024344668792334)
,p_plug_name=>unistr('JSON\5217\3092\542B\3080\5BFE\8A71\30B0\30EA\30C3\30C9')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(23809455633792123)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(24023856559792333)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(24018094199792318)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Clothes - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    case :APEX$ROW_STATUS',
'    when ''C'' then',
'        insert into jig_clothes(',
'            name',
'            ,features',
'            ,price',
'        )',
'        values',
'        (',
'            :NAME',
'            ,json_object(',
'                key ''color'' value :COLOR',
'                ,key ''size'' value :SIZE',
'            )',
'            ,:PRICE',
'        )',
'        returning id into :ID;',
'    when ''U'' then',
'        update jig_clothes set',
'            name = :NAME',
'            ,features = json_object(',
'                key ''color'' value :COLOR',
'                ,key ''size'' value :SIZE',
'            )',
'            ,price = :PRICE',
'        where id = :ID;',
'    when ''D'' then',
'        delete from jig_clothes where id = :ID;',
'    end case;',
'end;'))
,p_attribute_05=>'Y'
,p_attribute_06=>'PLSQL_CODE'
,p_attribute_07=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    r jig_clothes%rowtype;',
'begin',
'    select * into r from jig_clothes where id = :ID for update nowait;',
'end;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>24023856559792333
);
wwv_flow_imp.component_end;
end;
/
