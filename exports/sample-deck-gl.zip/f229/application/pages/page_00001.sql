prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>229
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'deck.gl'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://unpkg.com/deck.gl@latest/dist.min.js',
'https://unpkg.com/maplibre-gl@3.0.0/dist/maplibre-gl.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const {DeckGL, ScatterplotLayer} = deck;',
'',
'/* ',
unistr(' * mydeckgl\304C\5730\56F3\3068Deck.gl\304C\63CF\3044\305F\30EA\30FC\30B8\30E7\30F3\306E\4E21\65B9\3092'),
unistr(' * \5C0F\306B\6301\3064\30EA\30FC\30B8\30E7\30F3\3002'),
' */',
'const mydeck = document.getElementById("mydeckgl");',
'/*',
unistr(' * Deck.gl\304C\63CF\753B\3059\308B\30AD\30E3\30F3\30D0\30B9\8981\7D20\3092\4F5C\6210\3059\308B\3002'),
' */',
'const canvasEl = document.createElement(''canvas'');',
'',
'/*',
unistr(' * canvas\8981\7D20\306E\6307\5B9A\3092\8FFD\52A0\3057\3066\3044\308B\3002'),
unistr(' * controller\306Ftrue\306B\3057\3066\3044\308B\304C\3001\30EA\30FC\30B8\30E7\30F3\3068\3057\3066\7D44\307F\8FBC\3080\3068'),
unistr(' * \6A5F\80FD\3057\306A\3044\3002'),
' */',
'new DeckGL({',
'    canvas: canvasEl,',
'    mapStyle: ''https://basemaps.cartocdn.com/gl/positron-nolabels-gl-style/style.json'',',
'    initialViewState: {',
'        longitude: -122.45,',
'        latitude: 37.8,',
'        zoom: 15',
'    },',
'    controller: true,',
'    layers: [',
'        new ScatterplotLayer({',
'            data: [',
'                {position: [-122.45, 37.8], color: [255, 0, 0], radius: 100}',
'            ],',
'            getPosition: d => d.position,',
'            getFillColor: d => d.color,',
'            getRadius: d => d.radius',
'',
'        })',
'    ]',
'});',
'',
'/*',
unistr(' * MapLibre\304C\63CF\753B\3057\305F\5730\56F3\306E\8981\7D20\3092mydeckgl\306E\5B50\8981\7D20\306B\79FB\52D5\3059\308B\3002 '),
' */',
'const mapEl = document.querySelector(''.maplibregl-map'');',
'mydeck.appendChild(mapEl);',
'/*',
unistr(' * Deck.gl\304C\63CF\753B\3057\305F\30AD\30E3\30F3\30D0\30B9\3092\3001\30EA\30FC\30B8\30E7\30F3\306E'),
unistr(' * \5DE6\4E0A\306B\30D1\30C7\30A3\30F3\30B0\FF10\3067\914D\7F6E\3059\308B\3002'),
' */',
'canvasEl.style.top  = 0;',
'canvasEl.style.left = 0;',
'mydeck.appendChild(canvasEl);'))
,p_css_file_urls=>'https://unpkg.com/maplibre-gl@3.0.0/dist/maplibre-gl.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(122423076925663147)
,p_plug_name=>'deck.gl'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(123132530699020011)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>'<div id="mydeckgl" class="h640"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
