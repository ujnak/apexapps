prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>229
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>unistr('\5168\753B\9762')
,p_alias=>unistr('\5168\753B\9762')
,p_step_title=>unistr('\5168\753B\9762')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://unpkg.com/deck.gl@latest/dist.min.js',
'https://unpkg.com/maplibre-gl@3.0.0/dist/maplibre-gl.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const {DeckGL, ScatterplotLayer} = deck;',
'',
'new DeckGL({',
'    mapStyle: ''https://basemaps.cartocdn.com/gl/positron-nolabels-gl-style/style.json'',',
'    initialViewState: {',
'        longitude: -122.45,',
'        latitude: 37.8,',
'        zoom: 15',
'    },',
'    controller: true,',
'    layers: [',
'        new ScatterplotLayer({',
'            data: [',
'                {position: [-122.45, 37.8], color: [255, 0, 0], radius: 100}',
'            ],',
'            getPosition: d => d.position,',
'            getFillColor: d => d.color,',
'            getRadius: d => d.radius',
'        })',
'    ]',
'});'))
,p_css_file_urls=>'https://unpkg.com/maplibre-gl@3.0.0/dist/maplibre-gl.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp.component_end;
end;
/
