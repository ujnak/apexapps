prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>7601775501100353
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'data-action for page item'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#actions#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21041335182687332)
,p_plug_name=>'Controls'
,p_region_name=>'CONTROLS'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21793406623436859)
,p_plug_name=>'data-action for page item'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21041637767687335)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(21041335182687332)
,p_button_name=>'SUBMIT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Submit'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="SUBMIT"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21040965132687328)
,p_name=>'P1_INPUT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(21041335182687332)
,p_prompt=>'Input'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'data-action="SET_VALUE"'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21041411588687333)
,p_name=>'P1_MESSAGE'
,p_item_sequence=>10
,p_prompt=>'Message'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21041950391687338)
,p_name=>'P1_SELECT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(21041335182687332)
,p_prompt=>'Select'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:D1;R1,D2;R2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_attributes=>'data-action="SELECT"'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21042038315687339)
,p_name=>'P1_POPUP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(21041335182687332)
,p_prompt=>'Popup LOV'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'STATIC:D1;R1,D2;R2'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_tag_attributes=>'data-action="SELECT"'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21042114866687340)
,p_name=>'P1_SELECT_ONE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(21041335182687332)
,p_prompt=>'Select One'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_lov=>'STATIC:D1;R1,D2;R2'
,p_cSize=>30
,p_tag_attributes=>'data-action="SELECT"'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21042257657687341)
,p_name=>'P1_SELECT_MANY'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(21041335182687332)
,p_prompt=>'Select Many'
,p_display_as=>'NATIVE_SELECT_MANY'
,p_lov=>'STATIC:D1;R1,D2;R2'
,p_cSize=>30
,p_tag_attributes=>'data-action="SELECT"'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0',
  'use_defaults', 'Y')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21042535562687344)
,p_name=>'P1_RADIO_GROUP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(21041335182687332)
,p_prompt=>'Radio Group'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:D1;R1,D2;R2'
,p_tag_attributes=>'data-action="SELECT_GROUP"'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21042691126687345)
,p_name=>'P1_CHECK_BOX_GROUP'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(21041335182687332)
,p_prompt=>'Check Box Group'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:D1;R1,D2;R2'
,p_tag_attributes=>'data-action="SELECT_GROUP"'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21042773200687346)
,p_name=>'P1_DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(21041335182687332)
,p_prompt=>'Date'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_tag_attributes=>'data-action="SET_VALUE"'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
