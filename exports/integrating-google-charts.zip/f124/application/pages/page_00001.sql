prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>124
,p_default_id_offset=>33964520520201767
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Integrating Google Charts'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://www.gstatic.com/charts/loader.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'google.charts.load(''current'', {packages: [''bar'']});',
'google.charts.setOnLoadCallback(drawChart);',
'',
'function drawChart() {',
'    const groups = [ "ENAME", "SAL" ];',
'    const value  = JSON.parse(apex.items.P1_VALUE.value);',
'    value.unshift(groups);',
'',
'    var data = new google.visualization.arrayToDataTable(',
'        value',
'    );',
'    ',
'    var options = {',
'        series: {',
'            0: { color: ''#309fdb'' }',
'        },',
'        legend: { position: ''none'' },',
'        bars: ''horizontal'',',
'        axes: {',
'            x: {',
'                all: {',
'                    format: {',
'                        pattern: ''decimal''',
'                    }',
'                }',
'            },',
'            y: {',
'                all: {',
'                    label: ''''',
'                }',
'            }',
'        }',
'    };',
'',
'    var chart = new google.charts.Bar(document.getElementById(''myChart''));',
'    chart.draw(data, options);',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(132695751391745669)
,p_plug_name=>'Google Charts'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(133409117279875012)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<div id="myChart"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133607135703875713)
,p_plug_name=>'Integrating Google Charts'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(133385850138874963)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(132695324761745665)
,p_name=>'P1_VALUE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(132695494953745667)
,p_computation_sequence=>10
,p_computation_item=>'P1_VALUE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        json_array( ename, sal )',
'        order by empno',
'    )',
'from emp where deptno = 10'))
);
wwv_flow_imp.component_end;
end;
/
