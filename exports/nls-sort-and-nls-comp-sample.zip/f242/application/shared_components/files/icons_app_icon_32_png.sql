prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 242
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>242
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000E14944415458476334987FFB3FC30002C651078C86C068080C9910D0E5FFC7A023C482B3C4D87AF931C3DB3FAC0CAC02622495';
wwv_flow_imp.g_varchar2_table(2) := '2A449703918A4C0CF14652380DCFDD7C132C77EDD557921C415507E8CA8B335C7EF892244750CD01EB6FBC63D877FB3538142EDEBACFC0A5A043545450CD01C8B62D3CF78C61F9FD7FB477C0C5175F19F425B8312CA28B03409680002861C2D80652FC60';
wwv_flow_imp.g_varchar2_table(3) := '07D1D40130CB6096836874319A3A009CC870043D2C2E68EE0042A98B6E0E184D84B0A2793411A2274A9A244242D531B223169D7F41748D48745D4028EB912B3FEA80D110180D81010F01007B81DD41328035550000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(52760094210902315)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
