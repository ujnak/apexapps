prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>320
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\3053\306E\52D5\7269\306F\4F55\FF1F')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#t_Footer {',
'    display: none;',
'}',
'',
'.button-submit {',
'    font-size: 2em;',
'    width: 10em;',
'    height: 3em;',
'    position: fixed;',
'    bottom: 5%;',
'    left: 50%;',
'    transform: translateX(-50%);',
'}'))
,p_step_template=>wwv_flow_imp.id(34099599601230468)
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240125094141'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30306172391748832)
,p_plug_name=>'Request'
,p_region_css_classes=>'u-flex u-justify-content-center'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(34126252791230489)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30306269558748833)
,p_plug_name=>'Response'
,p_region_css_classes=>'u-flex u-justify-content-center'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(34126252791230489)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30306366597748834)
,p_button_sequence=>30
,p_button_name=>'SUBMIT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(34264610444230589)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\554F\3044\5408\308F\305B\308B')
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'button-submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30306454232748835)
,p_name=>'P1_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30306269558748833)
,p_prompt=>'Response'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(34261833298230583)
,p_item_template_options=>'#DEFAULT#:margin-left-lg:margin-right-lg'
,p_is_persistent=>'N'
,p_attribute_01=>'MARKDOWN'
,p_attribute_04=>'180'
,p_attribute_25=>'TINYMCE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30306597256748836)
,p_name=>'P1_IMAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30306172391748832)
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(34261833298230583)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'DROPZONE_ICON'
,p_attribute_15=>'1000'
,p_attribute_18=>'Y'
,p_attribute_19=>'1:1'
,p_attribute_22=>'ENVIRONMENT'
,p_attribute_23=>'XL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30306648906748837)
,p_name=>'onChage Clear'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_IMAGE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30306798455748838)
,p_event_id=>wwv_flow_imp.id(30306648906748837)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_RESPONSE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30307164407748842)
,p_event_id=>wwv_flow_imp.id(30306648906748837)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(30306366597748834)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30307291071748843)
,p_name=>'onClilck Call Gemini'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(30306366597748834)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30307330342748844)
,p_event_id=>wwv_flow_imp.id(30307291071748843)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_RESPONSE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// \30B9\30D4\30CA\30FC\3092\8868\793A\3057\3001\753B\9762\64CD\4F5C\3092\30D6\30ED\30C3\30AF\3059\308B\3002'),
'let spinner = apex.widget.waitPopup();',
unistr('// P1_IMAGE\306B\8A2D\5B9A\3055\308C\3066\3044\308B\30D5\30A1\30A4\30EB\3092\53D6\308A\51FA\3059\3002'),
'let fileReader = new FileReader();',
'let file = document.getElementById("P1_IMAGE").files[0];',
'',
unistr('// Gemini Pro Vision\3092ORDS\306EREST API\7D4C\7531\3067\547C\3073\51FA\3059\3002'),
'const req = new XMLHttpRequest();',
'req.open("POST", "&G_REQUEST_URL.", true);',
unistr('// \73FE\884C\306EAPEX\306F\753B\50CF\306E\30AF\30ED\3063\30D4\30F3\30B0\3092\884C\3046\3068\3001\30D5\30A9\30FC\30DE\30C3\30C8\304CPNG\306B\5909\308F\308B\3002'),
unistr('// \3053\306E\52D5\4F5C\306F\5C06\6765\306E\30D0\30FC\30B8\30E7\30F3\3067\5909\66F4\3055\308C\308B\53EF\80FD\6027\304C\3042\308B\3002'),
'req.setRequestHeader(''content-type'',''image/png'');',
unistr('// APEX\306E\30BB\30C3\30B7\30E7\30F3\3067ORDS API\3092\8A8D\8A3C\3059\308B\305F\3081\306BApex-Session\30D8\30C3\30C0\30FC\3092\8A2D\5B9A\3057\3066\3044\308B\3002'),
'const authHeader = apex.env.APP_ID.concat('','',apex.env.APP_SESSION);',
'req.setRequestHeader(''Apex-Session'', authHeader);',
'req.onload = (event) => {',
'    // console.log(req.response);',
unistr('    // \5F71\97FF\3092\53D7\3051\308B\8981\7D20\306BREST API\306E\30EC\30B9\30DD\30F3\30B9\3092\8A2D\5B9A\3059\308B\3002'),
'    let elem = this.affectedElements.toArray()[0];',
'    apex.item(elem).setValue(req.response);',
unistr('    // \30B9\30D4\30CA\30FC\306E\505C\6B62\304A\3088\3073\753B\9762\64CD\4F5C\306E\30D6\30ED\30C3\30AF\3092\89E3\9664\3059\308B'),
'    spinner.remove();',
'};',
unistr('// \8981\6C42\306E\9001\4FE1\3002'),
'req.send(file);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30307464447748845)
,p_event_id=>wwv_flow_imp.id(30307291071748843)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(30306366597748834)
);
wwv_flow_imp.component_end;
end;
/
