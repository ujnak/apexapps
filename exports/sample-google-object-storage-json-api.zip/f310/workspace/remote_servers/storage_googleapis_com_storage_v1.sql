prompt --workspace/remote_servers/storage_googleapis_com_storage_v1
begin
--   Manifest
--     REMOTE SERVER: storage-googleapis-com-storage-v1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>310
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(26701734161033871)
,p_name=>'storage-googleapis-com-storage-v1'
,p_static_id=>'storage_googleapis_com_storage_v1'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('storage_googleapis_com_storage_v1'),'https://storage.googleapis.com/storage/v1/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('storage_googleapis_com_storage_v1'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('storage_googleapis_com_storage_v1'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('storage_googleapis_com_storage_v1'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('storage_googleapis_com_storage_v1'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
