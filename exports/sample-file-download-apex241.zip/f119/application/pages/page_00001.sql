prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>119
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\65B0\3057\3044\30C0\30A6\30F3\30ED\30FC\30C9')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17152018518705996)
,p_plug_name=>unistr('\65B0\3057\3044\30C0\30A6\30F3\30ED\30FC\30C9')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(16920928115705369)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17154995931782205)
,p_plug_name=>'Files'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16889056270705305)
,p_plug_display_sequence=>50
,p_query_type=>'TABLE'
,p_query_table=>'EBMJ_TEMP_FILES'
,p_include_rowid_column=>false
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_row_selection_type=>'MULTIPLE'
,p_current_selection_page_item=>'P1_SELECTED_FILES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_IMAGE', '{"source":"BLOB_COLUMN","blobColumn":"CONTENT","filenameColumn":"CONTENT_FILENAME","mimeTypeColumn":"CONTENT_MIMETYPE","lastUpdatedColumn":"CONTENT_LASTUPD"}',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_SIZE', 't-Avatar--xl',
  'AVATAR_TYPE', 'image',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'TITLE', '&CONTENT_FILENAME.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17155016980782206)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17155148149782207)
,p_name=>'CONTENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CONTENT'
,p_data_type=>'BLOB'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17155284257782208)
,p_name=>'CONTENT_FILENAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CONTENT_FILENAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17155310217782209)
,p_name=>'CONTENT_MIMETYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CONTENT_MIMETYPE'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17155437925782210)
,p_name=>'CONTENT_CHARSET'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CONTENT_CHARSET'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17155532002782211)
,p_name=>'CONTENT_LASTUPD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CONTENT_LASTUPD'
,p_data_type=>'DATE'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17155693799782212)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(16890477291705308)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17155736155782213)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17155693799782212)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(17027886144705597)
,p_button_image_alt=>'Delete'
,p_show_processing=>'Y'
,p_confirm_message=>unistr('\672C\5F53\306B\524A\9664\3057\307E\3059\304B\FF1F')
,p_confirm_style=>'danger'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17154630923782202)
,p_button_sequence=>20
,p_button_name=>'UPLOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(17027886144705597)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload'
,p_show_processing=>'Y'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17155969052782215)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17155693799782212)
,p_button_name=>'DOWNLOAD_MULTI'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(17027886144705597)
,p_button_image_alt=>'Download (Multi)'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17156441653782220)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17155693799782212)
,p_button_name=>'VIEW_SINGLE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(17027886144705597)
,p_button_image_alt=>'View (Single)'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17156968187782225)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(17155693799782212)
,p_button_name=>'DOWNLOAD_PROCESS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(17027886144705597)
,p_button_image_alt=>'Download (Process)'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17157454804782230)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(17155693799782212)
,p_button_name=>'VIEW_PROCESS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(17027886144705597)
,p_button_image_alt=>'View (Process)'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(17157029279782226)
,p_branch_name=>'Call Download'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.:DOWNLOAD:&DEBUG.::P1_SELECTED_FILES:\&P1_SELECTED_FILES.\&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(17156968187782225)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(17157578675782231)
,p_branch_name=>'Call View'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.:VIEW:&DEBUG.::P1_SELECTED_FILES:\&P1_SELECTED_FILES.\&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(17157454804782230)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16111730085903749)
,p_name=>'P1_UPLOAD_FILES'
,p_item_sequence=>10
,p_prompt=>'Upload Files'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(17025392654705591)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'Y'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17154814984782204)
,p_name=>'P1_SELECTED_FILES'
,p_item_sequence=>30
,p_prompt=>'Selected Files'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(17025392654705591)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17156256088782218)
,p_name=>'onClick DOWNLOAD_MULTI'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(17155969052782215)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17156317601782219)
,p_event_id=>wwv_flow_imp.id(17156256088782218)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DOWNLOAD'
,p_attribute_01=>'Y'
,p_attribute_02=>'download_&SYSDATE_YYYYMMDD..zip'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select content, content_filename from ebmj_temp_files ',
'where id in (select column_value from apex_string.split(:P1_SELECTED_FILES, '':''))'))
,p_attribute_06=>'P1_SELECTED_FILES'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17156545094782221)
,p_name=>'onClick VIEW_SINGLE'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(17156441653782220)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17156617489782222)
,p_event_id=>wwv_flow_imp.id(17156545094782221)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DOWNLOAD'
,p_attribute_01=>'N'
,p_attribute_03=>'INLINE'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select content, content_filename from ebmj_temp_files ',
'where id in (select column_value from apex_string.split(:P1_SELECTED_FILES, '':''))',
'fetch first 1 rows only'))
,p_attribute_06=>'P1_SELECTED_FILES'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17154511566782201)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Store Uploaded Files'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into ebmj_temp_files(content_filename, content_mimetype, content, content_lastupd)',
'select filename, mime_type, blob_content, created_on',
'from apex_application_temp_files',
'where name in (select column_value from apex_string.split(:P1_UPLOAD_FILES, '':''));'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(17154630923782202)
,p_internal_uid=>17154511566782201
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17155898781782214)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Files'
,p_process_sql_clob=>'delete from ebmj_temp_files where id in (select column_value from apex_string.split(:P1_SELECTED_FILES, '':''));'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(17155736155782213)
,p_internal_uid=>17155898781782214
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17156877214782224)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_DOWNLOAD'
,p_process_name=>'Download Files'
,p_attribute_01=>'Y'
,p_attribute_02=>'download_&SYSDATE_YYYYMMDD..zip'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select content, content_filename from ebmj_temp_files ',
'where id in (select column_value from apex_string.split(:P1_SELECTED_FILES, '':''))'))
,p_process_when=>'DOWNLOAD'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>17156877214782224
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17157316912782229)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_DOWNLOAD'
,p_process_name=>'View File'
,p_attribute_01=>'N'
,p_attribute_03=>'INLINE'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select content, content_filename from ebmj_temp_files ',
'where id in (select column_value from apex_string.split(:P1_SELECTED_FILES, '':''))',
'fetch first 1 rows only'))
,p_process_when=>'VIEW'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>17157316912782229
);
wwv_flow_imp.component_end;
end;
/
