prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>106
,p_default_id_offset=>84737093043345260
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Timeline'
,p_alias=>'HOME'
,p_step_title=>'JET Timeline'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code=>'var timeline;'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'require(["require", "exports", "knockout", "ojs/ojbootstrap", "ojs/ojarraydataprovider", "ojs/ojknockout", "ojs/ojtimeline", "ojs/ojformlayout", "ojs/ojbutton"], function (require, exports, ko, ojbootstrap_1, ArrayDataProvider) {',
'    "use strict";',
'      ',
'    class SeriesModel {',
'        /*',
unistr('         * Timeline\3067\8868\793A\3059\308B\30C7\30FC\30BF\3092\66F4\65B0\3059\308B\3002'),
'         */',
'        update(data) {',
'            this.dataProvider(new ArrayDataProvider(data, {',
'                keyAttributes: "id",',
'            }));',
'        }',
'',
'        constructor() {',
'            /*',
unistr('             * this.dataProvider\306Fknockout\306EobservableArray\306B\5909\66F4\3057\3001'),
unistr('             * \30C7\30FC\30BF\306F\30B3\30F3\30B9\30C8\30E9\30AF\30BF\306E\5916\304B\3089\8A2D\5B9A\3059\308B\3002'),
'             */',
'            this.dataProvider = ko.observableArray();',
'            /*',
'            this.dataProvider = new ArrayDataProvider(JSON.parse(data), {',
'                keyAttributes: ''id''',
'            });',
'            */',
'            /*',
unistr('             * overviewValue, orientationValue\306F\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\3067\8A2D\5B9A\3059\308B\3002'),
'             */',
'            this.overviewValue = ko.observable(apex.items.P1_OVERVIEW.value);',
'            this.orientationValue = ko.observable(apex.items.P1_ORIENTATION.value);',
unistr('            /* \5909\66F4\306A\3057 */'),
'            this.currentDateString = ''Feb 1, 2010'';',
'            this.currentDate = new Date(this.currentDateString).toISOString();',
'            this.referenceObjects = [',
'                {',
'                    value: this.currentDate',
'                }',
'            ];',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        timeline = new SeriesModel();',
'        ko.applyBindings(timeline, document.getElementById(''timelineContainer''));',
unistr('        /* \30DA\30FC\30B8\30FB\30ED\30FC\30C9\6642\306E\8868\793A */'),
'        apex.actions.invoke("update-timeline");     ',
'    });',
'});',
'',
'/*',
unistr(' * Timeline\3092\66F4\65B0\3059\308B\3002'),
' */',
'apex.actions.add([',
'    {',
'        name: "update-timeline",',
'        action: () => {',
'            apex.server.process ( "GET_DATA", {},',
'                {',
'                    success: (data) =>  {',
'                        // console.log(data);',
'                        timeline.update(data);',
'                    }',
'                }',
'            );',
'        }',
'    }',
']);'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#JET_CSS_DIRECTORY#alta/oj-alta-notag-min.css',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.demo-timeline {',
'    width: 100%;',
'    height: 32rem;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>\3053\306E\5BFE\8A71\30B0\30EA\30C3\30C9\5185\3067\30C7\30FC\30BF\3092\76F4\63A5\633F\5165\3001\66F4\65B0\304A\3088\3073\524A\9664\3067\304D\307E\3059\3002<br>'),
unistr('  \300C\884C\306E\8FFD\52A0\300D\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\65B0\3057\3044\884C\3092\633F\5165\3067\304D\307E\3059\3002<br>'),
unistr('  \30BB\30EB\5185\3092\30C0\30D6\30EB\30AF\30EA\30C3\30AF\3059\308B\304B\3001<strong>\300C\7DE8\96C6\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\30B9\30D7\30EC\30C3\30C9\30B7\30FC\30C8\3067\30C7\30FC\30BF\3092\7DE8\96C6\3059\308B\5834\5408\3068\540C\3058\3088\3046\306B\30C7\30FC\30BF\5024\3092\66F4\65B0\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30EC\30DD\30FC\30C8\306E\4E00\756A\4E0A\306B\3042\308B\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC(<span class="fa fa-bars" aria-hidden="true"></span>)\3092\4F7F\7528\3057\3066\3001\9078\629E\3057\305F\884C\3092\8907\88FD\3001\524A\9664\3001\30EA\30D5\30EC\30C3\30B7\30E5\307E\305F\306F\56DE\5FA9\3057\307E\3059\3002<br>'),
unistr('  \500B\3005\306E\884C\306E\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\3092\4F7F\7528\3057\3066\3001\5358\4E00\884C\30D3\30E5\30FC\306B\30A2\30AF\30BB\30B9\3057\305F\308A\3001\65B0\3057\3044\884C\3092\8FFD\52A0\3057\305F\308A\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30C7\30FC\30BF\3092\898B\3064\3051\308B\306B\306F\3001\691C\7D22\30C0\30A4\30A2\30ED\30B0\306B\691C\7D22\6587\5B57\5217\3092\5165\529B\3059\308B\304B\3001\5217\30D8\30C3\30C0\30FC\3092\30AF\30EA\30C3\30AF\3057\3066\623B\3055\308C\308B\30EC\30B3\30FC\30C9\3092\5236\9650\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30A2\30AF\30B7\30E7\30F3\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\591A\304F\306E\6A5F\80FD\3092\5B9F\884C\3067\304D\307E\3059\3002\3053\308C\306B\306F\3001\8868\793A\5217\307E\305F\306F\975E\8868\793A\5217\306E\9078\629E\3068\305D\306E\8868\793A\9806\5E8F\306B\52A0\3048\3001\591A\304F\306E\30C7\30FC\30BF\304A\3088\3073\66F8\5F0F\8A2D\5B9A\6A5F\80FD\304C\542B\307E\308C\307E\3059\3002\30C1\30E3\30FC\30C8\30FB\30AA\30D7\30B7\30E7\30F3\3092\4F7F\7528\3057\3066\3001\30C7\30FC\30BF\306E\8FFD\52A0\30D3\30E5\30FC\3092\5B9A\7FA9\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\72EC\81EA\306E\30AB\30B9\30BF\30DE\30A4\30BA\5185\5BB9\3092\4FDD\5B58\3059\308B\5834\5408\3001\30EC\30DD\30FC\30C8\3092\9078\629E\3059\308B\304B\3001\300C\30C0\30A6\30F3\30ED\30FC\30C9\300D\3092\30AF\30EA\30C3\30AF\3057\3066\30C7\30FC\30BF\3092\30A2\30F3\30ED\30FC\30C9\3057\307E\3059\3002<p>'),
'',
unistr('<p>\8FFD\52A0\60C5\5831\3092\5165\624B\3059\308B\306B\306F\3001\300C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\306E\4E00\756A\4E0B\306E\300C\30D8\30EB\30D7\300D\3092\30AF\30EA\30C3\30AF\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30EA\30BB\30C3\30C8\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\5BFE\8A71\30B0\30EA\30C3\30C9\3092\30C7\30D5\30A9\30EB\30C8\8A2D\5B9A\306B\623B\3059\3053\3068\304C\3067\304D\307E\3059\3002</p>')))
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230905123502'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(158576254973605295)
,p_plug_name=>'Timeline'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(160615135508287788)
,p_plug_display_sequence=>50
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="timelineContainer">',
'    <oj-timeline',
'        id="tline"',
'        :aria-label="[[''Overview Timeline Demo. Current date is '' + currentDateString]]"',
'        minor-axis.scale="weeks"',
'        minor-axis.zoom-order=''["months", "weeks", "days"]''',
'        major-axis.scale="quarters"',
'        start=''[[new Date("Jan 1, 2010").toISOString()]]''',
'        end=''[[new Date("Dec 31, 2010").toISOString()]]''',
'        selection-mode="single"',
'        orientation="[[orientationValue]]"',
'        overview.rendered="[[ko.toJS(overviewValue)]]"',
'        reference-objects="[[referenceObjects]]"',
'        selection=''["e4"]''',
'        data="[[dataProvider]]"',
'        class="demo-timeline">',
'        <template slot="seriesTemplate" data-oj-as="series">',
'            <oj-timeline-series label="[[series.id]]" empty-text="No Data."></oj-timeline-series>',
'        </template>',
'        <template slot="itemTemplate" data-oj-as="item">',
'            <oj-timeline-item',
'                series-id="[[item.data.series]]"',
'                start="[[item.data.begin]]"',
'                label="[[item.data.title]]"',
'                description="[[item.data.description]]">',
'            </oj-timeline-item>',
'        </template>',
'    </oj-timeline>',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(158576895909605302)
,p_plug_name=>'Options To Control The Timeline Below'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(160680328512287826)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160873384283287979)
,p_plug_name=>'Tmln Events'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(160670572197287821)
,p_plug_display_sequence=>60
,p_query_type=>'TABLE'
,p_query_table=>'TMLN_EVENTS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Timeline'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160874683950287981)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160875102439287982)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>unistr('\30A2\30AF\30B7\30E7\30F3')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160876148167287983)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'ID'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160877132634287984)
,p_name=>'EID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Eid'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>8
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160878123802287985)
,p_name=>'TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TITLE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Title'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>80
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160879106880287986)
,p_name=>'BEGIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BEGIN'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Begin'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160880184956287987)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>200
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160881104142287988)
,p_name=>'SERIES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SERIES'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Series'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>80
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(160873873335287980)
,p_internal_uid=>76136780291942720
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(160874238687287980)
,p_interactive_grid_id=>wwv_flow_imp.id(160873873335287980)
,p_static_id=>'761372'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(160874401837287981)
,p_report_id=>wwv_flow_imp.id(160874238687287980)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160875592693287982)
,p_view_id=>wwv_flow_imp.id(160874401837287981)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(160875102439287982)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160876536828287983)
,p_view_id=>wwv_flow_imp.id(160874401837287981)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(160876148167287983)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160877576452287984)
,p_view_id=>wwv_flow_imp.id(160874401837287981)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(160877132634287984)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160878531946287985)
,p_view_id=>wwv_flow_imp.id(160874401837287981)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(160878123802287985)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160879568512287986)
,p_view_id=>wwv_flow_imp.id(160874401837287981)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(160879106880287986)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160880559914287987)
,p_view_id=>wwv_flow_imp.id(160874401837287981)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(160880184956287987)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160881560017287988)
,p_view_id=>wwv_flow_imp.id(160874401837287981)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(160881104142287988)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(158575665354605289)
,p_button_sequence=>10
,p_button_name=>'INIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(160753539411287871)
,p_button_image_alt=>'Init'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(158576334418605296)
,p_name=>'P1_ORIENTATION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(158576895909605302)
,p_item_default=>'horizontal'
,p_prompt=>'Timeline Orientation'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(160751070291287869)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'horizontal'
,p_attribute_03=>'Horizontal'
,p_attribute_04=>'vertical'
,p_attribute_05=>'Vertical'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(158576476866605297)
,p_name=>'P1_OVERVIEW'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(158576895909605302)
,p_item_default=>'on'
,p_prompt=>'Timeline Overview'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(160751070291287869)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'on'
,p_attribute_03=>'Enabled'
,p_attribute_04=>'off'
,p_attribute_05=>'Disabled'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(158576541083605298)
,p_name=>'onChange Orientation'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_ORIENTATION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(158576639803605299)
,p_event_id=>wwv_flow_imp.id(158576541083605298)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'timeline.orientationValue($v(this.triggeringElement));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(158576778435605300)
,p_name=>'onChage Overview'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_OVERVIEW'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(158576842961605301)
,p_event_id=>wwv_flow_imp.id(158576778435605300)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'timeline.overviewValue($v(this.triggeringElement));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(158577010694605303)
,p_name=>'onSave Timeline'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(160873384283287979)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(158577105858605304)
,p_event_id=>wwv_flow_imp.id(158577010694605303)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.invoke("update-timeline"); '
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(158576054364605293)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>unistr('\30C7\30FC\30BF\30FB\30ED\30FC\30C9')
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(158575665354605289)
,p_internal_uid=>73838961321260033
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(160882148094287989)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(160873384283287979)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Timeline - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>76145055050942729
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(158576162046605294)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'begin',
'    select json_arrayagg(',
'        json_object(',
'            key ''id'' value eid',
'            ,key ''title'' value title',
'            ,key ''begin'' value begin',
'            ,key ''description'' value description',
'            ,key ''series'' value series',
'        )',
'    ) into l_response',
'    from tmln_events;',
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>73839069003260034
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(158575811749605291)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(158576054364605293)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\82F1\8A9E')
,p_process_sql_clob=>'execute immediate ''alter session set nls_date_language = ''''AMERICAN'''''';'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>73838718706260031
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(158577207849605305)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(158576054364605293)
,p_process_type=>'NATIVE_DATA_LOADING'
,p_process_name=>unistr('\521D\671F\5316')
,p_attribute_01=>wwv_flow_imp.id(160890004482295201)
,p_attribute_02=>'SQL_QUERY'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    apex_web_service.make_rest_request_b(',
'        p_url => ''https://www.oracle.com/webfolder/technetwork/jet/cookbook/dataVisualizations/timeline/basicTimeline/seriesOneData.json''',
'        ,p_http_method => ''GET''',
'    ) as blob_content',
'from dual;'))
,p_internal_uid=>73840114806260045
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(158575924251605292)
,p_process_sequence=>50
,p_parent_process_id=>wwv_flow_imp.id(158576054364605293)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\65E5\672C\8A9E')
,p_process_sql_clob=>'execute immediate ''alter session set nls_date_language = ''''JAPANESE'''''';'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>73838831208260032
);
wwv_flow_imp.component_end;
end;
/
