prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>164
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'APEX_EXEC 2'
,p_alias=>'APEX-EXEC-2'
,p_step_title=>'APEX_EXEC 2'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(95136276632940573)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(47191099754363640)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(47075322191363366)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(47253845315363797)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(95108185198862293)
,p_name=>'P6_OUTPUT'
,p_item_sequence=>10
,p_prompt=>'Output'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>40
,p_tag_attributes=>'style="font-family: monospace;"'
,p_field_template=>wwv_flow_imp.id(47249759539363779)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47572111146154548)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generate Output'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_context   apex_exec.t_context;',
'    l_output clob;',
'    l_line   varchar2(32767);',
'    procedure lob_write(',
'        p_clob in out nocopy clob,',
'        p_line varchar2',
'    )',
'    as',
'        l_length number;',
'        l_line   varchar2(32767);',
'    begin',
'        l_length := length(p_line);',
'        dbms_lob.writeAppend(',
'            lob_loc => p_clob',
'            ,amount => l_length',
'            ,buffer => p_line',
'        );',
'        dbms_lob.writeAppend(',
'            lob_loc => p_clob',
'            ,amount => 1',
'            ,buffer => apex_application.LF',
'        );',
'    end lob_write;',
'begin',
'    dbms_lob.createTemporary(',
'        lob_loc => l_output',
'        ,cache => false',
'        ,dur => DBMS_LOB.CALL',
'    );',
'',
'    l_context := apex_exec.open_rest_source_query(',
'        p_static_id => ''purchase_orders'',',
'        p_max_rows => 10 );',
'',
'    while apex_exec.next_row( l_context ) LOOP',
'        lob_write(l_output,',
'            ''| PO: '' || apex_exec.get_varchar2( l_context, ''DATA_REFERENCE'' ) );',
'        ',
'        apex_exec.open_array( l_context, ''DATA_LINEITEMS'' );',
'        while apex_exec.next_array_row( l_context ) loop',
'            lob_write(l_output,',
'                ''|       #''',
'                || apex_exec.get_varchar2( l_context, ''ITEMNUMBER'' )',
'                || '': ''',
'                || apex_exec.get_varchar2( l_context, ''QUANTITY'' )',
'                || '' x ''',
'                || apex_exec.get_varchar2( l_context, ''PART_DESCRIPTION'' )',
'                || '', ''',
'                || to_char( apex_exec.get_number( l_context, ''PART_UNITPRICE'' ), ''FM99990D00'' )',
'            );',
'        end loop;',
'        dbms_output.put_line( null );',
'        apex_exec.close_array( l_context );',
'    end loop;',
'    apex_exec.close( l_context );',
'    apex_session_state.set_value(',
'        p_item => ''P6_OUTPUT''',
'        ,p_value => l_output',
'    );',
'    dbms_lob.freeTemporary(l_output);',
'exception',
'    when others then',
'        apex_exec.close( l_context );',
'        raise;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>47572111146154548
);
wwv_flow_imp.component_end;
end;
/
