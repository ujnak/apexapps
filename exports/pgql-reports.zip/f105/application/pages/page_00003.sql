prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7335198607042437
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_imp.id(66832156565405415)
,p_name=>'PGQL2'
,p_alias=>'PGQL2'
,p_step_title=>'PGQL2'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20220909075829'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66862282960636787)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(66746790498405349)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(66637275250405277)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(66808863444405386)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(66862874894636787)
,p_name=>'PGQL2'
,p_template=>wwv_flow_imp.id(66734326111405343)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT T0$1.T AS "s.ACCT_ID$T",',
'T0$1.V AS "s.ACCT_ID$V",',
'T0$1.VN AS "s.ACCT_ID$VN",',
'T0$1.VT AS "s.ACCT_ID$VT",',
'T0$0.T AS "e.AMOUNT$T",',
'T0$0.V AS "e.AMOUNT$V",',
'T0$0.VN AS "e.AMOUNT$VN",',
'T0$0.VT AS "e.AMOUNT$VT",',
'T0$2.T AS "d.ACCT_ID$T",',
'T0$2.V AS "d.ACCT_ID$V",',
'T0$2.VN AS "d.ACCT_ID$VN",',
'T0$2.VT AS "d.ACCT_ID$VT"',
'FROM "WKSP_APEXDEV".SQLCL_BANK_GRAPHGE$ T0$0,',
'"WKSP_APEXDEV".SQLCL_BANK_GRAPHVT$ T0$1,',
'"WKSP_APEXDEV".SQLCL_BANK_GRAPHVT$ T0$2',
'WHERE T0$0.K=n''AMOUNT'' AND',
'T0$1.K=n''ACCT_ID'' AND',
'T0$2.K=n''ACCT_ID'' AND',
'T0$0.SVID=T0$1.VID AND',
'T0$0.DVID=T0$2.VID AND',
'(T0$1.VN in (',
'    select column_value from table(apex_string.split(:P3_ACCT_IDS,'',''))',
'  )',
');'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P3_ACCT_IDS'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(66772241765405362)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66863241898636788)
,p_query_column_id=>1
,p_column_alias=>'s.ACCT_ID$T'
,p_column_display_sequence=>1
,p_column_heading=>'S.Acct Id$T'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66863668138636791)
,p_query_column_id=>2
,p_column_alias=>'s.ACCT_ID$V'
,p_column_display_sequence=>2
,p_column_heading=>'S.Acct Id$V'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66864054675636791)
,p_query_column_id=>3
,p_column_alias=>'s.ACCT_ID$VN'
,p_column_display_sequence=>3
,p_column_heading=>'S.Acct Id$Vn'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66864404293636791)
,p_query_column_id=>4
,p_column_alias=>'s.ACCT_ID$VT'
,p_column_display_sequence=>4
,p_column_heading=>'S.Acct Id$Vt'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66864858898636792)
,p_query_column_id=>5
,p_column_alias=>'e.AMOUNT$T'
,p_column_display_sequence=>5
,p_column_heading=>'E.Amount$T'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66865233096636792)
,p_query_column_id=>6
,p_column_alias=>'e.AMOUNT$V'
,p_column_display_sequence=>6
,p_column_heading=>'E.Amount$V'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66865637362636793)
,p_query_column_id=>7
,p_column_alias=>'e.AMOUNT$VN'
,p_column_display_sequence=>7
,p_column_heading=>'E.Amount$Vn'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66866098034636793)
,p_query_column_id=>8
,p_column_alias=>'e.AMOUNT$VT'
,p_column_display_sequence=>8
,p_column_heading=>'E.Amount$Vt'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66866401172636793)
,p_query_column_id=>9
,p_column_alias=>'d.ACCT_ID$T'
,p_column_display_sequence=>9
,p_column_heading=>'D.Acct Id$T'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66866861485636793)
,p_query_column_id=>10
,p_column_alias=>'d.ACCT_ID$V'
,p_column_display_sequence=>10
,p_column_heading=>'D.Acct Id$V'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66867235693636794)
,p_query_column_id=>11
,p_column_alias=>'d.ACCT_ID$VN'
,p_column_display_sequence=>11
,p_column_heading=>'D.Acct Id$Vn'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66867645577636794)
,p_query_column_id=>12
,p_column_alias=>'d.ACCT_ID$VT'
,p_column_display_sequence=>12
,p_column_heading=>'D.Acct Id$Vt'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66848384965491005)
,p_name=>'P3_ACCT_IDS'
,p_item_sequence=>10
,p_prompt=>'ACCT_IDs'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(66804730634405382)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(66848425377491006)
,p_name=>unistr('ACCT_ID\306E\5909\66F4')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_ACCT_IDS'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(66848579493491007)
,p_event_id=>wwv_flow_imp.id(66848425377491006)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(66862874894636787)
);
wwv_flow_imp.component_end;
end;
/
