prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 159
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>159
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000B64944415458476334987FFB3FC30002C651078C86C068088C86C0A00F01EE6FAF19A4F8B91898FFFE64309013C128332F3C7A';
wwv_flow_imp.g_varchar2_table(2) := 'C3F097991D6B59FAECF34F86AF1C4278CB59822521DF97A70CE282026007186271C0793C0E78F9FE03C3271E69CA1CA0CAFA9541575E9C81FDCF37863823290CC3169D7BC6F093850BAB25971FBE64B8FD9B7B883B00390A484D03C3230A4613E180E782';
wwv_flow_imp.g_varchar2_table(3) := 'D144885C14935A1252A528A6758399605D30EA80D110180D81D110A075080000DE59E541E45F2F000000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(51846624034620640)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
