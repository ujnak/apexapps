prompt --workspace/remote_servers/graph_microsoft_com_v1_0_me
begin
--   Manifest
--     REMOTE SERVER: graph-microsoft-com-v1-0-me
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>128
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(32930591610624372)
,p_name=>'graph-microsoft-com-v1-0-me'
,p_static_id=>'graph_microsoft_com_v1_0_me'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('graph_microsoft_com_v1_0_me'),'https://graph.microsoft.com/v1.0/me/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('graph_microsoft_com_v1_0_me'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('graph_microsoft_com_v1_0_me'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('graph_microsoft_com_v1_0_me'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('graph_microsoft_com_v1_0_me'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
