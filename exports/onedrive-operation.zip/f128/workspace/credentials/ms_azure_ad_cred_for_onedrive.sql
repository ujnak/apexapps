prompt --workspace/credentials/ms_azure_ad_cred_for_onedrive
begin
--   Manifest
--     CREDENTIAL: MS Azure AD Cred for OneDrive
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>128
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(33099546120120319)
,p_name=>'MS Azure AD Cred for OneDrive'
,p_static_id=>'MS_AZURE_AD'
,p_authentication_type=>'OAUTH2_CLIENT_CREDENTIALS'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
