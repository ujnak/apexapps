prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>128
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('OneDrive\64CD\4F5C')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#page-actions#MIN#.js'
,p_javascript_code_onload=>'apex.actions.add([COPY_BY_BUTTON]);'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230606023054'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33046176876894411)
,p_plug_name=>'Graph API Response'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(33207058388276605)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response blob;',
'    l_response_pretty clob;',
'begin',
'    if :P1_MS_GRAPH_API is not null then',
'        l_response := apex_web_service.make_rest_request_b(',
'            p_url => :P1_MS_GRAPH_API',
'            ,p_http_method => ''GET''',
'            ,p_credential_static_id => ''MS_AZURE_AD''',
'        );',
'        select json_serialize(l_response returning clob pretty) into l_response_pretty from dual;',
'    end if;',
'    return ''<pre><code id="apiresult">'' || l_response_pretty || ''</code></pre>'';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_MS_GRAPH_API'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33316028657276731)
,p_plug_name=>unistr('OneDrive\64CD\4F5C')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(33174059511276587)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33828663301940513)
,p_plug_name=>'Item Container'
,p_region_template_options=>'#DEFAULT#:t-ItemContainer--alignCenter'
,p_plug_template=>wwv_flow_imp.id(33199301772276601)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91343994487248815)
,p_button_sequence=>50
,p_button_name=>'REFRESH_TOKEN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(33279921186276653)
,p_button_image_alt=>'Refresh Token'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33046008476894410)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(33828663301940513)
,p_button_name=>'SUBMIT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(33279921186276653)
,p_button_image_alt=>'Submit'
,p_button_position=>'BUTTON_END'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33828582215940512)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(33046176876894411)
,p_button_name=>'COPY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(33279921186276653)
,p_button_image_alt=>'Copy'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$copy-by-button?id=apiresult"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33045934562894409)
,p_name=>'P1_MS_GRAPH_API'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(33828663301940513)
,p_prompt=>'MS Graph API'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(33277492800276650)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33046242510894412)
,p_name=>'Click Submit'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(33046008476894410)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33046362954894413)
,p_event_id=>wwv_flow_imp.id(33046242510894412)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Call Graph API'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33046176876894411)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91344130497248817)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Refresh Token'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_refresh_token varchar2(4000) := :G_REFRESH_TOKEN;',
'    l_response clob;',
'    l_response_json json_object_t;',
'    l_access_token varchar2(4000);',
'    l_expires_in_sec number;',
'    C_CRED_OAUTH2 constant varchar2(20) := ''MS_AZURE_AD'';',
'    C_CRED_BASIC  constant varchar2(20) := ''MS_AZURE_AD_BASIC'';',
'begin',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Content-Type'',''application/x-www-form-urlencoded'',p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => ''https://login.microsoftonline.com/common/oauth2/v2.0/token''',
'        ,p_http_method => ''POST''',
'        ,p_body => ''grant_type=refresh_token'' || chr(38) || ''refresh_token='' || l_refresh_token',
'        ,p_credential_static_id => C_CRED_BASIC',
'    );',
'    l_response_json  := json_object_t.parse(l_response);',
unistr('    /* \30A2\30AF\30BB\30B9\30FB\30C8\30FC\30AF\30F3\306E\30A2\30C3\30D7\30C7\30FC\30C8 */'),
'    l_access_token   := l_response_json.get_string(''access_token'');',
'    l_expires_in_sec := l_response_json.get_number(''expires_in'');',
'    if l_access_token is not null then',
'        apex_credential.set_session_token(',
'            p_credential_static_id => C_CRED_OAUTH2',
'            ,p_token_type          => APEX_CREDENTIAL.C_TOKEN_ACCESS',
'            ,p_token_value         => l_access_token',
'            ,p_token_expires       => (sysdate + l_expires_in_sec/86400)',
'        );',
'        apex_debug.info(''Access Token is updated by %s'', substr(l_access_token, 1,20));',
'    else',
'        apex_debug.info(''Access Token is not updated.'');',
'    end if;',
unistr('    /* \30EA\30D5\30EC\30C3\30B7\30E5\30FB\30C8\30FC\30AF\30F3\306E\30A2\30C3\30D7\30C7\30FC\30C8\3000(\3082\3057\3042\308C\3070) */'),
'    l_refresh_token := l_response_json.get_string(''refresh_token'');',
'    if l_refresh_token is not null then',
'        :G_REFRESH_TOKEN := l_refresh_token;',
'        /* ',
unistr('         * apex_credential.set_session_token\3067\30EA\30D5\30EC\30C3\30B7\30E5\30FB\30C8\30FC\30AF\30F3\3092\4FDD\5B58\3059\308B\30AA\30D7\30B7\30E7\30F3\304C'),
unistr('         * \3042\308B\306E\3067\547C\3073\51FA\3057\3066\3044\308B\304C\3001\4ECA\306E\3068\3053\308D\4F7F\3044\9053\306F\306A\3044\306F\305A\3002 '),
unistr('         * \30EA\30D5\30EC\30C3\30B7\30E5\30FB\30C8\30FC\30AF\30F3\306E\6709\52B9\671F\9593\306FSPA\3067\3042\308C\307024\6642\9593\3001\305D\308C\4EE5\5916\306F90\65E5\3068\306E\3053\3068\306A\306E\3067\3001'),
unistr('         * APEX\3067\306F90\65E5\306A\306F\305A\3060\304C\3001\FF11\65E5\3068\3057\3066\3044\308B\3002'),
'         * https://learn.microsoft.com/ja-jp/azure/active-directory/develop/refresh-tokens',
'         */',
'        apex_credential.set_session_token(',
'            p_credential_static_id => C_CRED_OAUTH2',
'            ,p_token_type          => APEX_CREDENTIAL.C_TOKEN_REFRESH',
'            ,p_token_value         => l_refresh_token',
'            ,p_token_expires       => (sysdate + 1)',
'        );',
'        apex_debug.info(''Refresh Token is updated by %s'', substr(l_refresh_token, 1,20));',
'    else',
'        apex_debug.info(''Refresh Token is not updated.'');',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91343994487248815)
,p_internal_uid=>91344130497248817
);
wwv_flow_imp.component_end;
end;
/
