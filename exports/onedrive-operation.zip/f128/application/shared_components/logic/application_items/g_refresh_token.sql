prompt --application/shared_components/logic/application_items/g_refresh_token
begin
--   Manifest
--     APPLICATION ITEM: G_REFRESH_TOKEN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>128
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(11980873792210297)
,p_name=>'G_REFRESH_TOKEN'
,p_protection_level=>'I'
);
wwv_flow_imp.component_end;
end;
/
