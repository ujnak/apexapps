prompt --application/shared_components/security/authentications/ms_azure_ad
begin
--   Manifest
--     AUTHENTICATION: MS Azure AD
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>128
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(33318478602360721)
,p_name=>'MS Azure AD'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(33099546120120319)
,p_attribute_02=>'OPENID_CONNECT'
,p_attribute_03=>'https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration'
,p_attribute_07=>'User.Read,Files.ReadWrite,profile,offline_access,email'
,p_attribute_09=>'email'
,p_attribute_11=>'Y'
,p_attribute_13=>'Y'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure post_auth is',
'begin',
'  :G_REFRESH_TOKEN := apex_json.get_varchar2(''refresh_token'');',
'end post_auth;'))
,p_invalid_session_type=>'LOGIN'
,p_post_auth_process=>'post_auth'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
