prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 128
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>128
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000E0494441545847636CDC1DFF9F610001E3A8034643603404464360D087C0CFF70C0C825C422865E5FB6FEF1858F9FF33303131';
wwv_flow_imp.g_varchar2_table(2) := '525C86122C09B97E0A31A82BE8A058F4FBCF2F8633378E33B0093250EC08B21C00720DC8118F9E3F60F8F3F717CE50F8F8F33D032B1FFEAA862C07802D7FF69041495C1D6F14DC7D7E83E133FB0BBC6A083A80F7A70483B2A4068621E6CACE0CEC2C9C78';
wwv_flow_imp.g_varchar2_table(3) := '0D3F74732BC38577FB297380819023839DBA3759896DD401A321303C4280E3A7208386A40159B9E0D6CB8B0CDF58DF51960DC9B299044D040B2212CC224BE9A803464360340446430000BB91AB61CBA454390000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(33306231011276695)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
