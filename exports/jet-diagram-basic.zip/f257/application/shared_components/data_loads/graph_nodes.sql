prompt --application/shared_components/data_loads/graph_nodes
begin
--   Manifest
--     DATA LOAD: Graph Nodes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>257
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(77911542001528651)
,p_name=>'Graph Nodes'
,p_format=>'JSON'
,p_encoding=>'utf-8'
,p_has_header_row=>false
,p_row_selector=>'nodes'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(77911820426528679)
,p_data_profile_id=>wwv_flow_imp.id(77911542001528651)
,p_name=>'ID'
,p_sequence=>1
,p_is_primary_key=>true
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4
,p_selector=>'id'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(77912182120528679)
,p_data_profile_id=>wwv_flow_imp.id(77911542001528651)
,p_name=>'CATEGORY'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_decimal_char=>'.'
,p_selector=>'category'
);
wwv_flow_imp_shared.create_load_table(
 p_id=>wwv_flow_imp.id(77912336328528679)
,p_name=>'Graph Nodes'
,p_static_id=>'GRAPGH_NODES'
,p_target_type=>'TABLE'
,p_table_name=>'DG_BASIC_NODES'
,p_data_profile_id=>wwv_flow_imp.id(77911542001528651)
,p_loading_method=>'REPLACE'
,p_commit_interval=>200
,p_error_handling=>'ABORT'
,p_skip_validation=>'N'
);
wwv_flow_imp.component_end;
end;
/
