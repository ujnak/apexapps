prompt --application/shared_components/data_loads/graph_links
begin
--   Manifest
--     DATA LOAD: Graph Links
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>257
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(77915350739671767)
,p_name=>'Graph Links'
,p_format=>'JSON'
,p_encoding=>'utf-8'
,p_has_header_row=>false
,p_row_selector=>'links'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(77915600856671768)
,p_data_profile_id=>wwv_flow_imp.id(77915350739671767)
,p_name=>'ID'
,p_sequence=>1
,p_is_primary_key=>true
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4
,p_selector=>'id'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(77915988773671769)
,p_data_profile_id=>wwv_flow_imp.id(77915350739671767)
,p_name=>'END_NODE'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4
,p_selector=>'end'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(77916205259671769)
,p_data_profile_id=>wwv_flow_imp.id(77915350739671767)
,p_name=>'START_NODE'
,p_sequence=>3
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4
,p_selector=>'start'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(77916572393671769)
,p_data_profile_id=>wwv_flow_imp.id(77915350739671767)
,p_name=>'CATEGORY'
,p_sequence=>4
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_decimal_char=>'.'
,p_selector=>'category'
);
wwv_flow_imp_shared.create_load_table(
 p_id=>wwv_flow_imp.id(77916787489671769)
,p_name=>'Graph Links'
,p_static_id=>'GRAPH_LINKS'
,p_target_type=>'TABLE'
,p_table_name=>'DG_BASIC_LINKS'
,p_data_profile_id=>wwv_flow_imp.id(77915350739671767)
,p_loading_method=>'REPLACE'
,p_commit_interval=>200
,p_error_handling=>'ABORT'
,p_skip_validation=>'N'
);
wwv_flow_imp.component_end;
end;
/
