prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>257
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'JET Diagram Basic'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code=>'var diagram;'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'requirejs.config({',
'   paths: {',
'        ''diagramLayouts'': "&APEX_PATH!RAW.#APP_FILES#layouts",',
'    }',
'});',
'',
'require(["require", "exports", "knockout", "ojs/ojbootstrap", "diagramLayouts/DemoCircleLayout", "ojs/ojarraydataprovider", "ojs/ojattributegrouphandler", "ojs/ojknockout", "ojs/ojdiagram"], function (require, exports, ko, ojbootstrap_1, layout, Arra'
||'yDataProvider, ojattributegrouphandler_1) {',
'      "use strict";',
'      ',
'    class DiagramModel {',
'        /*',
unistr('         * Diagram\3067\8868\793A\3059\308B\30C7\30FC\30BF\3092\66F4\65B0\3059\308B\3002'),
'         */',
'        update(data) {',
'            this.nodeDataProvider(new ArrayDataProvider(data.nodes, {',
'                keyAttributes: "id",',
'            }));',
'            this.linkDataProvider(new ArrayDataProvider(data.links, {',
'                keyAttributes: "id",',
'            }));',
'        }',
'',
'        constructor() {',
'            // this.data = JSON.parse(jsonData);',
'            this.colorHandler = new ojattributegrouphandler_1.ColorAttributeGroupHandler();',
'            this.layoutFunc = layout.circleLayoutWithLayoutArgs(150);',
'            this.panningValue = ko.observable(apex.items.P1_PANNING.value);',
'            this.zoomingValue = ko.observable(apex.items.P1_ZOOMING.value);',
'            /*',
unistr('             * this.nodeDataProvider, linkDataProvider\306Fknockout\306EobservableArray\306B\5909\66F4\3057\3001'),
unistr('             * \30C7\30FC\30BF\306F\30B3\30F3\30B9\30C8\30E9\30AF\30BF\306E\5916\304B\3089\8A2D\5B9A\3059\308B\3002'),
'             */            ',
'            this.nodeDataProvider = ko.observableArray();',
'            this.linkDataProvider = ko.observableArray();',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        diagram = new DiagramModel();',
'        ko.applyBindings(diagram, document.getElementById(''diagram-container''));',
unistr('        /* \30DA\30FC\30B8\30FB\30ED\30FC\30C9\6642\306E\8868\793A */'),
'        apex.actions.invoke("update-diagram");        ',
'    });',
'});',
'',
'/*',
unistr(' * Diagram\3092\66F4\65B0\3059\308B\3002'),
' */',
'apex.actions.add([',
'    {',
'        name: "update-diagram",',
'        action: () => {',
'            apex.server.process ( "GET_DATA", {},',
'                {',
'                    success: (data) =>  {',
'                        // console.log(data);',
'                        diagram.update(data);',
'                    }',
'                }',
'            );',
'        }',
'    }',
']);'))
,p_css_file_urls=>'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230907215655'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77589932920008511)
,p_plug_name=>'Nodes'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(77706967047407506)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'DG_BASIC_NODES'
,p_include_rowid_column=>true
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Nodes'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77590162851008513)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77590218620008514)
,p_name=>'CATEGORY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATEGORY'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Category'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77590804260008520)
,p_name=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROWID'
,p_data_type=>'ROWID'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77590907567008521)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77591090333008522)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(77590039694008512)
,p_internal_uid=>77590039694008512
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>300
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(77918319142910949)
,p_interactive_grid_id=>wwv_flow_imp.id(77590039694008512)
,p_static_id=>'779184'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(77918522779910950)
,p_report_id=>wwv_flow_imp.id(77918319142910949)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77919085409910953)
,p_view_id=>wwv_flow_imp.id(77918522779910950)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(77590162851008513)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77919965943910958)
,p_view_id=>wwv_flow_imp.id(77918522779910950)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(77590218620008514)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77920835397910961)
,p_view_id=>wwv_flow_imp.id(77918522779910950)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(77590804260008520)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77921784636910964)
,p_view_id=>wwv_flow_imp.id(77918522779910950)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(77590907567008521)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77591261128008524)
,p_plug_name=>'Links'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(77706967047407506)
,p_plug_display_sequence=>50
,p_query_type=>'TABLE'
,p_query_table=>'DG_BASIC_LINKS'
,p_include_rowid_column=>true
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Links'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77591417074008526)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77591568006008527)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77591688969008528)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>4
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77591745204008529)
,p_name=>'CATEGORY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATEGORY'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Category'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77591857898008530)
,p_name=>'ROWID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ROWID'
,p_data_type=>'ROWID'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77591946496008531)
,p_name=>'START_NODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'START_NODE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Start Node'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(77592026966008532)
,p_name=>'END_NODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_NODE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'End Node'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(77591326200008525)
,p_internal_uid=>77591326200008525
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>300
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(77924205607970650)
,p_interactive_grid_id=>wwv_flow_imp.id(77591326200008525)
,p_static_id=>'779243'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(77924435342970650)
,p_report_id=>wwv_flow_imp.id(77924205607970650)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77925368871970655)
,p_view_id=>wwv_flow_imp.id(77924435342970650)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(77591568006008527)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77926233401970658)
,p_view_id=>wwv_flow_imp.id(77924435342970650)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(77591688969008528)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77927188758970661)
,p_view_id=>wwv_flow_imp.id(77924435342970650)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(77591745204008529)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77928020304970663)
,p_view_id=>wwv_flow_imp.id(77924435342970650)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(77591857898008530)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77928959778970666)
,p_view_id=>wwv_flow_imp.id(77924435342970650)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(77591946496008531)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(77929872517970668)
,p_view_id=>wwv_flow_imp.id(77924435342970650)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(77592026966008532)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77592905162008541)
,p_plug_name=>'Diagram'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(77651746921407477)
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="diagram-container">',
'    <oj-diagram',
'        id="diagram1"',
'        animation-on-data-change="auto"',
'        panning="[[panningValue]]"',
'        zooming="[[zoomingValue]]"',
'        min-zoom=".5"',
'        max-zoom="2"',
'        node-data="[[nodeDataProvider]]"',
'        link-data="[[linkDataProvider]]"',
'        layout="[[layoutFunc]]"',
'        aria-label="This is a simple diagram that shows how to render Nodes and Links">',
'        <template slot="nodeTemplate" data-oj-as="node">',
'            <oj-diagram-node',
'                label="[[node.data.id]]"',
'                short-desc=''[["Node " + node.data.id + ", Category " + node.data.category]]''',
'                icon.color="[[colorHandler.getValue(node.data.category)]]"',
'                icon.width="50"',
'                icon.height="50">',
'            </oj-diagram-node>',
'        </template>',
'        <template slot="linkTemplate" data-oj-as="link">',
'            <oj-diagram-link',
'                start-node="[[link.data.start]]"',
'                end-node="[[link.data.end]]"',
'                short-desc=''[["Link " + link.data.id + ", Category " + link.data.category + ", connects " + link.data.start + " to " + link.data.end]]''',
'                color="[[colorHandler.getValue(link.data.category)]]"',
'                start-connector-type="none"',
'                end-connector-type="arrow">',
'            </oj-diagram-link>',
'        </template>',
'    </oj-diagram>',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77593087573008542)
,p_plug_name=>'Controls'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(77650396161407476)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77592189568008533)
,p_button_sequence=>10
,p_button_name=>'INIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(77790158842407558)
,p_button_image_alt=>'Init'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77593321228008545)
,p_name=>'P1_PANNING'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(77593087573008542)
,p_item_default=>'none'
,p_prompt=>'Panning'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:none;none,auto;auto'
,p_field_template=>wwv_flow_imp.id(77787674153407556)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77593467638008546)
,p_name=>'P1_ZOOMING'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(77593087573008542)
,p_item_default=>'none'
,p_prompt=>'Zooming'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:none;none,auto;auto'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(77787674153407556)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77592761355008539)
,p_name=>'onSave Nodes'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(77589932920008511)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77592890804008540)
,p_event_id=>wwv_flow_imp.id(77592761355008539)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77591261128008524)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77593691055008548)
,p_event_id=>wwv_flow_imp.id(77592761355008539)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.invoke("update-diagram");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77593703473008549)
,p_name=>'onSave Links'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(77591261128008524)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77593819622008550)
,p_event_id=>wwv_flow_imp.id(77593703473008549)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.actions.invoke("update-diagram");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77940319661719601)
,p_name=>'onChange Panning'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_PANNING'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77940470917719602)
,p_event_id=>wwv_flow_imp.id(77940319661719601)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'diagram.panningValue($v(this.triggeringElement));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77940593104719603)
,p_name=>'onChange Zooming'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_ZOOMING'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77940645891719604)
,p_event_id=>wwv_flow_imp.id(77940593104719603)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'diagram.zoomingValue($v(this.triggeringElement));',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77592299609008534)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>unistr('\521D\671F\5316')
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(77592189568008533)
,p_internal_uid=>77592299609008534
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77591170436008523)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(77589932920008511)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Nodes - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>77591170436008523
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77592659586008538)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(77591261128008524)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Links - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>77592659586008538
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77593551276008547)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'begin',
'    select json_object(',
'        key ''nodes'' value (',
'            select json_arrayagg(',
'                json_object(',
'                    key ''id'' value id',
'                    ,key ''category'' value category',
'                )',
'            ) from dg_basic_nodes',
'        )',
'        ,key ''links'' value (',
'            select json_arrayagg(',
'                json_object(',
'                    key ''id'' value id',
'                    ,key ''category'' value category',
'                    ,key ''start'' value start_node',
'                    ,key ''end'' value end_node',
'                )',
'            ) from dg_basic_links',
'        )',
'    ) into l_response',
'    from dual;',
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>77593551276008547
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77592373444008535)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(77592299609008534)
,p_process_type=>'NATIVE_DATA_LOADING'
,p_process_name=>unistr('\30CE\30FC\30C9')
,p_attribute_01=>wwv_flow_imp.id(77912336328528679)
,p_attribute_02=>'SQL_QUERY'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    apex_web_service.make_rest_request_b(',
'        p_url => ''https://www.oracle.com/webfolder/technetwork/jet/cookbook/dataVisualizations/diagram/resources/diagramDataSample.json''',
'        ,p_http_method => ''GET''',
'    ) as blob_content',
'from dual;'))
,p_internal_uid=>77592373444008535
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77592526719008537)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(77592299609008534)
,p_process_type=>'NATIVE_DATA_LOADING'
,p_process_name=>unistr('\30EA\30F3\30AF')
,p_attribute_01=>wwv_flow_imp.id(77916787489671769)
,p_attribute_02=>'SQL_QUERY'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    apex_web_service.make_rest_request_b(',
'        p_url => ''https://www.oracle.com/webfolder/technetwork/jet/cookbook/dataVisualizations/diagram/resources/diagramDataSample.json''',
'        ,p_http_method => ''GET''',
'    ) as blob_content',
'from dual;'))
,p_internal_uid=>77592526719008537
);
wwv_flow_imp.component_end;
end;
/
