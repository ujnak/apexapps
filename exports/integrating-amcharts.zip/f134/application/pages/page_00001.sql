prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>134
,p_default_id_offset=>37088793418218138
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Integrating amCharts'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.amcharts.com/lib/5/index.js',
'https://cdn.amcharts.com/lib/5/xy.js',
'https://cdn.amcharts.com/lib/5/themes/Animated.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'am5.ready(function() {',
'',
'// Create root element',
'// https://www.amcharts.com/docs/v5/getting-started/#Root_element',
'var root = am5.Root.new("myChart");',
'',
'// Set themes',
'// https://www.amcharts.com/docs/v5/concepts/themes/',
'root.setThemes([',
'  am5themes_Animated.new(root)',
']);',
'',
'// Create chart',
'// https://www.amcharts.com/docs/v5/charts/xy-chart/',
'var chart = root.container.children.push(am5xy.XYChart.new(root, {',
'  panX: false,',
'  panY: false,',
'  wheelX: "panX",',
'  wheelY: "zoomX",',
'  paddingLeft:0,',
'  layout: root.verticalLayout',
'}));',
'',
'// Data',
'const value = apex.item("P1_VALUE").getValue();',
'var data = JSON.parse(value);',
'',
'// Create axes',
'// https://www.amcharts.com/docs/v5/charts/xy-chart/axes/',
'var yAxis = chart.yAxes.push(am5xy.CategoryAxis.new(root, {',
'  categoryField: "ename",',
'  renderer: am5xy.AxisRendererY.new(root, {',
'    inversed: true,',
'    cellStartLocation: 0.1,',
'    cellEndLocation: 0.9,',
'    minorGridEnabled: true',
'  })',
'}));',
'yAxis.data.setAll(data);',
'',
'var xAxis = chart.xAxes.push(am5xy.ValueAxis.new(root, {',
'  renderer: am5xy.AxisRendererX.new(root, {',
'    strokeOpacity: 0.1,',
'    minGridDistance: 50',
'  }),',
'  min: 0',
'}));',
'',
'// Add series',
'// https://www.amcharts.com/docs/v5/charts/xy-chart/series/',
'var series = chart.series.push(am5xy.ColumnSeries.new(root, {',
'    xAxis: xAxis,',
'    yAxis: yAxis,',
'    valueXField: "sal",',
'    categoryYField: "ename",',
'    sequencedInterpolation: true,',
'    fill: am5.color(''#309fdb'')',
'}));',
'',
'',
'series.columns.template.setAll({',
'    height: am5.p50,',
'    strokeOpacity: 0,',
'});',
'',
'series.data.setAll(data);',
'series.appear();',
'',
'// Make stuff animate on load',
'// https://www.amcharts.com/docs/v5/concepts/animations/',
'chart.appear(1000, 100);',
'',
'}); // end am5.ready()'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(172646516555270379)
,p_plug_name=>'amCharts'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(173359882443399722)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<div id="myChart" class="h400"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(173557900867400423)
,p_plug_name=>'Integrating amCharts'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(173336615302399673)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172646192935270376)
,p_name=>'P1_VALUE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(172646376495270378)
,p_computation_sequence=>20
,p_computation_item=>'P1_VALUE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        json_object(',
'            ''ename'' value ename,',
'            ''sal''     value sal',
'        )',
'    order by empno asc )',
'from emp where deptno = 10'))
);
wwv_flow_imp.component_end;
end;
/
