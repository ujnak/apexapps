prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Explain Image without Submit'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6327087114173516)
,p_plug_name=>'Explain Image without Submit'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20045268862071714)
,p_plug_name=>'Left'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20045419167071716)
,p_plug_name=>'Preview'
,p_parent_plug_id=>wwv_flow_imp.id(20045268862071714)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<img id="preview" src="&P1_IMAGE." style="width: 100%;"></img>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20045335673071715)
,p_plug_name=>'Right'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20045107641071713)
,p_name=>'P1_IMAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(20045268862071714)
,p_prompt=>'Image File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'display_as', 'INLINE',
  'purge_file_at', 'REQUEST',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20045591701071717)
,p_name=>'P1_RESPONSE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(20045335673071715)
,p_prompt=>'Response'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_custom_html', 'N',
  'format', 'MARKDOWN',
  'min_height', '400')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20045950791071721)
,p_name=>'P1_PROMPT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(20045335673071715)
,p_item_default=>unistr('\3053\306E\5199\771F\304B\3089\5206\304B\308B\60C5\666F\3092\8AAC\660E\3057\3066\304F\3060\3055\3044\3002')
,p_prompt=>'Prompt'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20045651131071718)
,p_name=>'onChange P1_IMAGE'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_IMAGE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20045762787071719)
,p_event_id=>wwv_flow_imp.id(20045651131071718)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const fileReader = new FileReader();',
'fileReader.onload = (function() {',
'    document.getElementById("preview").src = fileReader.result;',
unistr('    /* Ajax\30B3\30FC\30EB\30D0\30C3\30AF EXPLAIN_IMAGE \3092\547C\3073\51FA\3059\3002 */'),
'    const spinner = apex.util.showSpinner($(''body''), {',
'        fixed: true',
'    });',
'    apex.server.process(',
'        ''EXPLAIN_IMAGE'',',
'        {',
'            p_clob_01: fileReader.result,',
'            pageItems: "#P1_PROMPT"',
'        },',
'        {',
'            success: function(data) {',
'                apex.item("P1_RESPONSE").setValue(data.choices[0].message.content);',
'                spinner.remove();',
'            },',
'            error: function(xfr, status, errorThrown) {',
unistr('                console.error("\30A8\30E9\30FC:", status, errorThrown);'),
'                spinner.remove();',
'            }',
'        }',
'    );',
'});',
'const file = this.triggeringElement.files[0];',
'if (file) {',
'    fileReader.readAsDataURL(file);',
'} else {',
'    document.getElementById("preview").src = '''';',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(20045843572071720)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EXPLAIN_IMAGE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    /* Local LM Studio */',
'    C_ENDPOINT constant varchar2(4000) := ''http://host.containers.internal:8080/v1/chat/completions'';',
'    /* LLM model name */',
'    C_MODEL    constant varchar2(200) := ''gemma-3n-e4b-it-mlx@?'';',
unistr('    /* APEX\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\30D5\30ED\30F3\30C8\30A8\30F3\30C9\304C\9001\4FE1\3059\308B\5199\771F\30C7\30FC\30BF */'),
'    l_image_clob clob := apex_application.g_clob_01;',
unistr('    /* \5199\771F\306B\95A2\3059\308B\5909\6570 */'),
'    l_image    json_object_t;',
'    l_image_url json_object_t;',
unistr('    /* \9001\4FE1\3059\308B\30E1\30C3\30BB\30FC\30B8 */'),
'    l_prompt   json_object_t;',
'    l_content  json_array_t;',
'    l_message  json_object_t;',
'    l_messages json_array_t;',
'    l_request  json_object_t;',
'    l_request_clob clob;',
unistr('    /* \53D7\4FE1\3059\308B\30E1\30C3\30BB\30FC\30B8 */'),
'    l_response clob;',
'    e_call_api_failed exception;',
'begin',
'    /*',
unistr('     * \30D5\30ED\30F3\30C8\30FB\30A8\30F3\30C9\304C\9001\4FE1\3057\3066\304F\308B\5199\771F\306E\30C7\30FC\30BF\3092\305D\306E\307E\307ELLM\306B\6E21\3059\3002'),
'     */',
'    l_image_url := json_object_t();',
'    l_image_url.put(''url'', l_image_clob);',
'    l_image := json_object_t();',
'    l_image.put(''type'', ''image_url'');',
'    l_image.put(''image_url'', l_image_url);',
unistr('    /* \30D7\30ED\30F3\30D7\30C8\306E\6E96\5099 */'),
'    l_prompt := json_object_t();',
'    l_prompt.put(''type'', ''text'');',
'    l_prompt.put(''text'', :P1_PROMPT);   ',
unistr('    /* content\306E\4F5C\6210 */'),
'    l_content := json_array_t();',
'    l_content.append(l_prompt);',
'    l_content.append(l_image);',
unistr('    /* message\306E\4F5C\6210 - system\30D7\30ED\30F3\30D7\30C8\306F\7121\3057, user\306E\5358\767A\306E\307F */'),
'    l_message := json_object_t();',
'    l_message.put(''role'', ''user'');',
'    l_message.put(''content'', l_content);',
unistr('    /* messages\306E\4F5C\6210 */'),
'    l_messages := json_array_t();',
'    l_messages.append(l_message);',
unistr('    /* request\306E\4F5C\6210 */'),
'    l_request := json_object_t();',
unistr('    l_request.put(''model'', C_MODEL); /* \4F7F\7528\3059\308B\30E2\30C7\30EB\306FGemma 3n */'),
'    l_request.put(''messages'', l_messages);',
'    -- l_request.put(''max_tokens'', p_max_tokens);',
'    /* call OpenAI chat completions api */',
'    l_request_clob := l_request.to_clob();',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_ENDPOINT',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_call_api_failed;',
'    end if;',
'    /*',
unistr('     * LM Studio\306ELLM\304C\8FD4\3059JSON\3092\305D\306E\307E\307E\30D5\30ED\30F3\30C8\30A8\30F3\30C9\306B\623B\3059\3002'),
unistr('     * \5185\5BB9\306E\89E3\91C8\306F\30D5\30ED\30F3\30C8\30FB\30A8\30F3\30C9\306B\5B9F\88C5\3059\308B\3002'),
'     */',
'    htp.p(l_response);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>20045843572071720
);
wwv_flow_imp.component_end;
end;
/
