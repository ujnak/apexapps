prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>136
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'ChatGPT App'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230302074550'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58616187591087823)
,p_plug_name=>'System Message'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(58974538280685262)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>'select * from apex_collections where collection_name = ''CHATGPT'''
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58616630472087828)
,p_plug_name=>'Chat History'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(58915676136685233)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select seq_id, c001, clob001, n001, n002, n003',
'from apex_collections',
'where collection_name = ''CHATGPT'' order by seq_id desc'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(58616746843087829)
,p_region_id=>wwv_flow_imp.id(58616630472087828)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'C001'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'CLOB001'
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if N001/}',
'prompt_tokens: &N001. completion_tokens: &N002. total_tokens: &N003.',
'{endif/}'))
,p_media_adv_formatting=>false
,p_pk1_column_name=>'SEQ_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58616804152087830)
,p_plug_name=>'User Message'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(58974538280685262)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select * from apex_collections where collection_name = ''CHATGPT'''
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59083474397685347)
,p_plug_name=>'ChatGPT App'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(58941583192685246)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(58616320724087825)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(58616187591087823)
,p_button_name=>'SET_SYSTEM_MESSAGE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(59047454270685304)
,p_button_image_alt=>'Set System Message'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(58617077876087832)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(58616804152087830)
,p_button_name=>'SEND_USER_MESSAGE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(59047454270685304)
,p_button_image_alt=>'Send User Message'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(58617404973087836)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(59083474397685347)
,p_button_name=>'INIT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(59047454270685304)
,p_button_image_alt=>'Start New Conversation'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.:INIT_CONVERSATION:&DEBUG.:::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58616274838087824)
,p_name=>'P1_SYSTEM_MESSAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(58616187591087823)
,p_item_default=>'You are a helpful assistant.'
,p_prompt=>'System Message'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(59044999821685303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58616982655087831)
,p_name=>'P1_USER_MESSAGE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(58616804152087830)
,p_prompt=>'User Message'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(59044999821685303)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(58618067307087842)
,p_name=>'P1_REQUEST'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_prompt=>'Request'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(59044999821685303)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(58616487450087826)
,p_name=>'onClick Set System Message'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(58616320724087825)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58616589871087827)
,p_event_id=>wwv_flow_imp.id(58616487450087826)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_collection.add_member(',
'        p_collection_name => ''CHATGPT''',
'        ,p_c001 => ''system''',
'        ,p_clob001 => :P1_SYSTEM_MESSAGE',
'    );',
'end;'))
,p_attribute_02=>'P1_SYSTEM_MESSAGE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58617524890087837)
,p_event_id=>wwv_flow_imp.id(58616487450087826)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(58617161789087833)
,p_name=>'onClick Send User Message'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(58617077876087832)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58617238092087834)
,p_event_id=>wwv_flow_imp.id(58617161789087833)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request  json_object_t;',
'    l_request_clob clob;',
'    l_messages json_array_t;',
'    l_message  json_object_t;',
'    /*',
unistr('    \3000\3000* OpenAI\306E\30C9\30AD\30E5\30E1\30F3\30C8\3088\308A\3001API\306E\5FDC\7B54\4F8B\3092\62DD\501F\3002'),
unistr('     * \53C2\8003: https://platform.openai.com/docs/guides/chat'),
'     */',
'    l_response_clob clob := q''~{',
' ''id'': ''chatcmpl-6p9XYPYSTTRi0xEviKjjilqrWU2Ve'',',
' ''object'': ''chat.completion'',',
' ''created'': 1677649420,',
' ''model'': ''gpt-3.5-turbo'',',
' ''usage'': {''prompt_tokens'': 56, ''completion_tokens'': 31, ''total_tokens'': 87},',
' ''choices'': [',
'   {',
'    ''message'': {',
'      ''role'': ''assistant'',',
'      ''content'': ''The 2020 World Series was played in Arlington, Texas at the Globe Life Field, which was the new home stadium for the Texas Rangers.''},',
'    ''finish_reason'': ''stop'',',
'    ''index'': 0',
'   }',
'  ]',
'}~'';',
'    l_response json_object_t;',
'    l_choices json_array_t;',
'    l_role    varchar2(80);',
'    l_content clob;',
'    l_usage json_object_t;',
'begin',
'    /*',
unistr('    \3000\3000* \30E6\30FC\30B6\30FC\306B\3088\308B\30E1\30C3\30BB\30FC\30B8\3092\30B3\30EC\30AF\30B7\30E7\30F3\306B\8FFD\8A18\3059\308B\3002'),
'     */',
'    apex_collection.add_member(',
'        p_collection_name => ''CHATGPT''',
'        ,p_c001 => ''user''',
'        ,p_clob001 => :P1_USER_MESSAGE',
'    );',
'    /*',
unistr('     * ChatGPT\306EAPI\306B\9001\4FE1\3059\308B\30E1\30C3\30BB\30FC\30B8\3092\4F5C\6210\3059\308B\3002'),
'     */',
'    /*',
unistr('    \3000\3000* APEX\30B3\30EC\30AF\30B7\30E7\30F3CHATGPT\3088\308A\3001\4F5C\6210\6642\523B\306E\6607\9806\3067\30E1\30C3\30BB\30FC\30B8\306E\914D\5217\306B\3059\308B\3002'),
'     */',
'    l_messages := json_array_t();',
'    for r in (select c001, clob001 from apex_collections where collection_name = ''CHATGPT'' order by seq_id)',
'    loop',
'        l_message := json_object_t();',
'        l_message.put(''role''   ,r.c001);',
'        l_message.put(''content'',r.clob001);',
'        l_messages.append(l_message);',
'    end loop;',
'    l_request := json_object_t();',
'    l_request.put(''model'',''gpt-3.5-turbo'');',
'    l_request.put(''messages'', l_messages);',
'    /* ',
unistr('     * temprature, top_p\306A\3069\306E\30D1\30E9\30E1\30FC\30BF\3092\8A2D\5B9A\3059\308B\3068\3057\305F\3089\3001\3053\3053\3067put\3059\308B\3002'),
'     */',
'    l_request_clob := l_request.to_clob();',
unistr('    /* \30C7\30D0\30C3\30B0\306E\305F\3081\3001\9001\4FE1\3059\308B\30E1\30C3\30BB\30FC\30B8\3092P1_REQUEST\306B\66F8\304D\8FBC\3080\3002 */'),
'    :P1_REQUEST := l_request_clob;',
'    /*',
unistr('     * OpenAI\306EChatGPT\306EAPI\3092\547C\3073\51FA\3059\3002\4ECA\306E\6240\3001\30B3\30E1\30F3\30C8\30A2\30A6\30C8\3002'),
'     *',
unistr('     * \53C2\7167: https://openai.com/blog/introducing-chatgpt-and-whisper-apis'),
'     * API Ref: https://platform.openai.com/docs/api-reference/chat',
'    */',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'',p_reset => false);',
'    /*',
'    l_response_clob := apex_web_service.make_rest_request(',
'        p_url => ''https://api.openai.com/v1/chat/completions''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'        ,p_credential_static_id => ''OPENAI_API_KEY''',
'    );',
'    */',
unistr('    /* \30C9\30AD\30E5\30E1\30F3\30C8\306B\8A18\8F09\3055\308C\3066\3044\308B\30EC\30B9\30DD\30F3\30B9\3067\51E6\7406\3092\7D99\7D9A\3059\308B\3002 */'),
'    l_response := json_object_t(l_response_clob);',
'    l_choices := l_response.get_array(''choices'');',
'    l_message := treat(treat(l_choices.get(0) as json_object_t).get(''message'') as json_object_t);',
'    l_role    := l_message.get_string(''role'');',
'    l_content := l_message.get_clob(''content'');',
unistr('    /* usage\3082\53D6\308A\51FA\3059\3002 */'),
'    l_usage := treat(l_response.get(''usage'') as json_object_t);',
'    /*',
unistr('     * ChatGPT\304B\3089\306E\5FDC\7B54\3092APEX\30B3\30EC\30AF\30B7\30E7\30F3\306B\8FFD\8A18\3059\308B\3002'),
'     */',
'    apex_collection.add_member(',
'        p_collection_name => ''CHATGPT''',
'        ,p_c001 => l_role',
'        ,p_clob001 => l_content',
'        ,p_n001 => l_usage.get_number(''prompt_tokens'')',
'        ,p_n002 => l_usage.get_number(''completion_tokens'')',
'        ,p_n003 => l_usage.get_number(''total_tokens'')',
'    );',
unistr('    /* \30E6\30FC\30B6\30FC\306E\30E1\30C3\30BB\30FC\30B8\3092\6D88\53BB\3059\308B */'),
'    :P1_USER_MESSAGE := '''';',
'end;'))
,p_attribute_02=>'P1_USER_MESSAGE'
,p_attribute_03=>'P1_REQUEST,P1_USER_MESSAGE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(58617365118087835)
,p_event_id=>wwv_flow_imp.id(58617161789087833)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(58616630472087828)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(58616017829087822)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init Conversation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if not apex_collection.collection_exists(''CHATGPT'') then',
'        apex_collection.create_collection(''CHATGPT'');',
'    end if;',
'    if :REQUEST = ''INIT_CONVERSATION'' then',
'        apex_collection.create_or_truncate_collection(''CHATGPT'');',
'        :P1_REQUEST := '''';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
