prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>unistr('\30CA\30EC\30C3\30B8\30D9\30FC\30B9\691C\7D22')
,p_alias=>unistr('\30CA\30EC\30C3\30B8\30D9\30FC\30B9\691C\7D22')
,p_step_title=>unistr('\30CA\30EC\30C3\30B8\30D9\30FC\30B9\691C\7D22')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'26'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12405338699060554)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12211694653838813)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12406006322060557)
,p_plug_name=>unistr('\691C\7D22\7D50\679C')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1555738898046108210
,p_plug_display_sequence=>20
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'custom_layout', 'N',
  'lazy_loading', 'Y',
  'minimum_characters', '0',
  'no_query_entered_message', unistr('\691C\7D22\8A9E\3092\5165\529B\3057\3066\304F\3060\3055\3044\3002'),
  'no_results_found_message', unistr('\691C\7D22\8A9E\306E\7D50\679C\304C\3042\308A\307E\305B\3093\3002'),
  'results_per_page', '15',
  'results_per_page_type', 'STATIC',
  'search_as_you_type', 'N',
  'search_page_item', 'P3_SEARCH',
  'show_result_count', 'N',
  'use_pagination', 'Y')).to_clob
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(12406548306060557)
,p_region_id=>wwv_flow_imp.id(12406006322060557)
,p_search_config_id=>wwv_flow_imp.id(12404435315002573)
,p_use_as_initial_result=>false
,p_max_results=>5
,p_display_sequence=>10
,p_name=>unistr('\30C6\30AD\30B9\30C8\691C\7D22')
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(12407075673060558)
,p_region_id=>wwv_flow_imp.id(12406006322060557)
,p_search_config_id=>wwv_flow_imp.id(12404195942917761)
,p_use_as_initial_result=>false
,p_max_results=>5
,p_display_sequence=>20
,p_name=>unistr('\30D9\30AF\30C8\30EB\691C\7D22')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12407511040060558)
,p_name=>'P3_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12405338699060554)
,p_item_display_point=>'SMART_FILTERS'
,p_prompt=>unistr('\691C\7D22')
,p_placeholder=>unistr('\691C\7D22...')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_field_template=>2040785906935475274
,p_item_css_classes=>'mxw800 t-Form-fieldContainer--noPadding'
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'SEARCH',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
