prompt --application/shared_components/navigation/search_config/ベクトル検索
begin
--   Manifest
--     SEARCH CONFIG: ベクトル検索
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(12404195942917761)
,p_label=>unistr('\30D9\30AF\30C8\30EB\691C\7D22')
,p_static_id=>'VECTOR_SEARCH'
,p_search_type=>'VECTOR'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'DIFY_KB_TEST'
,p_oratext_index_column_name=>'EMBEDDING'
,p_vector_provider_id =>wwv_flow_imp.id(12205894366824295)
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'COSINE'
,p_return_max_results=>100
,p_pk_column_name=>'ID'
,p_title_column_name=>'SOURCE'
,p_description_column_name=>'TEXT'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-chatbot'
,p_version_scn=>5921355
);
wwv_flow_imp.component_end;
end;
/
