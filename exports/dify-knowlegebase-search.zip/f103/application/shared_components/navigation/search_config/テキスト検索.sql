prompt --application/shared_components/navigation/search_config/テキスト検索
begin
--   Manifest
--     SEARCH CONFIG: テキスト検索
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(12404435315002573)
,p_label=>unistr('\30C6\30AD\30B9\30C8\691C\7D22')
,p_static_id=>'TEXT_SEARCH'
,p_search_type=>'TEXT_MANUAL'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'DIFY_KB_TEST'
,p_oratext_index_column_name=>'TEXT'
,p_pk_column_name=>'ID'
,p_title_column_name=>'SOURCE'
,p_description_column_name=>'TEXT'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-font'
,p_version_scn=>5927842
);
wwv_flow_imp.component_end;
end;
/
