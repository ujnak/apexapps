prompt --workspace/remote_servers/ollama_bge_m3_latest
begin
--   Manifest
--     REMOTE SERVER: Ollama bge-m3:latest
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(12205894366824295)
,p_name=>'Ollama bge-m3:latest'
,p_static_id=>'ollama_bge_m3_latest'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('ollama_bge_m3_latest'),'https://localhost')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('ollama_bge_m3_latest'),'')
,p_server_type=>'VECTOR'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('ollama_bge_m3_latest'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('ollama_bge_m3_latest'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('ollama_bge_m3_latest'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('ollama_bge_m3_latest'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('ollama_bge_m3_latest'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('ollama_bge_m3_latest'),'')
,p_embedding_type=>'PLSQL'
,p_emb_function=>'generate_embedding'
);
wwv_flow_imp.component_end;
end;
/
