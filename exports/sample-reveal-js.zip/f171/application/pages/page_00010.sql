prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>171
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'multiple-presentations'
,p_alias=>'MULTIPLE-PRESENTATIONS'
,p_step_title=>'multiple-presentations'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/highlight/highlight.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/markdown/markdown.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/math/math.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let deck1 = new Reveal( document.querySelector( ''.deck1'' ), {',
'    embedded: true,',
'	progress: false,',
'	keyboardCondition: ''focused'',',
'	plugins: [ RevealHighlight ]',
'} );',
'deck1.on( ''slidechanged'', () => {',
'    console.log( ''Deck 1 slide changed'' );',
'} );',
'deck1.initialize();',
'',
'let deck2 = new Reveal( document.querySelector( ''.deck2'' ), {',
'	embedded: true,',
'	progress: false,',
'	keyboardCondition: ''focused'',',
'	plugins: [ RevealMarkdown, RevealMath ]',
'} );',
'deck2.initialize().then( () => {',
'	deck2.slide(1);',
'} );',
'deck2.on( ''slidechanged'', () => {',
'	console.log( ''Deck 2 slide changed'' );',
'} );'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.css',
'https://cdn.jsdelivr.net/npm/reveal.js/dist/theme/white.css',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/highlight/monokai.css'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.reveal {',
'    border: 4px solid #ccc;',
'}',
'',
'.reveal.focused {',
'	border-color: #94b5ff;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Ref: https://github.com/hakimel/reveal.js/blob/master/examples/multiple-presentations.html',
'====================================================================================',
'Copyright (C) 2011-2024 Hakim El Hattab, http://hakim.se, and reveal.js contributors',
'',
'Permission is hereby granted, free of charge, to any person obtaining a copy',
'of this software and associated documentation files (the "Software"), to deal',
'in the Software without restriction, including without limitation the rights',
'to use, copy, modify, merge, publish, distribute, sublicense, and/or sell',
'copies of the Software, and to permit persons to whom the Software is',
'furnished to do so, subject to the following conditions:',
'',
'The above copyright notice and this permission notice shall be included in',
'all copies or substantial portions of the Software.',
'',
'THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR',
'IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,',
'FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE',
'AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER',
'LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,',
'OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN',
'THE SOFTWARE.'))
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(206442858274213332)
,p_plug_name=>'Deck'
,p_region_css_classes=>'w95p h600'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(68817980603643228)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'		<div style="display: flex; flex-direction: row;">',
'			<div class="reveal deck1" style="width: 100%; height: 50vh; margin: 10px;">',
'				<div class="slides">',
'					<section>Deck 1, Slide 1</section>',
'					<section>Deck 1, Slide 2</section>',
'					<section>',
'						<pre data-id="code-animation"><code class="hljs" data-trim data-line-numbers>',
'							import React, { useState } from ''react'';',
'							function Example() {',
'							  const [count, setCount] = useState(0);',
'							}',
'						</code></pre>',
'					</section>',
'				</div>',
'			</div>',
'',
'			<div class="reveal deck2" style="width: 100%; height: 50vh; margin: 10px;">',
'				<div class="slides">',
'					<section>Deck 2, Slide 1</section>',
'					<section>Deck 2, Slide 2</section>',
'					<section data-markdown>',
'						<script type="text/template">',
'							## Markdown plugin',
'',
'							- 1',
'							- 2',
'							- 3',
'						</script>',
'					</section>',
'					<section>',
'						<h3>The Lorenz Equations</h3>',
'',
'						\[\begin{aligned}',
'						\dot{x} &amp; = \sigma(y-x) \\',
'						\dot{y} &amp; = \rho x - y - xz \\',
'						\dot{z} &amp; = -\beta z + xy',
'						\end{aligned} \]',
'					</section>',
'				</div>',
'			</div>',
'		</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
