prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>171
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'scroll'
,p_alias=>'SCROLL'
,p_step_title=>'scroll'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/notes/notes.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/markdown/markdown.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/highlight/highlight.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let deck1 = new Reveal( document.querySelector( ''.deck1'' ), {',
'    embedded: true,',
'	view: ''scroll'',',
'	hash: true,',
'	plugins: [ RevealMarkdown, RevealHighlight, RevealNotes ]',
'} );',
'deck1.initialize();'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reset.css',
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.css',
'https://cdn.jsdelivr.net/npm/reveal.js/dist/theme/black.css',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/highlight/monokai.css'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.reveal {',
'    border: 4px solid #ccc;',
'}',
'',
'.reveal.focused {',
'	border-color: #94b5ff;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Ref: https://github.com/hakimel/reveal.js/blob/master/examples/scroll.html',
'====================================================================================',
'Copyright (C) 2011-2024 Hakim El Hattab, http://hakim.se, and reveal.js contributors',
'',
'Permission is hereby granted, free of charge, to any person obtaining a copy',
'of this software and associated documentation files (the "Software"), to deal',
'in the Software without restriction, including without limitation the rights',
'to use, copy, modify, merge, publish, distribute, sublicense, and/or sell',
'copies of the Software, and to permit persons to whom the Software is',
'furnished to do so, subject to the following conditions:',
'',
'The above copyright notice and this permission notice shall be included in',
'all copies or substantial portions of the Software.',
'',
'THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR',
'IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,',
'FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE',
'AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER',
'LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,',
'OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN',
'THE SOFTWARE.'))
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(275547569836227659)
,p_plug_name=>'Deck'
,p_region_css_classes=>'w95p h600'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(68817980603643228)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'		<div class="reveal deck1">',
'',
'			<div class="slides">',
'',
'				<section><h1>Scroll View</h1></section>',
'				<section data-background="indigo">',
'					<h2>Scroll triggered fragments</h2>',
'					<ul>',
'						<li class="fragment fade-left">Step one</li>',
'						<li class="fragment fade-left">Step two</li>',
'						<li class="fragment fade-left">Step three</li>',
'					</ul>',
'				</section>',
'				<section data-background-color="#fff"><h2>Scrollbar inverts<br>based on slide bg</h2></section>',
'				<section data-auto-animate data-auto-animate-easing="cubic-bezier(0.770, 0.000, 0.175, 1.000)">',
'					<h2>Auto-Animate</h2>',
unistr('					<p>Scroll triggered auto-animations \D83D\DE0D</p>'),
'					<div class="r-hstack justify-center">',
'						<div data-id="box1" style="background: #999; width: 50px; height: 50px; margin: 10px; border-radius: 5px;"></div>',
'						<div data-id="box2" style="background: #999; width: 50px; height: 50px; margin: 10px; border-radius: 5px;"></div>',
'						<div data-id="box3" style="background: #999; width: 50px; height: 50px; margin: 10px; border-radius: 5px;"></div>',
'					</div>',
'				</section>',
'				<section data-auto-animate data-auto-animate-easing="cubic-bezier(0.770, 0.000, 0.175, 1.000)">',
'					<div class="r-hstack justify-center">',
'						<div data-id="box1" data-auto-animate-delay="0" style="background: cyan; width: 150px; height: 100px; margin: 10px;"></div>',
'						<div data-id="box2" data-auto-animate-delay="0.1" style="background: magenta; width: 150px; height: 100px; margin: 10px;"></div>',
'						<div data-id="box3" data-auto-animate-delay="0.2" style="background: yellow; width: 150px; height: 100px; margin: 10px;"></div>',
'					</div>',
'					<h2 style="margin-top: 20px;">Auto-Animate</h2>',
'				</section>',
'				<section data-auto-animate data-auto-animate-easing="cubic-bezier(0.770, 0.000, 0.175, 1.000)">',
'					<div class="r-stack">',
'						<div data-id="box1" style="background: cyan; width: 300px; height: 300px; border-radius: 200px;"></div>',
'						<div data-id="box2" style="background: magenta; width: 200px; height: 200px; border-radius: 200px;"></div>',
'						<div data-id="box3" style="background: yellow; width: 100px; height: 100px; border-radius: 200px;"></div>',
'					</div>',
'					<h2 style="margin-top: 20px;">Auto-Animate</h2>',
'				</section>',
'				<section data-background-gradient="linear-gradient(to bottom, #283b95, #17b2c3)" id="gradient-bg">',
'					<h2 data-id="code-title">Code highlights,<br />meet scroll triggers</h2>',
'					<pre data-id="code-animation"><code class="hljs javascript" data-trim data-line-numbers="|4,8-11|17|22-24"><script type="text/template">',
'						import React, { useState } from ''react'';',
'',
'						function Example() {',
'						  const [count, setCount] = useState(0);',
'',
'						  return (',
'						    <div>',
'						      <p>You clicked {count} times</p>',
'						      <button onClick={() => setCount(count + 1)}>',
'						        Click me',
'						      </button>',
'						    </div>',
'						  );',
'						}',
'',
'						function SecondExample() {',
'						  const [count, setCount] = useState(0);',
'',
'						  return (',
'						    <div>',
'						      <p>You clicked {count} times</p>',
'						      <button onClick={() => setCount(count + 1)}>',
'						        Click me',
'						      </button>',
'						    </div>',
'						  );',
'						}',
'					</script></code></pre>',
'				</section>',
'				<section class="stack">',
'          <section data-background="https://static.slid.es/reveal/image-placeholder.png" id="image-bg">',
'            <h2>Image Backgrounds</h2>',
'          </section>',
'          <section data-background-video-muted data-background-video="https://s3.amazonaws.com/static.slid.es/site/homepage/v1/homepage-video-editor.mp4,https://s3.amazonaws.com/static.slid.es/site/homepage/v1/homepage-video-editor.webm">',
'            <h2>Video background</h2>',
'          </section>',
'        </section>',
'				<section><h2>The end</h2></section>',
'',
'			</div>',
'',
'		</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
