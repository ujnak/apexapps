prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>171
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'transitions'
,p_alias=>'TRANSITIONS'
,p_step_title=>'transitions'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'		<style type="text/css" media="screen">',
'			.slides section.has-dark-background,',
'			.slides section.has-dark-background h3 {',
'				color: #fff;',
'			}',
'			.slides section.has-light-background,',
'			.slides section.has-light-background h3 {',
'				color: #222;',
'			}',
'		</style>',
''))
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let deck1 = new Reveal( document.querySelector( ''.deck1'' ), {',
'    embedded: true,',
'	center: true,',
'	history: true,',
'',
'	// transition: ''slide'',',
'	// transitionSpeed: ''slow'',',
'	// backgroundTransition: ''slide''',
'} );',
'deck1.initialize();'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.css',
'https://cdn.jsdelivr.net/npm/reveal.js/dist/theme/white.css'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.reveal {',
'    border: 4px solid #ccc;',
'}',
'',
'.reveal.focused {',
'	border-color: #94b5ff;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Ref: https://github.com/hakimel/reveal.js/blob/master/examples/transitions.html',
'====================================================================================',
'Copyright (C) 2011-2024 Hakim El Hattab, http://hakim.se, and reveal.js contributors',
'',
'Permission is hereby granted, free of charge, to any person obtaining a copy',
'of this software and associated documentation files (the "Software"), to deal',
'in the Software without restriction, including without limitation the rights',
'to use, copy, modify, merge, publish, distribute, sublicense, and/or sell',
'copies of the Software, and to permit persons to whom the Software is',
'furnished to do so, subject to the following conditions:',
'',
'The above copyright notice and this permission notice shall be included in',
'all copies or substantial portions of the Software.',
'',
'THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR',
'IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,',
'FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE',
'AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER',
'LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,',
'OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN',
'THE SOFTWARE.'))
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(344654083515273591)
,p_plug_name=>'Deck'
,p_region_css_classes=>'w95p h600'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(68817980603643228)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'		<div class="reveal deck1">',
'',
'			<div class="slides">',
'',
'				<section>',
'					<h3>Default</h3>',
'				</section>',
'',
'				<section>',
'					<h3>Default</h3>',
'				</section>',
'',
'				<section data-transition="zoom">',
'					<h3>data-transition: zoom</h3>',
'				</section>',
'',
'				<section data-transition="zoom-in fade-out">',
'					<h3>data-transition: zoom-in fade-out</h3>',
'				</section>',
'',
'				<section>',
'					<h3>Default</h3>',
'				</section>',
'',
'				<section data-transition="convex">',
'					<h3>data-transition: convex</h3>',
'				</section>',
'',
'				<section data-transition="convex-in concave-out">',
'					<h3>data-transition: convex-in concave-out</h3>',
'				</section>',
'',
'				<section>',
'					<section data-transition="zoom">',
'						<h3>Default</h3>',
'					</section>',
'					<section data-transition="concave">',
'						<h3>data-transition: concave</h3>',
'					</section>',
'					<section data-transition="convex-in fade-out">',
'						<h3>data-transition: convex-in fade-out</h3>',
'					</section>',
'					<section>',
'						<h3>Default</h3>',
'					</section>',
'				</section>',
'',
'				<section data-transition="none">',
'					<h3>data-transition: none</h3>',
'				</section>',
'',
'				<section>',
'					<h3>Default</h3>',
'				</section>',
'',
'			</div>',
'',
'		</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
