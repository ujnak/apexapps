prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>171
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'media'
,p_alias=>'MEDIA'
,p_step_title=>'media'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const elm = document.querySelector(''.deck1'');',
'let deck1 = new Reveal(elm, {',
'    embedded: true,',
'    hash: true',
'});',
'deck1.initialize();'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.css',
'https://cdn.jsdelivr.net/npm/reveal.js/dist/theme/white.css'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Ref: https://github.com/hakimel/reveal.js/blob/master/examples/media.html',
'====================================================================================',
'Copyright (C) 2011-2024 Hakim El Hattab, http://hakim.se, and reveal.js contributors',
'',
'Permission is hereby granted, free of charge, to any person obtaining a copy',
'of this software and associated documentation files (the "Software"), to deal',
'in the Software without restriction, including without limitation the rights',
'to use, copy, modify, merge, publish, distribute, sublicense, and/or sell',
'copies of the Software, and to permit persons to whom the Software is',
'furnished to do so, subject to the following conditions:',
'',
'The above copyright notice and this permission notice shall be included in',
'all copies or substantial portions of the Software.',
'',
'THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR',
'IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,',
'FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE',
'AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER',
'LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,',
'OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN',
'THE SOFTWARE.'))
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(206441111000161288)
,p_plug_name=>'Deck'
,p_region_css_classes=>'w95p h600'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(68817980603643228)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'		<div class="reveal deck1">',
'',
'			<div class="slides">',
'',
'				<section>',
'					<h2>Examples of embedded Video, Audio and Iframes</h2>',
'				</section>',
'',
'				<section>',
'					<h2>Iframe</h2>',
'					<iframe data-autoplay width="700" height="540" src="https://slides.com/news/auto-animate/embed" frameborder="0"></iframe>',
'				</section>',
'',
'				<section data-background-iframe="https://www.youtube.com/embed/h1_nyI3z8gI" data-background-interactive>',
'					<h2 style="color: #fff;">Iframe Background</h2>',
'				</section>',
'',
'				<section>',
'					<h2>Video</h2>',
'					<video src="http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4" data-autoplay></video>',
'				</section>',
'',
'				<section data-background-video="http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4">',
'					<h2>Background Video</h2>',
'				</section>',
'',
'				<section>',
'					<h2>Auto-playing audio</h2>',
'					<audio src="#APP_FILES#assets/beeping.wav" data-autoplay></audio>',
'				</section>',
'',
'				<section>',
'					<h2>Audio inside slide fragments</h2>',
'					<div class="fragment">',
'						Beep 1',
'						<audio src="#APP_FILES#assets/beeping.wav" data-autoplay></audio>',
'					</div>',
'					<div class="fragment">',
'						Beep 2',
'						<audio src="#APP_FILES#assets/beeping.wav" data-autoplay></audio>',
'					</div>',
'				</section>',
'',
'				<section>',
'					<h2>Audio with controls</h2>',
'					<audio src="#APP_FILES#assets/beeping.wav" controls></audio>',
'				</section>',
'',
'			</div>',
'',
'		</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
