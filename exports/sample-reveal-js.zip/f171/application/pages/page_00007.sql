prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>171
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'markdown'
,p_alias=>'MARKDOWN'
,p_step_title=>'markdown'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/markdown/markdown.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/highlight/highlight.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/notes/notes.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/math/math.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const elm = document.querySelector(''.deck1'');',
'let deck1 = new Reveal(elm, {',
'    embedded: true,',
'	controls: true,',
'	progress: true,',
'	history: true,',
'	center: true,',
'	plugins: [ RevealMarkdown, RevealHighlight, RevealNotes, RevealMath.KaTeX ]',
'});',
'deck1.initialize();'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.css',
'https://cdn.jsdelivr.net/npm/reveal.js/dist/theme/white.css',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/highlight/monokai.css'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Ref: https://github.com/hakimel/reveal.js/blob/master/examples/markdown.html',
'====================================================================================',
'Copyright (C) 2011-2024 Hakim El Hattab, http://hakim.se, and reveal.js contributors',
'',
'Permission is hereby granted, free of charge, to any person obtaining a copy',
'of this software and associated documentation files (the "Software"), to deal',
'in the Software without restriction, including without limitation the rights',
'to use, copy, modify, merge, publish, distribute, sublicense, and/or sell',
'copies of the Software, and to permit persons to whom the Software is',
'furnished to do so, subject to the following conditions:',
'',
'The above copyright notice and this permission notice shall be included in',
'all copies or substantial portions of the Software.',
'',
'THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR',
'IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,',
'FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE',
'AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER',
'LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,',
'OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN',
'THE SOFTWARE.'))
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(206435437158086733)
,p_plug_name=>'Deck'
,p_region_css_classes=>'w95p h600'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(68817980603643228)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'		<div class="reveal deck1">',
'',
'			<div class="slides">',
'',
'                <!-- Use external markdown resource, separate slides by three newlines; vertical slides by two newlines -->',
'                <section data-markdown="#APP_FILES#markdown.md" data-separator="^\n\n\n" data-separator-vertical="^\n\n"></section>',
'',
'                <!-- Slides are separated by three dashes (the default) -->',
'                <section data-markdown>',
'                    <script type="text/template">',
'                        ## Demo 1',
'                        Slide 1',
'                        ---',
'                        ## Demo 1',
'                        Slide 2',
'                        ---',
'                        ## Demo 1',
'                        Slide 3',
'                    </script>',
'                </section>',
'',
'                <!-- Slides are separated by regexp matching newline + three dashes + newline, vertical slides identical but two dashes -->',
'                <section data-markdown data-separator="^\n---\n$" data-separator-vertical="^\n--\n$">',
'                    <script type="text/template">',
'                        ## Demo 2',
'                        Slide 1.1',
'',
'                        --',
'',
'                        ## Demo 2',
'                        Slide 1.2',
'',
'                        ---',
'',
'                        ## Demo 2',
'                        Slide 2',
'                    </script>',
'                </section>',
'',
'                <!-- No "extra" slides, since the separator can''t be matched ("---" will become horizontal rulers) -->',
'                <section data-markdown data-separator="$x">',
'                    <script type="text/template">',
'                        A',
'',
'                        ---',
'',
'                        B',
'',
'                        ---',
'',
'                        C',
'                    </script>',
'                </section>',
'',
'                <!-- Slide attributes -->',
'                <section data-markdown>',
'                    <script type="text/template">',
'                        <!-- .slide: data-background="#000000" -->',
'                        ## Slide attributes',
'                    </script>',
'                </section>',
'',
'                <!-- Element attributes -->',
'                <section data-markdown>',
'                    <script type="text/template">',
'                        ## Element attributes',
'                        - Item 1 <!-- .element: class="fragment" data-fragment-index="2" -->',
'                        - Item 2 <!-- .element: class="fragment" data-fragment-index="1" -->',
'                    </script>',
'                </section>',
'',
'                <!-- Code -->',
'                <section data-markdown>',
'                    <script type="text/template">',
'                        ```php [1|3-5]',
'                        public function foo()',
'                        {',
'                            $foo = array(',
'                                ''bar'' => ''bar''',
'                            )',
'                        }',
'                        ```',
'                    </script>',
'                </section>',
'',
'                <!-- add optional line count offset, in this case 287 -->',
'                <section data-markdown>',
'                    <script type="text/template">',
'                        ## echo.c',
'',
'                        ```c [287: 2|4,6]',
'                        /* All of the options in this arg are valid, so handle them. */',
'                        p = arg + 1;',
'                        do {',
'                            if (*p == ''n'')',
'                                nflag = 0;',
'                            if (*p == ''e'')',
'                                eflag = ''\\'';',
'                        } while (*++p); ',
'                        ```',
'                        [source](https://git.busybox.net/busybox/tree/coreutils/echo.c?h=1_36_stable#n287)',
'                    </script>',
'                </section>',
'',
'                <!-- Images -->',
'                <section data-markdown>',
'                    <script type="text/template">',
'                        ![Sample image](https://s3.amazonaws.com/static.slid.es/logo/v2/slides-symbol-512x512.png)',
'                    </script>',
'                </section>',
'',
'                <!-- Math -->',
'                <section data-markdown>',
'					## The Lorenz Equations',
'					`\[\begin{aligned}',
'					\dot{x} &amp; = \sigma(y-x) \\',
'					\dot{y} &amp; = \rho x - y - xz \\',
'					\dot{z} &amp; = -\beta z + xy',
'					\end{aligned} \]`',
'                </section>',
'',
'            </div>',
'		</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
