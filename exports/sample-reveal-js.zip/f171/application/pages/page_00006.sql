prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>171
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'layout-helpers'
,p_alias=>'LAYOUT-HELPERS'
,p_step_title=>'layout-helpers'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.js',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/highlight/highlight.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const elm = document.querySelector(''.deck1'');',
'let deck1 = new Reveal(elm, {',
'    embedded: true,',
'	center: true,',
'	hash: true,',
'	plugins: [ RevealHighlight ]',
'});',
'deck1.initialize();'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/reveal.js/dist/reveal.min.css',
'https://cdn.jsdelivr.net/npm/reveal.js/dist/theme/white.css',
'https://cdn.jsdelivr.net/npm/reveal.js/plugin/highlight/monokai.css'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Ref: https://github.com/hakimel/reveal.js/blob/master/examples/layout-helpers.html',
'====================================================================================',
'Copyright (C) 2011-2024 Hakim El Hattab, http://hakim.se, and reveal.js contributors',
'',
'Permission is hereby granted, free of charge, to any person obtaining a copy',
'of this software and associated documentation files (the "Software"), to deal',
'in the Software without restriction, including without limitation the rights',
'to use, copy, modify, merge, publish, distribute, sublicense, and/or sell',
'copies of the Software, and to permit persons to whom the Software is',
'furnished to do so, subject to the following conditions:',
'',
'The above copyright notice and this permission notice shall be included in',
'all copies or substantial portions of the Software.',
'',
'THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR',
'IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,',
'FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE',
'AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER',
'LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,',
'OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN',
'THE SOFTWARE.'))
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(137342707711255786)
,p_plug_name=>'Deck'
,p_region_css_classes=>'w95p h600'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(68817980603643228)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'		<div class="reveal deck1">',
'',
'			<div class="slides">',
'',
'				<section>',
'					<h2>Layout Helper Examples</h2>',
'					<ul>',
'						<li><a href="#/fit-text">Big Text</a></li>',
'						<li><a href="#/stretch">Stretch</a></li>',
'						<li><a href="#/stack">Stack</a></li>',
'						<li><a href="#/hstack">HStack</a></li>',
'						<li><a href="#/vstack">VStack</a></li>',
'					</ul>',
'				</section>',
'',
'				<section id="fit-text">',
'					<h2>Fit Text</h2>',
'					<p>Resizes text to be as large as possible within its container.</p>',
'					<pre><code class="html" data-trim data-line-numbers>',
'					  <h2 class="r-fit-text">FIT</h2>',
'					</code></pre>',
'				</section>',
'',
'				<section>',
'					<h2 class="r-fit-text">FIT</h2>',
'				</section>',
'',
'				<section>',
'					<h2 class="r-fit-text">HELLO WORLD</h2>',
'					<h2 class="r-fit-text">BOTH THESE TITLES USE FIT-TEXT</h2>',
'				</section>',
'',
'				<section id="stretch">',
'					<h2>Stretch</h2>',
'					<p>Makes an element as tall as possible while remaining within the slide bounds.</p>',
'					<pre><code class="html" data-trim data-line-numbers>',
'					  <h2>Stretch Example</h2>',
'					  <img src="#APP_FILES#assets/image2.png" class="r-stretch">',
'					  <p>Image byline</p>',
'					</code></pre>',
'				</section>',
'',
'				<section>',
'					<h2>Stretch Example</h2>',
'					<img src="#APP_FILES#assets/image2.png" class="r-stretch">',
'					<p>Image byline</p>',
'				</section>',
'',
'				<section id="stack">',
'					<h2>Stack</h2>',
'					<p>Stacks multiple elements on top of each other, for use with fragments.</p>',
'					<pre><code class="html" data-trim data-line-numbers>',
'					  <div class="r-stack">',
'					    &lt;img class="fragment" width="450" height="300" src="..."&gt;',
'					    &lt;img class="fragment" width="300" height="450" src="..."&gt;',
'					    &lt;img class="fragment" width="400" height="400" src="..."&gt;',
'					  </div>',
'					</code></pre>',
'				</section>',
'',
'				<section>',
'					<h2>Stack Example</h2>',
'					<div class="r-stack">',
'						<p class="fragment fade-in-then-out">One</p>',
'						<p class="fragment fade-in-then-out">Two</p>',
'						<p class="fragment fade-in-then-out">Three</p>',
'						<p class="fragment fade-in-then-out">Four</p>',
'					</div>',
'					<div class="r-stack">',
'						<img src="https://placekitten.com/450/300" width="450" height="300" class="fragment">',
'						<img src="https://placekitten.com/300/450" width="300" height="450" class="fragment">',
'						<img src="https://placekitten.com/400/400" width="400" height="400" class="fragment">',
'					</div>',
'				</section>',
'',
'				<section>',
'					<h2>Stack Example</h2>',
'					<p>fade-in-then-out fragments</p>',
'					<div class="r-stack">',
'						<img src="https://placekitten.com/450/300" width="450" height="300" class="fragment fade-in-then-out">',
'						<img src="https://placekitten.com/300/450" width="300" height="450" class="fragment fade-in-then-out">',
'						<img src="https://placekitten.com/400/400" width="400" height="400" class="fragment fade-in-then-out">',
'					</div>',
'				</section>',
'',
'				<section id="hstack">',
'					<h2>HStack</h2>',
'					<p>Stacks multiple elements horizontally.</p>',
'					<pre><code class="html" data-trim data-line-numbers>',
'					  <div class="r-hstack">',
'					    &lt;img width="450" height="300" src="..."&gt;',
'					    &lt;img width="300" height="450" src="..."&gt;',
'					    &lt;img width="400" height="400" src="..."&gt;',
'					  </div>',
'					</code></pre>',
'				</section>',
'',
'				<section data-auto-animate>',
'					<h2>HStack Example</h2>',
'					<div class="r-hstack">',
'						<p style="padding: 0.50em; background: #eee; margin: 0.25em">One</p>',
'						<p style="padding: 0.75em; background: #eee; margin: 0.25em">Two</p>',
'						<p style="padding: 1.00em; background: #eee; margin: 0.25em">Three</p>',
'					</div>',
'				</section>',
'',
'				<section id="vstack">',
'					<h2>VStack</h2>',
'					<p>Stacks multiple elements vertically.</p>',
'					<pre><code class="html" data-trim data-line-numbers>',
'					  <div class="r-vstack">',
'					    &lt;img width="450" height="300" src="..."&gt;',
'					    &lt;img width="300" height="450" src="..."&gt;',
'					    &lt;img width="400" height="400" src="..."&gt;',
'					  </div>',
'					</code></pre>',
'				</section>',
'',
'				<section data-auto-animate>',
'					<h2>VStack Example</h2>',
'					<div class="r-vstack">',
'						<p style="padding: 0.50em; background: #eee; margin: 0.25em">One</p>',
'						<p style="padding: 0.75em; background: #eee; margin: 0.25em">Two</p>',
'						<p style="padding: 1.00em; background: #eee; margin: 0.25em">Three</p>',
'					</div>',
'				</section>',
'',
'			</div>',
'',
'		</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
