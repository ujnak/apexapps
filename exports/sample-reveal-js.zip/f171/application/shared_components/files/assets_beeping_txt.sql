prompt --application/shared_components/files/assets_beeping_txt
begin
--   Manifest
--     APP STATIC FILES: 171
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>171
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '536F757263653A2068747470733A2F2F66726565736F756E642E6F72672F70656F706C652F66656E6E656C6C696F74742F736F756E64732F3337393431392F0A4C6963656E73653A2043433020287075626C696320646F6D61696E29';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(69086058586696056)
,p_file_name=>'assets/beeping.txt'
,p_mime_type=>'text/plain'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
