prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>231
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Vector Similarity Search'
,p_alias=>'HOME'
,p_step_title=>'Pinecone'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>\3053\306E\5BFE\8A71\30B0\30EA\30C3\30C9\5185\3067\30C7\30FC\30BF\3092\76F4\63A5\633F\5165\3001\66F4\65B0\304A\3088\3073\524A\9664\3067\304D\307E\3059\3002<br>'),
unistr('  \300C\884C\306E\8FFD\52A0\300D\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\65B0\3057\3044\884C\3092\633F\5165\3067\304D\307E\3059\3002<br>'),
unistr('  \30BB\30EB\5185\3092\30C0\30D6\30EB\30AF\30EA\30C3\30AF\3059\308B\304B\3001<strong>\300C\7DE8\96C6\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\30B9\30D7\30EC\30C3\30C9\30B7\30FC\30C8\3067\30C7\30FC\30BF\3092\7DE8\96C6\3059\308B\5834\5408\3068\540C\3058\3088\3046\306B\30C7\30FC\30BF\5024\3092\66F4\65B0\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30EC\30DD\30FC\30C8\306E\4E00\756A\4E0A\306B\3042\308B\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC(<span class="fa fa-bars" aria-hidden="true"></span>)\3092\4F7F\7528\3057\3066\3001\9078\629E\3057\305F\884C\3092\8907\88FD\3001\524A\9664\3001\30EA\30D5\30EC\30C3\30B7\30E5\307E\305F\306F\56DE\5FA9\3057\307E\3059\3002<br>'),
unistr('  \500B\3005\306E\884C\306E\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\3092\4F7F\7528\3057\3066\3001\5358\4E00\884C\30D3\30E5\30FC\306B\30A2\30AF\30BB\30B9\3057\305F\308A\3001\65B0\3057\3044\884C\3092\8FFD\52A0\3057\305F\308A\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30C7\30FC\30BF\3092\898B\3064\3051\308B\306B\306F\3001\691C\7D22\30C0\30A4\30A2\30ED\30B0\306B\691C\7D22\6587\5B57\5217\3092\5165\529B\3059\308B\304B\3001\5217\30D8\30C3\30C0\30FC\3092\30AF\30EA\30C3\30AF\3057\3066\623B\3055\308C\308B\30EC\30B3\30FC\30C9\3092\5236\9650\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30A2\30AF\30B7\30E7\30F3\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\591A\304F\306E\6A5F\80FD\3092\5B9F\884C\3067\304D\307E\3059\3002\3053\308C\306B\306F\3001\8868\793A\5217\307E\305F\306F\975E\8868\793A\5217\306E\9078\629E\3068\305D\306E\8868\793A\9806\5E8F\306B\52A0\3048\3001\591A\304F\306E\30C7\30FC\30BF\304A\3088\3073\66F8\5F0F\8A2D\5B9A\6A5F\80FD\304C\542B\307E\308C\307E\3059\3002\30C1\30E3\30FC\30C8\30FB\30AA\30D7\30B7\30E7\30F3\3092\4F7F\7528\3057\3066\3001\30C7\30FC\30BF\306E\8FFD\52A0\30D3\30E5\30FC\3092\5B9A\7FA9\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\72EC\81EA\306E\30AB\30B9\30BF\30DE\30A4\30BA\5185\5BB9\3092\4FDD\5B58\3059\308B\5834\5408\3001\30EC\30DD\30FC\30C8\3092\9078\629E\3059\308B\304B\3001\300C\30C0\30A6\30F3\30ED\30FC\30C9\300D\3092\30AF\30EA\30C3\30AF\3057\3066\30C7\30FC\30BF\3092\30A2\30F3\30ED\30FC\30C9\3057\307E\3059\3002<p>'),
'',
unistr('<p>\8FFD\52A0\60C5\5831\3092\5165\624B\3059\308B\306B\306F\3001\300C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\306E\4E00\756A\4E0B\306E\300C\30D8\30EB\30D7\300D\3092\30AF\30EA\30C3\30AF\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30EA\30BB\30C3\30C8\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\5BFE\8A71\30B0\30EA\30C3\30C9\3092\30C7\30D5\30A9\30EB\30C8\8A2D\5B9A\306B\623B\3059\3053\3068\304C\3067\304D\307E\3059\3002</p>')))
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230707083751'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39444812413647142)
,p_plug_name=>'Vec Embeddings'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39223738458646885)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TEXT,',
'       EMBEDDING_ID,',
'       EMBEDDING_SEQ,',
'       json_value(embedding, ''$.size()'') EMBEDDING,',
'       VECTOR_ID,',
'       STATUS,',
'       CREATED,',
'       CREATED_BY,',
'       UPDATED,',
'       UPDATED_BY',
'  from VEC_EMBEDDINGS'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Vector Similarity Search'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39446131957647145)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39446691727647146)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>unistr('\30A2\30AF\30B7\30E7\30F3')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39447694060647149)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'ID'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39448639130647150)
,p_name=>'EMBEDDING_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMBEDDING_ID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Embedding'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>160
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39449665753647150)
,p_name=>'TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TEXT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Text'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>true
,p_max_length=>2048
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39450668273647151)
,p_name=>'EMBEDDING_SEQ'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMBEDDING_SEQ'
,p_data_type=>'NUMBER'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Embedding Seq'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39451623977647152)
,p_name=>'EMBEDDING'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMBEDDING'
,p_data_type=>'NUMBER'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Embedding'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39452628073647153)
,p_name=>'VECTOR_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VECTOR_ID'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Vector ID'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>160
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39453695070647154)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39454629707647155)
,p_name=>'CREATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39455688442647156)
,p_name=>'CREATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_BY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39456642443647156)
,p_name=>'UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPDATED'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39457631407647157)
,p_name=>'UPDATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPDATED_BY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'N'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(39445317465647143)
,p_internal_uid=>39445317465647143
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>false
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(39445738636647144)
,p_interactive_grid_id=>wwv_flow_imp.id(39445317465647143)
,p_static_id=>'394458'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>5
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(39445921006647144)
,p_report_id=>wwv_flow_imp.id(39445738636647144)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39447073208647147)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(39446691727647146)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39448059106647149)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(39447694060647149)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39449063286647150)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(39448639130647150)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39450044174647151)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(39449665753647150)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39451013727647152)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(39450668273647151)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39452025439647152)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(39451623977647152)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39453040021647153)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(39452628073647153)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39454078728647154)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(39453695070647154)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39455074565647155)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(39454629707647155)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39456019680647156)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(39455688442647156)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39457084849647157)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(39456642443647156)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39458079838647157)
,p_view_id=>wwv_flow_imp.id(39445921006647144)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(39457631407647157)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39459841792647161)
,p_plug_name=>'Pinecone'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(39235656827646891)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39500574131658302)
,p_plug_name=>'Response'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(39251461741646900)
,p_plug_display_sequence=>100
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request clob;',
'    l_response clob;',
'    l_response_json json_object_t;',
'    /* Cohere */',
'    l_embeddings json_array_t;',
'    l_embedding  json_array_t;',
'    l_embedding_id vec_embeddings.embedding_id%type;',
'    /* Pinecone */',
'    l_query_json json_object_t;',
'    l_matches json_array_t;',
'    l_vector  json_object_t;',
'    l_vector_id vec_embeddings.vector_id%type;',
'    l_score   number;',
'    l_text    vec_embeddings.text%type;',
'    C_QUERY constant varchar2(80) := :G_INDEX || ''/query'';',
'    e_query_exception exception;',
'    l_output clob;',
'begin',
'    /*',
unistr('     * \554F\5408\305B\304C\306A\3044\6642\306F\306A\306B\3082\3057\306A\3044\3002'),
'     */',
'    if :P1_QUERY is null then',
'        return '''';',
'    end if;',
'    /*',
unistr('     * \6700\521D\306BCo.Embed\3092\547C\3073\51FA\3057\3066\3001Query\306Eembedding\3092\751F\6210\3059\308B\3002'),
'     */',
'    select json_object(',
'        key ''texts'' value json_array(:P1_QUERY)',
unistr('        -- \30E2\30C7\30EB\3092\6307\5B9A\3059\308B\3002'),
'        ,key ''model''    value :P1_MODEL',
unistr('        -- \30C8\30E9\30F3\30B1\30FC\30C8\3092\6307\5B9A\3059\308B\3002'),
'        ,key ''truncate'' value :P1_TRUNCATE',
'    returning clob)',
'    into l_request',
'    from dual;',
'    /*',
unistr('     * Cohere Co.Embed\3092\547C\3073\51FA\3059\3002'),
'     * https://docs.cohere.com/reference/embed',
'     */',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'', p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => ''https://api.cohere.ai/v1/embed''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''COHERE_API''',
'    );',
'    -- apex_debug.info(l_response);',
'    l_response_json := json_object_t.parse(l_response);',
'    l_embedding_id  := l_response_json.get_string(''id'');',
'    l_embeddings    := l_response_json.get_array(''embeddings'');',
'    l_embedding     := json_array_t(l_embeddings.get(0));',
'    /*',
unistr('     * Pinecone\306B\554F\3044\5408\308F\305B\308B\3002'),
'     */',
'    l_query_json := json_object_t();',
'    l_query_json.put(''includeValues'', false);',
'    l_query_json.put(''includeMetadata'', false);',
'    l_query_json.put(''vector'', l_embedding);',
'    l_query_json.put(''topK'', :P1_TOP_K);',
'    l_request := l_query_json.to_clob;',
unistr('    /* query\3092\547C\3073\51FA\3059\3002 */'),
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'',p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'',p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_QUERY',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''PINECONE_API''',
'    );',
'    -- apex_debug.info(l_response);',
'    if apex_web_service.g_status_code <> 200 then',
'        apex_debug.info(l_response);',
'        raise e_query_exception;',
'    end if;',
'    /*',
unistr('     * \30EC\30B9\30DD\30F3\30B9\3092\52D5\7684\30B3\30F3\30C6\30F3\30C4\3068\3057\3066\5370\5237\3059\308B\3002'),
'     */',
'    l_response_json := json_object_t.parse(l_response);',
'    l_matches := l_response_json.get_array(''matches'');',
'    for i in 1..l_matches.get_size',
'    loop',
'        l_vector := json_object_t(l_matches.get(i-1));',
'        l_vector_id := l_vector.get_string(''id'');',
'        l_score     := l_vector.get_number(''score'');',
'        select text into l_text from vec_embeddings where vector_id = l_vector_id;',
'        l_output := l_output || ''<p>id = '' || l_vector_id || '', score = '' || l_score || ''</p>'';',
'        l_output := l_output || ''<p>'' || l_text || ''</p>'';',
'    end loop;',
'    return l_output;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_TOP_K,P1_QUERY'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39014576227816244)
,p_button_sequence=>50
,p_button_name=>'GENERATE_EMBEDDINGS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(39324614148646957)
,p_button_image_alt=>'Generate Embeddings (Co.Embed)'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39014917394816248)
,p_button_sequence=>60
,p_button_name=>'UPSERT_VECTORS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(39324614148646957)
,p_button_image_alt=>'Upsert Vectors'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39500657433658303)
,p_button_sequence=>90
,p_button_name=>'QUERY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(39324614148646957)
,p_button_image_alt=>'Query'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39500954375658306)
,p_button_sequence=>110
,p_button_name=>'DELETE_ALL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39324614148646957)
,p_button_image_alt=>'Delete All'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39014700265816246)
,p_name=>'P1_MODEL'
,p_item_sequence=>30
,p_item_default=>'embed-multilingual-v2.0'
,p_prompt=>'Model'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(39322106084646953)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39014868827816247)
,p_name=>'P1_TRUNCATE'
,p_item_sequence=>40
,p_item_default=>'NONE'
,p_prompt=>'Truncate'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(39322106084646953)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39015191469816250)
,p_name=>'P1_QUERY'
,p_item_sequence=>80
,p_prompt=>'Query'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(39322106084646953)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39500408387658301)
,p_name=>'P1_TOP_K'
,p_item_sequence=>70
,p_item_default=>'1'
,p_prompt=>'Top K'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(39322106084646953)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39500725014658304)
,p_name=>'onClick Query'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(39500657433658303)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39500807792658305)
,p_event_id=>wwv_flow_imp.id(39500725014658304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39500574131658302)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39459302221647160)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(39444812413647142)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Vector Similarity Search - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>39459302221647160
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39014646456816245)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generate Embeddings'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request  clob;',
'    l_response clob;',
'    l_response_json json_object_t;',
'    l_embeddings    json_array_t;',
'    l_embedding     json_array_t;',
'    l_embedding_clob clob;',
'    l_id           vec_embeddings.id%type;',
'    l_embedding_id vec_embeddings.embedding_id%type;',
'    l_count number;',
'    C_COLLECTION constant varchar2(20) := ''COHERE_EMBED_REQUEST'';',
'    e_embed_exception exception;',
'begin',
'    /*',
unistr('     * embedding\306E\751F\6210\304C\5FC5\8981\306A\30C7\30FC\30BF\3092\78BA\8A8D\3059\308B\3002'),
'     */',
'    select count(*) into l_count from vec_embeddings where embedding is null;',
'    if l_count = 0 then',
unistr('        /* embedding\304C\672A\751F\6210\306E\30C7\30FC\30BF\304C\306A\3044\305F\3081\7D42\4E86\3002 */'),
'        return;',
'    end if;',
'    /*',
unistr('     * \8868VEC_EMBEDDINGS\304B\3089\3001embedding\306E\751F\6210\5BFE\8C61\3067\3042\308B\30C7\30FC\30BF\3092APEX\30B3\30EC\30AF\30B7\30E7\30F3\306B\30B3\30D4\30FC\3059\308B\3002'),
'     */',
'    apex_collection.create_or_truncate_collection(C_COLLECTION);',
'    for r in (',
'        select id, text from vec_embeddings where embedding is null order by id',
'    )',
'    loop',
'        apex_collection.add_member(',
'            p_collection_name => C_COLLECTION',
'            ,p_n001 => r.id',
'            ,p_c001 => r.text',
'        );',
'    end loop;',
unistr('    /* \5FF5\306E\70BA\3001\30B7\30FC\30B1\30F3\30B9ID\304C1\304B\3089\9023\756A\306B\306A\308B\3088\3046\306B\3059\308B\3002 */'),
'    apex_collection.resequence_collection(C_COLLECTION);',
'    /*',
unistr('     * APEX\30B3\30EC\30AF\30B7\30E7\30F3\304B\3089Co.Embed\306E\30EA\30AF\30A8\30B9\30C8\3092\751F\6210\3059\308B\3002'),
'     */',
'    select json_object(',
'        key ''texts'' value',
'        (',
'            select json_arrayagg(c001 order by seq_id asc) from apex_collections',
'            where collection_name = C_COLLECTION',
'        )',
unistr('        -- \30E2\30C7\30EB\3092\6307\5B9A\3059\308B\3002'),
'        ,key ''model''    value :P1_MODEL',
unistr('        -- \30C8\30E9\30F3\30B1\30FC\30C8\3092\6307\5B9A\3059\308B\3002'),
'        ,key ''truncate'' value :P1_TRUNCATE',
'    returning clob)',
'    into l_request',
'    from dual;',
'    apex_debug.info(l_request);',
'    /* ',
unistr('     * Cohere Co.Embed\3092\547C\3073\51FA\3059\3002'),
'     * https://docs.cohere.com/reference/embed',
'     */',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'', p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => ''https://api.cohere.ai/v1/embed''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''COHERE_API''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        apex_debug.info(l_response);',
'        raise e_embed_exception;',
'    end if;',
'    /*',
unistr('     * \751F\6210\3055\308C\305Fembedding\3092\53D6\308A\51FA\3057\3001\8868VEC_EMBEDDINGS\306B\4FDD\5B58\3059\308B\3002'),
'     */',
'    l_response_json := json_object_t.parse(l_response);',
'    l_embedding_id  := l_response_json.get_string(''id'');',
'    l_embeddings    := l_response_json.get_array(''embeddings'');',
'    for i in 1..l_embeddings.get_size',
'    loop',
'         l_embedding := json_array_t(l_embeddings.get(i-1));',
unistr('         l_embedding_clob := l_embedding.to_clob; /* embedding\81EA\4F53\306FFLOAT\306E\914D\5217\3068\3057\3066\3001JSON\306E\307E\307E\4FDD\5B58\3059\308B\3002 */'),
'         select n001 into l_id from apex_collections where collection_name = C_COLLECTION and seq_id = i;',
'         update vec_embeddings set ',
'            embedding_id = l_embedding_id',
'            ,embedding_seq = i',
'            ,embedding = l_embedding_clob',
'         where id = l_id;',
'     end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39014576227816244)
,p_internal_uid=>39014646456816245
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39015073422816249)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Upsert Vectors'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request clob;',
'    l_request_json json_object_t;',
'    l_vectors json_array_t;',
'    l_vector  json_object_t;',
'    l_vector_id vec_embeddings.vector_id%type;',
'    l_response clob;',
'    C_UPSERT constant varchar2(100) := :G_INDEX || ''/vectors/upsert'';',
'    e_upsert_exception exception;',
'begin',
'    /*',
unistr('     * Cohere\3067\751F\6210\3057\305F\305D\308C\305E\308C\306Eembedding\304C\3001Pinecone\3067\306Evector\306B\3042\305F\308B\3002'),
unistr('     * vector\30AA\30D6\30B8\30A7\30AF\30C8(id\3068values = embedding\3092\542B\3080\30AA\30D6\30B8\30A7\30AF\30C8)\306E\914D\5217\304C\3001'),
unistr('     * Pinecone\306E\30A4\30F3\30C7\30C3\30AF\30B9\3078\306EUpsert\30EA\30AF\30A8\30B9\30C8\306B\306A\308B\3002'),
'     */',
'    l_vectors := json_array_t();',
'    for r in (',
'        select embedding_id, embedding_seq, embedding from vec_embeddings',
'        where status = ''C'' and embedding is not null',
'    )',
'    loop',
'       l_vector_id := r.embedding_id || ''-'' || r.embedding_seq;',
'       l_vector := json_object_t();',
'       l_vector.put(''id'', l_vector_id);',
'       l_vector.put(''values'', json_array_t(r.embedding));',
'       l_vectors.append(l_vector);',
'       update vec_embeddings set vector_id = l_vector_id, status = ''U''',
'       where embedding_id = r.embedding_id and embedding_seq = r.embedding_seq;',
'    end loop;',
'    l_request_json := json_object_t();',
'    l_request_json.put(''vectors'', l_vectors);',
'    l_request := l_request_json.to_clob;',
'    /*',
unistr('     * Pinecone\306EUpsert\3092\547C\3073\51FA\3059\3002'),
'     */',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'',p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'',p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_UPSERT',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''PINECONE_API''',
'    );',
unistr('    /* \30EC\30B9\30DD\30F3\30B9\672C\6587\306F\89E3\6790\4E0D\8981\3002 */'),
'    apex_debug.info(l_response);',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_upsert_exception;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39014917394816248)
,p_internal_uid=>39015073422816249
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>231
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39501093425658307)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete All Vectors'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'    C_DELETE constant varchar2(100) := :G_INDEX || ''/vectors/delete'';',
'    e_delete_exception exception;',
'begin',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'',p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'',p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_DELETE',
'        ,p_http_method => ''POST''',
'        ,p_body => ''{"deleteAll":true}''',
'        ,p_credential_static_id => ''PINECONE_API''',
'    );',
unistr('    /* \30EC\30B9\30DD\30F3\30B9\672C\6587\306F\89E3\6790\4E0D\8981\3002 */'),
'    apex_debug.info(l_response);',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_delete_exception;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39500954375658306)
,p_internal_uid=>39501093425658307
);
null;
wwv_flow_imp.component_end;
end;
/
