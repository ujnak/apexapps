prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(9422935573584280)
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Stripe Payment'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://js.stripe.com/v3/'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var stripe = Stripe(''&G_STRIPE_KEY.'');',
'var apex_path = ''&G_APEX_PATH.'';',
'var successUrl = apex_path + ''/stripe-payment/success?session='' + apex.env.APP_SESSION;',
'var cancelUrl =  apex_path + ''/stripe-payment/cancel?session='' + apex.env.APP_SESSION;',
'var customerEmail = ''&G_CUSTOMER_EMAIL.'';'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add([',
'{',
'    name: "stripe-payment",',
'    action: function( event, element, args ) {',
'        let item = { price: apex.items.P1_PRODUCT.value, quantity: Number(apex.items.P1_QUANTITY.value) };',
'        let items = [ item ];',
'        console.log(items);',
'        stripe.redirectToCheckout({',
'            lineItems: items,    ',
'            mode: ''payment'',',
'            successUrl: successUrl,',
'            cancelUrl: cancelUrl,',
'            customerEmail: customerEmail   ',
'        }).then(function (result) {',
'            if (result.error) {',
'                console.log(''Error opening Stripe payment page.'');',
'            }',
'        });',
'    }',
'}',
']);'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20220823090028'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9431511941584299)
,p_plug_name=>'Stripe Payment'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(9297302866584205)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8467534988803127)
,p_button_sequence=>30
,p_button_name=>'B_STRIPE_PAY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(9398094406584263)
,p_button_image_alt=>'Stripe Pay'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$stripe-payment"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8466869842803120)
,p_name=>'P1_PRODUCT'
,p_item_sequence=>10
,p_prompt=>'Product'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(9395553262584261)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8467479647803126)
,p_name=>'P1_QUANTITY'
,p_item_sequence=>20
,p_prompt=>'Quantity'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(9395553262584261)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
);
wwv_flow_imp.component_end;
end;
/
