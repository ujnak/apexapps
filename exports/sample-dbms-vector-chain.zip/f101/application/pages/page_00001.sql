prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7216664599291959
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample DBMS_VECTOR_CHAIN'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240514053309'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7523014969353904)
,p_plug_name=>'Sample DBMS_VECTOR_CHAIN'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7302368181353118)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7526337553355409)
,p_plug_name=>'Chunks'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7310458693353134)
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    n001 chunk_id, n002 chunk_offset, n003 chunk_length',
'    ,c001 chunk_data',
'from apex_collections where collection_name = ''CHUNKS'' '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Chunks'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(7526419674355410)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>7526419674355410
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7526518163355411)
,p_db_column_name=>'CHUNK_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Chunk Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7526664840355412)
,p_db_column_name=>'CHUNK_OFFSET'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Chunk Offset'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7526709215355413)
,p_db_column_name=>'CHUNK_LENGTH'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Chunk Length'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7526828129355414)
,p_db_column_name=>'CHUNK_DATA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Chunk Data'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(7538989370975510)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'75390'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CHUNK_ID:CHUNK_OFFSET:CHUNK_LENGTH:CHUNK_DATA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7525608990355402)
,p_button_sequence=>40
,p_button_name=>'TO_TEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(7398888192353341)
,p_button_image_alt=>'To Text'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7526165676355407)
,p_button_sequence=>70
,p_button_name=>'TO_CHUNKS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(7398888192353341)
,p_button_image_alt=>'To Chunks'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7525597429355401)
,p_name=>'P1_FILE'
,p_item_sequence=>10
,p_prompt=>'File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(7396350292353332)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7525756513355403)
,p_name=>'P1_TEXT'
,p_data_type=>'CLOB'
,p_item_sequence=>50
,p_prompt=>'Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(7396350292353332)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7525977206355405)
,p_name=>'P1_PLAINTEXT'
,p_item_sequence=>20
,p_item_default=>'true'
,p_prompt=>'Plaintext'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(7396350292353332)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'true'
,p_attribute_03=>'true'
,p_attribute_04=>'false'
,p_attribute_05=>'false'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7526077606355406)
,p_name=>'P1_CHARSET'
,p_item_sequence=>30
,p_item_default=>'UTF8'
,p_prompt=>'charset'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7396350292353332)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7526246875355408)
,p_name=>'P1_PARAMS'
,p_item_sequence=>60
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{ ',
'    "by":"vocabulary",',
'    "vocabulary":"myvocab",',
'    "max":"100",',
'    "overlap":"0",',
'    "split":"custom",',
'    "custom_list": [ "<p>" , "<s>" ],',
'    "language":"american",',
'    "normalize":"options",',
'    "norm_options": [ "WHITESPACE" ]',
'}'))
,p_prompt=>'Params'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(7396350292353332)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7525829111355404)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UTL_TO_TEXT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_content blob;',
'    l_params  json;',
'begin',
'    select blob_content into l_content',
'    from apex_application_temp_files where name = :P1_FILE;',
'    l_params := ',
'        json(',
'            json_object(',
'                key ''plaintext'' value :P1_PLAINTEXT',
'                ,key ''charset''  value :P1_CHARSET',
'            )',
'        );',
'    :P1_TEXT := dbms_vector_chain.utl_to_text(',
'        data => l_content',
'        ,params => l_params',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(7525608990355402)
,p_internal_uid=>7525829111355404
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7526983345355415)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UTL_TO_CHUNKS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_chunks vector_array_t;',
'    l_clob   clob;',
'    l_params json;',
'    l_chunk  json;',
'begin',
'    l_params := json(:P1_PARAMS);',
'    apex_collection.create_or_truncate_collection(''CHUNKS'');',
'    l_clob := :P1_TEXT;',
'    l_chunks := dbms_vector_chain.utl_to_chunks(',
'        data => l_clob',
'        ,params => l_params',
'    );',
'    for i in l_chunks.FIRST .. l_chunks.LAST',
'    loop',
'        l_chunk := json(l_chunks(i));',
'        apex_collection.add_member(',
'            p_collection_name => ''CHUNKS''',
'            ,p_n001 => json_value(l_chunk, ''$.chunk_id''     returning number)',
'            ,p_n002 => json_value(l_chunk, ''$.chunk_offset'' returning number)',
'            ,p_n003 => json_value(l_chunk, ''$.chunk_length'' returning number)',
'            ,p_c001 => json_value(l_chunk, ''$.chunk_data''   returning varchar2)',
'        );',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(7526165676355407)
,p_internal_uid=>7526983345355415
);
wwv_flow_imp.component_end;
end;
/
