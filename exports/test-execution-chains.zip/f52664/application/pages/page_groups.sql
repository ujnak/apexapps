prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 52664
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>30040104978234657984
,p_default_application_id=>52664
,p_default_id_offset=>4789681694429745162
,p_default_owner=>'WKSP_JAPANCOMMUNITY'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(8339762394187213305)
,p_group_name=>unistr('\7BA1\7406')
);
wwv_flow_imp.component_end;
end;
/
