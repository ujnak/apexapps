prompt --application/shared_components/globalization/dyntranslations
begin
--   Manifest
--     DYNAMIC TRANSLATIONS: 52664
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-16'
,p_default_workspace_id=>30040104978234657984
,p_default_application_id=>52664
,p_default_id_offset=>4789681694429745162
,p_default_owner=>'WKSP_JAPANCOMMUNITY'
);
null;
wwv_flow_imp.component_end;
end;
/
