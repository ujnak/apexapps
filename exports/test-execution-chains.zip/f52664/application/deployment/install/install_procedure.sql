prompt --application/deployment/install/install_procedure
begin
--   Manifest
--     INSTALL: INSTALL-procedure
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-16'
,p_default_workspace_id=>30040104978234657984
,p_default_application_id=>52664
,p_default_id_offset=>4789681694429745162
,p_default_owner=>'WKSP_JAPANCOMMUNITY'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9577464711680469168)
,p_install_id=>wwv_flow_imp.id(9575678974733462570)
,p_name=>'procedure'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace procedure execution_chain_step(',
'    p_message       varchar2',
'    ,p_file_item    varchar2 default null',
'    ,p_start        number   default 1',
'    ,p_end          number   default 60',
'    ,p_totalwork    number   default 60',
'    ,p_sleep        number   default 1',
')',
'as',
'    l_filename varchar2(400) := '''';',
'    l_message  abp_transactions.message%type;',
'begin',
unistr('    /* \51E6\7406\6642\9593\3092\30B7\30DF\30E5\30EC\30FC\30C8 */'),
'    for i in p_start..p_end',
'    loop',
'        dbms_session.sleep(p_sleep);',
'        apex_background_process.set_progress(p_sofar => i ,p_totalwork => p_totalwork);',
'    end loop;',
unistr('    /* \30A2\30C3\30D7\30ED\30FC\30C9\3055\308C\305F\30D5\30A1\30A4\30EB\3092\8A18\9332 */'),
'    begin',
'        select filename into l_filename',
'        from apex_application_temp_files',
'        where name = p_file_item;',
'    exception',
'        when no_data_found then',
unistr('            null; -- l_filename\306F\7A7A\306E\307E\307E'),
'    end;',
'    if l_filename is null then',
'        l_message := p_message || '' no file found for '' || p_file_item;',
'    else',
'        l_message := p_message || '' file processed for '' || l_filename;',
'    end if;',
'    insert into abp_transactions(username, message) values(sys_context(''APEX$SESSION'', ''APP_USER''),l_message);',
'end;',
'/'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(9577464833789469168)
,p_script_id=>wwv_flow_imp.id(9577464711680469168)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PROCEDURE'
,p_object_name=>'EXECUTION_CHAIN_STEP'
,p_last_updated_by=>'APEXDEV'
,p_last_updated_on=>to_date('20230428045244','YYYYMMDDHH24MISS')
,p_created_by=>'APEXDEV'
,p_created_on=>to_date('20230428045244','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
