create or replace procedure execution_chain_step(
    p_message       varchar2
    ,p_file_item    varchar2 default null
    ,p_start        number   default 1
    ,p_end          number   default 60
    ,p_totalwork    number   default 60
    ,p_sleep        number   default 1
)
as
    l_filename varchar2(400) := '';
    l_message  abp_transactions.message%type;
begin
    /* 処理時間をシミュレート */
    for i in p_start..p_end
    loop
        dbms_session.sleep(p_sleep);
        apex_background_process.set_progress(p_sofar => i ,p_totalwork => p_totalwork);
    end loop;
    /* アップロードされたファイルを記録 */
    begin
        select filename into l_filename
        from apex_application_temp_files
        where name = p_file_item;
    exception
        when no_data_found then
            null; -- l_filenameは空のまま
    end;
    if l_filename is null then
        l_message := p_message || ' no file found for ' || p_file_item;
    else
        l_message := p_message || ' file processed for ' || l_filename;
    end if;
    insert into abp_transactions(session_id, message) values(sys_context('APEX$SESSION', 'APP_SESSION'),l_message);
end;
/