prompt --application/shared_components/json_source/empdept_j
begin
--   Manifest
--     DOCUMENT SOURCE: EMPDEPT_J
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>144
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_document_source(
 p_id=>wwv_flow_imp.id(42374593075140598)
,p_name=>'EMPDEPT_J'
,p_static_id=>'empdept_j'
,p_document_source_type=>'JSON_COLLECTION'
,p_location=>'LOCAL'
,p_object_name=>'EMPDEPT_J'
,p_data_profile_id=>wwv_flow_imp.id(42374608029140598)
,p_version_scn=>19572151
);
wwv_flow_imp.component_end;
end;
/
