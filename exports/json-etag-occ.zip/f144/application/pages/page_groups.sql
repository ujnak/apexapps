prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 144
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.2'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>144
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(42357732634131265)
,p_group_name=>unistr('\7BA1\7406')
);
wwv_flow_imp.component_end;
end;
/
