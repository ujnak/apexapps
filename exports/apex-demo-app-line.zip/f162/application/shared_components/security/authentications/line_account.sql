prompt --application/shared_components/security/authentications/line_account
begin
--   Manifest
--     AUTHENTICATION: LINE Account
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>162
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(54065516416345164)
,p_name=>'LINE Account'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(53627860517233642)
,p_attribute_02=>'OPENID_CONNECT'
,p_attribute_03=>'https://access.line.me/.well-known/openid-configuration'
,p_attribute_07=>'profile'
,p_attribute_09=>'#sub# (#APEX_AUTH_NAME#)'
,p_attribute_10=>'name'
,p_attribute_11=>'N'
,p_attribute_13=>'Y'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure post_auth is',
'begin',
'  :G_DISPLAY_NAME := apex_json.get_varchar2(''name'');',
'end post_auth;'))
,p_invalid_session_type=>'LOGIN'
,p_post_auth_process=>'post_auth'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
