prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 181
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.4'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>181
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000B5494441545847637CDB68F79F610001E3A8034643603404464360D087C0975F7F19FE88A830FCF8CFC420A4AC8F5166BEBB7B';
wwv_flow_imp.g_varchar2_table(2) := '918183F11FD6B294FDE77B06CE9F1FF096B3044BC287BFB919F885C5C872C0C7B7AF18E459BF52E6800F7C8A0C62CA5A0C5FFEB33388D8856318F6E6D04A061EC69F582D7975F71A83C0A7FB43DC01A351301A02039E0B46A3E0C5E75F0C1CD2EA649584';
wwv_flow_imp.g_varchar2_table(3) := '3F9EDE6490E065A3AC20A2758399605D30EA80D110180D81D110A0750800003E38E781895428E80000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(80267449671091499)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
