prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>110
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Manage Shared LOVs'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221205131846'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11748440151224132)
,p_plug_name=>'Used Shared LOVs'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12327778784609028)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Page Item */',
'select ''PAGE_ITEM'' as type, page_id, region as region, item_name as name,',
'    lov_named_lov as LIST_OF_VALUES_NAME',
'from APEX_APPLICATION_PAGE_ITEMS',
'where workspace = :P1_WORKSPACE and application_id = :P1_APPLICATION_ID',
'    and lov_named_lov is not null',
'/* Classic Report Column */',
'union',
'select ''Classic Report'' as type, page_id, region_name as region, column_alias as name,',
'    named_list_of_values as LIST_OF_VALUES_NAME',
'from APEX_APPLICATION_PAGE_RPT_COLS',
'where workspace = :P1_WORKSPACE and application_id = :P1_APPLICATION_ID',
'    and named_list_of_values is not null',
'/* Interactive Report Columns */',
'union',
'select ''IR'' as type, page_id, region_name as region, column_alias as name,',
'    named_lov as LIST_OF_VALUES_NAME',
'from apex_APPLICATION_PAGE_IR_COL',
'where workspace = :P1_WORKSPACE and application_id = :P1_APPLICATION_ID',
'    and named_lov is not null',
'/* Interactive Grid Columns */',
'union',
'select ''IG'' as type, g.page_id, g.region_name as region, g.name, ',
'    l.LIST_OF_VALUES_NAME as LIST_OF_VALUES_NAME',
'from APEX_APPL_PAGE_IG_COLUMNS g join APEX_APPLICATION_LOVS l on g.lov_id = l.lov_id',
'where g.workspace = :P1_WORKSPACE and g.application_id = :P1_APPLICATION_ID',
'   and l.list_of_values_name is not null'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1_WORKSPACE,P1_APPLICATION_ID'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Used Shared LOVs'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(11748583162224133)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>11748583162224133
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11748613805224134)
,p_db_column_name=>'LIST_OF_VALUES_NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'List Of Values Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12444717909680403)
,p_db_column_name=>'TYPE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12444835413680404)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12444940053680405)
,p_db_column_name=>'REGION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Region'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12445037356680406)
,p_db_column_name=>'NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(12440248204660554)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'124403'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TYPE:PAGE_ID:REGION:NAME:LIST_OF_VALUES_NAME:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12436769873609092)
,p_plug_name=>'Manage Shared LOVs'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(12294718809609013)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12445124956680407)
,p_plug_name=>'Unused Shared LOVs'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12327778784609028)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with used_lovs as (',
'/* Page Item */',
'select lov_named_lov as LIST_OF_VALUES_NAME',
'from APEX_APPLICATION_PAGE_ITEMS',
'where workspace = :P1_WORKSPACE and application_id = :P1_APPLICATION_ID',
'/* Classic Report Column */',
'union',
'select named_list_of_values as LIST_OF_VALUES_NAME',
'from APEX_APPLICATION_PAGE_RPT_COLS',
'where workspace = :P1_WORKSPACE and application_id = :P1_APPLICATION_ID',
'/* Interactive Report Columns */',
'union',
'select named_lov as LIST_OF_VALUES_NAME',
'from apex_APPLICATION_PAGE_IR_COL',
'where workspace = :P1_WORKSPACE and application_id = :P1_APPLICATION_ID',
'/* Interactive Grid Columns */',
'union',
'select l.LIST_OF_VALUES_NAME as LIST_OF_VALUES_NAME',
'from APEX_APPL_PAGE_IG_COLUMNS g join APEX_APPLICATION_LOVS l on g.lov_id = l.lov_id',
'where g.workspace = :P1_WORKSPACE and g.application_id = :P1_APPLICATION_ID',
')',
'select LIST_OF_VALUES_NAME from APEX_APPLICATION_LOVS',
'where workspace = :P1_WORKSPACE and application_id = :P1_APPLICATION_ID',
'minus select list_of_values_name from used_lovs'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1_WORKSPACE,P1_APPLICATION_ID'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Unused Shared LOVs'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(12445237249680408)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>12445237249680408
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12445309045680409)
,p_db_column_name=>'LIST_OF_VALUES_NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'List Of Values Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(12471712826734879)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'124718'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LIST_OF_VALUES_NAME'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11748280261224130)
,p_name=>'P1_WORKSPACE'
,p_item_sequence=>10
,p_prompt=>'Workspace'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select workspace d, workspace r from apex_workspaces order by workspace'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Choose Workspace --'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(12398127745609063)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11748358037224131)
,p_name=>'P1_APPLICATION_ID'
,p_item_sequence=>20
,p_prompt=>'Application'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select application_name d, application_id r from apex_applications',
'where workspace = :P1_WORKSPACE'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Choose Application --'
,p_lov_cascade_parent_items=>'P1_WORKSPACE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(12398127745609063)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11748716757224135)
,p_name=>unistr('\30EC\30DD\30FC\30C8\306E\30EA\30D5\30EC\30C3\30B7\30E5')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_APPLICATION_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11748801940224136)
,p_event_id=>wwv_flow_imp.id(11748716757224135)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('Used Shared LOVs\306E\30EA\30D5\30EC\30C3\30B7\30E5')
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11748440151224132)
);
wwv_flow_imp.component_end;
end;
/
