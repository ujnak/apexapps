prompt --application/deployment/install/install_nktable
begin
--   Manifest
--     INSTALL: INSTALL-nktable
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.2'
,p_default_workspace_id=>14753839747585513
,p_default_application_id=>115
,p_default_id_offset=>36703795117236011
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(70558432455007500)
,p_install_id=>wwv_flow_imp.id(70557929031001755)
,p_name=>'nktable'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- create tables',
'create table nk_test (',
'    code                           varchar2(8 char) not null constraint nk_test_code_pk primary key,',
'    name                           varchar2(80 char)',
')',
';',
'',
'-- load data',
''))
);
wwv_flow_imp.component_end;
end;
/
