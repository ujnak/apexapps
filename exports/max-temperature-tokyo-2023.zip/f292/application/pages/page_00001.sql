prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>292
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\6771\4EAC\306E\6700\9AD8\6C17\6E29')
,p_alias=>'HOME'
,p_step_title=>unistr('\6771\4EAC\306E\6700\9AD8\6C17\6E29')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231013065630'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(106799842942083044)
,p_plug_name=>unistr('\6771\4EAC\306E\6700\9AD8\6C17\6E29(2022&2023)')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(107545518726151709)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    sample_date',
'    ,max_temp_2023',
'    ,max_temp_2022',
'from',
'(',
'    select',
'        city',
'        ,sample_date',
'        ,max_temperature max_temp_2023',
unistr('        /* LAG\95A2\6570\3092\4F7F\3063\3066365\65E5\524D\FF08\958F\5E74\3067\3042\308C\3070366)\3001\3064\307E\308A\6628\5E74\306E\6700\9AD8\6C17\6E29\3092\53C2\7167\3059\308B\3002 */'),
'        ,lag(max_temperature, 365, null)',
'            over (partition by city order by sample_date) max_temp_2022',
'    from opm_temperatures',
')',
'where sample_date between date''2023-06-01'' and date''2023-10-01''',
'order by sample_date asc'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(106799959088083045)
,p_region_id=>wwv_flow_imp.id(106799842942083044)
,p_chart_type=>'line'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(106800061729083046)
,p_chart_id=>wwv_flow_imp.id(106799959088083045)
,p_seq=>10
,p_name=>unistr('2023\5E74')
,p_max_row_count=>10000
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'MAX_TEMP_2023'
,p_items_label_column_name=>'SAMPLE_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(106800488640083050)
,p_chart_id=>wwv_flow_imp.id(106799959088083045)
,p_seq=>20
,p_name=>unistr('2022\5E74')
,p_max_row_count=>10000
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'MAX_TEMP_2022'
,p_items_label_column_name=>'SAMPLE_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(106800100949083047)
,p_chart_id=>wwv_flow_imp.id(106799959088083045)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'date-short'
,p_numeric_pattern=>'M-d'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(106800299720083048)
,p_chart_id=>wwv_flow_imp.id(106799959088083045)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107804741017151933)
,p_plug_name=>unistr('\6771\4EAC\306E\6700\9AD8\6C17\6E29')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(107545518726151709)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(107805134879151934)
,p_region_id=>wwv_flow_imp.id(107804741017151933)
,p_chart_type=>'line'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(107806867218151937)
,p_chart_id=>wwv_flow_imp.id(107805134879151934)
,p_seq=>10
,p_name=>unistr('2023\5E74')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    sample_date',
'    ,max_temperature',
'from opm_temperatures',
'where sample_date between date''2023-06-01'' and date''2023-10-01''',
'order by sample_date asc'))
,p_max_row_count=>10000
,p_items_value_column_name=>'MAX_TEMPERATURE'
,p_items_label_column_name=>'SAMPLE_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(107805617340151935)
,p_chart_id=>wwv_flow_imp.id(107805134879151934)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'date-short'
,p_numeric_pattern=>'M-d'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(107806297092151936)
,p_chart_id=>wwv_flow_imp.id(107805134879151934)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>true
,p_zoom_order_weeks=>true
,p_zoom_order_months=>true
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107808678800151943)
,p_plug_name=>unistr('\6771\4EAC\306E\6700\9AD8\6C17\6E29')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(107628678324151756)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107825102296514907)
,p_plug_name=>unistr('\6771\4EAC\306E\6700\9AD8\6C17\6E29\306E\5DEE\5206(2023-2022)')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(107545518726151709)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    sample_date',
'    ,max_temp_2023',
'    ,max_temp_2022',
'    ,(max_temp_2023 - max_temp_2022) max_temp_diff',
'from',
'(',
'    select',
'        city',
'        ,sample_date',
'        ,max_temperature max_temp_2023',
unistr('        /* LAG\95A2\6570\3092\4F7F\3063\3066365\65E5\524D\FF08\958F\5E74\3067\3042\308C\3070366)\3001\3064\307E\308A\6628\5E74\306E\6700\9AD8\6C17\6E29\3092\53C2\7167\3059\308B\3002 */'),
'        ,lag(max_temperature, 365, null)',
'            over (partition by city order by sample_date) max_temp_2022',
'    from opm_temperatures',
')',
'where sample_date between date''2023-06-01'' and date''2023-10-01''',
'order by sample_date asc'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(107825232212514908)
,p_region_id=>wwv_flow_imp.id(107825102296514907)
,p_chart_type=>'line'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(107825328499514909)
,p_chart_id=>wwv_flow_imp.id(107825232212514908)
,p_seq=>10
,p_name=>'2023 - 2022'
,p_max_row_count=>10000
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'MAX_TEMP_DIFF'
,p_items_label_column_name=>'SAMPLE_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(107825584930514911)
,p_chart_id=>wwv_flow_imp.id(107825232212514908)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'date-short'
,p_numeric_pattern=>'M-d'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(107825629923514912)
,p_chart_id=>wwv_flow_imp.id(107825232212514908)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107826998625514925)
,p_plug_name=>unistr('\6771\4EAC\306E\6700\9AD8\6C17\6E29(2022&2023)')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(107545518726151709)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    sample_date',
unistr('    /* 2023\5E74\306E\6700\9AD8\6C17\6E29\306E7\65E5\9593\79FB\52D5\5E73\5747 */'),
'    ,avg(max_temp_2023) over (order by sample_date asc range between interval ''6'' day preceding and current row) max_temp_2023',
unistr('    /* 2022\5E74\306E\6700\9AD8\6C17\6E29\306E\FF17\65E5\9593\79FB\52D5\5E73\5747 */'),
'    ,avg(max_temp_2022) over (order by sample_date asc range between interval ''6'' day preceding and current row) max_temp_2022',
'from',
'(',
'    select',
'        city',
'        ,sample_date',
'        ,max_temperature max_temp_2023',
unistr('        /* LAG\95A2\6570\3092\4F7F\3063\3066365\65E5\524D\FF08\958F\5E74\3067\3042\308C\3070366)\3001\3064\307E\308A\6628\5E74\306E\6700\9AD8\6C17\6E29\3092\53C2\7167\3059\308B\3002 */'),
'        ,lag(max_temperature, 365, null)',
'            over (partition by city order by sample_date) max_temp_2022',
'    from opm_temperatures',
')',
'where sample_date between date''2023-06-01'' and date''2023-10-01''',
'order by sample_date asc'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(107827017932514926)
,p_region_id=>wwv_flow_imp.id(107826998625514925)
,p_chart_type=>'line'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(107827121035514927)
,p_chart_id=>wwv_flow_imp.id(107827017932514926)
,p_seq=>10
,p_name=>unistr('2023\5E74')
,p_max_row_count=>10000
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'MAX_TEMP_2023'
,p_items_label_column_name=>'SAMPLE_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(107827215969514928)
,p_chart_id=>wwv_flow_imp.id(107827017932514926)
,p_seq=>20
,p_name=>unistr('2022\5E74')
,p_max_row_count=>10000
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'MAX_TEMP_2022'
,p_items_label_column_name=>'SAMPLE_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(107827325658514929)
,p_chart_id=>wwv_flow_imp.id(107827017932514926)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'date-short'
,p_numeric_pattern=>'M-d'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(107827485407514930)
,p_chart_id=>wwv_flow_imp.id(107827017932514926)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107827533002514931)
,p_plug_name=>unistr('\6771\4EAC\306E\6700\9AD8\6C17\6E29\306E\5DEE\5206(2023-2022)')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(107545518726151709)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    sample_date',
'    ,max_temp_2023',
'    ,max_temp_2022',
'    ,(max_temp_2023 - max_temp_2022) max_temp_diff',
'from',
'(',
'    select',
'        sample_date',
unistr('        /* 2023\5E74\306E\6700\9AD8\6C17\6E29\306E7\65E5\9593\79FB\52D5\5E73\5747 */'),
'        ,avg(max_temp_2023) over (order by sample_date asc range between interval ''6'' day preceding and current row) max_temp_2023',
unistr('        /* 2022\5E74\306E\6700\9AD8\6C17\6E29\306E\FF17\65E5\9593\79FB\52D5\5E73\5747 */'),
'        ,avg(max_temp_2022) over (order by sample_date asc range between interval ''6'' day preceding and current row) max_temp_2022',
'    from',
'    (',
'        select',
'            city',
'            ,sample_date',
'            ,max_temperature max_temp_2023',
unistr('            /* LAG\95A2\6570\3092\4F7F\3063\3066365\65E5\524D\FF08\958F\5E74\3067\3042\308C\3070366)\3001\3064\307E\308A\6628\5E74\306E\6700\9AD8\6C17\6E29\3092\53C2\7167\3059\308B\3002 */'),
'            ,lag(max_temperature, 365, null)',
'                over (partition by city order by sample_date) max_temp_2022',
'        from opm_temperatures',
'    )',
'    where sample_date between date''2023-06-01'' and date''2023-10-01''',
')',
'order by sample_date asc'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(107827683886514932)
,p_region_id=>wwv_flow_imp.id(107827533002514931)
,p_chart_type=>'line'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(107827788002514933)
,p_chart_id=>wwv_flow_imp.id(107827683886514932)
,p_seq=>10
,p_name=>'2023 - 2022'
,p_max_row_count=>10000
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'MAX_TEMP_DIFF'
,p_items_label_column_name=>'SAMPLE_DATE'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(107827872145514934)
,p_chart_id=>wwv_flow_imp.id(107827683886514932)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'date-short'
,p_numeric_pattern=>'M-d'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(107827901512514935)
,p_chart_id=>wwv_flow_imp.id(107827683886514932)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp.component_end;
end;
/
