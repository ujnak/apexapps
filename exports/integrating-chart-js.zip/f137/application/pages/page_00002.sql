prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>137
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Template Component'
,p_alias=>'TEMPLATE-COMPONENT'
,p_step_title=>'Template Component'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32504432502296665)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32304907864135609)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(32189234172135336)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(32367712686135767)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64082133588302885)
,p_plug_name=>'Chart.js'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32292561493135582)
,p_plug_display_sequence=>30
,p_location=>null
,p_template_component_type=>'PARTIAL'
,p_plug_source_type=>'TMPL_CHART_JS_BAR_CHART'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'COLOR', '#309fdb',
  'GROUPS', 'P2_GROUPS',
  'ORIENTATION', 'y',
  'VALUE', 'P2_VALUE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64083843233302906)
,p_name=>'P2_GROUPS'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64083946243302907)
,p_name=>'P2_VALUE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(32505857687296676)
,p_computation_sequence=>10
,p_computation_item=>'P2_GROUPS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        ename',
'    order by empno asc )',
'from emp where deptno = 10'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(32506229468296677)
,p_computation_sequence=>20
,p_computation_item=>'P2_VALUE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        sal',
'    order by empno asc )',
'from emp where deptno = 10'))
);
wwv_flow_imp.component_end;
end;
/
