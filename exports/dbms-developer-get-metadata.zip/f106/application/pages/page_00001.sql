prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>7739405930131605
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Get Metadata'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24170443667501324)
,p_plug_name=>'Get Metadata'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10943322330491522)
,p_button_sequence=>20
,p_button_name=>'PLSQL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'PLSQL'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10943622016491525)
,p_button_sequence=>30
,p_button_name=>'JAVASCRIPT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'JavaScript'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10943253606491521)
,p_name=>'P1_TABLE'
,p_item_sequence=>10
,p_prompt=>'Table'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select table_name from user_tables order by 1 asc'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10943481607491523)
,p_name=>'P1_COLUMNS'
,p_item_sequence=>40
,p_prompt=>'Columns'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10943571429491524)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PLSQL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_json json;',
'   l_columns varchar2(32767);',
'begin',
'    select dbms_developer.get_metadata(:P1_TABLE) into l_json;',
'    select json_arrayagg(name) into l_columns from',
'    (',
'        select name from json_table(',
'            l_json,',
'            ''$.objectInfo.columns[*]''',
'            columns',
'            name varchar2(40) path ''$.name''',
'        )',
'    );',
'    :P1_COLUMNS := l_columns;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10943322330491522)
,p_internal_uid=>10943571429491524
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10943822574491527)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'JS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const dbmsDeveloper = plsffi.resolvePackage(''DBMS_DEVELOPER'');',
'const metadata = dbmsDeveloper.get_metadata(apex.env.P1_TABLE);',
'const columns = metadata.objectInfo.columns;',
'const columnNames = columns.map(column => column.name);',
'apex.env.P1_COLUMNS = JSON.stringify(columnNames);'))
,p_process_clob_language=>'JAVASCRIPT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10943622016491525)
,p_internal_uid=>10943822574491527
);
wwv_flow_imp.component_end;
end;
/
