prompt --application/shared_components/security/authorizations/has_23_db
begin
--   Manifest
--     SECURITY SCHEME: Has 23+ DB
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(6356421387844921770)
,p_name=>'Has 23+ DB'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>'return sys.dbms_db_version.version >= 23;'
,p_version_scn=>41750799145127
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
