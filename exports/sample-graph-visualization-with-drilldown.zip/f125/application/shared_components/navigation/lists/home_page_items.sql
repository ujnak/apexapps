prompt --application/shared_components/navigation/lists/home_page_items
begin
--   Manifest
--     LIST: Home Page Items
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(4606781149012032809)
,p_name=>'Home Page Items'
,p_list_status=>'PUBLIC'
,p_version_scn=>41750799143878
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(260335887692381933)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>'Basic Graph'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-radar-chart'
,p_security_scheme=>wwv_flow_imp.id(6356421387844921770)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'11'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(262336303468736674)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>'Interaction'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-hand-pointer-o'
,p_security_scheme=>wwv_flow_imp.id(6356421387844921770)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(263338035384111770)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'Selection'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-square-selected-o'
,p_security_scheme=>wwv_flow_imp.id(6356421387844921770)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(264339675998186990)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>'Network Evolution'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-play'
,p_security_scheme=>wwv_flow_imp.id(6356421387844921770)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(264736282432263835)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>'Styling'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-paint-brush'
,p_security_scheme=>wwv_flow_imp.id(6356421387844921770)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'15'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(267536214215543460)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>'Saving Graph State'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-save'
,p_security_scheme=>wwv_flow_imp.id(6356421387844921770)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(199305513715633080)
,p_list_item_display_sequence=>340
,p_list_item_link_text=>'Keyboard Navigation Shortcuts'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-hand-pointer-o'
,p_security_scheme=>wwv_flow_imp.id(6356421387844921770)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(78545883472099222)
,p_list_item_display_sequence=>350
,p_list_item_link_text=>'Geographical Layout'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-map'
,p_security_scheme=>wwv_flow_imp.id(6356421387844921770)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
