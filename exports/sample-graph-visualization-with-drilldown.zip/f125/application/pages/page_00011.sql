prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Basic Graph - 23c'
,p_alias=>'BASIC-GRAPH'
,p_step_title=>'Basic Graph'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(6356421387844921770)
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(259019582264401223)
,p_plug_name=>'Query from Property Graph'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Please note that pagination needs the GVT plugin instance''s Attributes > ''SQL Query supports Pagination'' property to be turned on in APEX. Page size is configured in Attributes > Page Size.<br></br>',
'',
'<li>Select Property Graph as source type.</li>',
'<li>Select Graph Name.</li>',
'<li>Take below query as example. Fill in MATCH clause and COLUMNS clause.</li>',
'<li>Fill in WHERE clause(optional).</li>',
'<br></br>',
'<code>/*  In the below query, data is selected from Property Graph and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.*/',
'    ',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(259019631910401224)
,p_plug_name=>'Query from Property Graph'
,p_parent_plug_id=>wwv_flow_imp.id(259019582264401223)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'GRAPH'
,p_query_table=>'EBA_SAMPLE_GRAPH'
,p_query_match=>'(m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)'
,p_query_columns=>'vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager'
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'Y',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(259019713297401225)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(259019837198401226)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(259019953827401227)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7639208780728752333)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>10
,p_plug_source=>'On this page, we see the example of a Property Graph. <p>Below are some ways by which you can interact with the graph: <ul><li>Click on the graph''s vertices to select them individually. </li><li>Draw selection around vertices to perform multi-select.'
||'</li><li>Click and drag vertices to move them within the graph.</li><li>Right-click a vertex or an edge to see more details.</li><li>Hover over the icons to view explanations for each icon.</li></ul>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8980929145006481801)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12039918748870076938)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23543377549263178831)
,p_plug_name=>'SQL Query'
,p_region_name=>'dbt-details'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Please note that pagination needs the GVT plugin instance''s Attributes > ''SQL Query supports Pagination'' property to be turned on in APEX. Page size is configured in Attributes > Page Size.<br></br>',
'',
'<strong>SQL/PGQ query</strong>',
'<br>',
'<code>/*  In the below query, data is selected from Property Graph and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.*/',
'    ',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16805069916431258162)
,p_plug_name=>'Graph from tables'
,p_parent_plug_id=>wwv_flow_imp.id(23543377549263178831)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'Y',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201701082433403822)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201701099089403823)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201701268971403824)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23543378073742178837)
,p_plug_name=>'Graph from Property Graph'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source=>'In the below example, data is selected from Property Graph with JSON format that the Graph Visualization Toolkit (GVT) plugin accepts, i.e., as vertices, edges, etc.<br><br>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29683882605591577957)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp.component_end;
end;
/
