prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Interaction - 23c'
,p_alias=>'INTERACTION-23C'
,p_step_title=>'Interaction'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[defer]#APP_FILES#js/graphDrillDown#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(6356421387844921770)
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190627615177293292)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The Search feature allows users to type in a search keyword and find the matching vertices ',
'and edges among the graph nodes. The vertices and edges that match the user input gets highlighted, ',
'making it easier for the user to locate them in the graph region. The plugin offers a search field to capture ',
'keyword and initiate search, a built-in search logic that can identify and highlight matching vertices ',
'or edges from the graph data, and the option to let the consuming application externalize the search logic.',
'<br/><br/>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190627697216293293)
,p_plug_name=>'Search'
,p_parent_plug_id=>wwv_flow_imp.id(190627615177293292)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'When the user initiates a search in the keyword field, plugin performs',
' a ''starts with'' comparison using the keyword, on the attributes of all vertices and edges in the graph. ',
' The matching vertices/edges are then highlighted inside the graph region. <br></br>',
'',
'<strong>Attributes > Settings </strong>',
'<code>',
'{"searchEnabled" : true}',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190627840428293294)
,p_plug_name=>'Search'
,p_parent_plug_id=>wwv_flow_imp.id(190627615177293292)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "vertex": {',
    '        "size": 12,',
    '        "label": "${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '        "color": "${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '        "icon": "fa-user",',
    '        "legend": "${properties.JOB_TITLE}",',
    '        "children": {',
    '            "salary": {',
    '                "size": 8,',
    '                "color": "${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '                "icon": {',
    '                    "class": "fa-money",',
    '                    "color": "black"',
    '                },',
    '                "border": {',
    '                    "width": 1,',
    '                    "color": "#FB8500"',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[!!properties.COUNTRY_ID]": {',
    '        "children": {',
    '            "flag": {',
    '                "size": 10,',
    '                "image": {',
    '                    "url": "https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '                    "scale": 0.8',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]": {',
    '        "icon": "fa-user-secret"',
    '    },',
    '    "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'Y',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(190627886856293295)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(190627979206293296)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(190628079753293297)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190628219283293298)
,p_plug_name=>'Smart Group'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The Smart Group feature allows users to group vertices that satisfies specified conditions on graph properties. The conditions can include: <br>',
'1. vertices match certain vertex conditions.<br>',
'2. vertices are connected to each other with an edge fulfilling certain edge condition.',
'<br><br/>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(175966808402202903)
,p_plug_name=>'Automatic Smart Group'
,p_parent_plug_id=>wwv_flow_imp.id(190628219283293298)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_02', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '"smartGroups":[',
    '        {',
    '        "_id": 582378657398,',
    '        "name": "Automatic Group by DEPARTMENT_ID",',
    '        "type": "group",',
    '        "automatic": true,',
    '        "enabled": true,',
    '        "groupBy": "DEPARTMENT_ID",',
    '        "conditions": {',
    '          "conditions": [],',
    '          "operator": "and"',
    '        }',
    '        }]',
    '}')),
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "vertex": {',
    '        "size": 12,',
    '        "label": "${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '        "color": "${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '        "icon": "fa-user",',
    '        "legend": "${properties.JOB_TITLE}",',
    '        "children": {',
    '            "salary": {',
    '                "size": 8,',
    '                "color": "${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '                "icon": {',
    '                    "class": "fa-money",',
    '                    "color": "black"',
    '                },',
    '                "border": {',
    '                    "width": 1,',
    '                    "color": "#FB8500"',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[!!properties.COUNTRY_ID]": {',
    '        "children": {',
    '            "flag": {',
    '                "size": 10,',
    '                "image": {',
    '                    "url": "https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '                    "scale": 0.8',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]": {',
    '        "icon": "fa-user-secret"',
    '    },',
    '    "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(175966872582202904)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(175967004779202905)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(175967112114202906)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190628281036293299)
,p_plug_name=>'Manual Smart Group'
,p_parent_plug_id=>wwv_flow_imp.id(190628219283293298)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'User can expand the drop down button and pick the smart group of their choice from smart group options menu. ',
'As the user proceeds to click the group button, grouping of vertices happens based on the chosen smart group option.',
'Smart group options are passed into plugin via the smart group settings, and are filtered based on the setting''s property "automatic" = false. In below example, when the user picks the smart group option of the user''s choice from the drop down menu, '
||'vertices will be grouped by DEPARTMENT_ID or JOB_TITLE.',
'Click Smart Group dropdown button beside Group Icon and choose from the list. Then click Group icon to see the Smart Group result.',
'To switch between smart group settings, please ungroup first, then reselect from the smart group list.',
'<br></br>',
'<strong>Attributes > Settings </strong>',
'<code>',
'{"smartGroups":[',
'    {',
'        "_id": 582378657398,',
'        "name": "Manual Group by DEPARTMENT_ID",',
'        "type": "group",',
'        "automatic": false,',
'        "enabled": true,',
'        "groupBy": "DEPARTMENT_ID",',
'        "conditions": {',
'          "conditions": [],',
'          "operator": "and"',
'        }',
'    },',
'    {',
'       "_id": 45245237398,',
'        "name": "Manual Group by JOB_TITLE",',
'        "type": "group",',
'        "automatic": false,',
'        "enabled": true,',
'        "groupBy": "JOB_TITLE",',
'        "conditions": {',
'          "conditions": [],',
'          "operator": "and"',
'        }',
'    }',
']',
'}',
'</code>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190628401539293300)
,p_plug_name=>'Manual Smart Group'
,p_parent_plug_id=>wwv_flow_imp.id(190628219283293298)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_02', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '"smartGroups":[',
    '        {',
    '        "_id": 582378657398,',
    '        "name": "Manual Group by DEPARTMENT_ID",',
    '        "type": "group",',
    '        "automatic": false,',
    '        "enabled": true,',
    '        "groupBy": "DEPARTMENT_ID",',
    '        "conditions": {',
    '          "conditions": [],',
    '          "operator": "and"',
    '        }',
    '      },',
    '      {',
    '       "_id": 45245237398,',
    '        "name": "Manual Group by JOB_TITLE",',
    '        "type": "group",',
    '        "automatic": false,',
    '        "enabled": true,',
    '        "groupBy": "JOB_TITLE",',
    '        "conditions": {',
    '          "conditions": [],',
    '          "operator": "and"',
    '        }',
    '      }',
    ']',
    '}')),
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "vertex": {',
    '        "size": 12,',
    '        "label": "${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '        "color": "${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '        "icon": "fa-user",',
    '        "legend": "${properties.JOB_TITLE}",',
    '        "children": {',
    '            "salary": {',
    '                "size": 8,',
    '                "color": "${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '                "icon": {',
    '                    "class": "fa-money",',
    '                    "color": "black"',
    '                },',
    '                "border": {',
    '                    "width": 1,',
    '                    "color": "#FB8500"',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[!!properties.COUNTRY_ID]": {',
    '        "children": {',
    '            "flag": {',
    '                "size": 10,',
    '                "image": {',
    '                    "url": "https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '                    "scale": 0.8',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]": {',
    '        "icon": "fa-user-secret"',
    '    },',
    '    "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(190628471272293301)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(190628643756293302)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(190628739574293303)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190628806719293304)
,p_plug_name=>'Automatic Smart Group'
,p_parent_plug_id=>wwv_flow_imp.id(190628219283293298)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The user can activate automatic smart group option by the setting''s property "automatic" = true.',
'In below example, plugin is passed with smart group setting with "automatic"=true and "groupBy"="DEPARTMENT_ID" and those vertices with same DEPARTMENT_ID will be grouped instantly after loading the graph.',
'<br></br>',
'<strong>Attributes > Settings </strong>',
'<code>',
'{"smartGroups":[',
'    {',
'        "_id": 582378657398,',
'        "name": "Automatic Group by DEPARTMENT_ID",',
'        "type": "group",',
'        "automatic": true,',
'        "enabled": true,',
'        "groupBy": "DEPARTMENT_ID",',
'        "conditions": {',
'          "conditions": [],',
'          "operator": "and"',
'        }',
'      }',
'    ]',
'}',
'</code>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8983517707865927173)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12039918748870076938)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14364070963803129678)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>10
,p_plug_source=>'This page shows the different ways that you can interact with the graph.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23545579670521533506)
,p_plug_name=>'Basic Interaction'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The below example shows how you can interact with the graph by switching layouts etc.',
'<br/><br/>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17119386226976899753)
,p_plug_name=>'Interaction'
,p_region_name=>'graph'
,p_parent_plug_id=>wwv_flow_imp.id(23545579670521533506)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "vertex": {',
    '        "size": 12,',
    '        "label": "${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '        "color": "${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '        "icon": "fa-user",',
    '        "legend": "${properties.JOB_TITLE}",',
    '        "children": {',
    '            "salary": {',
    '                "size": 8,',
    '                "color": "${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '                "icon": {',
    '                    "class": "fa-money",',
    '                    "color": "black"',
    '                },',
    '                "border": {',
    '                    "width": 1,',
    '                    "color": "#FB8500"',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[!!properties.COUNTRY_ID]": {',
    '        "children": {',
    '            "flag": {',
    '                "size": 10,',
    '                "image": {',
    '                    "url": "https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '                    "scale": 0.8',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]": {',
    '        "icon": "fa-user-secret"',
    '    },',
    '    "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'Y',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201701397159403825)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201701400125403826)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201701540473403827)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23545576586990533475)
,p_plug_name=>'Details'
,p_parent_plug_id=>wwv_flow_imp.id(23545579670521533506)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Interaction depicted in this example, is achieved by changing the ''Settings'' property of the component / plugin at runtime. The buttons in the page ''Force'', ''Radial'' etc has Dynamic actions that updates the Settings value of the component and the gra'
||'ph reflects the change.',
'<br><br><strong>',
'Example:',
'</strong><br>',
'''Force'' button''s dynamic action triggers this:',
'<br>',
'<code>',
'const { self } = apex.region(''graph'');',
'self.settings = { ...self.settings, layout: ''force'' };',
'</code>',
'<br/>',
'Please note that pagination needs the GVT plugin instance''s Attributes > ''SQL Query supports Pagination'' property to be turned on in APEX. Page size is configured in Attributes > Page Size.<br></br>',
'<strong>Query:</strong>',
'<br>',
'<code>',
'/*  ',
'    Interaction depicted by this example, is achieved via ''Settings'' parameter',
'    controlled via buttons in the page, and isn''t affected by the query.',
'',
'    In the below query, data is selected from Property Graph and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.*/',
'    ',
'    SELECT employee,e, manager',
'    FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'    MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'    COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
'    )',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23545579812987533507)
,p_plug_name=>'Expanding Nodes'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The below examples shows how the ''Expand'' function can be used to fetch adjacent elements of a node. ',
'''Expand'' can be triggered on a node by selecting it, and choosing ''Expand'' from the toolbar or the context-menu.',
'<br/><br/>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23545579099053533500)
,p_plug_name=>'Javascript fetching data'
,p_parent_plug_id=>wwv_flow_imp.id(23545579812987533507)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This example shows how node expansion can be done, when the expanded data is supplied through javascript.',
'<br/><br/>',
'Attributes > Expand attribute of GVT should be supplied with the javascript, that will fetch data during node ''Expand''.',
'<br/><br/>',
'Notice: Expanded nodes from this example are generated from a random number. PL/SQL fetching data example shows expanded nodes in same graph.',
'',
'',
'<br/>',
'<br/>',
'<strong>',
'Attributes> Expand ',
'</strong>',
'',
'<br/><br/>',
'// fetch logic randomized. Replace with actual fetched data',
'<br>',
'<code>',
'let fetchedVertexId = Math.floor(Math.random() * 1000 + 1000);',
'let edgeId = Math.floor(Math.random() * 1000 + 1000);',
'return {',
'    vertices: [{',
'        id: ids[0], // the source/expanded vertex',
'    }, {',
'        id: fetchedVertexId,',
'        properties: {',
'            FIRST_NAME: "Expanded",',
'            LAST_NAME: fetchedVertexId',
'        }',
'    }],',
'    edges: [{ id: edgeId, source: ids[0], target: fetchedVertexId }]',
'}',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23545579262468533502)
,p_plug_name=>'Expand'
,p_region_name=>'GRAPHVIZ'
,p_parent_plug_id=>wwv_flow_imp.id(23545579812987533507)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "vertex": {',
    '        "size": 12,',
    '        "label": "${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '        "color": "${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '        "icon": "fa-user",',
    '        "legend": "${properties.JOB_TITLE}",',
    '        "children": {',
    '            "salary": {',
    '                "size": 8,',
    '                "color": "${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '                "icon": {',
    '                    "class": "fa-money",',
    '                    "color": "black"',
    '                },',
    '                "border": {',
    '                    "width": 1,',
    '                    "color": "#FB8500"',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[!!properties.COUNTRY_ID]": {',
    '        "children": {',
    '            "flag": {',
    '                "size": 10,',
    '                "image": {',
    '                    "url": "https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '                    "scale": 0.8',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]": {',
    '        "icon": "fa-user-secret"',
    '    },',
    '    "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_11', wwv_flow_string.join(wwv_flow_t_varchar2(
    'let fetchedVertexId = Math.floor(Math.random() * 1000 + 1000);',
    'let edgeId = Math.floor(Math.random() * 1000 + 1000);',
    'return {',
    '    vertices: [{',
    '        id: ids[0], // the source/expanded vertex',
    '    }, {',
    '        id: fetchedVertexId,',
    '        properties: {',
    '            FIRST_NAME: "Expanded",',
    '            LAST_NAME: fetchedVertexId',
    '        }',
    '    }],',
    '    edges: [{ id: edgeId, source: ids[0], target: fetchedVertexId }]',
    '}')),
  'attribute_14', 'Y',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201701606340403828)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201701749575403829)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201701865838403830)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23545579393293533503)
,p_plug_name=>'PL/SQL fetching data'
,p_parent_plug_id=>wwv_flow_imp.id(23545579812987533507)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This example shows how node expansion can be done, when the expanded data is supplied through PL/SQL.',
'<br/><br/>',
'Attributes > Expand attribute of GVT should be supplied with the javascript that invokes a process containing the PL/SQL.',
'',
'<br/>',
'<br/>',
'<strong>',
'Attributes> Expand ',
'</strong>',
'',
'<br/>',
'<code>',
'const data = await apex.server.process(''Expand'', {',
'    f01: ids',
'}, { dataType: ''text'' });',
'try {',
'    return JSON.parse(data);',
'} catch (error) {',
'    return [];',
'}',
'</code>',
'',
'<br/><br/>',
'The ''Expand'' process that contains the data fetching PL/SQL, is configured in the Processes tab.',
'',
'<br/></br>',
'<strong> ''Expand'' process</strong>',
'<br/>',
'<code>',
'// fetch logic randomized. Replace with actual fetched data',
'DECLARE ',
'    data clob;',
'    ids sys.dbms_sql.varchar2a :=  APEX_APPLICATION.G_F01;',
'    graph VARCHAR2(100) := ''EBA_SAMPLE_GRAPH'';',
'    hops NUMBER := 2;',
'    n NUMBER := hops - 1;',
'    id_strings VARCHAR2(32767) := '' ('';',
'    query VARCHAR2(32767);',
'',
'BEGIN',
'    for i in ids.FIRST..ids.LAST LOOP',
'        IF i = ids.LAST THEN',
'            id_strings := id_strings || apex_exec.enquote_literal(ids(i)) || '') '';    ',
'        ELSE     ',
'            id_strings := id_strings || apex_exec.enquote_literal(ids(i)) || '', '';',
'        END IF;',
'    END LOOP;',
'',
'    query  := ''SELECT id_x, id_e, id_z ',
'    FROM GRAPH_TABLE ('' || graph || '' MATCH (x) ->{,'' || n || ''} (y) -[e]-> (z) WHERE JSON_value(vertex_id(x), ''''$.ELEM_TABLE'''') || json_query(vertex_id(x), ''''$.KEY_VALUE'''' returning varchar2) IN',
'    '' || id_strings ||''',
'    COLUMNS (vertex_id(x) as id_x, edge_id(e) as id_e, vertex_id(z) as id_z))'';',
'',
'    SELECT CUST_SQLGRAPH_JSON(query) INTO data FROM sys.dual;',
'    apex_util.prn(data, false);',
'END;',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23545579643442533505)
,p_plug_name=>'Expand'
,p_parent_plug_id=>wwv_flow_imp.id(23545579812987533507)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "vertex": {',
    '        "size": 12,',
    '        "label": "${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '        "color": "${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '        "icon": "fa-user",',
    '        "legend": "${properties.JOB_TITLE}",',
    '        "children": {',
    '            "salary": {',
    '                "size": 8,',
    '                "color": "${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '                "icon": {',
    '                    "class": "fa-money",',
    '                    "color": "black"',
    '                },',
    '                "border": {',
    '                    "width": 1,',
    '                    "color": "#FB8500"',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[!!properties.COUNTRY_ID]": {',
    '        "children": {',
    '            "flag": {',
    '                "size": 10,',
    '                "image": {',
    '                    "url": "https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '                    "scale": 0.8',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]": {',
    '        "icon": "fa-user-secret"',
    '    },',
    '    "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_11', wwv_flow_string.join(wwv_flow_t_varchar2(
    'const data = await apex.server.process(''Expand'', {',
    '    f01: ids',
    '}, { dataType: ''text'' });',
    'try {',
    '    return JSON.parse(data);',
    '} catch (error) {',
    '    return [];',
    '}',
    '',
    '')),
  'attribute_14', 'Y',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201701921419403831)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201702023109403832)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201702116699403833)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29762920855248766679)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(192506158625404033)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17119386226976899753)
,p_button_name=>'Force'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Force'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-network-hub'
,p_button_cattributes=>'title="Force - Force correlation arrows to point at their inner-related vertices with all vertices ultimately pointing at the root vertex"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(192506578440404055)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17119386226976899753)
,p_button_name=>'Radial'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Radial'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-network-hub'
,p_button_cattributes=>'title="Radial - Display graph with outer vertices in a circle encompassing inner vertices and ultimately the root vertex centered in the middle"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(192507725110404056)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(17119386226976899753)
,p_button_name=>'First'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'First'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-align-left'
,p_button_cattributes=>'title="Change vertices'' labels to display first name only"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(192508132666404056)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(17119386226976899753)
,p_button_name=>'Last'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Last'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-align-left'
,p_button_cattributes=>'title="Change vertices'' labels to display last name only"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(192508520166404057)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(17119386226976899753)
,p_button_name=>'Full'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Full'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-align-left'
,p_button_cattributes=>'title="Change vertices'' labels to display full name"'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(192510256578404132)
,p_name=>'Force'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(192506158625404033)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(192510795991404149)
,p_event_id=>wwv_flow_imp.id(192510256578404132)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { self } = apex.region(''graph'');',
'self.settings = { ...self.settings, layout: ''force'' };'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(192511117265404155)
,p_name=>'Radial'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(192506578440404055)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(192511611897404156)
,p_event_id=>wwv_flow_imp.id(192511117265404155)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { self } = apex.region(''graph'');',
'self.settings = { ...self.settings, layout: ''radial'' };'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(192513822291404182)
,p_name=>'First'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(192507725110404056)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(192514390428404187)
,p_event_id=>wwv_flow_imp.id(192513822291404182)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(23545579670521533506)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { self } = apex.region(''graph'');',
'self.styles.vertex.label.text = ''${properties.FIRST_NAME}'';',
'self.styles = { ...self.styles };'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(192514620304404189)
,p_name=>'Last'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(192508132666404056)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(192515105033404190)
,p_event_id=>wwv_flow_imp.id(192514620304404189)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(23545579670521533506)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { self } = apex.region(''graph'');',
'self.styles.vertex.label.text = ''${properties.LAST_NAME}'';',
'self.styles = { ...self.styles };'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(192515549393404193)
,p_name=>'Full'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(192508520166404057)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(192516058661404193)
,p_event_id=>wwv_flow_imp.id(192515549393404193)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(23545579670521533506)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const { self } = apex.region(''graph'');',
'self.styles.vertex.label.text = ''${properties.FIRST_NAME} ${properties.LAST_NAME}'';',
'self.styles = { ...self.styles };'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33687973805693810)
,p_name=>'onDialogClose'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(23545579262468533502)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33688178700693812)
,p_event_id=>wwv_flow_imp.id(33687973805693810)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.location.reload();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(192509753853404122)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Expand'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE data clob;',
'    ids sys.dbms_sql.varchar2a :=  APEX_APPLICATION.G_F01;',
'    graph VARCHAR2(100) := ''EBA_SAMPLE_GRAPH'';',
'    hops NUMBER := 2;',
'    n NUMBER := hops - 1;',
'    id_strings VARCHAR2(32767) := '' ('';',
'    query VARCHAR2(32767);',
'',
'BEGIN',
'    for i in ids.FIRST..ids.LAST LOOP',
'        IF i = ids.LAST THEN',
'            id_strings := id_strings || apex_exec.enquote_literal(ids(i)) || '') '';    ',
'        ELSE     ',
'            id_strings := id_strings || apex_exec.enquote_literal(ids(i)) || '', '';',
'        END IF;',
'    END LOOP;',
'',
'    query  := ''SELECT id_x, id_e, id_z ',
'    FROM GRAPH_TABLE ('' || graph || '' MATCH (x) ->{,'' || n || ''} (y) -[e]-> (z) WHERE JSON_value(vertex_id(x), ''''$.ELEM_TABLE'''') || json_query(vertex_id(x), ''''$.KEY_VALUE'''' returning varchar2) IN',
'    '' || id_strings ||''',
'    COLUMNS (vertex_id(x) as id_x, edge_id(e) as id_e, vertex_id(z) as id_z))'';',
'',
'    SELECT CUST_SQLGRAPH_JSON(query) INTO data FROM sys.dual;',
'    apex_util.prn(data, false);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>6724956336055901
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(33687832400693809)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'REDIRECT_USER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    -- variable to store the final redirect url',
'    l_url VARCHAR2(32767);',
'BEGIN',
'    /*',
unistr('    * p_page\306B\958B\304F\30DA\30FC\30B8\306E\30DA\30FC\30B8\540D\3001p_items\306B\4E3B\30AD\30FC\306E\30A2\30A4\30C6\30E0\540D\3092\6307\5B9A\3059\308B\3002'),
'    */',
'    l_url := apex_page.get_url(',
'        p_page => ''employee-detail''',
'        ,p_items => ''P2_EMPLOYEE_ID''',
'        ,p_values => APEX_APPLICATION.G_X01',
'        ,p_triggering_element => ''#GRAPHVIZ''',
'    );',
'    -- return the generated url as a json response',
'    apex_json.open_object;',
'    apex_json.write(''url'', l_url);',
'    apex_json.close_object;',
'EXCEPTION ',
'    -- handle any unexpected errors and return an error message in json format',
'    WHEN OTHERS THEN',
'        apex_debug.message(''Error! '' || SQLERRM); -- log error for debugging',
'        apex_json.open_object;',
'        apex_json.write(''error'', ''an error occurred: '' || SQLERRM);',
'        apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>33687832400693809
);
wwv_flow_imp.component_end;
end;
/
