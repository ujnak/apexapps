prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>13
,p_name=>'Selection - 23c'
,p_alias=>'SELECTION-23C'
,p_step_title=>'Selection'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(6356421387844921770)
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8985212445321019108)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12039918748870076938)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14365121329628506361)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This page shows how vertices can be selected individually or in groups, and visualize',
'them in the selection area. The selection area shows only the vertices that the user selected, and thus helps the user isolate and work on them.'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17120616140559334803)
,p_plug_name=>'Selection Target'
,p_region_name=>'graph2'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*  This query retrieves empty data to show an empty graph initially,',
'    that gets overridden by Dynamic actions, when the user makes selection ',
'    in the first graph.*/',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  WHERE m.employee_id is NULL',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')',
''))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "vertex": {',
    '        "size": 12,',
    '        "label": "${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '        "color": "${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '        "icon": "fa-user",',
    '        "legend": "${properties.JOB_TITLE}",',
    '        "children": {',
    '            "salary": {',
    '                "size": 8,',
    '                "color": "${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '                "icon": {',
    '                    "class": "fa-money",',
    '                    "color": "black"',
    '                },',
    '                "border": {',
    '                    "width": 1,',
    '                    "color": "#FB8500"',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[!!properties.COUNTRY_ID]": {',
    '        "children": {',
    '            "flag": {',
    '                "size": 10,',
    '                "image": {',
    '                    "url": "https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '                    "scale": 0.8',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]": {',
    '        "icon": "fa-user-secret"',
    '    },',
    '    "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_12', 'return [];',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201702927952403841)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201703095032403842)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201703170243403843)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17120835323153780112)
,p_plug_name=>'Selection Source'
,p_region_name=>'graph'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "vertex": {',
    '        "size": 12,',
    '        "label": "${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '        "color": "${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '        "icon": "fa-user",',
    '        "legend": "${properties.JOB_TITLE}",',
    '        "children": {',
    '            "salary": {',
    '                "size": 8,',
    '                "color": "${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '                "icon": {',
    '                    "class": "fa-money",',
    '                    "color": "black"',
    '                },',
    '                "border": {',
    '                    "width": 1,',
    '                    "color": "#FB8500"',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[!!properties.COUNTRY_ID]": {',
    '        "children": {',
    '            "flag": {',
    '                "size": 10,',
    '                "image": {',
    '                    "url": "https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '                    "scale": 0.8',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]": {',
    '        "icon": "fa-user-secret"',
    '    },',
    '    "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'Y',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201702679988403838)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201702771160403839)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201702809011403840)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23546578411863908670)
,p_plug_name=>'Details'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'When selection is made in the first graph, the Dynamic Action for selection ',
'gets triggered and the below script gets executed. ',
'',
'<br><br><strong>Dynamic Action script</strong><br>',
'<code>',
'apex.region(''graph2'').self.data = this.data;',
'</code>',
'<br>',
'The script sets the second graphs',
'data with the selection made in the first graph.',
'',
'<br><br>',
'Please note that pagination needs the GVT plugin instance''s Attributes > ''SQL Query supports Pagination'' property to be turned on in APEX. Page size is configured in Attributes > Page Size.<br></br>',
'',
'<strong>First graph Query:</strong><br><br>',
'<code>/*  This example uses Dynamic action to set the contents of the second graph ',
'    at run time. The query doesn''t directly contribute to that, except',
'    fetching data to show the graph.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.*/',
'    ',
'    SELECT employee,e, manager',
'    FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'    MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'    COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
'    )',
'',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(193506154481778954)
,p_name=>'Selection'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(17120835323153780112)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_GRAPHVIZ|REGION TYPE|selection'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(193506638858778956)
,p_event_id=>wwv_flow_imp.id(193506154481778954)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region(''graph2'').self.data = this.data;'
);
wwv_flow_imp.component_end;
end;
/
