prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Geographical Layout'
,p_alias=>'GEOGRAPHICAL-LAYOUT'
,p_step_title=>'Geographical Layout'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(6356421387844921770)
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(199042909271954813)
,p_plug_name=>'Geographical Layout'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'The geographical layout allows the user to overlay the graph on a map, given that latitude and longitude coordinates exist as graph properties on the graph''s vertices.<br><br>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(199043199893954816)
,p_plug_name=>'Geographical Layout by Appearance'
,p_parent_plug_id=>wwv_flow_imp.id(199042909271954813)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'GRAPH'
,p_query_table=>'EBA_GRAPH_FLIGHTS'
,p_query_match=>'(m)-[e]->(n)'
,p_query_columns=>'vertex_id(m) as airport_depart, edge_id(e) as routes, vertex_id(n) as airport_arrival'
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_04', 'geographical',
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(78553037472230299)
,p_name=>'AIRPORT_DEPART'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(78553092355230300)
,p_name=>'ROUTES'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(78553184633230301)
,p_name=>'AIRPORT_ARRIVAL'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(199044068830954824)
,p_plug_name=>'Geographical Layout by Appearance'
,p_parent_plug_id=>wwv_flow_imp.id(199042909271954813)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Geographical layout can be configured in Attributes -> Appearance -> Layout -> Geographcial.<br></br>',
'<strong>SQL/PGQ query</strong>',
'<br></br>',
'<code>/*  In the below query, data is selected from Property Graph and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the routes between the airports.*/',
'    ',
'SELECT *',
'FROM GRAPH_TABLE ( EBA_GRAPH_FLIGHTS',
'  MATCH (m) -[e ]-> (n)',
'  COLUMNS (vertex_id(m) as airport_depart, edge_id(e) as routes, vertex_id(n) as airport_arrival )',
')',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(199044182519954825)
,p_plug_name=>'Geographical Layout by Setting'
,p_parent_plug_id=>wwv_flow_imp.id(199042909271954813)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'GRAPH'
,p_query_table=>'EBA_GRAPH_FLIGHTS'
,p_query_match=>'(m)-[e]-(n)'
,p_query_columns=>'vertex_id(m) as airport_depart, edge_id(e) as routes, vertex_id(n) as airport_arrival'
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_04', 'geographical',
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_maptype', 'osm_darkmatter',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(78553277753230302)
,p_name=>'AIRPORT_DEPART'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(78553369601230303)
,p_name=>'ROUTES'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(78553493758230304)
,p_name=>'AIRPORT_ARRIVAL'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(199044557409954829)
,p_plug_name=>'Geographical Layout by Setting'
,p_parent_plug_id=>wwv_flow_imp.id(199042909271954813)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Geographical layout can also be configured in Attributes -> Settings. Users have more options to customize the map. Below example shows using ''osm_darkmatter'' as mapType. <br>',
'For more details about geographical layout settings, please check <a href="https://docs.oracle.com/en/database/oracle/property-graph/24.1/pgjsd/pages/features/layouts.html" target="_blank">Graph JavaScript API Reference for Property Graph Visualizati'
||'on</a> Layouts section.<br>',
'</br>',
'<strong>Settings > Settings </strong>',
'<code>',
'{"layout" : ',
'  { "type":"geographical",',
'    "mapType": "world_map_mb"',
'  }',
'}',
'</code>',
'<strong>SQL/PGQ query</strong>',
'<br></br>',
'<code>/*  In the below query, data is selected from Property Graph and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the routes between the airports.*/',
'    ',
'SELECT *',
'FROM GRAPH_TABLE ( EBA_GRAPH_FLIGHTS',
'  MATCH (m) -[e ]-> (n)',
'  COLUMNS (vertex_id(m) as airport_depart, edge_id(e) as routes, vertex_id(n) as airport_arrival )',
')',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6903686591288857160)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9014677039650564595)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12039918748870076938)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14375077798230324767)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This use case uses EBA_GRAPH_FLIGHTS Property Graph. <br>',
'EBA_GRAPH_FLIGHTS graph includes location-based information (spatial data). <br>',
'Latitude and longitude coordinates exist as graph properties on the graph''s vertices.<br>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
