prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>'Saving Graph State'
,p_alias=>'SAVING-GRAPH-STATE-23C'
,p_step_title=>'Saving Graph State'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(6356421387844921770)
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13254380999478432274)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12039918748870076938)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18635219707642104188)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_source=>'The below example shows how various actions in the graph can be persisted. When the page reloads, all the persisted actions are retrieved from the database and applied back to the graph. Actions include group/ungroup and deleting nodes from graph, et'
||'c.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21389867121226759330)
,p_plug_name=>'Saving Graph State'
,p_region_name=>'graph'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*  In the below query, data is selected from Property Graph and ',
'    made into JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.',
'*/',
'',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "vertex": {',
    '        "size": 12,',
    '        "label": "${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '        "color": "${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '        "icon": "fa-user",',
    '        "legend": "${properties.JOB_TITLE}",',
    '        "children": {',
    '            "salary": {',
    '                "size": 8,',
    '                "color": "${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '                "icon": {',
    '                    "class": "fa-money",',
    '                    "color": "black"',
    '                },',
    '                "border": {',
    '                    "width": 1,',
    '                    "color": "#FB8500"',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[!!properties.COUNTRY_ID]": {',
    '        "children": {',
    '            "flag": {',
    '                "size": 10,',
    '                "image": {',
    '                    "url": "https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '                    "scale": 0.8',
    '                }',
    '            }',
    '        }',
    '    },',
    '    "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]": {',
    '        "icon": "fa-user-secret"',
    '    },',
    '    ',
    '  "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_12', wwv_flow_string.join(wwv_flow_t_varchar2(
    '    const actions = await apex.server.process(''Fetch'',null, {dataType: ''text''});',
    '    try {',
    '        return JSON.parse(actions);',
    '    } catch (error) {',
    '        return [];',
    '    }',
    '')),
  'attribute_13', wwv_flow_string.join(wwv_flow_t_varchar2(
    '    await apex.server.process(''Persist'', {',
    '        x01: JSON.stringify(action)',
    '    }, {dataType: ''text''});',
    '')),
  'attribute_14', 'Y',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201704190483403853)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201704227280403854)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201704373831403855)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23550778567131340445)
,p_plug_name=>'Details'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The state saving is done by making use of the scripts passed via the two attributes <b>FetchActions</b> ',
'and <b>Persist</b> (Settings > Fetch Actions, Persist in APEX). The data during save is persisted in the GRAPH_ACTION database table.',
'<br><br><strong>Fetch Actions:</strong><br>',
'<code>',
' const actions = await apex.server.process(''Fetch'',null, {dataType: ''text''});',
'    try {',
'        return JSON.parse(actions)',
'    } catch (error) {',
'        return [];',
'    }',
'',
'</code>',
'<br><strong>Persist:</strong><br>',
'<code>',
'    await apex.server.process(''Persist'', {',
'        x01: JSON.stringify(action)',
'    }, {dataType: ''text''});',
'',
'</code>',
'<br>',
'Please note that pagination needs the GVT plugin instance''s Attributes > ''SQL Query supports Pagination'' property to be turned on in APEX. Page size is configured in Attributes > Page Size.<br></br>',
'<br><strong>Query:</strong><br>',
'<code>/*  In the below query, data is selected from Property and made into',
'    JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.*/',
'',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(197703909498210630)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Persist'
,p_process_sql_clob=>'INSERT INTO EBA_GRAPHVIZ_GRAPH_ACTION(ACTION, USER_ID) VALUES(apex_application.g_x01, v(''APP_USER''));'
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'error occured during persist'
,p_internal_uid=>11919111980862409
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(197704329976210632)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fetch'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    data clob;',
'BEGIN',
'    SELECT JSON_ARRAYAGG(action FORMAT JSON ORDER BY ID ASC returning clob) INTO data FROM EBA_GRAPHVIZ_GRAPH_ACTION WHERE USER_ID = v(''APP_USER'');',
'    htp.p(data);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>11919532458862411
);
wwv_flow_imp.component_end;
end;
/
