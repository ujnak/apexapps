prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'Styling - 23c'
,p_alias=>'STYLING-23C'
,p_step_title=>'Styling'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(6356421387844921770)
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(192709092006506566)
,p_plug_name=>'Styling Toggle Settings'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'The Visibility and Styling Highlights feature lets users show or hide vertices or edges and control their styling through conditions defined via settings.  The users can manually toggle the legend item controls in the legend area and control the visi'
||'bility and styling of vertices and edges in the graph region.<br><br>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(192709136117506567)
,p_plug_name=>'Styling Toggle Settings Details'
,p_parent_plug_id=>wwv_flow_imp.id(192709092006506566)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Visibility and styling highlights have separate toggle controls that can be used to control them separately via the legend item. Visibility highlight is implicit in nature and is enabled for all legend items by default, whereas Styling highlight is a'
||'vailable only when it is configured via settings.',
'<br><br>',
'<strong>Attributes > Settings </strong>',
'<br>',
'<code>',
'{',
'    "filters": [',
'      {',
'          "id": 16835425432534,',
'          "component": "vertex",',
'          "stylingEnabled": true,',
'          "target": "vertex",',
'          "visibilityEnabled": true,',
'          "conditions": {',
'            "operator": "and",',
'            "conditions": [',
'                {',
'                "property": "DEPARTMENT_ID",',
'                "operator": ">",',
'                "value": "50"',
'                }',
'             ]},',
'        "properties": {',
'          "legendTitle": ["Department 50"],',
'          "colors": ["red"]',
'        }',
'      }',
'    ]',
'}',
'</code>',
'<br><br>',
'visibilityEnabled: Marks if Visibility is enabled for a filter item and the vertices/edges that it controls. If true, visibilty toggle is checked and target will show.<p></p>',
'stylingEnabled: Marks if Styling is enabled for a filter item and the vertices/edges that it controls. If true, styling toggle is checked and target is styled as set in properties.<p></p>',
'conditions: Conditions deciding which vertices/edges will be affected by the filter item<p></p>',
'component: The component (eg vertex/edge) for which the filter is defined<p></p>',
'target: The target on which this filter applies (vertex, source, target, edge, ingoing, outgoing)<p></p>',
'legendTitle: The title of the legend entry when the filter is shown in the legend area<p></p>',
'properties: The various properties (like colors, icons, image, animations) of a vertex/edge that this filter''s state can affect<p></p>',
'Notice: Checkbox for Visibility Toggle is always shown up. To show checkbox for Styling Toggle, "properties" JSON must include at least one of these values as keys. [colors, classes, sizes, icons, iconColors, image, label, style, animations]<p></p>',
'<br><br>',
'<strong>Query</strong>',
'<br>',
'<code>/*  ',
'    In the below query, data is selected from Property Graph and made into',
'    JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.',
'*/',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
');',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(192709339797506569)
,p_plug_name=>'Styling Toggle Settings'
,p_parent_plug_id=>wwv_flow_imp.id(192709092006506566)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_02', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '  "filters": [',
    '      {',
    '         "_id": 1570199998134,',
    '          "component": "vertex",',
    '          "stylingEnabled": true,',
    '          "target": "vertex",',
    '          "visibilityEnabled": true,',
    '          "conditions": {',
    '            "operator": "and",',
    '            "conditions": [',
    '                {',
    '                "property": "DEPARTMENT_ID",',
    '                "operator": ">",',
    '                "value": "50"',
    '                }',
    '             ]},',
    '        "properties": {',
    '          "legendTitle": ["Department > 50"],',
    '          "colors": ["red"]',
    '        }',
    '      }',
    '    ]',
    '}')),
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '   "vertex":{',
    '      "size":12,',
    '      "label":"${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '      "color":"${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '      "icon":"fa-user",',
    '      "legend":"${properties.JOB_TITLE}",',
    '      "children":{',
    '         "salary":{',
    '            "size":8,',
    '            "color":"${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '            "icon":{',
    '               "class":"fa-money",',
    '               "color":"black"',
    '            },',
    '            "border":{',
    '               "width":1,',
    '               "color":"#FB8500"',
    '            }',
    '         }',
    '      }',
    '   },',
    '   "vertex[!!properties.COUNTRY_ID]":{',
    '      "children":{',
    '         "flag":{',
    '            "size":10,',
    '            "image":{',
    '               "url":"https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '               "scale":0.8',
    '            }',
    '         }',
    '      }',
    '   },',
    '   "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]":{',
    '      "icon":"fa-user-secret"',
    '   },',
    '   "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'Y',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(192709458038506570)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(192709574369506571)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(259019495538401222)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6895269553971195622)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9006260002332903057)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12039918748870076938)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14366660760912663229)
,p_plug_name=>'About this page'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>10
,p_plug_source=>'This use case extends the previous ''Basic graph'' example by adding styling to the Graph Visualization region. Different ways to achieve styling are demonstrated with examples.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23547976298734060624)
,p_plug_name=>'Dynamic Expressions'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'Dynamic Expressions use the same ''Attributes-> Styles'' as Using the Settings Attribute but extend it further by using expressions inside ''Styles'' that evaluate at run-time.<br><br>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17141828476623221841)
,p_plug_name=>'Dynamic Expressions Graph'
,p_parent_plug_id=>wwv_flow_imp.id(23547976298734060624)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*  Query populates the JSON for a simple graph with just 10 edges.',
'    The graph shows employee manager reporting structure.',
'*/',
'',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')',
'FETCH FIRST 10 ROWS ONLY'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    ',
    '   "vertex":{',
    '   ',
    '      "label":"${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '      "color":"#00FF00"',
    '',
    '       ',
    '   },',
    '',
    '    "vertex[properties.EMPLOYEE_ID % 3 === 0 || id % 3 === 0]": {',
    '        "color": "red",',
    '        "icon": "fa-user",',
    '        "border": {',
    '            "width": 3',
    '        }',
    '    },',
    '    "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_14', 'N',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201703863120403850)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201703935047403851)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(201704075574403852)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23547977687055060638)
,p_plug_name=>'Dynamic Expressions Details'
,p_parent_plug_id=>wwv_flow_imp.id(23547976298734060624)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'In the below Styles JSON, dynamic expression is used to define the color of the vertices (will be red if the vertex id is a multiple of 3). Query doesn''t contain any styling info.',
'<br><br>',
'<strong>Settings > Styles </strong>',
'<br>',
'<code>',
'{',
'    "vertex[properties.EMPLOYEE_ID % 3 === 0]": {',
'        "color": "red",',
'        "border": {',
'            "width": 3',
'        }',
'    }',
'}',
'</code>',
'<br><br>',
'<strong>Query</strong>',
'<br>',
'<code>/* ',
'    In the below query, data is selected from Property Graph and made into',
'    JSON format that GVT accepts.',
'',
'    The query retrieves vertices and edges of the graph that visualizes ',
'    the reporting structure of employees to their managers.',
'*/',
'',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')',
'FETCH FIRST 10 ROWS ONLY',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23547977811231060639)
,p_plug_name=>'Using the Settings Attribute'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This example demonstrates styling the graph using the ''Attributes->Styles'' panel in APEX, the values of which gets applied to the settings parameter of the Graph Visualization Toolkit (GVT) component. ',
'<br>',
'Some styles applied in this example includes  <b>size, color, icon, children</b> etc. Interpolation in the below example interprets properties like JobId, Salary etc and derive values like color from it, for use in styling the graph.',
'<br><br>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23547975777270060619)
,p_plug_name=>'Vertex Styles'
,p_parent_plug_id=>wwv_flow_imp.id(23547977811231060639)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')',
''))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_03', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '   "vertex":{',
    '      "size":12,',
    '      "label":"${properties.FIRST_NAME} ${properties.LAST_NAME}",',
    '      "color":"${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
    '      "icon":"fa-user",',
    '      "legend":"${properties.JOB_TITLE}",',
    '      "children":{',
    '         "salary":{',
    '            "size":8,',
    '            "color":"${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
    '            "icon":{',
    '               "class":"fa-money",',
    '               "color":"black"',
    '            },',
    '            "border":{',
    '               "width":1,',
    '               "color":"#FB8500"',
    '            }',
    '         }',
    '      }',
    '   },',
    '   "vertex[!!properties.COUNTRY_ID]":{',
    '      "children":{',
    '         "flag":{',
    '            "size":10,',
    '            "image":{',
    '               "url":"https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
    '               "scale":0.8',
    '            }',
    '         }',
    '      }',
    '   },',
    '   "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]":{',
    '      "icon":"fa-user-secret"',
    '   },',
    '   "edge": {',
    '    "color": "gray",',
    '    "legend": "edge",',
    '    "width": 2,',
    '    "label": {',
    '      "color": "gray",',
    '      "font": {',
    '        "size": 12',
    '      }',
    '    }',
    '  }',
    '}')),
  'attribute_05', 'N',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'Y',
  'attribute_16', '640',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'evolution_exclude_show', 'N',
  'evolution_preservepositions', 'N',
  'force_clusterenabled', 'N',
  'force_hideunclusteredvertices', 'N',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'legendwidth', '300',
  'livesearch', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(192707076959506546)
,p_name=>'EMPLOYEE'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(192707136257506547)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(192707254176506548)
,p_name=>'MANAGER'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23547976134915060623)
,p_plug_name=>'Settings Attribute Details'
,p_parent_plug_id=>wwv_flow_imp.id(23547977811231060639)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Settings > Styles </strong>',
'<br>',
'<code>',
'{',
'   "vertex":{',
'      "size":12,',
'      "label":"${properties.FIRST_NAME} ${properties.LAST_NAME}",',
'      "color":"${interpolate.discrete(''properties.JOB_ID'', ''#d5445a'', ''#6d2f5f'', ''#25314c'', ''#244f54'', ''#449287'', ''#62b3b7'', ''#ffda40'', ''#dda831'', ''#e96e4c'', ''#e8b4af'', ''#b3b3b3'', ''#333333'')}",',
'      "icon":"fa-user",',
'      "legend":"${properties.JOB_TITLE}",',
'      "children":{',
'         "salary":{',
'            "size":8,',
'            "color":"${interpolate.color(''properties.SALARY'', ''white'', ''#FB8500'')}",',
'            "icon":{',
'               "class":"fa-money",',
'               "color":"black"',
'            },',
'            "border":{',
'               "width":1,',
'               "color":"#FB8500"',
'            }',
'         }',
'      }',
'   },',
'   "vertex[!!properties.COUNTRY_ID]":{',
'      "children":{',
'         "flag":{',
'            "size":10,',
'            "image":{',
'               "url":"https://flagcdn.com/40x30/${(properties.COUNTRY_ID === ''UK'' ? ''GB'' : properties.COUNTRY_ID).toLowerCase()}.png",',
'               "scale":0.8',
'            }',
'         }',
'      }',
'   },',
'   "vertex[[''AD_PRES'', ''AD_VP'', ''FI_MGR'', ''AC_MGR'', ''SA_MAN'', ''PU_MAN'', ''ST_MAN''].indexOf(properties.JOB_ID) >= 0]":{',
'      "icon":"fa-user-secret"',
'   }',
'}',
'</code>',
'<br>',
'<strong>Settings JSON</strong>',
'<br>',
'The legendWidth property can be used to customize the legend area''s width. ',
'<code>',
'{',
'    "legendWidth":300',
'}',
'</code>',
'<br>',
'',
'<br><br>',
'<strong>Query:</strong>',
'<br>',
'',
'',
'<code>',
'SELECT employee,e, manager',
'FROM GRAPH_TABLE ( EBA_SAMPLE_GRAPH',
'  MATCH (m IS EMPLOYEE ) -[e IS WORKS_FOR ]-> (n)',
'  COLUMNS (vertex_id(m) AS employee, edge_id(e) AS e, vertex_id(n) AS manager )',
')',
'</code>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
