prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 125
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(8582838197337836915)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DROP TABLE "EBA_GRAPHVIZ_REGIONS";',
'DROP TABLE "EBA_GRAPHVIZ_COUNTRIES";',
'DROP TABLE "EBA_GRAPHVIZ_LOCATIONS";',
'DROP TABLE "EBA_GRAPHVIZ_DEPARTMENTS";',
'DROP TABLE "EBA_GRAPHVIZ_JOBS";',
'DROP TABLE "EBA_GRAPHVIZ_EMPLOYEES";',
'DROP TABLE "EBA_GRAPHVIZ_JOB_HISTORY";',
'DROP TABLE "EBA_GRAPHVIZ_GRAPH_ACTION"; ',
'DROP TABLE "EBA_GRAPHVIZ_AIRPORTS";',
'DROP TABLE "EBA_GRAPHVIZ_ROUTES";',
'DROP MATERIALIZED VIEW "EBA_GRAPHVIZ_EMPLOYEES_VIEW";',
'',
'DROP SEQUENCE "EBA_GRAPHVIZ_GRAPH_ACTION_SEQ";',
'',
'BEGIN',
'    IF sys.dbms_db_version.version >= 23 THEN',
'        EXECUTE IMMEDIATE ''DROP PROPERTY GRAPH EBA_SAMPLE_GRAPH'';',
'        EXECUTE IMMEDIATE ''DROP PROPERTY GRAPH EBA_GRAPH_FLIGHTS'';',
'    END IF;',
'',
'END;'))
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
);
wwv_flow_imp.component_end;
end;
/
