prompt --application/deployment/install/install_create_property_graph_23
begin
--   Manifest
--     INSTALL: INSTALL-create_property_graph_23
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1384219233226996062)
,p_install_id=>wwv_flow_imp.id(8582838197337836915)
,p_name=>'create_property_graph_23'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_condition_type=>'EXPRESSION'
,p_condition=>'sys.dbms_db_version.version >= 23'
,p_condition2=>'PLSQL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE PROPERTY GRAPH EBA_SAMPLE_GRAPH',
'  VERTEX TABLES (',
'    eba_graphviz_countries',
'      KEY ( country_id )',
'      LABEL country PROPERTIES ( country_id, country_name, region_id ),',
'    eba_graphviz_departments',
'      KEY ( department_id )',
'      LABEL department PROPERTIES ( department_id, department_name, location_id, manager_id ),',
'    eba_graphviz_locations',
'      KEY ( location_id )',
'      LABEL location PROPERTIES ( city, country_id, location_id, postal_code, state_province, street_address ),',
'    eba_graphviz_job_history',
'      KEY ( employee_id, end_date, job_id, start_date )',
'      PROPERTIES ( department_id, employee_id, end_date, job_id, start_date ),',
'    eba_graphviz_jobs',
'      KEY ( job_id )',
'      LABEL job PROPERTIES ( job_id, job_title, max_salary, min_salary ),',
'    eba_graphviz_regions',
'      KEY ( region_id )',
'      LABEL region PROPERTIES ( region_id, region_name ),',
'    EBA_GRAPHVIZ_EMPLOYEES_VIEW',
'      KEY ( employee_id )',
'      LABEL employee PROPERTIES ( commission_pct, department_id, email, employee_id, first_name, hire_date, job_id, last_name, manager_id, phone_number, salary, job_title, COUNTRY_ID)',
'  )',
'  EDGE TABLES (',
'    eba_graphviz_countries AS country_located_in',
'      SOURCE KEY ( country_id ) REFERENCES eba_graphviz_countries (country_id)',
'      DESTINATION KEY ( region_id ) REFERENCES eba_graphviz_regions (region_id)',
'      NO PROPERTIES,',
'    eba_graphviz_departments AS department_located_in',
'      SOURCE KEY ( department_id ) REFERENCES eba_graphviz_departments (department_id)',
'      DESTINATION KEY ( location_id ) REFERENCES eba_graphviz_locations ( location_id )',
'      NO PROPERTIES,',
'    eba_graphviz_locations AS location_located_in',
'      SOURCE KEY ( location_id ) REFERENCES eba_graphviz_locations ( location_id )',
'      DESTINATION KEY ( country_id ) REFERENCES eba_graphviz_countries ( country_id )',
'      NO PROPERTIES,',
'    eba_graphviz_employees AS works_as',
'      SOURCE KEY ( employee_id ) REFERENCES EBA_GRAPHVIZ_EMPLOYEES_VIEW ( employee_id )',
'      DESTINATION KEY ( job_id ) REFERENCES eba_graphviz_jobs ( job_id )',
'      NO PROPERTIES,',
'    eba_graphviz_employees AS works_at',
'      SOURCE KEY ( employee_id ) REFERENCES EBA_GRAPHVIZ_EMPLOYEES_VIEW  ( employee_id ) ',
'      DESTINATION KEY ( department_id ) REFERENCES eba_graphviz_departments ( department_id ) ',
'      NO PROPERTIES,',
'    eba_graphviz_employees AS works_for',
'      SOURCE KEY ( employee_id ) REFERENCES EBA_GRAPHVIZ_EMPLOYEES_VIEW ( employee_id )',
'      DESTINATION KEY ( manager_id ) REFERENCES EBA_GRAPHVIZ_EMPLOYEES_VIEW  ( employee_id )',
'      NO PROPERTIES,',
'    eba_graphviz_job_history AS for_job KEY ( employee_id, start_date )',
'      SOURCE KEY ( employee_id, start_date ) REFERENCES eba_graphviz_job_history ( employee_id, start_date )',
'      DESTINATION KEY ( job_id ) REFERENCES eba_graphviz_jobs ( job_id )',
'      NO PROPERTIES,',
'    eba_graphviz_job_history AS for_department KEY ( employee_id, start_date )',
'      SOURCE KEY ( employee_id, start_date ) REFERENCES eba_graphviz_job_history ( employee_id, start_date )',
'      DESTINATION KEY ( department_id ) REFERENCES eba_graphviz_departments ( department_id )',
'      NO PROPERTIES,',
'    eba_graphviz_job_history AS for_employee KEY ( employee_id, start_date )',
'      SOURCE KEY ( employee_id, start_date ) REFERENCES eba_graphviz_job_history ( employee_id, start_date ) ',
'      DESTINATION KEY ( employee_id ) REFERENCES EBA_GRAPHVIZ_EMPLOYEES_VIEW  ( employee_id )',
'      NO PROPERTIES',
'  );',
'',
' ',
'',
' CREATE OR REPLACE PROPERTY GRAPH "EBA_GRAPH_FLIGHTS"',
'    VERTEX TABLES (',
'        "EBA_GRAPHVIZ_AIRPORTS"',
'            KEY ("ID")',
'            LABEL AIRPORT',
'            PROPERTIES ("NAME", "IATA", "LATITUDE" AS "latitude", "LONGITUDE" AS "longitude", "ALTITUDE")',
'    )',
'    EDGE TABLES (',
'        "EBA_GRAPHVIZ_ROUTES"',
'            KEY ("ID")',
'            SOURCE KEY("ORIG_AIRPORT_ID") REFERENCES EBA_GRAPHVIZ_AIRPORTS ("ID")',
'            DESTINATION KEY("DEST_AIRPORT_ID") REFERENCES EBA_GRAPHVIZ_AIRPORTS ("ID")',
'            LABEL ROUTE',
'            PROPERTIES ("ID", "AIRLINE", "DISTANCE")',
'    );'))
);
wwv_flow_imp.component_end;
end;
/
