prompt --application/deployment/install/install_create_cust_sqlgraph_json
begin
--   Manifest
--     INSTALL: INSTALL-create cust_sqlgraph_json
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(257019698021890299)
,p_install_id=>wwv_flow_imp.id(8582838197337836915)
,p_name=>'create cust_sqlgraph_json'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace FUNCTION CUST_SQLGRAPH_JSON (',
'  QUERY VARCHAR2,',
'  PAGE_START NUMBER DEFAULT NULL,',
'  PAGE_SIZE NUMBER DEFAULT NULL',
') RETURN CLOB',
'  AUTHID CURRENT_USER IS',
'  INCUR    SYS_REFCURSOR;',
'  L_CUR    NUMBER;',
'  RETVALUE CLOB;',
'BEGIN',
'',
'  OPEN INCUR FOR QUERY;',
'  L_CUR := DBMS_SQL.TO_CURSOR_NUMBER(INCUR);',
'  RETVALUE := ORA_SQLGRAPH_TO_JSON(L_CUR, PAGE_START, PAGE_SIZE);',
'  DBMS_SQL.CLOSE_CURSOR(L_CUR);',
'  RETURN RETVALUE;',
'END;',
''))
);
wwv_flow_imp.component_end;
end;
/
