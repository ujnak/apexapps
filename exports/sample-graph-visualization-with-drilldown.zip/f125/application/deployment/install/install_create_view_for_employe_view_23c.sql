prompt --application/deployment/install/install_create_view_for_employe_view_23c
begin
--   Manifest
--     INSTALL: INSTALL-create view for employe_view 23c
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.1'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>125
,p_default_id_offset=>34826242237804709
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(191100905863142061)
,p_install_id=>wwv_flow_imp.id(8582838197337836915)
,p_name=>'create view for employe_view 23c'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_condition_type=>'EXPRESSION'
,p_condition=>'sys.dbms_db_version.version >= 23'
,p_condition2=>'PLSQL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE MATERIALIZED VIEW EBA_GRAPHVIZ_EMPLOYEES_VIEW',
'AS',
'SELECT employees.*, jobs.job_title, locations.COUNTRY_ID',
'FROM',
'        EBA_GRAPHVIZ_EMPLOYEES employees',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_JOBS jobs ON employees.JOB_ID = jobs.JOB_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_DEPARTMENTS departments ON employees.DEPARTMENT_ID = departments.DEPARTMENT_ID',
'        LEFT OUTER JOIN EBA_GRAPHVIZ_LOCATIONS locations ON departments.LOCATION_ID = locations.LOCATION_ID'))
);
wwv_flow_imp.component_end;
end;
/
