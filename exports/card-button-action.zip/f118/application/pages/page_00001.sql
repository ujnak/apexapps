prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>118
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30AB\30FC\30C9\30A2\30AF\30B7\30E7\30F3')
,p_alias=>'HOME'
,p_step_title=>unistr('\30AB\30FC\30C9\30A2\30AF\30B7\30E7\30F3')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const SET_EMPNO = {',
'    name: "setempno",',
'    action: function(event, element, args) {',
'        apex.item("P1_EMPNO").setValue(args.empno);',
'    }',
'};',
'',
'const PAGE_ACTIONS_EMPCARD = [ SET_EMPNO ];'))
,p_javascript_code_onload=>'apex.actions.add(PAGE_ACTIONS_EMPCARD);'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221212224409'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16107160102924685)
,p_plug_name=>unistr('\30AB\30FC\30C9\30A2\30AF\30B7\30E7\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15938587964924572)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "EMPNO",',
'       "ENAME",',
'       "JOB",',
'       "MGR",',
'       ( select l1."ENAME" from "EMP" l1 where l1."EMPNO" = m."MGR") "MGR_L$1",',
'       "HIREDATE",',
'       "SAL",',
'       "COMM",',
'       "DEPTNO",',
'       ( select l2."DNAME" from "DEPT" l2 where l2."DEPTNO" = m."DEPTNO") "DEPTNO_L$2"',
'from "EMP" m'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P1_ORDER_BY", "orderBys": [{"key":"ENAME","expr":"\"ENAME\" asc"},{"key":"JOB","expr":"\"JOB\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(16107638799924687)
,p_region_id=>wwv_flow_imp.id(16107160102924685)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&ENAME.',
'<button type="button" title="Edit" aria-label="Edit" class="t-Button t-Button--noLabel t-Button--icon t-Button--noUI" data-action="setempno?empno=&EMPNO."><span aria-hidden="true" class="t-Icon fa fa-pencil"></span></button>',
''))
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'JOB'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(15658451904367014)
,p_card_id=>wwv_flow_imp.id(16107638799924687)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>unistr('\5F93\696D\54E1\756A\53F7\306E\8A2D\5B9A')
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$setempno?empno=&EMPNO.'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16108667157924690)
,p_plug_name=>unistr('\30AB\30FC\30C9\30A2\30AF\30B7\30E7\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(15964496261924585)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15658375445367013)
,p_name=>'P1_EMPNO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16108667157924690)
,p_prompt=>unistr('\5F93\696D\54E1\756A\53F7')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(16067804715924639)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16108144358924689)
,p_name=>'P1_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16107160102924685)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_item_default=>'ENAME'
,p_prompt=>unistr('\4E26\66FF\3048\57FA\6E96')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Ename;ENAME,Job;JOB'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(16067804715924639)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
