prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>10508790898791030
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Python Eval'
,p_alias=>'PYTHON-EVAL'
,p_step_title=>'Python Eval'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9164194510615739)
,p_name=>'Result'
,p_template=>2100526641005906379
,p_display_sequence=>90
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'    case',
'    when :P4_TYPE = ''pyqEval''      then',
'        l_sql := ''select * from table(pyqEval(<<<PAR_LST>>>,<<<OUT_FMT>>>,<<<SCR_NAME>>>))'';',
'    when :P4_TYPE = ''pyqTableEval'' then',
'        l_sql := ''select * from table(pyqTableEval(<<<INP_NAM>>>,<<<PAR_LST>>>,<<<OUT_FMT>>>,<<<SCR_NAME>>>))'';',
'    when :P4_TYPE = ''pyqRowEval''   then',
'        l_sql := ''select * from table(pyqRowEval(<<<INP_NAM>>>,<<<PAR_LST>>>,<<<OUT_FMT>>>,<<<ROW_NUM>>>,<<<SCR_NAME>>>))'';',
'    when :P4_TYPE = ''pyqGroupEval''   then',
'        l_sql := ''select * from table(pyqGroupEval(<<<INP_NAM>>>,<<<PAR_LST>>>,<<<OUT_FMT>>>,<<<GRP_COL>>>,<<<SCR_NAME>>>))'';',
'    else',
'        l_sql := ''select * from dual'';',
'    end case;',
'    if :P4_INP_NAM is not null then',
'        l_sql := replace(l_sql, ''<<<INP_NAM>>>'', CHR(39)||:P4_INP_NAM||CHR(39));',
'    else',
'        l_sql := replace(l_sql, ''<<<INP_NAM>>>'', ''NULL'');',
'    end if;',
'    if :P4_PAR_LST is not null then',
'        l_sql := replace(l_sql, ''<<<PAR_LST>>>'',  ''q''''|''||:P4_PAR_LST||''|'''''');',
'    else',
'        l_sql := replace(l_sql, ''<<<PAR_LST>>>'',  ''NULL'');',
'    end if;',
'    if :P4_OUT_FMT is not null then',
'        l_sql := replace(l_sql, ''<<<OUT_FMT>>>'',  ''q''''|''||:P4_OUT_FMT||''|'''''');',
'    else',
'        l_sql := replace(l_sql, ''<<<OUT_FMT>>>'',  ''NULL'');',
'    end if;',
'    if :P4_GRP_COL is not null then',
'        l_sql := replace(l_sql, ''<<<GRP_COL>>>'',  CHR(39)||:P4_GRP_COL||CHR(39));',
'    else',
'        l_sql := replace(l_sql, ''<<<GRP_COL>>>'',  ''NULL'');',
'    end if;',
'    if :P4_ROW_NUM is not null then',
'        l_sql := replace(l_sql, ''<<<ROW_NUM>>>'',  :P4_ROW_NUM);',
'    else',
'        l_sql := replace(l_sql, ''<<<ROW_NUM>>>'',  ''NULL'');',
'    end if;',
'    if :P4_SCR_NAME is not null then',
'        l_sql := replace(l_sql, ''<<<SCR_NAME>>>'', CHR(39)||:P4_SCR_NAME||CHR(39));',
'    end if;',
'    apex_debug.info(l_sql);',
'    return l_sql;',
'end;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>true
,p_query_row_template=>2538654340625403440
,p_plug_query_max_columns=>10
,p_query_num_rows=>15
,p_query_options=>'GENERIC_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9164299892615740)
,p_query_column_id=>1
,p_column_alias=>'COL01'
,p_column_display_sequence=>10
,p_column_heading=>'Col01'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9164338977615741)
,p_query_column_id=>2
,p_column_alias=>'COL02'
,p_column_display_sequence=>20
,p_column_heading=>'Col02'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9164451448615742)
,p_query_column_id=>3
,p_column_alias=>'COL03'
,p_column_display_sequence=>30
,p_column_heading=>'Col03'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9164561366615743)
,p_query_column_id=>4
,p_column_alias=>'COL04'
,p_column_display_sequence=>40
,p_column_heading=>'Col04'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9164680634615744)
,p_query_column_id=>5
,p_column_alias=>'COL05'
,p_column_display_sequence=>50
,p_column_heading=>'Col05'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9164794981615745)
,p_query_column_id=>6
,p_column_alias=>'COL06'
,p_column_display_sequence=>60
,p_column_heading=>'Col06'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9164826895615746)
,p_query_column_id=>7
,p_column_alias=>'COL07'
,p_column_display_sequence=>70
,p_column_heading=>'Col07'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9164946149615747)
,p_query_column_id=>8
,p_column_alias=>'COL08'
,p_column_display_sequence=>80
,p_column_heading=>'Col08'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9165058406615748)
,p_query_column_id=>9
,p_column_alias=>'COL09'
,p_column_display_sequence=>90
,p_column_heading=>'Col09'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9165186207615749)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>100
,p_column_heading=>'Col10'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11510001879200417)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(11124379716954602)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9164019651615738)
,p_button_sequence=>80
,p_button_name=>'EVAL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Eval'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9163399420615731)
,p_name=>'P4_TYPE'
,p_is_required=>true
,p_item_sequence=>10
,p_prompt=>'SQL API'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:pyqEval;pyqEval,pyqTableEval;pyqTableEval,pyqRowEval;pyqRowEval,pyqGroupEval;pyqGroupEval'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'REDIRECT_SET_VALUE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9163485380615732)
,p_name=>'P4_SCR_NAME'
,p_is_required=>true
,p_item_sequence=>20
,p_prompt=>'SCR_NAME - Script Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select name d, name r from user_pyq_scripts order by name asc'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9163538490615733)
,p_name=>'P4_INP_NAM'
,p_item_sequence=>30
,p_prompt=>'INP_NAM - Table or View Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'P4_TYPE'
,p_display_when2=>'pyqTableEval:pyqRowEval:pyqGroupEval'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9163677751615734)
,p_name=>'P4_PAR_LST'
,p_item_sequence=>40
,p_prompt=>'PAR_LST - Additional Parameter in JSON'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9163773116615735)
,p_name=>'P4_OUT_FMT'
,p_item_sequence=>50
,p_prompt=>'OUT_FMT - Output Format in JSON, Table/View, XML or PNG'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9163874678615736)
,p_name=>'P4_GRP_COL'
,p_item_sequence=>60
,p_prompt=>'GRP_COL - Group by Column'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'P4_TYPE'
,p_display_when2=>'pyqGroupEval'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9163943806615737)
,p_name=>'P4_ROW_NUM'
,p_item_sequence=>70
,p_prompt=>'ROW_NUM - Number of Rows to include'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>'P4_TYPE'
,p_display_when2=>'pyqRowEval'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp.component_end;
end;
/
