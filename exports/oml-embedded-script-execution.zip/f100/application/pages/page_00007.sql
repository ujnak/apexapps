prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>10508790898791030
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'R Eval'
,p_alias=>'R-EVAL'
,p_step_title=>'R Eval'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(12119880263424712)
,p_name=>'Result'
,p_template=>2100526641005906379
,p_display_sequence=>110
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'    case',
'    when :P7_TYPE = ''rqEval''      then',
'        l_sql := ''select * from table(rqEval(<<<PAR_CUR>>>,<<<OUT_QRY>>>,<<<EXP_NAM>>>))'';',
'    when :P7_TYPE = ''rqTableEval'' then',
'        l_sql := ''select * from table(rqTableEval(<<<INP_CUR>>>,<<<PAR_CUR>>>,<<<OUT_QRY>>>,<<<EXP_NAM>>>))'';',
'    when :P7_TYPE = ''rqRowEval''   then',
'        l_sql := ''select * from table(rqRowEval(<<<INP_CUR>>>,<<<PAR_CUR>>>,<<<OUT_QRY>>>,<<<ROW_NUM>>>,<<<EXP_NAM>>>))'';',
'    when :P7_TYPE = ''rqGroupEval''   then',
'        l_sql := ''select * from table(rqGroupEval(<<<INP_CUR>>>,<<<PAR_CUR>>>,<<<OUT_QRY>>>,<<<GRP_COL>>>,<<<EXP_NAM>>>))'';',
'    else',
'        l_sql := ''select * from dual'';',
'    end case;',
'    if :P7_INP_CUR is not null then',
'        l_sql := replace(l_sql, ''<<<INP_CUR>>>'', :P7_INP_CUR);',
'    else',
'        l_sql := replace(l_sql, ''<<<INP_CUR>>>'', ''NULL'');',
'    end if;',
'    if :P7_PAR_CUR is not null then',
'        l_sql := replace(l_sql, ''<<<PAR_CUR>>>'', :P7_PAR_CUR);',
'    else',
'        l_sql := replace(l_sql, ''<<<PAR_CUR>>>'',  ''NULL'');',
'    end if;',
'    if :P7_OUT_QRY is not null then',
'        l_sql := replace(l_sql, ''<<<OUT_QRY>>>'',  CHR(39)||:P7_OUT_QRY||CHR(39));',
'    else',
'        l_sql := replace(l_sql, ''<<<OUT_QRY>>>'',  ''NULL'');',
'    end if;',
'    if :P7_GRP_COL is not null then',
'        l_sql := replace(l_sql, ''<<<GRP_COL>>>'',  CHR(39)||:P7_GRP_COL||CHR(39));',
'    else',
'        l_sql := replace(l_sql, ''<<<GRP_COL>>>'',  ''NULL'');',
'    end if;',
'    if :P7_ROW_NUM is not null then',
'        l_sql := replace(l_sql, ''<<<ROW_NUM>>>'',  :P7_ROW_NUM);',
'    else',
'        l_sql := replace(l_sql, ''<<<ROW_NUM>>>'',  ''NULL'');',
'    end if;',
'    if :P7_EXP_NAM is not null then',
'        l_sql := replace(l_sql, ''<<<EXP_NAM>>>'', CHR(39)||:P7_EXP_NAM||CHR(39));',
'    end if;',
'    apex_debug.info(l_sql);',
'    return l_sql;',
'end;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>true
,p_query_row_template=>2538654340625403440
,p_plug_query_max_columns=>10
,p_query_num_rows=>15
,p_query_options=>'GENERIC_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12120355065424717)
,p_query_column_id=>1
,p_column_alias=>'COL01'
,p_column_display_sequence=>10
,p_column_heading=>'Col01'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12120432489424718)
,p_query_column_id=>2
,p_column_alias=>'COL02'
,p_column_display_sequence=>20
,p_column_heading=>'Col02'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12120572585424719)
,p_query_column_id=>3
,p_column_alias=>'COL03'
,p_column_display_sequence=>30
,p_column_heading=>'Col03'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12120621297424720)
,p_query_column_id=>4
,p_column_alias=>'COL04'
,p_column_display_sequence=>40
,p_column_heading=>'Col04'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12120758821424721)
,p_query_column_id=>5
,p_column_alias=>'COL05'
,p_column_display_sequence=>50
,p_column_heading=>'Col05'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12120821018424722)
,p_query_column_id=>6
,p_column_alias=>'COL06'
,p_column_display_sequence=>60
,p_column_heading=>'Col06'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12120969585424723)
,p_query_column_id=>7
,p_column_alias=>'COL07'
,p_column_display_sequence=>70
,p_column_heading=>'Col07'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12121089964424724)
,p_query_column_id=>8
,p_column_alias=>'COL08'
,p_column_display_sequence=>80
,p_column_heading=>'Col08'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12121190713424725)
,p_query_column_id=>9
,p_column_alias=>'COL09'
,p_column_display_sequence=>90
,p_column_heading=>'Col09'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12121284401424726)
,p_query_column_id=>10
,p_column_alias=>'COL10'
,p_column_display_sequence=>100
,p_column_heading=>'Col10'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12121594281424729)
,p_plug_name=>'Exp Nam'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1569994581593435632
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12129220999526082)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(11124379716954602)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12119705917424711)
,p_button_sequence=>100
,p_button_name=>'EVAL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Eval'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12121334373424727)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(12121594281424729)
,p_button_name=>'UPDATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Update'
,p_button_position=>'BUTTON_END'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12119040770424704)
,p_name=>'P7_TYPE'
,p_is_required=>true
,p_item_sequence=>10
,p_prompt=>'SQL API'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:rqEval;rqEval,rqTableEval;rqTableEval,rqRowEval;rqRowEval,rqTableEval;rqTableEval'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'REDIRECT_SET_VALUE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12119131224424705)
,p_name=>'P7_EXP_NAM'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(12121594281424729)
,p_prompt=>'EXP_NAM - Script Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select c001 d, c001 r from apex_collections where collection_name = ''RQSCRIPTS'''
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12119210046424706)
,p_name=>'P7_INP_CUR'
,p_item_sequence=>50
,p_prompt=>'INP_CUR - Cursor that specifies the data to pass'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_display_when=>'P7_TYPE'
,p_display_when2=>'rqTableEval:rqRowEval:rqGroupEval'
,p_display_when_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12119331482424707)
,p_name=>'P7_PAR_CUR'
,p_item_sequence=>60
,p_prompt=>'PAR_CUR - Cursor that contains argument values to pass'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12119444129424708)
,p_name=>'P7_OUT_QRY'
,p_item_sequence=>70
,p_prompt=>'OUT_QRY - Output Format in SQL SELECT, XML or PNG'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12119561161424709)
,p_name=>'P7_GRP_COL'
,p_item_sequence=>80
,p_prompt=>'GRP_COL - Group by Column'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'P7_TYPE'
,p_display_when2=>'rqGroupEval'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12119634806424710)
,p_name=>'P7_ROW_NUM'
,p_item_sequence=>90
,p_prompt=>'ROW_NUM - Number of Rows to include'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'P7_TYPE'
,p_display_when2=>'rqRowEval'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12121417486424728)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_collection.create_collection_from_query(',
'        p_collection_name => ''RQSCRIPTS''',
'        ,p_query => ''select name from user_rq_scripts''',
'        ,p_truncate_if_exists => ''YES''',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(12121334373424727)
,p_internal_uid=>12121417486424728
);
wwv_flow_imp.component_end;
end;
/
