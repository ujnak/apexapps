prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 251
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>251
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE900000109494441545847637C191DF29F610001E3A80346436034044643809810F8A3A8C2C0A8A20A2FAEDE5EBDC2C023C08F527CBDB9';
wwv_flow_imp.g_varchar2_table(2) := '7993815F4C0C2EF6E3DE5D06714E0E82451C5105D15F574F0671FF40B8612F37AE67E093964631FCD9CEED0CE2EAEA083520073D7F3AEA00EA84C02B295906616D1D92D2C0C757AF18E4FEFEA68E03BE69E930889A59C00D7B7DEA048310528203497C65';
wwv_flow_imp.g_varchar2_table(3) := '65C74827CCBBB78F3A609884C023665694420694C0A49D5C507CF7E2F85106413939B8D8FB478F18A4BF7CA24E087C9494C6286494ABEB510C7F346D124642E5BA7665D401D40981EF3CBC0CBF78F9E0861193063E9F3D43BDCA88A037285040546D4881';
wwv_flow_imp.g_varchar2_table(4) := 'F904B58E3A603404464360C04300002B6BF001B42420C90000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(74136579460628289)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
