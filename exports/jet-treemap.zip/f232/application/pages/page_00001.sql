prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>232
,p_default_id_offset=>84733308323282991
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Treemap'
,p_alias=>'HOME'
,p_step_title=>'JET Treemap'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code=>'var treemap;'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'require(["require", "exports", "knockout", "ojs/ojbootstrap", "ojs/ojarraytreedataprovider", "ojs/ojpalette", "ojs/ojpaletteutils", "ojs/ojknockout", "ojs/ojtreemap"], function (require, exports, ko, ojbootstrap_1, ArrayTreeDataProvider, ojpalette_1,'
||' ojpaletteutils_1) {',
'    "use strict";',
'      ',
'    class TreemapModel {',
'        /*',
unistr('         * Treemap\3067\8868\793A\3059\308B\30C7\30FC\30BF\3092\66F4\65B0\3059\308B\3002'),
'         */',
'        update(nodes) {',
'            this.treemapData(new ArrayTreeDataProvider(nodes, {',
'                keyAttributes: "label",',
'                childrenAttribute: "nodes",',
'            }));',
'        }',
'',
'        constructor() {',
'            /*',
unistr('             * this.treemapData\306Fknockout\306EobservableArray\306B\5909\66F4\3057\3001'),
unistr('             * \30C7\30FC\30BF\306F\30B3\30F3\30B9\30C8\30E9\30AF\30BF\306E\5916\304B\3089\8A2D\5B9A\3059\308B\3002'),
'             */',
'            this.treemapData = ko.observableArray();',
'            /*',
'            this.data = JSON.parse(jsonData);',
'            this.treemapData = new ArrayTreeDataProvider(this.data, {',
'                keyAttributes: ''label'',',
'                childrenAttribute: ''nodes''',
'            });',
'            */',
'            this.maxIncome = 70000;',
'            this.minIncome = 35000;',
'            this.colors = (0, ojpalette_1.getColorValuesFromPalette)(''viridis'');',
'            this.getColor = (meanIncome) => {',
'                return (0, ojpaletteutils_1.getColorValue)(this.colors, (meanIncome - this.minIncome) / (this.maxIncome - this.minIncome));',
'            };',
'            this.getShortDesc = (label, population, meanIncome) => {',
'                return (''&lt;b&gt;'' +',
'                    label +',
'                    ''&lt;/b&gt;&lt;br/&gt;Population: '' +',
'                    population +',
'                    ''&lt;br/&gt;Income: '' +',
'                    meanIncome);',
'            };',
'        }',
'    }',
'    (0, ojbootstrap_1.whenDocumentReady)().then(() => {',
'        treemap = new TreemapModel();',
'        ko.applyBindings(treemap, document.getElementById(''treemap-container''));',
unistr('        /* \30DA\30FC\30B8\30FB\30ED\30FC\30C9\6642\306E\8868\793A */'),
'        apex.actions.invoke("update-treemap");',
'    });',
'});',
'',
'/*',
unistr(' * Treemap\3092\66F4\65B0\3059\308B\3002'),
' */',
'apex.actions.add([',
'    {',
'        name: "update-treemap",',
'        action: () => {',
'            apex.server.process ( "GET_DATA", {},',
'                {',
'                    success: (data) =>  {',
'                        treemap.update(data);',
'                    }',
'                }',
'            );',
'        }',
'    }',
']);'))
,p_css_file_urls=>'#JET_CSS_DIRECTORY#stable/oj-stable-min.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>\3053\306E\5BFE\8A71\30B0\30EA\30C3\30C9\5185\3067\30C7\30FC\30BF\3092\76F4\63A5\633F\5165\3001\66F4\65B0\304A\3088\3073\524A\9664\3067\304D\307E\3059\3002<br>'),
unistr('  \300C\884C\306E\8FFD\52A0\300D\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\65B0\3057\3044\884C\3092\633F\5165\3067\304D\307E\3059\3002<br>'),
unistr('  \30BB\30EB\5185\3092\30C0\30D6\30EB\30AF\30EA\30C3\30AF\3059\308B\304B\3001<strong>\300C\7DE8\96C6\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\30B9\30D7\30EC\30C3\30C9\30B7\30FC\30C8\3067\30C7\30FC\30BF\3092\7DE8\96C6\3059\308B\5834\5408\3068\540C\3058\3088\3046\306B\30C7\30FC\30BF\5024\3092\66F4\65B0\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30EC\30DD\30FC\30C8\306E\4E00\756A\4E0A\306B\3042\308B\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC(<span class="fa fa-bars" aria-hidden="true"></span>)\3092\4F7F\7528\3057\3066\3001\9078\629E\3057\305F\884C\3092\8907\88FD\3001\524A\9664\3001\30EA\30D5\30EC\30C3\30B7\30E5\307E\305F\306F\56DE\5FA9\3057\307E\3059\3002<br>'),
unistr('  \500B\3005\306E\884C\306E\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\3092\4F7F\7528\3057\3066\3001\5358\4E00\884C\30D3\30E5\30FC\306B\30A2\30AF\30BB\30B9\3057\305F\308A\3001\65B0\3057\3044\884C\3092\8FFD\52A0\3057\305F\308A\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30C7\30FC\30BF\3092\898B\3064\3051\308B\306B\306F\3001\691C\7D22\30C0\30A4\30A2\30ED\30B0\306B\691C\7D22\6587\5B57\5217\3092\5165\529B\3059\308B\304B\3001\5217\30D8\30C3\30C0\30FC\3092\30AF\30EA\30C3\30AF\3057\3066\623B\3055\308C\308B\30EC\30B3\30FC\30C9\3092\5236\9650\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30A2\30AF\30B7\30E7\30F3\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\591A\304F\306E\6A5F\80FD\3092\5B9F\884C\3067\304D\307E\3059\3002\3053\308C\306B\306F\3001\8868\793A\5217\307E\305F\306F\975E\8868\793A\5217\306E\9078\629E\3068\305D\306E\8868\793A\9806\5E8F\306B\52A0\3048\3001\591A\304F\306E\30C7\30FC\30BF\304A\3088\3073\66F8\5F0F\8A2D\5B9A\6A5F\80FD\304C\542B\307E\308C\307E\3059\3002\30C1\30E3\30FC\30C8\30FB\30AA\30D7\30B7\30E7\30F3\3092\4F7F\7528\3057\3066\3001\30C7\30FC\30BF\306E\8FFD\52A0\30D3\30E5\30FC\3092\5B9A\7FA9\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\72EC\81EA\306E\30AB\30B9\30BF\30DE\30A4\30BA\5185\5BB9\3092\4FDD\5B58\3059\308B\5834\5408\3001\30EC\30DD\30FC\30C8\3092\9078\629E\3059\308B\304B\3001\300C\30C0\30A6\30F3\30ED\30FC\30C9\300D\3092\30AF\30EA\30C3\30AF\3057\3066\30C7\30FC\30BF\3092\30A2\30F3\30ED\30FC\30C9\3057\307E\3059\3002<p>'),
'',
unistr('<p>\8FFD\52A0\60C5\5831\3092\5165\624B\3059\308B\306B\306F\3001\300C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\306E\4E00\756A\4E0B\306E\300C\30D8\30EB\30D7\300D\3092\30AF\30EA\30C3\30AF\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30EA\30BB\30C3\30C8\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\5BFE\8A71\30B0\30EA\30C3\30C9\3092\30C7\30D5\30A9\30EB\30C8\8A2D\5B9A\306B\623B\3059\3053\3068\304C\3067\304D\307E\3059\3002</p>')))
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230907205035'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234742226307061043)
,p_plug_name=>'Treemap'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(234795328745429091)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="treemap-container">',
'    <oj-treemap style="width: 100%; height: 600px;"',
'        id="treemap1"',
'        animation-on-display="auto"',
'        animation-on-data-change="auto"',
'        data="[[treemapData]]">',
'        <template slot="nodeTemplate">',
'        <oj-treemap-node',
'            label="[[$current.data.label]]"',
'            value="[[$current.data.population]]"',
'            color="[[getColor($current.data.meanIncome)]]"',
'            short-desc="[[getShortDesc($current.data.label, $current.data.population, $current.data.meanIncome)]]"></oj-treemap-node>',
'        </template>',
'    </oj-treemap>',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(235053423626429375)
,p_plug_name=>'Tmap Populations'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(234824338440429112)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'TMAP_POPULATIONS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Treemap'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(235054691478429379)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(235055255760429380)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>unistr('\30A2\30AF\30B7\30E7\30F3')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(235056264770429382)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'ID'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(235057248624429383)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Label'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>80
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(235058177645429384)
,p_name=>'POPULATION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'POPULATION'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Population'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(235059175895429384)
,p_name=>'MEAN_INCOME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MEAN_INCOME'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Mean Income'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(235060177325429385)
,p_name=>'PARENT_NODE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PARENT_NODE_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Parent Node'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(235061129300429388)
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(235053887224429376)
,p_internal_uid=>74147820813628338
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(235054294923429377)
,p_interactive_grid_id=>wwv_flow_imp.id(235053887224429376)
,p_static_id=>'741483'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(235054484677429377)
,p_report_id=>wwv_flow_imp.id(235054294923429377)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(235055654278429381)
,p_view_id=>wwv_flow_imp.id(235054484677429377)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(235055255760429380)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(235056593622429382)
,p_view_id=>wwv_flow_imp.id(235054484677429377)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(235056264770429382)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(235057612802429383)
,p_view_id=>wwv_flow_imp.id(235054484677429377)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(235057248624429383)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(235058622639429384)
,p_view_id=>wwv_flow_imp.id(235054484677429377)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(235058177645429384)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(235059586275429385)
,p_view_id=>wwv_flow_imp.id(235054484677429377)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(235059175895429384)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(235060660490429385)
,p_view_id=>wwv_flow_imp.id(235054484677429377)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(235060177325429385)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(234741982459061041)
,p_button_sequence=>10
,p_button_name=>'INIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(234933709268429188)
,p_button_image_alt=>'Init'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(234742408558061045)
,p_name=>unistr('\5909\66F4\306E\4FDD\5B58')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(235053423626429375)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(234742484386061046)
,p_event_id=>wwv_flow_imp.id(234742408558061045)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.invoke("update-treemap");',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(234742116078061042)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\521D\671F\5316')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response clob;',
'    l_nodes json_array_t;',
'    l_node json_object_t;',
'    l_label varchar2(80);',
'    l_population number;',
'    l_mean_income number;',
'',
'    procedure process_node(',
'        p_node in json_object_t',
'        ,p_parent_node_id in number',
'    )',
'    as',
'        l_label       tmap_populations.label%type;',
'        l_population  tmap_populations.population%type;',
'        l_mean_income tmap_populations.mean_income%type;',
'        l_node_id     tmap_populations.id%type;',
'        l_nodes       json_array_t;',
'        l_node_count  pls_integer;',
'        l_node        json_object_t;',
'    begin',
'        l_label       := p_node.get_string(''label'');',
'        l_population  := p_node.get_number(''population'');',
'        l_mean_income := p_node.get_number(''meanIncome'');',
'        insert into tmap_populations(label, population, mean_income, parent_node_id)',
'        values(l_label, l_population, l_mean_income, p_parent_node_id) returning id into l_node_id;',
'        dbms_output.put_line(l_node_id || '','' || l_label || '','' || l_population || '','' || l_mean_income);',
'        l_nodes := p_node.get_array(''nodes'');',
'        if l_nodes is null then',
'            return;',
'        end if;',
'        l_node_count := l_nodes.get_size();',
'        if not l_node_count > 0 then',
'            return;',
'        end if;',
'        for i in 1..l_node_count',
'        loop',
'            l_node := treat(l_nodes.get(i-1) as json_object_t);',
'            process_node(l_node, l_node_id);',
'        end loop;',
'    end process_node;',
'begin',
'    delete from tmap_populations;',
'    commit;',
'    execute immediate ''alter table tmap_populations modify id generated by default on null as identity (start with limit value)'';',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => ''https://www.oracle.com/webfolder/technetwork/jet/cookbook/dataVisualizations/treeView/resources/usaMeanIncomeSubregion.json''',
'        ,p_http_method => ''GET''',
'    );',
'    l_nodes := json_array_t(l_response);',
'    for i in 1..l_nodes.get_size()',
'    loop',
'        l_node := treat(l_nodes.get(i-1) as json_object_t);',
'        process_node(l_node, null);',
'    end loop;',
'    commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(234741982459061041)
,p_internal_uid=>73836049667260004
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(235061889111429390)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(235053423626429375)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Treemap - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>74155822700628352
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(234742314706061044)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'function get_child_nodes(',
'    l_node_id in number',
')',
'return json_array_t',
'as',
'    l_node_count  pls_integer;',
'    l_nodes       json_array_t;',
'    l_node        json_object_t;',
'    l_child_nodes json_array_t;',
'begin',
'    select count(*) into l_node_count from tmap_populations',
'    where (l_node_id is null and parent_node_id is null) or (parent_node_id = l_node_id);',
'    if l_node_count = 0 then',
'        return null;',
'    end if;',
'    l_nodes := json_array_t;',
'    for r in (',
'        select',
'            id, ',
'            json_object(',
'                key ''label'' value label,',
'                key ''population'' value population,',
'                key ''meanIncome'' value mean_income',
'            ) as json',
'        from tmap_populations ',
'        where (l_node_id is null and parent_node_id is null) or (parent_node_id = l_node_id)',
'    )',
'    loop',
'        l_node := json_object_t(r.json);',
'        l_child_nodes := get_child_nodes(r.id);',
'        if l_child_nodes is not null then',
'            l_node.put(''nodes'', l_child_nodes);',
'        end if;',
'        l_nodes.append(l_node);',
'    end loop;',
'    return l_nodes;',
'end get_child_nodes;',
'begin',
'    htp.p(get_child_nodes(null).to_clob());',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>73836248295260006
);
wwv_flow_imp.component_end;
end;
/
