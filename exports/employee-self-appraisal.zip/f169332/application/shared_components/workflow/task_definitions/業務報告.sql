prompt --application/shared_components/workflow/task_definitions/業務報告
begin
--   Manifest
--     TASK_DEF: 業務報告
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>30040104978234657984
,p_default_application_id=>169332
,p_default_id_offset=>0
,p_default_owner=>'WKSP_JAPANCOMMUNITY'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(6127672778699666432)
,p_name=>unistr('\696D\52D9\5831\544A')
,p_static_id=>'EMPLOYEE_SELF_APPRAISAL'
,p_subject=>unistr('\696D\52D9\5831\544A\306E\4F9D\983C \5B9B\5148: &ENAME. - \8981\5B8C\4E86')
,p_task_type=>'ACTION'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,2:P2_TASK_ID:&TASK_ID.'
,p_actions_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select initcap(e.ename) ename, e.empno empno ',
'   from act_emp e ',
'   join act_review r ',
'   on r.empno = e.empno ',
'   where r.review_id = :APEX$TASK_PK'))
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(6159246426660255284)
,p_task_def_id=>wwv_flow_imp.id(6127672778699666432)
,p_name=>'Update Review Status to REQUESTED'
,p_execution_sequence=>10
,p_on_event=>'CREATE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update act_review',
'    set status = ''REQUESTED''',
'    where review_id = :APEX$TASK_PK;',
'end;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(6163114304226045419)
,p_task_def_id=>wwv_flow_imp.id(6127672778699666432)
,p_name=>'Update Review Status to SUBMITTED'
,p_execution_sequence=>20
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update act_review',
'    set status = ''SUBMITTED''',
'    where review_id = :APEX$TASK_PK;',
'end;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(6151915234241954366)
,p_task_def_id=>wwv_flow_imp.id(6127672778699666432)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'upper(:ename)'
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(6151915536900954368)
,p_task_def_id=>wwv_flow_imp.id(6127672778699666432)
,p_participant_type=>'BUSINESS_ADMIN'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'SOPHIE'
);
wwv_flow_imp.component_end;
end;
/
