prompt --application/shared_components/security/authentications/デモ用
begin
--   Manifest
--     AUTHENTICATION: デモ用
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>30040104978234657984
,p_default_application_id=>169332
,p_default_id_offset=>0
,p_default_owner=>'WKSP_JAPANCOMMUNITY'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(6231064581557901965)
,p_name=>unistr('\30C7\30E2\7528')
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'demo_authentication'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function demo_authentication (',
'    p_username in varchar2,',
'    p_password in varchar2 )',
'    return boolean',
'is',
'    c number;',
'begin',
'   select 1 into c from act_emp where ename = upper(p_username);',
'   return true;',
'exception',
'    when no_data_found then',
'        return false;',
'end;'))
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
