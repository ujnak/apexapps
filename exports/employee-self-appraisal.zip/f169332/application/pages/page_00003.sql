prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-17'
,p_default_workspace_id=>30040104978234657984
,p_default_application_id=>169332
,p_default_id_offset=>0
,p_default_owner=>'WKSP_JAPANCOMMUNITY'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>unistr('\79C1\306E\30C1\30FC\30E0')
,p_alias=>unistr('\79C1\306E\30C1\30FC\30E0')
,p_step_title=>unistr('\79C1\306E\30C1\30FC\30E0')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'YUJI.NAKAKOSHI@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20231026071049'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6170691170674148841)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(6115415766213789175)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(6115299794371789124)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(6115478184807789203)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6170691759851148842)
,p_plug_name=>unistr('\79C1\306E\30C1\30FC\30E0')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(6115343701047789145)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.empno,',
'       e.ename name,',
'       initcap(e.ename) initcapname,',
'       m.ename manager,',
'       count(r.review_id) no_of_reviews',
'from   ACT_EMP e',
'left join ACT_REVIEW r',
'  on   r.empno = e.empno',
'join   ACT_EMP m',
'  on   m.empno = e.mgr',
'where  m.ename = upper(:APP_USER)',
'group by e.empno, e.ename, initcap(e.ename), m.ename'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P3_ORDER_BY", "orderBys": [{"key":"INITCAPNAME","expr":"\"INITCAPNAME\" asc"},{"key":"NO_OF_REVIEWS","expr":"\"NO_OF_REVIEWS\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(6170692261247148844)
,p_region_id=>wwv_flow_imp.id(6170691759851148842)
,p_layout_type=>'FLOAT'
,p_title_adv_formatting=>false
,p_title_column_name=>'INITCAPNAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'NAME'
,p_badge_column_name=>'NO_OF_REVIEWS'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(4752985169332184621)
,p_card_id=>wwv_flow_imp.id(6170692261247148844)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>unistr('\696D\52D9\5831\544A\3092\4F9D\983C\3059\308B')
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::P4_EMPNO:&EMPNO.'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6170692779075148846)
,p_name=>'P3_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6170691759851148842)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_item_default=>'INITCAPNAME'
,p_prompt=>unistr('\4E26\66FF\3048\57FA\6E96')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Initcapname;INITCAPNAME,No Of Reviews;NO_OF_REVIEWS'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(6115474034559789201)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
