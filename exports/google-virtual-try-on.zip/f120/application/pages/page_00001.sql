prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>120
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Google Virtual Try-On'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19162159608754733)
,p_plug_name=>'Person'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19162626049754738)
,p_plug_name=>'Person Preview'
,p_parent_plug_id=>wwv_flow_imp.id(19162159608754733)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>'<img id="person" style="width:100%; height:auto;" src="&P1_PSERON."></img>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19162217420754734)
,p_plug_name=>'Product'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19162924222754741)
,p_plug_name=>'Product Preview'
,p_parent_plug_id=>wwv_flow_imp.id(19162217420754734)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<img id="product" style="width:100%; height:auto;" src="&P1_PRODUCT."></img>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19162363163754735)
,p_plug_name=>'Try-On'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20044405750071706)
,p_plug_name=>'virtical space'
,p_parent_plug_id=>wwv_flow_imp.id(19162363163754735)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>'<div style="height: 63px;"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20028613063878543)
,p_plug_name=>'Google Virtual Try-On'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19163370192754745)
,p_button_sequence=>10
,p_button_name=>'TRY_ON'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Try On'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19162438973754736)
,p_name=>'P1_PERSON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19162159608754733)
,p_prompt=>'Person'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_cropping', 'N',
  'allow_multiple_files', 'N',
  'display_as', 'NATIVE',
  'purge_files_at', 'REQUEST',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19162503926754737)
,p_name=>'P1_PRODUCT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19162217420754734)
,p_prompt=>'Product'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_cropping', 'N',
  'allow_multiple_files', 'N',
  'display_as', 'NATIVE',
  'purge_files_at', 'REQUEST',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19163029063754742)
,p_name=>'P1_TRY_ON'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(19162363163754735)
,p_prompt=>'Try On'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'SQL',
  'sql_statement', 'select blob001 from apex_collections where collection_name = ''VIRTUAL_TRY_ON'' and c001 = ''TRYON''')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19163528463754747)
,p_name=>'P1_PERSON_IMAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(19162159608754733)
,p_prompt=>'Person'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'SQL',
  'sql_statement', 'select blob001 from apex_collections where collection_name = ''VIRTUAL_TRY_ON'' and c001 = ''PERSON''')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19163630937754748)
,p_name=>'P1_PRODUCT_IMAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(19162217420754734)
,p_prompt=>'Product'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'SQL',
  'sql_statement', 'select blob001 from apex_collections where collection_name = ''VIRTUAL_TRY_ON'' and c001 = ''PRODUCT''')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19162793503754739)
,p_name=>'Perview Person'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_PERSON'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19163734857754749)
,p_event_id=>wwv_flow_imp.id(19162793503754739)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_PERSON_IMAGE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19163836190754750)
,p_event_id=>wwv_flow_imp.id(19162793503754739)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19162626049754738)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19162868084754740)
,p_event_id=>wwv_flow_imp.id(19162793503754739)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let fileReader = new FileReader();',
'fileReader.onload = (function() {',
'    document.getElementById("person").src = fileReader.result;',
'});',
'fileReader.readAsDataURL(this.triggeringElement.files[0]);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19163193848754743)
,p_name=>'Preview Product'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_PRODUCT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20043921072071701)
,p_event_id=>wwv_flow_imp.id(19163193848754743)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_PRODUCT_IMAGE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20044020632071702)
,p_event_id=>wwv_flow_imp.id(19163193848754743)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19162924222754741)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19163270705754744)
,p_event_id=>wwv_flow_imp.id(19163193848754743)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let fileReader = new FileReader();',
'fileReader.onload = (function() {',
'    document.getElementById("product").src = fileReader.result;',
'});',
'fileReader.readAsDataURL(this.triggeringElement.files[0]);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20044149702071703)
,p_name=>'On-Page Load'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20044235961071704)
,p_event_id=>wwv_flow_imp.id(20044149702071703)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19162626049754738)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20044331269071705)
,p_event_id=>wwv_flow_imp.id(20044149702071703)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19162924222754741)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19163423111754746)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Try On'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_COLNAME constant varchar2(20) := ''VIRTUAL_TRY_ON'';',
'    l_person_image     blob;',
'    l_product_image    blob;',
'    l_prediction_image blob;',
'    l_person_seq     number := null;',
'    l_product_seq    number := null;',
'    l_prediction_seq number := null;',
'    /* request */',
'    l_request       json_object_t;',
'    l_request_clob  clob;',
'    l_instances     json_array_t;',
'    l_instance      json_object_t;',
'    l_personImage   json_object_t;',
'    l_productImages json_array_t;',
'    l_productImage  json_object_t;',
'    l_image         json_object_t;',
'    l_parameters    json_object_t;',
'    /* response */',
'    l_response      json_object_t;',
'    l_response_clob clob;',
'    l_predictions   json_array_t;',
'    l_prediction    json_object_t;',
unistr('    /* API\3092\547C\3073\51FA\3059URL */'),
'    C_ENDPOINT_URL constant varchar2(400) :=',
'        ''https://'' || :G_LOCATION || ''-aiplatform.googleapis.com/v1/projects/'' || :G_PROJECT_ID ||',
'        ''/locations/'' || :G_LOCATION || ''/publishers/google/models/'' || :G_MODEL_ID || '':predict'';',
'    e_call_api_exception exception;',
'begin',
'    /*',
unistr('     * \4EBA\7269\306E\753B\50CF\3092\9078\629E\3059\308B\3002'),
'     */',
'    begin',
unistr('        /* \524D\56DE\306E\753B\50CF\3092\78BA\8A8D\3059\308B\3002 */'),
'        select seq_id into l_person_seq from apex_collections',
'        where collection_name = C_COLNAME and c001 = ''PERSON'';',
'    exception',
'    when no_data_found then',
unistr('        /* \306A\3051\308C\3070l_person_seq\306Fnull */'),
'        null;',
'    end;',
'    begin',
unistr('        /* \4ECA\56DE\30A2\30C3\30D7\30ED\30FC\30C9\3057\305F\753B\50CF\3092\53D6\308A\51FA\3059\3002 */'),
'        select blob_content into l_person_image',
'        from apex_application_temp_files where name = :P1_PERSON;',
'        if l_person_seq is not null then',
unistr('            /* \30A2\30C3\30D7\30ED\30FC\30C9\3057\305F\753B\50CF\3067\524D\56DE\3092\753B\50CF\3092\7F6E\304D\63DB\3048\308B\3002 */'),
'            apex_collection.update_member_attribute(C_COLNAME, l_person_seq, 1, l_person_image);',
'        else',
unistr('            /* \524D\56DE\306E\753B\50CF\304C\7121\3044\306E\3067\65B0\898F\306B\4FDD\5B58\3059\308B\3002 */'),
'            apex_collection.add_member(C_COLNAME, ''PERSON'', p_blob001 => l_person_image);',
'        end if;',
'    exception',
'    when no_data_found then',
unistr('        /* \30A2\30C3\30D7\30ED\30FC\30C9\3055\308C\305F\753B\50CF\304C\306A\3044\3002 */'),
'        if l_person_seq is not null then',
unistr('            /* \524D\56DE\306E\753B\50CF\3092l_person_image\3068\3057\3066\4F7F\7528\3059\308B\3002 */'),
'            select blob001 into l_person_image from apex_collections',
'            where collection_name = C_COLNAME and seq_id = l_person_seq;',
'        end if;',
'    end;',
'    /*',
unistr('     * \670D\306E\753B\50CF\3092\9078\629E\3059\308B\3002'),
'     */',
'    begin',
'        select seq_id into l_product_seq from apex_collections',
'        where collection_name = C_COLNAME and c001 = ''PRODUCT'';',
'    exception',
'    when no_data_found then',
'        null;',
'    end;',
'    begin',
'        select blob_content into l_product_image',
'        from apex_application_temp_files where name = :P1_PRODUCT;',
'        if l_product_seq is not null then',
'            apex_collection.update_member_attribute(C_COLNAME, l_product_seq, 1, l_product_image);',
'        else',
'            apex_collection.add_member(C_COLNAME, ''PRODUCT'', p_blob001 => l_product_image);',
'        end if;',
'    exception',
'    when no_data_found then',
'        if l_product_seq is not null then',
'            select blob001 into l_product_image from apex_collections',
'            where collection_name = C_COLNAME and seq_id = l_product_seq;',
'        end if;',
'    end;',
'    /*',
unistr('     * \4EBA\7269\3068\670D\306E\753B\50CF\304C\306A\3051\308C\3070\4F55\3082\3057\306A\3044\3002'),
'     */',
'    if l_person_image is null or l_product_image is null then',
'        return;',
'    end if;',
'    /*',
unistr('     * \30EA\30AF\30A8\30B9\30C8\306E\4F5C\6210\3002'),
'     */',
'    l_request   := json_object_t();',
'    l_instances := json_array_t();',
'    l_instance  := json_object_t();',
'    /* personImage */',
'    l_personImage := json_object_t();',
'    l_image       := json_object_t();',
'    l_image.put(''bytesBase64Encoded'', apex_web_service.blob2clobbase64(l_person_image, ''N'',''N''));',
'    -- l_image.put(''bytesBase64Encoded'', ''aaa'');',
'    l_personImage.put(''image'', l_image);',
'    l_instance.put(''personImage'', l_personImage);',
'    /* productImages */',
'    l_productImages := json_array_t();',
'    l_productImage  := json_object_t();',
'    l_image         := json_object_t();',
'    l_image.put(''bytesBase64Encoded'', apex_web_service.blob2clobbase64(l_product_image, ''N'',''N''));',
'    -- l_image.put(''bytesBase64Encoded'', ''bbb'');',
'    l_productImage.put(''image'', l_image);',
'    l_productImages.append(l_productImage);',
'    l_instance.put(''productImages'', l_productImages);',
'    /* instances */',
'    l_instances.append(l_instance);',
'    /* parameters */',
'    l_parameters := json_object_t();',
'    l_parameters.put(''sampleCount'', 1);',
'    l_parameters.put(''baseSteps'', 32);',
'    /* request */',
'    l_request.put(''instances'', l_instances);',
'    l_request.put(''parameters'', l_parameters);',
'    l_request_clob := l_request.to_clob();',
'    /* submit virtual try-on request */',
'    apex_debug.info(C_ENDPOINT_URL);',
'    -- apex_debug.info(l_request_clob);   -- too big!',
'    /*',
unistr('     * Google Gemini API\306E\547C\3073\51FA\3057\3002'),
'     */',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json; charset=utf-8'');',
'    l_response_clob := apex_web_service.make_rest_request(',
'        p_url => C_ENDPOINT_URL,',
'        p_http_method => ''POST'',',
'        p_body => l_request_clob,',
'        p_credential_static_id => :G_CREDENTIAL',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_call_api_exception;',
'    end if;',
'    /*',
unistr('     * \30EC\30B9\30DD\30F3\30B9\304B\3089\7D50\679C\306E\753B\50CF\3092\53D6\308A\51FA\3059\3002'),
'     */',
'    l_response := json_object_t(l_response_clob);',
'    l_predictions := l_response.get_array(''predictions'');',
'    /* only 1 prediction expected because sampleCount is 1 */',
'    l_prediction := treat(l_predictions.get(0) as json_object_t);',
'    l_prediction_image := apex_web_service.clobbase642blob(l_prediction.get_clob(''bytesBase64Encoded''));',
'    /*',
unistr('     * \753B\50CF\3092\30B3\30EC\30AF\30B7\30E7\30F3\306B\4FDD\5B58\3059\308B\3002'),
'     */',
'    begin',
unistr('        /* \524D\56DE\306E\7D50\679C\304C\3042\308C\3070\66F4\65B0\3059\308B\3002 */'),
'        select seq_id into l_prediction_seq from apex_collections',
'        where collection_name = C_COLNAME and c001 = ''TRYON'';',
'        apex_collection.update_member_attribute(C_COLNAME, l_prediction_seq, 1, l_prediction_image);',
'    exception',
'    when no_data_found then',
unistr('        /* \7121\3051\308C\3070\8FFD\52A0 */'),
'        apex_collection.add_member(C_COLNAME, ''TRYON'', p_blob001 => l_prediction_image);',
'    end;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(19163370192754745)
,p_internal_uid=>19163423111754746
);
wwv_flow_imp.component_end;
end;
/
