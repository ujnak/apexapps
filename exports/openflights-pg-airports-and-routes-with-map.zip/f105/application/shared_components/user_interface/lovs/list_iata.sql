prompt --application/shared_components/user_interface/lovs/list_iata
begin
--   Manifest
--     LIST_IATA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(15714716760123088)
,p_lov_name=>'LIST_IATA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    iata, airport_name, city, country',
'from ebaj_openflights_airports',
'group by iata, airport_name, city, country',
'order by country, city, airport_name'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'IATA'
,p_display_column_name=>'AIRPORT_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>5777111
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(15715295851129906)
,p_query_column_name=>'IATA'
,p_heading=>'IATA'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(15715512659129906)
,p_query_column_name=>'AIRPORT_NAME'
,p_heading=>'Airport Name'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(15715909556129906)
,p_query_column_name=>'CITY'
,p_heading=>'City'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(15716388532129906)
,p_query_column_name=>'COUNTRY'
,p_heading=>'Country'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
