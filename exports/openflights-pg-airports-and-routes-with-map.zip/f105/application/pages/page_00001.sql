prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Airports and Routes'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13911999887060622)
,p_plug_name=>'Airports and Routes'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from graph_table( ebaj_openflights_routes_graph',
'match (s is airport) -[e is connects]-> (d is airport)',
'where s.iata = :P1_SOURCE_IATA and d.iata = :P1_DESTINATION_IATA',
'columns (',
'   vertex_id(s) as s, edge_id(e) as e, vertex_id(d) as d',
'));'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_ajax_items_to_submit=>'P1_SOURCE_IATA,P1_DESTINATION_IATA'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_04', 'geographical',
  'attribute_05', 'N',
  'attribute_06', '100',
  'attribute_07', 'IATA',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'N',
  'attribute_16', '640',
  'bind_variable_pgql', 'N',
  'custom_theme', 'N',
  'darktheme', 'N',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'exploration_options', 'expand:focus:group:ungroup:drop:undo:redo:reset',
  'geo_showinfo', 'Y',
  'geo_shownavigation', 'Y',
  'livesearch', 'N',
  'modes_options', 'interaction:fitToScreen:sticky:evolution',
  'schema_visualization', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13912432017060627)
,p_name=>'S'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13912591830060628)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(13912672500060629)
,p_name=>'D'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13914057131060643)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    route_id,',
'    sdo_geometry(',
'        2001,',
'        4326,',
'        sdo_point_type(',
'            source_longitude,',
'            source_latitude,',
'            NULL',
'        ),',
'        NULL,',
'        NULL',
'    ) as source_location,',
'    source_iata,',
'    sdo_geometry(',
'        2001,',
'        4326,',
'        sdo_point_type(',
'            dest_longitude,',
'            dest_latitude,',
'            NULL',
'        ),',
'        NULL,',
'        NULL',
'    ) as dest_location,',
'    dest_iata,',
'    create_great_circle_linestring(',
'        source_longitude,',
'        source_latitude,',
'        dest_longitude,',
'        dest_latitude,',
'        100,',
'        4326',
'    ) as flight_path',
'from graph_table( ebaj_openflights_routes_graph',
'    match (s is airport) -[e is connects]-> (d is airport)',
'    where s.iata = :P1_SOURCE_IATA and d.iata = :P1_DESTINATION_IATA',
'    columns (',
'        e.route_id     as route_id,',
'        s."longitude"  as source_longitude,',
'        s."latitude"   as source_latitude,',
'        d."longitude"  as dest_longitude,',
'        d."latitude"   as dest_latitude,',
'        s.iata         as source_iata,',
'        d.iata         as dest_iata',
'    )',
')'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_ajax_items_to_submit=>'P1_SOURCE_IATA,P1_DESTINATION_IATA'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(13914116702060644)
,p_region_id=>wwv_flow_imp.id(13914057131060643)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(13914264620060645)
,p_map_region_id=>wwv_flow_imp.id(13914116702060644)
,p_name=>unistr('\51FA\767A')
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_pk_column=>'ROUTE_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'SOURCE_LOCATION'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IANA: &SOURCE_IATA.<br>',
'Location: &SOURCE_LOCATION.',
''))
,p_info_window_adv_formatting=>false
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(13914328117060646)
,p_map_region_id=>wwv_flow_imp.id(13914116702060644)
,p_name=>unistr('\5230\7740')
,p_layer_type=>'POINT'
,p_display_sequence=>20
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_pk_column=>'ROUTE_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'DEST_LOCATION'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IANA: &DEST_IATA.<br>',
'Location: &DEST_LOCATION.'))
,p_info_window_adv_formatting=>false
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(13914459878060647)
,p_map_region_id=>wwv_flow_imp.id(13914116702060644)
,p_name=>unistr('\7D4C\8DEF')
,p_layer_type=>'LINE'
,p_display_sequence=>30
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_pk_column=>'ROUTE_ID'
,p_geometry_column_data_type=>'SDO_GEOMETRY'
,p_geometry_column=>'FLIGHT_PATH'
,p_stroke_color=>'#101010'
,p_stroke_style=>'SOLID'
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15331488669403767)
,p_plug_name=>'Airports and Routes'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13912336409060626)
,p_button_sequence=>30
,p_button_name=>'SEARCH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Search'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13912138044060624)
,p_name=>'P1_SOURCE_IATA'
,p_item_sequence=>10
,p_prompt=>'Source IATA'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LIST_IATA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    iata, airport_name, city, country',
'from ebaj_openflights_airports',
'group by iata, airport_name, city, country',
'order by country, city, airport_name'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13912212862060625)
,p_name=>'P1_DESTINATION_IATA'
,p_item_sequence=>20
,p_prompt=>'Destination IATA'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LIST_IATA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    iata, airport_name, city, country',
'from ebaj_openflights_airports',
'group by iata, airport_name, city, country',
'order by country, city, airport_name'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp.component_end;
end;
/
