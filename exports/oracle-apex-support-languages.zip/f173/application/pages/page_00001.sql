prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>173
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('APEX\306E\30B5\30DD\30FC\30C8\8A00\8A9E')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('/* Oracle APEX 24.1 \3067\30B5\30DD\30FC\30C8\3055\308C\3066\3044\308B\30E9\30F3\30BF\30A4\30E0\8A00\8A9E */'),
'const SUPPORTED_LANGUAGES = "ar,pt-br,hr,cs,da,nl,fi,fr,fr-ca,de,el,he,hu,is,it,ja,ko,no,pl,pt,ro,ru,sr-cyrl,sr-latn,zh-cn,sk,sl,es,sv,th,zh-tw,tr,uk,vi".split('','');',
'const INTERVAL = 1000 * 2; // 10 sec',
'var taskId;',
'',
'/*',
unistr(' * \30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0P1_LANG\306B\5207\308A\66FF\3048\308B\8A00\8A9E\3092\8A2D\5B9A\3059\308B\3002P1_LANG\306B\306F\3001\5024\306E\5909\66F4\3067\30DA\30FC\30B8\3092\9001\4FE1\3059\308B'),
unistr(' * \52D5\7684\30A2\30AF\30B7\30E7\30F3\304C\8A2D\5B9A\3055\308C\3066\3044\308B\3002\7D50\679C\3068\3057\3066\5207\308A\66FF\3048\305F\8A00\8A9E\3067APEX_UTIL.SET_PREFENCE\304C\547C\3073\51FA\3055\308C\3001'),
unistr(' * FSP_LANGUAGE_PREFERENCE\304C\5909\66F4\3055\308C\308B\3002'),
' * ',
unistr(' * P1_AUTO_SUBMIT\306BY\304C\8A2D\5B9A\3055\308C\3066\3044\308B\3068\3001\8A00\8A9E\306E\81EA\52D5\5207\308A\66FF\3048\3092\7D99\7D9A\3059\308B\3002'),
' */',
'function autoChange() {',
'    let currentIndex = SUPPORTED_LANGUAGES.findIndex(lang => lang === apex.item("P1_LANG").getValue());',
'    let nextIndex = currentIndex === (SUPPORTED_LANGUAGES.length - 1) ? 0 : currentIndex + 1;',
'    apex.item("P1_LANG").setValue(SUPPORTED_LANGUAGES[nextIndex]);',
'    apex.item("P1_AUTO_SUBMIT").setValue("Y");',
'}',
'',
'/*',
unistr(' * \8A00\8A9E\306E\81EA\52D5\5207\308A\66FF\3048\3092\958B\59CB\3059\308B\3002'),
' */',
'function startLoop() {',
'    if ( !taskId ) {',
'        taskId = setInterval(autoChange, INTERVAL);',
'        document.getElementById("START_LOOP").disabled = true;',
'        document.getElementById("STOP_LOOP").disabled  = false;',
'        console.log(''Start Language selection changed task '', taskId);',
'    }',
'}',
'',
'/*',
unistr(' * \8A00\8A9E\306E\81EA\52D5\5207\308A\66FF\3048\3092\505C\6B62\3059\308B\3002'),
' */',
'function stopLoop() {',
'    if (taskId) {',
'        clearInterval(taskId);',
'        document.getElementById("START_LOOP").disabled = false;',
'        document.getElementById("STOP_LOOP").disabled  = true;',
'        console.log(''Stop Language selection changed task '', taskId);',
'        taskId = null;',
'    }',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \8A00\8A9E\306E\81EA\52D5\5207\308A\66FF\3048\304C\6709\52B9\3067\3042\308C\3070\3001startLoop\3092\547C\3073\51FA\3059\3002'),
' */',
'if ( apex.item("P1_AUTO_ENABLED").getValue() === "Y" ) {',
'    startLoop();',
'}',
'else',
'{',
'    document.getElementById("START_LOOP").disabled = false;',
'    document.getElementById("STOP_LOOP").disabled  = true;    ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61991613905061631)
,p_plug_name=>unistr('\958B\767A\8A00\8A9E')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(64361803477585163)
,p_plug_display_sequence=>30
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_message clob;',
'begin',
'    l_message := apex_lang.message(''INSTALLER.WELCOME'');',
'    return l_message;',
'end;'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61992017177061635)
,p_plug_name=>'EMP'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(64352005649585142)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'EMP'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(61992139133061636)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>61992139133061636
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61992278092061637)
,p_db_column_name=>'EMPNO'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Empno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61992300864061638)
,p_db_column_name=>'ENAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ename'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61992455190061639)
,p_db_column_name=>'JOB'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Job'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61992539632061640)
,p_db_column_name=>'MGR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Mgr'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61992646738061641)
,p_db_column_name=>'HIREDATE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Hiredate'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61992773145061642)
,p_db_column_name=>'SAL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Sal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61992897334061643)
,p_db_column_name=>'COMM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Comm'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61992965832061644)
,p_db_column_name=>'DEPTNO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Deptno'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(64569446955715530)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'645695'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EMPNO:ENAME:JOB:MGR:HIREDATE:SAL:COMM:DEPTNO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64559605053585789)
,p_plug_name=>unistr('APEX\306E\30B5\30DD\30FC\30C8\8A00\8A9E')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(64328579276585094)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64586945528215801)
,p_plug_name=>'Start Stop Buttns'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(64298094945585029)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64587001388215802)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(64586945528215801)
,p_button_name=>'START_LOOP'
,p_button_static_id=>'START_LOOP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(64435461810585334)
,p_button_image_alt=>'Start Loop'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64587173980215803)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(64586945528215801)
,p_button_name=>'STOP_LOOP'
,p_button_static_id=>'STOP_LOOP'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(64435461810585334)
,p_button_image_alt=>'Stop Loop'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61991775797061632)
,p_name=>'P1_LANG'
,p_is_required=>true
,p_item_sequence=>20
,p_item_default=>'ja'
,p_prompt=>unistr('\8A00\8A9E')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'SUPPORTED LANGUAGES'
,p_lov=>'.'||wwv_flow_imp.id(64570273318775070)||'.'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(64432946183585327)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64588054699215812)
,p_name=>'P1_AUTO_SUBMIT'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64588142131215813)
,p_name=>'P1_AUTO_ENABLED'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61993098611061645)
,p_name=>'onChange Submit'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_LANG'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61993179592061646)
,p_event_id=>wwv_flow_imp.id(61993098611061645)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61993227264061647)
,p_name=>'Set Direction'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61993348720061648)
,p_event_id=>wwv_flow_imp.id(61993227264061647)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.documentElement.setAttribute(''dir'', ''rtl'');',
''))
,p_client_condition_type=>'IN_LIST'
,p_client_condition_element=>'P1_LANG'
,p_client_condition_expression=>'ar,he'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61993416155061649)
,p_event_id=>wwv_flow_imp.id(61993227264061647)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.documentElement.setAttribute(''dir'', ''ltr'');',
''))
,p_client_condition_type=>'NOT_IN_LIST'
,p_client_condition_element=>'P1_LANG'
,p_client_condition_expression=>'ar,he'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(64587224271215804)
,p_name=>'onClick START_LOOP'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(64587001388215802)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64587345983215805)
,p_event_id=>wwv_flow_imp.id(64587224271215804)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'startLoop();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(64587654742215808)
,p_name=>'onClick STOP_LOOP'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(64587173980215803)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64587930647215811)
,p_event_id=>wwv_flow_imp.id(64587654742215808)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'stopLoop();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61991913019061634)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Language Preference'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_util.set_preference(',
'        p_preference => ''FSP_LANGUAGE_PREFERENCE''',
'        ,p_value => :P1_LANG',
'    );',
'    /*',
unistr('     * autoChange\3067\306E\547C\3073\51FA\3057\3067\3042\308C\3070\3001P1_AUTO_ENABLED\3092Y\3068\3059\308B\3002'),
unistr('     * \624B\52D5\5207\308A\66FF\3048\306E\3068\304D\306FP1_AUTO_SUBMIT\306F\7A7A\306B\306A\308B\305F\3081\3001\81EA\52D5\5207\308A\66FF\3048\306F'),
unistr('     * \7D99\7D9A\3057\306A\3044\3002'),
'     */',
'    if :P1_AUTO_SUBMIT = ''Y'' then',
'        :P1_AUTO_ENABLED := ''Y'';',
'    else',
'        :P1_AUTO_ENABLED := '''';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>61991913019061634
);
wwv_flow_imp.component_end;
end;
/
