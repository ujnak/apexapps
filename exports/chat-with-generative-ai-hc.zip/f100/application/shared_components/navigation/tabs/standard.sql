prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.6'
,p_default_workspace_id=>2138965587838225
,p_default_application_id=>100
,p_default_id_offset=>5768918050551366
,p_default_owner=>'APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
