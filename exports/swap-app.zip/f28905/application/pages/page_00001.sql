prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-16'
,p_default_workspace_id=>30040104978234657984
,p_default_application_id=>28905
,p_default_id_offset=>0
,p_default_owner=>'WKSP_JAPANCOMMUNITY'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\5165\308C\66FF\3048')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230512063352'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11661284497162525231)
,p_plug_name=>unistr('\5DE6')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12130804385134898213)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11661284935440525236)
,p_plug_name=>unistr('\53F3')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(12130804385134898213)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12130996842044898362)
,p_plug_name=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\5165\308C\66FF\3048')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(12130771039669898199)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11661285236491525239)
,p_button_sequence=>30
,p_button_name=>'SWAP'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(12130877621128898249)
,p_button_image_alt=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\5165\308C\66FF\3048')
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11661284755657525234)
,p_name=>'P1_APP_L'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11661284497162525231)
,p_prompt=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_APPLICATIONS'
,p_lov=>'select application_id, alias, application_name from apex_applications '
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(12130875189329898247)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_10=>'ALIAS:P1_ALIAS_L'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11661284804248525235)
,p_name=>'P1_ALIAS_L'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(11661284497162525231)
,p_prompt=>unistr('\5225\540D')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(12130875189329898247)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11661285068122525237)
,p_name=>'P1_APP_R'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11661284935440525236)
,p_prompt=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_APPLICATIONS'
,p_lov=>'select application_id, alias, application_name from apex_applications '
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(12130875189329898247)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_10=>'ALIAS:P1_ALIAS_R'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11661285124718525238)
,p_name=>'P1_ALIAS_R'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11661284935440525236)
,p_prompt=>unistr('\5225\540D')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(12130875189329898247)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11661285307368525240)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>unistr('SWAP\306E\30AF\30EA\30C3\30AF...')
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(11661285236491525239)
,p_internal_uid=>11661285307368525240
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11661285534535525242)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(11661285307368525240)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\5165\308C\66FF\3048')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_left_id   apex_applications.application_id%type;',
'    l_left_name apex_applications.application_name%type;',
'    l_left_alias apex_applications.alias%type;',
'    l_right_id   apex_applications.application_id%type;',
'    l_right_name apex_applications.application_name%type;',
'    l_right_alias apex_applications.alias%type;',
'    C_TEMP_ALIAS constant varchar2(80) := ''QGEADAFBTEWE'';',
'begin',
unistr('    -- \5DE6\5074\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\60C5\5831\3092\53D6\5F97\3059\308B\3002'),
'    l_left_id    := :P1_APP_L;',
'    l_left_alias := :P1_ALIAS_L;',
'    l_left_name  := apex_application_admin.get_application_name(',
'        p_application_id => l_left_id',
'    );',
unistr('    -- \53F3\5074\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\60C5\5831\3092\53D6\5F97\3059\308B\3002'),
'    l_right_id    := :P1_APP_R;',
'    l_right_alias := :P1_ALIAS_R;',
'    l_right_name  := apex_application_admin.get_application_name(',
'        p_application_id => l_right_id',
'    );',
unistr('    -- \5DE6\5074\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306B\53F3\5074\306E\60C5\5831\3092\8A2D\5B9A\3059\308B\3002'),
'    apex_application_admin.set_application_name(',
'        p_application_id => l_left_id',
'        ,p_application_name => l_right_name',
'    );',
'    apex_application_admin.set_application_name(',
'        p_application_id => l_right_id',
'        ,p_application_name => l_left_name',
'    );',
unistr('    -- \5DE6\306E\30A2\30D7\30EA\306E\5225\540D\3092\4E00\6642\7684\306B\5909\66F4\3059\308B\3002'),
'    apex_application_admin.set_application_alias(',
'        p_application_id => l_left_id',
'        ,p_application_alias => C_TEMP_ALIAS',
'    );',
unistr('    -- \53F3\5074\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306B\5DE6\5074\306E\60C5\5831\3092\8A2D\5B9A\3059\308B\3002'),
'    apex_application_admin.set_application_alias(',
'        p_application_id => l_right_id',
'        ,p_application_alias => l_left_alias',
'    );',
unistr('    -- \5DE6\5074\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306B\53F3\5074\306E\60C5\5831\3092\8A2D\5B9A\3059\308B\3002'),
'    apex_application_admin.set_application_alias(',
'        p_application_id => l_left_id',
'        ,p_application_alias => l_right_alias',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>11661285534535525242
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11661285609071525243)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(11661285307368525240)
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>unistr('\30AF\30EA\30A2')
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_internal_uid=>11661285609071525243
);
wwv_flow_imp.component_end;
end;
/
