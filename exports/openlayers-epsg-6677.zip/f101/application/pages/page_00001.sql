prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>7601775501100353
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\65E5\672C\6E2C\5730\7CFB2011\5730\56F3')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/proj4@2.19.10/dist/proj4.js',
'https://cdn.jsdelivr.net/npm/ol@10.6.1/dist/ol.js',
'#APP_FILES#app#MIN#.js'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#map {',
'   width: 100%;',
'   height: 800px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15005374285384245)
,p_plug_name=>unistr('\65E5\672C\6E2C\5730\7CFB2011\5730\56F3')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23946306318952442)
,p_plug_name=>unistr('\65E5\672C\6E2C\5730\7CFB2011\5730\56F3')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>'<div id="map"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23946191010952440)
,p_name=>'P1_STATUS'
,p_item_sequence=>10
,p_prompt=>'Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23946298187952441)
,p_name=>'P1_LINEWIDTH'
,p_item_sequence=>20
,p_item_default=>'1'
,p_prompt=>'Line width'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(23946427910952443)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_GEOM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_extent varchar2(200);',
'    l_extent_array json_array_t;',
'    l_min_x number;',
'    l_min_y number;',
'    l_max_x number;',
'    l_max_y number;',
'    l_line_array_clob clob;',
'    l_line_array json_array_t;',
'    l_response   json_object_t;',
'    l_response_blob blob;',
'begin',
unistr('    /* \5F15\6570\3067\3042\308B\30DE\30C3\30D7\306E\8868\793A\3055\308C\3066\3044\308B\9818\57DF\3092\53D6\5F97\3059\308B */'),
'    l_extent := apex_application.g_x01;',
'    apex_debug.info(''extent = %s'', l_extent);',
'    l_extent_array := json_array_t(l_extent);',
'    l_min_x := l_extent_array.get_number(0);',
'    l_min_y := l_extent_array.get_number(1);',
'    l_max_x := l_extent_array.get_number(2);',
'    l_max_y := l_extent_array.get_number(3);',
'    /* ',
unistr('     * \6307\5B9A\3057\305F\9818\57DF\306E\7B49\9AD8\7DDA\3092\691C\7D22\3057\3066\3001JSON\914D\5217\3067\8FD4\3059\3002\672C\6765\306FEPSG:4326\3067\8FD4\3059'),
unistr('     * \3079\304D\3060\304C\3001OpenLayers\3067EPSG:6677\3092\63CF\753B\3059\308B\3088\3046\306B\3057\3066\3044\308B\306E\3067\5909\63DB\3057\306A\3044\3002'),
'     */',
'    begin',
'        select json_arrayagg(geojson format json returning clob)',
'        into l_line_array_clob',
'        from',
'        (',
'            select sdo_util.to_geojson(geom) as geojson from contour_lines_6677',
'            where SDO_FILTER(',
'                GEOM,',
'                SDO_GEOMETRY(',
unistr('                    2003,                    -- 2\6B21\5143\30DD\30EA\30B4\30F3\FF08\77E9\5F62\FF09'),
'                    6677,                    -- EPSG:6677',
unistr('                    NULL,                    -- SDO_POINT (\4F7F\7528\3057\306A\3044)'),
unistr('                    SDO_ELEM_INFO_ARRAY(1, 1003, 3),  -- \77E9\5F62\306E\5B9A\7FA9'),
'                    SDO_ORDINATE_ARRAY(l_min_x, l_min_y, l_max_x, l_max_y)',
'                )',
'            ) = ''TRUE''',
'        );',
'    exception',
'        when no_data_found then',
'            l_line_array_clob := null;',
'        when others then',
'            raise;',
'    end;',
'    if l_line_array_clob is null then',
unistr('        /* \691C\7D22\7D50\679C\304C\306A\3051\308C\3070\7A7A\306E\7D50\679C\3092\8FD4\3059 */'),
'        htp.p(''{ "geom": [] }'');',
'        return;',
'    end if;',
unistr('    /* \691C\7D22\7D50\679C\3092\30D6\30E9\30A6\30B6\306B\8FD4\3059\3002 */'),
'    l_line_array := json_array_t.parse(l_line_array_clob);',
'    l_response := json_object_t();',
'    l_response.put(''geom'', l_line_array);',
'    l_response_blob := l_response.to_blob();',
unistr('    /* \5927\91CF\306E\30C7\30FC\30BF\306B\306A\308B\53EF\80FD\6027\304C\3042\308B\306E\3067\3001\30C7\30FC\30BF\306E\30C0\30A6\30F3\30ED\30FC\30C9\3092\5B9F\65BD\3059\308B\3002 */'),
'    sys.htp.init;',
'    sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_response_blob));',
'    sys.htp.p(''Content-Type: application/json'');',
'    sys.htp.p(''Content-Disposition: attachment; filename=geom.json'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_response_blob);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>23946427910952443
);
wwv_flow_imp.component_end;
end;
/
