prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>142
,p_default_id_offset=>49662744171253641
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\30D6\30E9\30F3\30C9\30FB\30A2\30A4\30B3\30F3')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.fa6-instagram {',
'    background-image: url("#WORKSPACE_FILES#instagram.svg");',
'    background-repeat: no-repeat;',
'    display: block;',
'    background-position: center center;',
'    background-size: contain;',
'    width: 16px;',
'    height: 16px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230215082132'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99309500736110042)
,p_plug_name=>'Brand Icon'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(99184362161727952)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span aria-hidden="true" class="t-Icon fa fa-facebook"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-facebook-square"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-github"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-github-square"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-google"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-linkedin"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-linkedin-square"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-oracle-o"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-oracle-o-square"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-oracle"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-twitter"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-twitter-square"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-youtube"></span>',
'<span aria-hidden="true" class="t-Icon fa fa-youtube-square"></span>',
'<span aria-hidden="true" class="t-Icon fa fa6-instagram"></span>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
