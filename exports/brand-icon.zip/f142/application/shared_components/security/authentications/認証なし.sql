prompt --application/shared_components/security/authentications/認証なし
begin
--   Manifest
--     AUTHENTICATION: 認証なし
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>142
,p_default_id_offset=>49662744171253641
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(99295925656740607)
,p_name=>unistr('\8A8D\8A3C\306A\3057')
,p_scheme_type=>'NATIVE_DAD'
,p_attribute_01=>'nobody'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
