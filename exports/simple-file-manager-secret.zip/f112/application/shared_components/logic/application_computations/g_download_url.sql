prompt --application/shared_components/logic/application_computations/g_download_url
begin
--   Manifest
--     APPLICATION COMPUTATION: G_DOWNLOAD_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>112
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(14524599029888042)
,p_computation_sequence=>10
,p_computation_item=>'G_DOWNLOAD_URL'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \7C21\6613URL\304CON\306E\3068\304D\306BAPEX_UTIL.HOST_URL(''SCRIPT'')\304C\6B63\3057\3044\5024\3092'),
unistr(' * \8FD4\3055\306A\3044\3053\3068\304C\3042\308B\3002\4EE5\4E0B\306F\305D\306E\30EF\30FC\30AF\30A2\30E9\30A6\30F3\30C9\3068\3057\3066\306E\5B9F\88C5\3082\542B\3080\3002'),
' */',
'declare',
'    l_download_url varchar2(800);',
'    l_apex_path    varchar2(400);',
'    l_pattern      varchar2(100);',
'    l_alias        varchar2(200);',
'begin',
unistr('    /* https://\30DB\30B9\30C8\540D:\30DD\30FC\30C8\756A\53F7/ords \307E\3067\3002 */'),
'    l_apex_path := apex_util.host_url(''APEX_PATH'');',
unistr('    /* ORDS\5225\540D\3092\53D6\5F97\3059\308B\3002\901A\5E38\306F\30EF\30FC\30AF\30B9\30DA\30FC\30B9\540D\306B\4E00\81F4\3059\308B\3002 */'),
'    select pattern into l_pattern from user_ords_schemas',
'    where parsing_schema = sys_context(''USERENV'',''CURRENT_USER'');',
'    /*',
unistr('     * \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\5225\540D\3002 \65E5\672C\8A9E\306E\5BFE\5FDC\3092\884C\306A\3063\3066\3044\308B\304C\52B9\679C\306F\672A\78BA\8A8D\3002 '),
unistr('     * \672C\6765\306FAPEX_URL.HOST_URL(''SCRIPT'')\306F\3053\3053\307E\3067\306E\6587\5B57\5217\3092\8FD4\3059\3002'),
unistr('    \3000*/'),
'    l_alias := utl_url.escape(lower(:APP_ALIAS), false, ''AL32UTF8'');',
unistr('    /* \5168\4F53\3068\3057\3066\306EURL */'),
'    l_download_url := l_apex_path || ''r/'' || l_pattern || ''/'' || l_alias || ''/download?id='';',
'    return l_download_url;',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
