prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>201
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Transformers.js Object Detector'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.container {',
'    margin: 40px auto;',
'    width: max(50vw, 400px);',
'    display: flex;',
'    flex-direction: column;',
'    align-items: center;',
'}',
'',
'#image-container {',
'    width: 100%;',
'    margin-top: 20px;',
'    position: relative;',
'}',
'',
'#image-container>img {',
'    width: 100%;',
'}',
'',
'.bounding-box {',
'    position: absolute;',
'    box-sizing: border-box;',
'    border-width: 2px;',
'    border-style: solid;',
'}',
'',
'.bounding-box-label {',
'    color: white;',
'    position: absolute;',
'    font-size: 12px;',
'    margin-top: -16px;',
'    margin-left: -2px;',
'    padding: 1px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105697838956803742)
,p_plug_name=>'Object Detector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(106706495756884336)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="container">',
'<div id="image-container" class="w80p"></div>',
'</div>',
'<script type="module" defer>',
'import { pipeline, env } from ''https://cdn.jsdelivr.net/npm/@xenova/transformers@2.6.0'';',
'',
'// Since we will download the model from the Hugging Face Hub, we can skip the local model check',
'env.allowLocalModels = false;',
'',
'// Reference the elements that we will need',
'const fileUpload = document.getElementById(''P1_IMAGE'');',
'const imageContainer = document.getElementById(''image-container'');',
'',
'// Create a new object detection pipeline',
'apex.item("P1_STATUS").setValue(''Loading model...'');',
'const detector = await pipeline(''object-detection'', ''Xenova/detr-resnet-50'');',
'apex.item("P1_STATUS").setValue(''Ready'');',
'',
'fileUpload.addEventListener(''change'', function (e) {',
'    const file = e.target.files[0];',
'    if (!file) {',
'        return;',
'    }',
'',
'    const reader = new FileReader();',
'',
'    // Set up a callback when the file is loaded',
'    reader.onload = function (e2) {',
'        imageContainer.innerHTML = '''';',
'        const image = document.createElement(''img'');',
'        image.src = e2.target.result;',
'        imageContainer.appendChild(image);',
'        detect(image);',
'    };',
'    reader.readAsDataURL(file);',
'});',
'',
'',
'// Detect objects in the image',
'async function detect(img) {',
'    apex.item("P1_STATUS").setValue(''Analysing...'');',
'    const output = await detector(img.src, {',
'        threshold: 0.5,',
'        percentage: true,',
'    });',
'    apex.item("P1_STATUS").setValue('''');',
'    output.forEach(renderBox);',
'}',
'',
'// Render a bounding box and label on the image',
'function renderBox({ box, label }) {',
'    const { xmax, xmin, ymax, ymin } = box;',
'',
'    // Generate a random color for the box',
'    const color = ''#'' + Math.floor(Math.random() * 0xFFFFFF).toString(16).padStart(6, 0);',
'',
'    // Draw the box',
'    const boxElement = document.createElement(''div'');',
'    boxElement.className = ''bounding-box'';',
'    Object.assign(boxElement.style, {',
'        borderColor: color,',
'        left: 100 * xmin + ''%'',',
'        top: 100 * ymin + ''%'',',
'        width: 100 * (xmax - xmin) + ''%'',',
'        height: 100 * (ymax - ymin) + ''%'',',
'    })',
'',
'    // Draw label',
'    const labelElement = document.createElement(''span'');',
'    labelElement.textContent = label;',
'    labelElement.className = ''bounding-box-label'';',
'    labelElement.style.backgroundColor = color;',
'',
'    boxElement.appendChild(labelElement);',
'    imageContainer.appendChild(boxElement);',
'}',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105697743237803741)
,p_name=>'P1_STATUS'
,p_item_sequence=>20
,p_prompt=>'Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(106843858187884949)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105697917327803743)
,p_name=>'P1_IMAGE'
,p_item_sequence=>10
,p_prompt=>'Image'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(106843858187884949)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
,p_attribute_18=>'N'
);
wwv_flow_imp.component_end;
end;
/
