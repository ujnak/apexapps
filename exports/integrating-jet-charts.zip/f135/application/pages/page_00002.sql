prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>135
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'oj-chart'
,p_alias=>'OJ-CHART'
,p_step_title=>'oj-chart'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>'require(["ojs/ojchart"], function() {});'
,p_css_file_urls=>'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31576097501006208)
,p_plug_name=>'oj-chart'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(31375433996004631)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<oj-chart',
'    id="barChart"',
'    type="bar"',
'    orientation="horizontal"',
'    stack="off"',
'    groups=''&P2_GROUPS!ATTR.''',
'    series=''[ { "color": "#309fdb", "items": &P2_VALUE!ATTR. } ]''',
'    animation-on-display="auto"',
'    animation-on-data-change="auto"',
'    hover-behavior="dim">',
'</oj-chart>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31583799832137878)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(31387887764004656)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(31272180348004427)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(31450670985004799)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31575828162006206)
,p_name=>'P2_GROUPS'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31575941250006207)
,p_name=>'P2_VALUE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(31576123475006209)
,p_computation_sequence=>10
,p_computation_item=>'P2_GROUPS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        json_object(',
'            ''name'' value ename',
'        )',
'    order by empno asc )',
'from emp where deptno = 10'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(31576283391006210)
,p_computation_sequence=>20
,p_computation_item=>'P2_VALUE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        sal',
'    order by empno asc )',
'from emp where deptno = 10'))
);
wwv_flow_imp.component_end;
end;
/
