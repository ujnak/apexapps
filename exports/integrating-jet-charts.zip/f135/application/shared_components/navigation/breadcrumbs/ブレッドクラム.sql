prompt --application/shared_components/navigation/breadcrumbs/ブレッドクラム
begin
--   Manifest
--     MENU: ブレッドクラム
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>135
,p_default_id_offset=>35374607149853667
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(66646787497858094)
,p_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(66646924297858094)
,p_short_name=>unistr('\30DB\30FC\30E0')
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(66958708603991546)
,p_short_name=>'oj-chart'
,p_link=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(67000628681950407)
,p_short_name=>'Template Component'
,p_link=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(67006547092053810)
,p_short_name=>'Report - oj-chart'
,p_link=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(67196223624060045)
,p_short_name=>'Report - Template Component'
,p_link=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp.component_end;
end;
/
