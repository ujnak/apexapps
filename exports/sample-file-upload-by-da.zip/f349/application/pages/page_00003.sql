prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>349
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Document'
,p_alias=>'DOCUMENT'
,p_page_mode=>'MODAL'
,p_step_title=>'Document'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(79955860257453506)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240313074833'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80257620541453914)
,p_plug_name=>'Document'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(79991717113453525)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'FUD_DOCUMENTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80260707362453917)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(79994589633453527)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76182586959993921)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(80257620541453914)
,p_button_name=>'REPLACE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(80131555963453594)
,p_button_image_alt=>'Replace'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(80261115503453917)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(80260707362453917)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(80131555963453594)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(80262500075453918)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(80260707362453917)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(80131555963453594)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(80262926756453919)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(80260707362453917)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(80131555963453594)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(80263305641453919)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(80260707362453917)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(80131555963453594)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80257943556453915)
,p_name=>'P3_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(80257620541453914)
,p_item_source_plug_id=>wwv_flow_imp.id(80257620541453914)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80258369731453915)
,p_name=>'P3_FILE_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(80257620541453914)
,p_item_source_plug_id=>wwv_flow_imp.id(80257620541453914)
,p_prompt=>'File Name'
,p_source=>'FILE_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(80129037621453593)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80258793198453915)
,p_name=>'P3_MIME_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(80257620541453914)
,p_item_source_plug_id=>wwv_flow_imp.id(80257620541453914)
,p_source=>'MIME_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80259186639453915)
,p_name=>'P3_CONTENT'
,p_source_data_type=>'BLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(80257620541453914)
,p_item_source_plug_id=>wwv_flow_imp.id(80257620541453914)
,p_prompt=>'Content'
,p_source=>'CONTENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(80129037621453593)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_02=>'MIME_TYPE'
,p_attribute_03=>'FILE_NAME'
,p_attribute_06=>'Y'
,p_attribute_08=>'attachment'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80261278478453917)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(80261115503453917)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80262076456453918)
,p_event_id=>wwv_flow_imp.id(80261278478453917)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76182603256993922)
,p_name=>'onClick REPLACE'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(76182586959993921)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76182710976993923)
,p_event_id=>wwv_flow_imp.id(76182603256993922)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \30DC\30BF\30F3\3092\62BC\3057\305F\3068\304D\306B\547C\3073\51FA\3055\308C\308B\3002'),
' */',
'const content = document.getElementById("P3_CONTENT");',
'const file    = content.files[0];',
'const filename = file.name;',
'const mimetype = file.type;',
'const reader  = new FileReader();',
unistr('const spinner = apex.widget.waitPopup(); // \30B9\30D4\30CA\30FC\8868\793A\958B\59CB\3002'),
'',
'/* ',
unistr(' * P3_CONTENT\306B\8A2D\5B9A\3055\308C\305F\30D5\30A1\30A4\30EB\304C\8AAD\307F\8FBC\307E\308C\305F\3002'),
' */',
'reader.onload = () => {',
'    /*',
unistr('     * \8AAD\307F\8FBC\3093\3060\30D5\30A1\30A4\30EB\3092ORDS REST API\3092\547C\3073\51FA\3057\3066\9001\4FE1\3059\308B\3002'),
'     */',
'    const formData = new FormData();',
'    formData.append("file", reader.result);',
'    const request = new XMLHttpRequest();',
'',
'    /*',
unistr('     * \9001\4FE1\304C\5B8C\4E86\3057\305F\3002'),
'     */',
'    request.onreadystatechange = () => {',
'        if (request.readyState === 4) {',
'            alert(request.response);',
unistr('            spinner.remove(); // \30B9\30D4\30CA\30FC\8868\793A\7D42\4E86\3002'),
'        }',
'    };',
'',
'    /*',
unistr('     * ORDS REST API\3092\547C\3073\51FA\3059\3002'),
unistr('     * \9001\4FE1\304C\7D42\4E86\3057\305F\3089request.onreadystatechange\304C\547C\3073\51FA\3055\308C\308B\3002'),
'     */',
'    request.open("PUT", "/ords/apexdev/fud/upload?id=" + apex.items.P3_ID.value + ''&name='' + filename + ''&type='' + mimetype);',
'    request.setRequestHeader("Apex-Session", apex.env.APP_ID + "," + apex.env.APP_SESSION);',
'    request.send(formData);',
'}',
'',
'/*',
unistr(' * P3_CONTENT\3067\9078\629E\3055\308C\305F\30D5\30A1\30A4\30EB\3092\8AAD\307F\8FBC\3080\3002'),
unistr(' * \8AAD\307F\8FBC\307F\5B8C\4E86\3067 reader.onload \304C\547C\3073\51FA\3055\308C\308B\3002'),
' */',
'reader.readAsBinaryString(file);'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80264191783453919)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(80257620541453914)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0Document')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>80264191783453919
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80264518961453919)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>80264518961453919
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80263709307453919)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(80257620541453914)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0Document')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>80263709307453919
);
wwv_flow_imp.component_end;
end;
/
