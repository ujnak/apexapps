prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>182
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'PowerPoint Viewer'
,p_alias=>'POWERPOINT-VIEWER'
,p_step_title=>'PowerPoint Viewer'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APP_FILES#js/jszip.min.js',
'#APP_FILES#js/filereader.js',
'#APP_FILES#js/d3.min.js',
'#APP_FILES#js/nv.d3.min.js',
'#APP_FILES#js/dingbat.js',
'#APP_FILES#js/pptxjs.min.js',
'#APP_FILES#js/divs2slides.min.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#container").pptxToHtml({',
'    pptxFileUrl: apex.item("P5_DOCUMENT_URL").getValue(),',
'    slideMode: false,',
'    keyBoardShortCut: false',
'});'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APP_FILES#css/pptxjs.css',
'#APP_FILES#css/nv.d3.min.css'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66379884677820494)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(66174492997819654)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(66058737585819394)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(66237206192819811)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66408871904429101)
,p_plug_name=>'Document Viewer'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(66162016902819626)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>'<div id="container" class="h600"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64591743335215849)
,p_button_sequence=>20
,p_button_name=>'VIEW'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(66235623703819807)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'View'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64591681623215848)
,p_name=>'P5_ID'
,p_item_sequence=>10
,p_prompt=>'Document'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select title d, id r from ebaj_docv_documents',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Document -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(66233106822819800)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64591868576215850)
,p_name=>'P5_DOCUMENT_URL'
,p_item_sequence=>30
,p_prompt=>'Document URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(66233106822819800)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(66408997420429102)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Document URL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url varchar2(400);',
'begin',
'    l_url := apex_page.get_url(',
'        p_application => :APP_ID',
'        ,p_page => ''download''',
'        ,p_items => ''P6_ID''',
'        ,p_values => :P5_ID -- assume select list on page 5',
'    );',
'    :P5_DOCUMENT_URL := l_url;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(64591743335215849)
,p_internal_uid=>66408997420429102
);
wwv_flow_imp.component_end;
end;
/
