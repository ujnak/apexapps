prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>182
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Word Viewer'
,p_alias=>'WORD-VIEWER'
,p_step_title=>'Word Viewer'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "mammoth": "https://cdn.jsdelivr.net/npm/mammoth@1.8.0/+esm"',
'        }',
'    }',
'</script>'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64591540743215847)
,p_plug_name=>'Document Viewer'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(66162016902819626)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="container"></div>',
'<script type="module">',
'    import mammoth from ''mammoth'';',
'',
'    const element = document.getElementById("container");',
'    const url = apex.item("P4_DOCUMENT_URL").getValue();',
'    fetch( url )',
'    .then(response => response.arrayBuffer())',
'        .then(arrayBuffer => {',
'            mammoth.convertToHtml( { arrayBuffer: arrayBuffer })',
'            .then(result => {',
'                element.insertAdjacentHTML("afterbegin", result.value);',
'            });',
'        });',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66378209945820490)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(66174492997819654)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(66058737585819394)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(66237206192819811)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64591283327215844)
,p_button_sequence=>20
,p_button_name=>'VIEW'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(66235623703819807)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'View'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64591115152215843)
,p_name=>'P4_ID'
,p_item_sequence=>10
,p_prompt=>'Document'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select title d, id r from ebaj_docv_documents'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Document -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(66233106822819800)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64591334491215845)
,p_name=>'P4_DOCUMENT_URL'
,p_item_sequence=>30
,p_prompt=>'Document URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(66233106822819800)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(64591462393215846)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Document URL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url varchar2(400);',
'begin',
'    l_url := apex_page.get_url(',
'        p_application => :APP_ID',
'        ,p_page => ''download''',
'        ,p_items => ''P6_ID''',
'        ,p_values => :P4_ID -- assume select list on page 4',
'    );',
'    :P4_DOCUMENT_URL := l_url;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(64591283327215844)
,p_internal_uid=>64591462393215846
);
wwv_flow_imp.component_end;
end;
/
