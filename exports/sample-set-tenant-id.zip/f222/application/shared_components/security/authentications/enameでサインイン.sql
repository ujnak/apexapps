prompt --application/shared_components/security/authentications/enameでサインイン
begin
--   Manifest
--     AUTHENTICATION: ENAMEでサインイン
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>222
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(24736337923721915)
,p_name=>unistr('ENAME\3067\30B5\30A4\30F3\30A4\30F3')
,p_scheme_type=>'NATIVE_OPEN_DOOR'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure set_tenant',
'as',
'    l_deptno emp.deptno%type;',
'begin',
'    select deptno into l_deptno from emp where ename = :APP_USER;',
'    apex_session.set_tenant_id(',
'        p_tenant_id => to_char(l_deptno)',
'    );',
'exception',
'    when no_data_found then',
'        null;',
'end;'))
,p_post_auth_process=>'set_tenant'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
