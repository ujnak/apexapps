prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>108
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'LM Studio'
,p_alias=>'LM-STUDIO'
,p_step_title=>'LM Studio'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#app#MIN#.js'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.point {',
'    position: absolute;',
'    width: 10px;',
'    height: 10px;',
'    background-color: red;',
'    border-radius: 50%;',
'    border: 2px solid white;',
'    box-shadow: 0 0 5px rgba(0,0,0,0.5);',
'    transform: translate(-50%, -50%);',
'    cursor: pointer;',
'}',
'',
'.bounding-box {',
'    border-color: #0F0;',
'    position: absolute;',
'    box-sizing: border-box;',
'    border-width: 2px;',
'    border-style: solid;',
'}',
'',
'.line-div {',
'    position: absolute;',
'    background-color: #ff0000;',
'    height: 3px;',
'    transform-origin: left center;',
'    z-index: 10;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29725540223297568)
,p_plug_name=>'Left Region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29725619177297569)
,p_plug_name=>'Right Region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31122189596692623)
,p_plug_name=>'RoboBrain2.0 Simple Inference'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15667548133380074)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(29725619177297569)
,p_button_name=>'SET_IMAGE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Set Image'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15668354761380074)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(29725619177297569)
,p_button_name=>'ASK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Ask'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15667968193380074)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(29725619177297569)
,p_button_name=>'RENDER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Render'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29726380453297581)
,p_name=>'P2_IMAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(29725540223297568)
,p_prompt=>'Image'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_css_classes=>'w100p'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#:margin-top-none:margin-left-none'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'SQL',
  'sql_statement', 'select blob001 from apex_collections where collection_name = ''IMAGE'' and n001 = 1;')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29728717865297588)
,p_name=>'P2_IMAGE_FILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(29725619177297569)
,p_prompt=>'Image File'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_cropping', 'N',
  'allow_multiple_files', 'N',
  'display_as', 'INLINE',
  'purge_files_at', 'REQUEST',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29728957945297590)
,p_name=>'P2_PROMPT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(29725619177297569)
,p_prompt=>'Prompt'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29729090905297592)
,p_name=>'P2_RESPONSE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(29725619177297569)
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>10
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29729975995297600)
,p_name=>'P2_TASK'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(29725619177297569)
,p_item_default=>'general'
,p_prompt=>'Task'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:general;general,pointing;pointing,affordance;affordance,trajectory;trajectory,grounding;grounding'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '5',
  'page_action_on_selection', 'NONE')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29730434421297605)
,p_name=>'P2_ENABLE_THINKING'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(29725619177297569)
,p_item_default=>'N'
,p_prompt=>'Enable Thinking'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15672038471380079)
,p_name=>'onClick RENDER'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(15667968193380074)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15672548610380080)
,p_event_id=>wwv_flow_imp.id(15672038471380079)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'render();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15670856455380078)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Image'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_blob blob;',
'    l_mime_type varchar2(4000);',
'begin',
'    select blob_content, mime_type into l_blob, l_mime_type',
'    from apex_application_temp_files where name = :P2_IMAGE_FILE;',
'    /*',
unistr('     * \30A2\30C3\30D7\30ED\30FC\30C9\3057\305F\30A4\30E1\30FC\30B8\306F\3064\306D\306BN001=1\3067\53D6\5F97\3067\304D\308B\3002'),
unistr('     * \3053\308C\304C\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0P2_IMAGE\306E\30BD\30FC\30B9\3068\306A\308B\3002'),
'     */',
'    apex_collection.create_or_truncate_collection(''IMAGE'');',
'    apex_collection.add_member(',
'        p_collection_name => ''IMAGE''',
'        ,p_n001    => 1',
'        ,p_c001    => l_mime_type',
'        ,p_blob001 => l_blob',
'    );',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15667548133380074)
,p_internal_uid=>15670856455380078
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15671230812380079)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ask'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    /* Local LM Studio */',
'    C_ENDPOINT constant varchar2(4000) := ''http://host.containers.internal:8080/v1/chat/completions'';',
'    /* LLM model name */',
'    C_MODEL    constant varchar2(200) := ''baai_robobrain2.0-7b@bf16'';',
'    ',
unistr('    /* \5199\771F\306B\95A2\3059\308B\5909\6570 */'),
'    l_image    json_object_t;',
'    l_image_url json_object_t;',
'    l_mime_type apex_application_temp_files.mime_type%type;',
'    l_blob_content apex_application_temp_files.blob_content%type;',
unistr('    /* \9001\4FE1\3059\308B\30E1\30C3\30BB\30FC\30B8 */'),
'    l_prompt   json_object_t;',
'    l_text     clob;',
'    l_content  json_array_t;',
'    l_message  json_object_t;',
'    l_messages json_array_t;',
'    l_request  json_object_t;',
'    l_request_clob clob;',
unistr('    /* \53D7\4FE1\3059\308B\30E1\30C3\30BB\30FC\30B8 */'),
'    l_response clob;',
'    l_response_json json_object_t;',
'    e_call_api_failed exception;',
'    l_choices json_array_t;',
'    l_choice  json_object_t;',
'    l_response_message clob;',
'begin',
unistr('    /* \5199\771F\306E\53D6\308A\51FA\3057 */'),
'    select blob001, c001 into l_blob_content, l_mime_type',
'    from apex_collections where collection_name = ''IMAGE'' and n001 = 1;',
unistr('    /* \30A4\30E1\30FC\30B8\306E\6E96\5099 - base64\3067\9001\4FE1\3059\308B */'),
'    l_image_url := json_object_t();',
'    /*',
unistr('     * LM Studio\3067\306Fimage_url\30AA\30D6\30B8\30A7\30AF\30C8\306B\76F4\63A5base64\306E\6587\5B57\5217\3092\5165\308C\308B\306E\306F\4E0D\53EF\3067\3001'),
unistr('     * url\30AA\30D6\30B8\30A7\30AF\30C8\306Bbase64\306E\6587\5B57\5217\3092\5165\308C\3066\3001image_url\306B\4E0E\3048\308B\5FC5\8981\304C\3042\308B\3002'),
'     */',
'    apex_debug.info(''mime_type = %s'', l_mime_type);',
'    l_image_url.put(''url'', ''data:'' || l_mime_type || '';base64,'' ',
'        || apex_web_service.blob2clobbase64(l_blob_content, ''N'', ''N'')',
'    );',
'    l_image := json_object_t();',
'    l_image.put(''type'', ''image_url'');',
'    l_image.put(''image_url'', l_image_url);',
unistr('    /* \30D7\30ED\30F3\30D7\30C8\306E\6E96\5099 */'),
'    l_prompt := json_object_t();',
'    l_prompt.put(''type'', ''text'');',
unistr('    /* \30BF\30B9\30AF\306E\9078\629E\306B\5F93\3063\3066\3001\30D7\30ED\30F3\30C8\30D7\30C8\3092\62E1\5F35\3059\308B\3002 */'),
'    if :P2_TASK = ''pointing'' then',
'        apex_debug.info(''Pointing task detected. We automatically add a pointing prompt for inference.'');',
'        l_text := apex_string.format(''%s. Your answer should be formatted as a list of tuples, i.e. [(x1, y1), (x2, y2), ...], where each tuple contains the x and y coordinates of a point satisfying the conditions above. The coordinates should indica'
||'te the normalized pixel locations of the points in the image. '', :P2_PROMPT);',
'    elsif :P2_TASK = ''affordance'' then',
'        apex_debug.info(''Affordance task detected. We automatically add an affordance prompt for inference.'');',
'        l_text := apex_string.format(''You are a robot using the joint control. The task is \"%s\". Please predict a possible affordance area of the end effector.'', :P2_PROMPT);',
'    elsif :P2_TASK = ''trajectory'' then',
'        apex_debug.info(''Trajectory task detected. We automatically add a trajectory prompt for inference.'');',
'        l_text := apex_string.format(''You are a robot using the joint control. The task is \"%s\". Please predict up to 10 key trajectory points to complete the task. Your answer should be formatted as a list of tuples, i.e. [[x1, y1], [x2, y2], ...]'
||', where each tuple contains the x and y coordinates of a point.'', :P2_PROMPT);',
'    elsif :P2_TASK = ''grounding'' then',
'        apex_debug.info(''Grounding task detected. We automatically add a grounding prompt for inference.'');',
'        l_text := apex_string.format(''Please provide the bounding box coordinate of the region this sentence describes: %s.'', :P2_PROMPT);',
'    else',
'        apex_debug.info(''General Task.'');',
'        l_text := :P2_PROMPT;',
'    end if;',
unistr('    /* Think\3092\3064\3051\308B\FF1F */'),
'    if :P2_ENABLE_THINKING = ''Y'' then ',
'        l_text := ''/think '' || l_text;',
'    end if;',
'    l_prompt.put(''text'', l_text);   ',
unistr('    /* content\306E\4F5C\6210 */'),
'    l_content := json_array_t();',
'    l_content.append(l_prompt);',
'    l_content.append(l_image);',
unistr('    /* message\306E\4F5C\6210 - system\30D7\30ED\30F3\30D7\30C8\306F\7121\3057, user\306E\5358\767A\306E\307F */'),
'    l_message := json_object_t();',
'    l_message.put(''role'', ''user'');',
'    l_message.put(''content'', l_content);',
unistr('    /* messages\306E\4F5C\6210 */'),
'    l_messages := json_array_t();',
'    l_messages.append(l_message);',
unistr('    /* request\306E\4F5C\6210 */'),
'    l_request := json_object_t();',
unistr('    l_request.put(''model'', C_MODEL); /* \4F7F\7528\3059\308B\30E2\30C7\30EB\306FGemma 3 */'),
'    l_request.put(''messages'', l_messages);',
'    -- l_request.put(''max_tokens'', p_max_tokens);',
'    /* call OpenAI chat completions api */',
'    l_request_clob := l_request.to_clob();',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_ENDPOINT',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'    );',
'    /* process response */',
'    if not apex_web_service.g_status_code between 200 and 300 then',
'        raise e_call_api_failed;',
'    end if;',
'    l_response_json := json_object_t(l_response);',
'    l_choices := l_response_json.get_array(''choices'');',
'    l_response_message := '''';',
'    for i in 1..l_choices.get_size()',
'    loop',
'        l_choice := treat(l_choices.get(i-1) as json_object_t);',
'        l_message := l_choice.get_object(''message'');',
'        l_response_message := l_response_message || l_message.get_clob(''content'');',
'    end loop;',
'    :P2_RESPONSE := l_response_message;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(15668354761380074)
,p_internal_uid=>15671230812380079
);
wwv_flow_imp.component_end;
end;
/
