prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>102
,p_default_id_offset=>15868166035179723
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'RoboBrain2.0 Simple Inference'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#app#MIN#.js'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.point {',
'    position: absolute;',
'    width: 10px;',
'    height: 10px;',
'    background-color: red;',
'    border-radius: 50%;',
'    border: 2px solid white;',
'    box-shadow: 0 0 5px rgba(0,0,0,0.5);',
'    transform: translate(-50%, -50%);',
'    cursor: pointer;',
'}',
'',
'.bounding-box {',
'    border-color: #0F0;',
'    position: absolute;',
'    box-sizing: border-box;',
'    border-width: 2px;',
'    border-style: solid;',
'}',
'',
'.line-div {',
'    position: absolute;',
'    background-color: #ff0000;',
'    height: 3px;',
'    transform-origin: left center;',
'    z-index: 10;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45769713862871791)
,p_plug_name=>'Left Region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45769792816871792)
,p_plug_name=>'Right Region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47166363236266846)
,p_plug_name=>'RoboBrain2.0 Simple Inference'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45770032026871795)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(45769792816871792)
,p_button_name=>'SET_IMAGE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Set Image'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45770232266871797)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(45769792816871792)
,p_button_name=>'ASK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Ask'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45770832726871803)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(45769792816871792)
,p_button_name=>'RENDER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Render'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45769576010871790)
,p_name=>'P1_IMAGE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(45769713862871791)
,p_prompt=>'Image'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_css_classes=>'w100p'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#:margin-top-none:margin-left-none'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'SQL',
  'sql_statement', 'select blob001 from apex_collections where collection_name = ''IMAGE'' and n001 = 1;')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45769958511871794)
,p_name=>'P1_IMAGE_FILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(45769792816871792)
,p_prompt=>'Image File'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_cropping', 'N',
  'allow_multiple_files', 'N',
  'display_as', 'INLINE',
  'purge_files_at', 'REQUEST',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45770198591871796)
,p_name=>'P1_PROMPT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(45769792816871792)
,p_prompt=>'Prompt'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45770331551871798)
,p_name=>'P1_RESPONSE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(45769792816871792)
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>10
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45771216641871806)
,p_name=>'P1_TASK'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(45769792816871792)
,p_item_default=>'general'
,p_prompt=>'Task'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:general;general,pointing;pointing,affordance;affordance,trajectory;trajectory,grounding;grounding'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '5',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45771675067871811)
,p_name=>'P1_ENABLE_THINKING'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(45769792816871792)
,p_item_default=>'N'
,p_prompt=>'Enable Thinking'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45771307373871807)
,p_name=>'onClick RENDER'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(45770832726871803)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45771355494871808)
,p_event_id=>wwv_flow_imp.id(45771307373871807)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \5FDC\7B54\306EJSON\304B\3089answer\5C5E\6027\3068\3057\3066\8FD4\3055\308C\3066\3044\308B\5EA7\6A19\3092\53D6\308A\51FA\3059\3002'),
' */',
'const response = JSON.parse(apex.item("P1_RESPONSE").getValue());',
'let positions = response.answer;',
'if (! positions ) {',
'    console.log(''No position found.'');',
'    return;',
'};',
'apex.debug.info(positions);',
'',
'/*',
unistr(' * \753B\50CF\304C\8868\793A\3055\308C\3066\3044\308BIMG\8981\7D20\3092\53D6\308A\51FA\3059\3002'),
' */',
'const img = document.getElementById("P1_IMAGE");',
'',
'/*',
unistr(' * \9078\629E\3055\308C\3066\3044\308B\30BF\30B9\30AF\3092\53D6\308A\51FA\3059\3002'),
' */',
'const task = apex.item("P1_TASK").getValue();',
'',
'render(positions, img, task);'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45770433660871799)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Image'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_blob blob;',
'    l_mime_type varchar2(4000);',
'begin',
'    select blob_content, mime_type into l_blob, l_mime_type',
'    from apex_application_temp_files where name = :P1_IMAGE_FILE;',
'    /*',
unistr('     * \30A2\30C3\30D7\30ED\30FC\30C9\3057\305F\30A4\30E1\30FC\30B8\306F\3064\306D\306BN001=1\3067\53D6\5F97\3067\304D\308B\3002'),
unistr('     * \3053\308C\304C\30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0P1_IMAGE\306E\30BD\30FC\30B9\3068\306A\308B\3002'),
'     */',
'    apex_collection.create_or_truncate_collection(''IMAGE'');',
'    apex_collection.add_member(',
'        p_collection_name => ''IMAGE''',
'        ,p_n001    => 1',
'        ,p_c001    => l_mime_type',
'        ,p_blob001 => l_blob',
'    );',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(45770032026871795)
,p_internal_uid=>14060414320917519
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45772092937871815)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ask_FastAPI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    /* Local LM Studio */',
'    C_ENDPOINT constant varchar2(4000) := ''http://host.containers.internal:8000/inference'';',
'    /*',
unistr('     * /inference\306F\4EE5\4E0B\306E\30EA\30AF\30A8\30B9\30C8\3092\53D7\3051\4ED8\3051\308B\3002'),
'     {',
'        "text": "What is shown in this image?",',
'        "image": image_base64,',
'        "task": "general",',
'        "plot": False,',
'        "enable_thinking": True,',
'        "do_sample": True,',
'        "temperature": 0.7',
'    }',
'     */',
unistr('    /* \9001\4FE1\3059\308B\30E1\30C3\30BB\30FC\30B8 */'),
'    l_request       json_object_t;',
'    l_request_clob clob;',
'    l_mime_type apex_application_temp_files.mime_type%type;',
'    l_blob_content apex_application_temp_files.blob_content%type;',
'    l_text     clob;',
'    l_image    clob;',
unistr('    /* \53D7\4FE1\3059\308B\30E1\30C3\30BB\30FC\30B8 */'),
'    l_response clob;',
'    l_response_json json_object_t;',
'    e_call_api_failed exception;',
'    l_choices json_array_t;',
'    l_choice  json_object_t;',
'    l_response_message clob;',
'begin',
unistr('    /* \5199\771F\306E\53D6\308A\51FA\3057 */'),
'    select blob001, c001 into l_blob_content, l_mime_type',
'    from apex_collections where collection_name = ''IMAGE'' and n001 = 1;',
unistr('    /* \30EA\30AF\30A8\30B9\30C8\306E\6E96\5099 */'),
'    l_request := json_object_t();',
'    l_text := :P1_PROMPT;',
'    l_image := ''data:'' || l_mime_type || '';base64,'' ',
'        || apex_web_service.blob2clobbase64(l_blob_content, ''N'', ''N'');',
'    l_request.put(''text'', l_text);',
'    l_request.put(''image'', l_image);',
'    l_request.put(''task'', :P1_TASK);',
'    l_request.put(''plot'', false);',
'    l_request.put(''enable_thinking'', (:P1_ENABLE_THINKING = ''Y''));',
'    l_request.put(''do_sample'', true);',
'    l_request.put(''temperature'', 0.7);',
'    l_request_clob := l_request.to_clob();',
'    /*',
unistr('     * FastAPI\30B5\30FC\30D0\30FC\306E\547C\3073\51FA\3057\3002 '),
'     */',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => C_ENDPOINT',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'    );',
'    /* process response */',
'    if not apex_web_service.g_status_code between 200 and 300 then',
'        raise e_call_api_failed;',
'    end if;',
'    :P1_RESPONSE := l_response;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(45770232266871797)
,p_internal_uid=>14062073597917535
);
wwv_flow_imp.component_end;
end;
/
