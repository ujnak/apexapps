prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>239
,p_default_id_offset=>57595908960029697
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30BF\30A4\30E0\30E9\30A4\30F3')
,p_alias=>'HOME'
,p_step_title=>unistr('APEX\30BD\30FC\30B7\30E3\30EB\30E1\30C7\30A3\30A2')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add([',
'{',
'    name: "like",',
'    action: (event, element, args) => {',
'        apex.items.P1_ACTION_ID.value = args.id;',
'        apex.event.trigger(document, ''action-like'');',
'    }',
'},',
'{',
'    name: "delete",',
'    action: (event, element, args) => {',
'        apex.items.P1_ACTION_ID.value = args.id;',
'        apex.event.trigger(document, ''action-delete'');',
'    }',
'},',
'{',
'    name: "open-map",',
'    action: () => {',
'        apex.event.trigger(document, ''action-open-map'');',
'    }',
'}',
']);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.user-has-liked {',
'color: red;',
'}',
'',
'@media (max-width: 640px) {',
'    .new-post-button {',
'        position: fixed;',
'        bottom: 24px;',
'        right: 24px;',
'        z-index: 1000;',
'    }',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_overwrite_navigation_list=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230810012318'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48787160300185768024)
,p_plug_name=>unistr('\6295\7A3F')
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size600x400:js-headingLevel-1'
,p_plug_template=>wwv_flow_imp.id(49245779805557794844)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'TABLE'
,p_query_table=>'SM_POSTS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49255179522394934099)
,p_plug_name=>unistr('\30BF\30A4\30E0\30E9\30A4\30F3')
,p_region_name=>'timeline'
,p_region_css_classes=>'t-Chat'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49245744545977794825)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    p.id,',
'    p.post_owner AS user_name,',
'    p.post_comment AS comment_text,',
'    p.photo,',
'    p.photo_mimetype,',
'    p.photo_lastupd,',
'    apex_util.get_since(p.post_date) post_date,',
'    (',
'        select count(*) from SM_REACTIONS smr ',
'        where smr.post_id=p.id',
'    ) as REACTIONS,',
'    (',
'        select ''user-has-liked'' from SM_REACTIONS smr ',
'        where smr.post_id=p.id and smr.reaction_owner=:APP_USER',
'    ) USER_REACTION_CSS',
'from SM_POSTS p ',
'order by p.post_date desc',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(49255179676743934100)
,p_region_id=>wwv_flow_imp.id(49255179522394934099)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'USER_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'POST_DATE'
,p_body_adv_formatting=>false
,p_body_column_name=>'COMMENT_TEXT'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'USER_NAME'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_media_source_type=>'BLOB'
,p_media_blob_column_name=>'PHOTO'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_css_classes=>'selectDisable'
,p_media_description=>'&COMMENT_TEXT.'
,p_pk1_column_name=>'ID'
,p_mime_type_column_name=>'PHOTO_MIMETYPE'
,p_last_updated_column_name=>'PHOTO_LASTUPD'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(49255179722568934101)
,p_card_id=>wwv_flow_imp.id(49255179676743934100)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'&REACTIONS.'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$like?id=&ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-heart &USER_REACTION_CSS.'
,p_action_css_classes=>'js-heart-button'
,p_is_hot=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(49255179846825934102)
,p_card_id=>wwv_flow_imp.id(49255179676743934100)
,p_action_type=>'BUTTON'
,p_position=>'SECONDARY'
,p_display_sequence=>20
,p_label=>unistr('\524A\9664')
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$delete?id=&ID.'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-trash-o'
,p_is_hot=>false
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':USER_NAME=:APP_USER'
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49255180717107934111)
,p_plug_name=>unistr('\6295\7A3F\3068\3044\3044\306D\306E\5730\70B9')
,p_region_name=>'map'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49245779805557794844)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct lat, lon, user_name, apex_util.get_since(cdate) as since from',
'(',
'   select lat, lon, post_owner as user_name, post_date as cdate from SM_POSTS',
'   union',
'   select lat, lon, reaction_owner as user_name, reaction_date as cdate from SM_REACTIONS',
')',
''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(49255180835780934112)
,p_region_id=>wwv_flow_imp.id(49255180717107934111)
,p_height=>300
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'MOUSEWHEEL_ZOOM:RECTANGLE_ZOOM:SCALE_BAR:INFINITE_MAP'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(49255180977087934113)
,p_map_region_id=>wwv_flow_imp.id(49255180835780934112)
,p_name=>unistr('\5730\70B9')
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LON'
,p_latitude_column=>'LAT'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>true
,p_tooltip_html_expr=>'&USER_NAME. @ &SINCE.'
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48787161922894768041)
,p_button_sequence=>10
,p_button_name=>'ADD_POST'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(49245877493524794890)
,p_button_image_alt=>unistr('\6295\7A3F\3057\307E\3059')
,p_button_position=>'AFTER_LOGO'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'new-post-button'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48787162294561768044)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_button_name=>'SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(49245877322900794890)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\6295\7A3F')
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'post-button'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787160420886768026)
,p_name=>'P1_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787160572526768027)
,p_name=>'P1_POST_COMMENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_prompt=>unistr('\30B3\30E1\30F3\30C8')
,p_source=>'POST_COMMENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(49245874828696794888)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787160615964768028)
,p_name=>'P1_PHOTO'
,p_source_data_type=>'BLOB'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_prompt=>unistr('\5199\771F')
,p_source=>'PHOTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'capture="environment"'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(49245874510319794888)
,p_item_css_classes=>'file-upload'
,p_item_icon_css_classes=>'fa-camera-retro'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_02=>'PHOTO_MIMETYPE'
,p_attribute_03=>'PHOTO_FILENAME'
,p_attribute_04=>'PHOTO_CHARSET'
,p_attribute_05=>'PHOTO_LASTUPD'
,p_attribute_06=>'N'
,p_attribute_11=>'image/*'
,p_attribute_12=>'DROPZONE_BLOCK'
,p_attribute_13=>unistr('\6295\7A3F\3059\308B\5199\771F\3092\9078\3076')
,p_attribute_15=>'10000'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787160801393768029)
,p_name=>'P1_PHOTO_FILENAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_prompt=>'Photo Filename'
,p_source=>'PHOTO_FILENAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>512
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(49245874828696794888)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(49244900053223794804)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787160828055768030)
,p_name=>'P1_PHOTO_MIMETYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_prompt=>'Photo Mimetype'
,p_source=>'PHOTO_MIMETYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>512
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(49245874828696794888)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(49244900053223794804)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787160956613768031)
,p_name=>'P1_PHOTO_CHARSET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_prompt=>'Photo Charset'
,p_source=>'PHOTO_CHARSET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>512
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(49245874828696794888)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(49244900053223794804)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787161013951768032)
,p_name=>'P1_PHOTO_LASTUPD'
,p_source_data_type=>'DATE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_prompt=>'Photo Lastupd'
,p_source=>'PHOTO_LASTUPD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(49245874828696794888)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(49244900053223794804)
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787161184448768033)
,p_name=>'P1_LAT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_source=>'LAT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787161214627768034)
,p_name=>'P1_LON'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_source=>'LON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787161402879768035)
,p_name=>'P1_POST_OWNER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_source=>'POST_OWNER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787161446253768036)
,p_name=>'P1_POST_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_source=>'POST_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787161526054768037)
,p_name=>'P1_CREATED'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_prompt=>'Created'
,p_source=>'CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(49245874828696794888)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(49244900053223794804)
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787161681990768038)
,p_name=>'P1_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_prompt=>'Created By'
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(49245874828696794888)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(49244900053223794804)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787161800955768039)
,p_name=>'P1_UPDATED'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_prompt=>'Updated'
,p_source=>'UPDATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(49245874828696794888)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(49244900053223794804)
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48787161854295768040)
,p_name=>'P1_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_item_source_plug_id=>wwv_flow_imp.id(48787160300185768024)
,p_prompt=>'Updated By'
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(49245874828696794888)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(49244900053223794804)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49255179956232934103)
,p_name=>'P1_ACTION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(49255179522394934099)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48787162099362768042)
,p_name=>unistr('\6295\7A3F\3057\307E\3059\3092\30AF\30EA\30C3\30AF')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(48787161922894768041)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48787162115715768043)
,p_event_id=>wwv_flow_imp.id(48787162099362768042)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('\6295\7A3F\30C0\30A4\30A2\30ED\30B0\3092\958B\304F')
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(48787160300185768024)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48787162404988768045)
,p_name=>unistr('\6295\7A3F\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(48787162294561768044)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.items.P1_PHOTO.value.length > 0 || apex.items.P1_POST_COMMENT.value.length > 0',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48787162483818768046)
,p_event_id=>wwv_flow_imp.id(48787162404988768045)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('\6295\7A3F\306E\4FDD\5B58')
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SAVE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(49255180086358934104)
,p_name=>'action-like'
,p_event_sequence=>30
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'action-like'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49255180122995934105)
,p_event_id=>wwv_flow_imp.id(49255180086358934104)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('\3044\3044\306D - UI\306E\66F4\65B0(\4EF6\6570 + \30CF\30FC\30C8\306E\8272)')
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const button = document.querySelector(''[data-id="'' + apex.items.P1_ACTION_ID.value +''"] .js-heart-button''); // get the card',
'const label  = button.querySelector(".a-CardView-buttonLabel"); // get the likes count section',
'const icon   = button.querySelector(".a-CardView-buttonIcon");  // gets the element if its liked already',
'let likeCount = label.textContent;',
'if (icon.classList.contains("user-has-liked")) {',
'    // user has liked this already, and they are unliking it now -- decrement',
'    label.textContent = --likeCount;',
'} else {',
'    // user is liking the post -- increment',
'    label.textContent = ++likeCount;',
'}',
'icon.classList.toggle("user-has-liked"); // either add this class or remove it'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49255180295596934106)
,p_event_id=>wwv_flow_imp.id(49255180086358934104)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>unistr('\3044\3044\306D - DB\306E\51E6\7406')
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    -- try to store this posts'' reaction from this user',
'    insert into SM_REACTIONS (post_id, reaction, reaction_owner, reaction_date, lat, lon)',
'        values (:P1_ACTION_ID, ''LIKED'', :APP_USER, sysdate, :P1_LAT, :P1_LON);',
'    exception when dup_val_on_index then',
'        -- remove it as it already existed',
'        delete from SM_REACTIONS where',
'            post_id=:P1_ACTION_ID and reaction_owner=:APP_USER;',
'end;',
''))
,p_attribute_02=>'P1_ACTION_ID,P1_LAT,P1_LON'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49255181699189934120)
,p_event_id=>wwv_flow_imp.id(49255180086358934104)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>unistr('\30D7\30C3\30B7\30E5\901A\77E5\306E\9001\4FE1')
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_count number;',
'    l_push_to sm_posts.post_owner%type;',
'    l_title varchar2(80);',
'begin',
'    select count(*) into l_count from sm_reactions',
'    where post_id=:P1_ACTION_ID and reaction_owner=:APP_USER;',
'    if l_count = 0 then',
unistr('        -- \3044\3044\306D\306E\89E3\9664\306A\306E\3067\901A\77E5\3057\306A\3044\3002'),
'        return;',
'    end if;',
'    select post_owner into l_push_to from sm_posts',
'    where id = :P1_ACTION_ID;',
unistr('    l_title := :APP_USER || ''\3055\3093\304C\3044\3044\306D\3057\307E\3057\305F\3002'';'),
'    apex_pwa.send_push_notification(',
'        p_user_name => l_push_to',
'        ,p_title    => l_title',
unistr('        -- body, icon, target_url\306E\8A2D\5B9A\306F\7701\7565\3002'),
'    );',
'    -- apex_pwa.push_queue;',
'end;'))
,p_attribute_02=>'P1_ACTION_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(49255180341617934107)
,p_name=>'action-delete'
,p_event_sequence=>40
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'action-delete'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49255180453589934108)
,p_event_id=>wwv_flow_imp.id(49255180341617934107)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('\524A\9664 - \78BA\8A8D\30C0\30A4\30A2\30ED\30B0')
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\6295\7A3F\3092\524A\9664\3057\3088\3046\3068\3057\3066\3044\307E\3059\3002\672C\5F53\306B\524A\9664\3057\307E\3059\304B\FF1F')
,p_attribute_02=>unistr('\78BA\8A8D')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49255180543443934109)
,p_event_id=>wwv_flow_imp.id(49255180341617934107)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>unistr('\524A\9664 - DB\306E\51E6\7406')
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'delete from SM_POSTS where id=:P1_ACTION_ID and post_owner=:APP_USER;'
,p_attribute_02=>'P1_ACTION_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49255180674201934110)
,p_event_id=>wwv_flow_imp.id(49255180341617934107)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>unistr('\524A\9664 - \30AB\30FC\30C9\306E\524A\9664')
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.querySelector(''[data-id="'' + apex.items.P1_ACTION_ID.value + ''"]'').remove();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(49255181032516934114)
,p_name=>'action-open-map'
,p_event_sequence=>50
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'action-open-map'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49255181173483934115)
,p_event_id=>wwv_flow_imp.id(49255181032516934114)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('\5730\56F3\3092\958B\304F')
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(49255180717107934111)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49255181260398934116)
,p_event_id=>wwv_flow_imp.id(49255181032516934114)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(49255180717107934111)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(49255181349128934117)
,p_name=>unistr('\73FE\5728\4F4D\7F6E\306E\53D6\5F97')
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49255181455121934118)
,p_event_id=>wwv_flow_imp.id(49255181349128934117)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_GET_CURRENT_POSITION'
,p_attribute_01=>'lat_long'
,p_attribute_03=>'P1_LAT'
,p_attribute_04=>'P1_LON'
,p_attribute_06=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49255179446281934098)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\6295\7A3F\8005\3068\6295\7A3F\65E5\306E\8A2D\5B9A')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P1_POST_OWNER := :APP_USER;',
':P1_POST_DATE := sysdate;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(48787162294561768044)
,p_internal_uid=>49197583537321904401
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(48787162527022768047)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(48787160300185768024)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\6295\7A3F\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(48787162294561768044)
,p_process_success_message=>unistr('\6295\7A3F\3057\307E\3057\305F\FF01')
,p_internal_uid=>48729566618062738350
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(48787160379007768025)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(48787160300185768024)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0\30BF\30A4\30E0\30E9\30A4\30F3')
,p_internal_uid=>48729564470047738328
);
wwv_flow_imp.component_end;
end;
/
