prompt --application/shared_components/navigation/lists/ユーザー設定
begin
--   Manifest
--     LIST: ユーザー設定
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>239
,p_default_id_offset=>57595908960029697
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(49606489297146852127)
,p_name=>unistr('\30E6\30FC\30B6\30FC\8A2D\5B9A')
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(49606485672552852121)
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(49606489617597852127)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('\30D7\30C3\30B7\30E5\901A\77E5')
,p_list_item_link_target=>'f?p=&APP_ID.:20010:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-bell-o'
,p_list_text_01=>unistr('\3053\306E\30C7\30D0\30A4\30B9\3067\30D7\30C3\30B7\30E5\901A\77E5\3092\53D7\4FE1\3059\308B\304B\3069\3046\304B\3092\69CB\6210\3057\307E\3059\3002')
,p_list_text_02=>'<span class="a-pwaPush--state"></span>'
,p_required_patch=>wwv_flow_imp.id(49606485331066852121)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
