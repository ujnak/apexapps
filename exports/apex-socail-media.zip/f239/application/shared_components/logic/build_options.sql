prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 239
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>239
,p_default_id_offset=>57595908960029697
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(49244900053223794804)
,p_build_option_name=>unistr('\30B3\30E1\30F3\30C8\30FB\30A2\30A6\30C8')
,p_build_option_status=>'EXCLUDE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(49606485331066852121)
,p_build_option_name=>unistr('\6A5F\80FD: \30D7\30C3\30B7\30E5\901A\77E5')
,p_build_option_status=>'INCLUDE'
,p_feature_identifier=>'APPLICATION_PUSH_NOTIFICATIONS'
,p_build_option_comment=>unistr('\30E6\30FC\30B6\30FC\304C\81EA\5206\306E\30C7\30D0\30A4\30B9\3067\30D7\30C3\30B7\30E5\901A\77E5\3092\30B5\30D6\30B9\30AF\30E9\30A4\30D6\3059\308B\3053\3068\3092\8A31\53EF\3057\307E\3059\3002')
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(49606485672552852121)
,p_build_option_name=>unistr('\6A5F\80FD: \30E6\30FC\30B6\30FC\8A2D\5B9A')
,p_build_option_status=>'INCLUDE'
,p_feature_identifier=>'APPLICATION_USER_SETTINGS'
,p_build_option_comment=>unistr('\30E6\30FC\30B6\30FC\8A2D\5B9A\30DA\30FC\30B8\306F\3001\3059\3079\3066\306E\30E6\30FC\30B6\30FC\8A2D\5B9A\30DA\30FC\30B8\306B\30EA\30F3\30AF\3059\308B\30C9\30ED\30EF\30FC\3067\3059\3002')
);
wwv_flow_imp.component_end;
end;
/
