prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 239
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>239
,p_default_id_offset=>57595908960029697
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(49677065650181470671)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table sm_reactions;',
'drop table sm_posts;'))
);
wwv_flow_imp.component_end;
end;
/
