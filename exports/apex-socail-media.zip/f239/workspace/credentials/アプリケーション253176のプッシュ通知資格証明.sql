prompt --workspace/credentials/アプリケーション253176のプッシュ通知資格証明
begin
--   Manifest
--     CREDENTIAL: アプリケーション253176のプッシュ通知資格証明
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>239
,p_default_id_offset=>57595908960029697
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(49611719349714042921)
,p_name=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3253176\306E\30D7\30C3\30B7\30E5\901A\77E5\8CC7\683C\8A3C\660E')
,p_static_id=>'_253176_'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
