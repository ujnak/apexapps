prompt --application/shared_components/security/authentications/demo
begin
--   Manifest
--     AUTHENTICATION: demo
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>317
,p_default_id_offset=>35304664411889501
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(47266088467821118)
,p_name=>'demo'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'demo_authentication'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function demo_authentication (',
'    p_username in varchar2,',
'    p_password in varchar2 )',
'    return boolean',
'is',
'begin',
'    if upper(p_username) in (',
'        ''STEVE'',''JANE'',''JAY'',''SUSIE'',''RALMUELL''',
'    ) then',
'        return true;',
'    end if;',
'    return false;',
'end;'))
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
