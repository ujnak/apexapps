prompt --application/shared_components/workflow/task_definitions/employee_badge_access
begin
--   Manifest
--     TASK_DEF: Employee Badge Access
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>317
,p_default_id_offset=>35304664411889501
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(45908895666862684)
,p_name=>'Employee Badge Access'
,p_static_id=>'EMPLOYEE_BADGE_ACCESS'
,p_subject=>'Approve Badge access for &EMPNO. - &ENAME.'
,p_task_type=>'APPROVAL'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,2:P2_TASK_ID:&TASK_ID.'
,p_actions_table_name=>'EMP_STATS'
,p_actions_pk_column_name=>'EMPNO'
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(45964546786887158)
,p_task_def_id=>wwv_flow_imp.id(45908895666862684)
,p_label=>'Joining Date'
,p_static_id=>'JOINING_DATE'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(45964865919887159)
,p_task_def_id=>wwv_flow_imp.id(45908895666862684)
,p_label=>'Mgr Name'
,p_static_id=>'MGR_NAME'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(45965454168891885)
,p_task_def_id=>wwv_flow_imp.id(45908895666862684)
,p_name=>'On Badge Access Completed'
,p_execution_sequence=>10
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'eba_demo_wf_parallel_pkg.complete_badge_access(',
'    p_task_pk => :APEX$TASK_PK',
'    ,p_task_outcome => :APEX$TASK_OUTCOME',
');'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(45964123953887140)
,p_task_def_id=>wwv_flow_imp.id(45908895666862684)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'RALMUELL'
);
wwv_flow_imp.component_end;
end;
/
