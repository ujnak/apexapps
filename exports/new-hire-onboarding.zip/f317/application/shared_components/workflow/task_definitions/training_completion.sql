prompt --application/shared_components/workflow/task_definitions/training_completion
begin
--   Manifest
--     TASK_DEF: Training Completion
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>317
,p_default_id_offset=>35304664411889501
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(46022111889180428)
,p_name=>'Training Completion'
,p_static_id=>'TRAINING_COMPLETION'
,p_subject=>'Complete Training Form'
,p_task_type=>'ACTION'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP,8:P8_TASK_ID:&TASK_ID.'
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(46076880112205261)
,p_task_def_id=>wwv_flow_imp.id(46022111889180428)
,p_label=>'Employee Name'
,p_static_id=>'ENAME'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(46076635046205230)
,p_task_def_id=>wwv_flow_imp.id(46022111889180428)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'&ENAME.'
);
wwv_flow_imp.component_end;
end;
/
