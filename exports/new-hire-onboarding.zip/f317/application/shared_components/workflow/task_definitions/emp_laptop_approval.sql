prompt --application/shared_components/workflow/task_definitions/emp_laptop_approval
begin
--   Manifest
--     TASK_DEF: Emp Laptop Approval
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>317
,p_default_id_offset=>35304664411889501
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(45966243556077874)
,p_name=>'Emp Laptop Approval'
,p_static_id=>'EMP_LAPTOP_APPROVAL'
,p_subject=>'Laptop Request for &ENAME.'
,p_task_type=>'APPROVAL'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:P3_TASK_ID:&TASK_ID.'
,p_actions_table_name=>'EMP_STATS'
,p_actions_pk_column_name=>'EMPNO'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(46021332969094950)
,p_task_def_id=>wwv_flow_imp.id(45966243556077874)
,p_name=>'On Laptop Access Completed'
,p_execution_sequence=>10
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'eba_demo_wf_parallel_pkg.complete_laptop_access(',
'    p_task_pk => :APEX$TASK_PK',
'    ,p_task_outcome => :APEX$TASK_OUTCOME',
');'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(46020904902082820)
,p_task_def_id=>wwv_flow_imp.id(45966243556077874)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'JANE'
);
wwv_flow_imp.component_end;
end;
/
