prompt --application/shared_components/plugins/process_type/onboarding_tasks
begin
--   Manifest
--     PLUGIN: ONBOARDING_TASKS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>317
,p_default_id_offset=>35304664411889501
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(46569112472864724)
,p_plugin_type=>'PROCESS TYPE'
,p_name=>'ONBOARDING_TASKS'
,p_display_name=>'Onboarding Tasks'
,p_supported_component_types=>'APEX_APPL_WORKFLOW_ACTIVITIES'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('PROCESS TYPE','ONBOARDING_TASKS'),'')
,p_default_escape_mode=>'HTML'
,p_api_version=>2
,p_execution_function=>'#OWNER#.eba_demo_wf_parallel_pkg.create_tasks'
,p_migration_function=>'#OWNER#.eba_demo_wf_parallel_pkg.complete_tasks'
,p_standard_attributes=>'WAIT_FOR_COMPLETION'
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(46570050128871846)
,p_plugin_id=>wwv_flow_imp.id(46569112472864724)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'REQUESTOR'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(46570306368875129)
,p_plugin_id=>wwv_flow_imp.id(46569112472864724)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_prompt=>'EMPNO'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>true
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(46570607671876704)
,p_plugin_id=>wwv_flow_imp.id(46569112472864724)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_prompt=>'DATE OF JOINING'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(46570879898878851)
,p_plugin_id=>wwv_flow_imp.id(46569112472864724)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_prompt=>'MANAGER NAME'
,p_attribute_type=>'PAGE ITEM'
,p_is_required=>false
,p_is_translatable=>false
);
wwv_flow_imp.component_end;
end;
/
