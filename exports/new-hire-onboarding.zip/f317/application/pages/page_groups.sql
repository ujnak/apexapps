prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 317
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>317
,p_default_id_offset=>35304664411889501
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(45898813150531997)
,p_group_name=>unistr('\7BA1\7406')
);
wwv_flow_imp.component_end;
end;
/
