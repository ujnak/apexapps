prompt --workspace/remote_servers/remote_hr
begin
--   Manifest
--     REMOTE SERVER: Remote HR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>156
,p_default_id_offset=>47289542263813149
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(94560413658406493)
,p_name=>'Remote HR'
,p_static_id=>'Remote_HR'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('Remote_HR'),'https://bp9ncf74sqibu4p-apexdev.adb.us-ashburn-1.oraclecloudapps.com/ords/apexrest')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('Remote_HR'),'')
,p_server_type=>'REMOTE_SQL'
,p_ords_version=>'22.4.3.r0331239'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('Remote_HR'),'UTC')
,p_credential_id=>wwv_flow_imp.id(94559393886341539)
,p_remote_sql_database_type=>'ORACLE'
,p_remote_sql_database_info=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "database_product_name":"Oracle"',
'   ,"database_product_version":"Oracle Database 19c Enterprise Edition Release 19.0.0.0.0 - Production\nVersion 19.18.0.1.0"',
'   ,"database_major_version":19',
'   ,"database_minor_version":0',
'   ,"env":{',
'        "defaultTimeZone":"UTC"',
'       ,"ordsVersion":"22.4.3.r0331239"',
'    }',
'}',
''))
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('Remote_HR'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('Remote_HR'),'')
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
