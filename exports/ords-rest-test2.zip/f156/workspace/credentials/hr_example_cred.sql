prompt --workspace/credentials/hr_example_cred
begin
--   Manifest
--     CREDENTIAL: HR Example Cred
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>156
,p_default_id_offset=>47289542263813149
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(94298417389918726)
,p_name=>'HR Example Cred'
,p_static_id=>'HR_EXAMPLE_CRED'
,p_authentication_type=>'OAUTH2_CLIENT_CREDENTIALS'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
