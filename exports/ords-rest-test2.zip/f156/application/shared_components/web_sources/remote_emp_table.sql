prompt --application/shared_components/web_sources/remote_emp_table
begin
--   Manifest
--     WEB SOURCE: Remote EMP Table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>156
,p_default_id_offset=>47289542263813149
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(94544004591646771)
,p_name=>'Remote EMP Table'
,p_static_id=>'Remote_EMP_Table'
,p_web_source_type=>'NATIVE_ORDS'
,p_data_profile_id=>wwv_flow_imp.id(94541081686646760)
,p_remote_server_id=>wwv_flow_imp.id(94518217571073409)
,p_url_path_prefix=>'/hr/employees/'
,p_auth_remote_server_id=>wwv_flow_imp.id(94518340779073410)
,p_auth_url_path_prefix=>'/oauth/token'
,p_credential_id=>wwv_flow_imp.id(94298417389918726)
,p_attribute_01=>'N'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(94544232433646773)
,p_web_src_module_id=>wwv_flow_imp.id(94544004591646771)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
