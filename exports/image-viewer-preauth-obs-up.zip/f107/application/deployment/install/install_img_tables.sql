prompt --application/deployment/install/install_img_tables
begin
--   Manifest
--     INSTALL: INSTALL-img_tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>107
,p_default_id_offset=>17825761441004022
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(43080091469568236)
,p_install_id=>wwv_flow_imp.id(43079307950559227)
,p_name=>'img_tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- create tables',
'create table img_items (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint img_items_id_pk primary key,',
'    name                           varchar2(80 char) not null',
')',
';',
'',
'create table img_images (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint img_images_id_pk primary key,',
'    item_id                        number',
'                                   constraint img_images_item_id_fk',
'                                   references img_items on delete set null,',
'    location                       varchar2(400 char) not null,',
'    file_name                      varchar2(80 char),',
'    mime_type                      varchar2(200 char),',
'    last_updated                   date not null',
')',
';',
'',
'-- table index',
'create index img_images_i1 on img_images (item_id);',
'',
'-- load data',
''))
);
wwv_flow_imp.component_end;
end;
/
