prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>107
,p_default_id_offset=>17825761441004022
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Img Item'
,p_alias=>'IMG-ITEM'
,p_page_mode=>'MODAL'
,p_step_title=>'Img Item'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#preview {',
'    width: 100%;',
'}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221213082919'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43058261314330912)
,p_plug_name=>'Img Item'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(42886492300330793)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'IMG_ITEMS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17565811979940115)
,p_plug_name=>'Preview'
,p_parent_plug_id=>wwv_flow_imp.id(43058261314330912)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(42886492300330793)
,p_plug_display_sequence=>50
,p_plug_source=>'<img id="preview" src="&P2_URL."></img>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43059871783331032)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(42889343036330794)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43060318864331032)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(43059871783331032)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(43019761505330858)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43061681884331033)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(43059871783331032)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(43019761505330858)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P2_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43062155549331033)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(43059871783331032)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(43019761505330858)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_position=>'NEXT'
,p_button_condition=>'P2_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43062476675331033)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(43059871783331032)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(43019761505330858)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'NEXT'
,p_button_condition=>'P2_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17565713851940114)
,p_name=>'P2_URL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(43058261314330912)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17566604339940123)
,p_name=>'P2_CURRENT_LOCATION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(43058261314330912)
,p_item_source_plug_id=>wwv_flow_imp.id(43058261314330912)
,p_source=>'CURRENT_LOCATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30505865784600257)
,p_name=>'P2_IMAGE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(43058261314330912)
,p_prompt=>'Image'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'capture="environment" accept="image/*"'
,p_field_template=>wwv_flow_imp.id(43017328596330856)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43058562622330913)
,p_name=>'P2_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(43058261314330912)
,p_item_source_plug_id=>wwv_flow_imp.id(43058261314330912)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ID'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(43018582516330857)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43058908156331030)
,p_name=>'P2_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(43058261314330912)
,p_item_source_plug_id=>wwv_flow_imp.id(43058261314330912)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(43018582516330857)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43060390958331032)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(43060318864331032)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43061206542331032)
,p_event_id=>wwv_flow_imp.id(43060390958331032)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17565966855940116)
,p_name=>unistr('\753B\50CF\306E\9078\629E')
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_IMAGE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17566093302940117)
,p_event_id=>wwv_flow_imp.id(17565966855940116)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>unistr('\9078\629E\3057\305F\753B\50CF\306E\30D7\30EC\30D3\30E5\30FC')
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let fileReader = new FileReader();',
'fileReader.onload = (function() {',
'    document.getElementById("preview").src = fileReader.result;',
'});',
'fileReader.readAsDataURL(this.triggeringElement.files[0]);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17566726103940124)
,p_event_id=>wwv_flow_imp.id(17565966855940116)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_GET_CURRENT_POSITION'
,p_attribute_01=>'geojson'
,p_attribute_02=>'P2_CURRENT_LOCATION'
,p_attribute_06=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43063306038331034)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(43058261314330912)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0Img Item')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(30506046976600258)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\30AA\30D6\30B8\30A7\30AF\30C8\30FB\30B9\30C8\30EC\30FC\30B8\306B\4FDD\5B58')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_file_name img_images.file_name%type;',
'    l_location  img_images.location%type;',
'    l_mime_type img_images.mime_type%type;',
'    l_blob blob;',
'    l_put_response dbms_cloud_oci_obs_object_storage_put_object_response_t;',
'    l_image_id img_images.id%type;',
'    l_status_code integer;',
'    file_upload_error exception;',
'begin',
'    /*',
unistr('     * APEX\306E\6A5F\80FD\3067\30A2\30C3\30D7\30ED\30FC\30C9\3055\308C\305F\30D5\30A1\30A4\30EB\3092\53D6\5F97\3059\308B\3002'),
'     */',
'    select blob_content, filename, mime_type into l_blob, l_file_name, l_mime_type',
'    from apex_application_temp_files',
'    where name = :P2_IMAGE;',
'    /*',
unistr('     * \4EEE\306ELOCATION\3067\3001\8868IMG_IMAGES\306B\884C\3092\633F\5165\3057ID\3092\53D6\5F97\3059\308B\3002'),
unistr('     * \53D6\5F97\3057\305FID\3067\30AA\30D6\30B8\30A7\30AF\30C8\30FB\30B9\30C8\30EC\30FC\30B8\306E\30AA\30D6\30B8\30A7\30AF\30C8\540D\3092\6C7A\5B9A\3057\307E\3059\3002'),
'     */',
'    insert into img_images(item_id, file_name, mime_type, location, last_updated)',
'    values(:P2_ID, l_file_name, l_mime_type, ''temp'', sysdate)',
'    returning id into l_image_id;',
'    l_location := :P2_ID || ''/'' || l_image_id || ''/'' || l_file_name;',
'    /*',
unistr('     * \753B\50CF\3092\30AA\30D6\30B8\30A7\30AF\30C8\30FB\30B9\30C8\30EC\30FC\30B8\306B\30A2\30C3\30D7\30ED\30FC\30C9\3059\308B\3002'),
'     */',
'     l_put_response := dbms_cloud_oci_obs_object_storage.put_object',
'    (',
'	    namespace_name => :G_NAMESPACE',
'        , bucket_name => :G_BUCKET',
'        , object_name => l_location',
'        , content_type => l_mime_type',
'        , put_object_body => l_blob',
'	    , region => :G_REGION',
'	    , credential_name => :G_CREDENTIAL',
'    );',
'    l_status_code := l_put_response.status_code;',
'    if l_status_code != 200 then',
'        raise file_upload_error;',
'    end if;',
'    /*',
unistr('     * \30AA\30D6\30B8\30A7\30AF\30C8\540D\3068\66F4\65B0\65E5\3092\66F4\65B0\3059\308B\3002'),
'     */',
'    update img_images set location = l_location, last_updated = sysdate where id = l_image_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43063677030331034)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43062952346331033)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(43058261314330912)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0Img Item')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17566266855940119)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\753B\50CFURL\306E\53D6\5F97')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select :G_PREAUTH_URL || g.location into :P2_URL',
'from img_items i join ',
'(',
'    select id, item_id, location, file_name, mime_type from',
'        (',
'            select',
'                row_number() over (partition by item_id order by last_updated desc) rn,',
'                id, item_id, location, file_name, mime_type',
'            from img_images',
'        )',
'    where rn = 1',
') g on i.id = g.item_id',
'where i.id = :P2_ID;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P2_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp.component_end;
end;
/
