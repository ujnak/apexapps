prompt --application/shared_components/security/authentications/microsoft_entra_id
begin
--   Manifest
--     AUTHENTICATION: Microsoft Entra ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>6839750546516074
,p_default_application_id=>100
,p_default_id_offset=>6841123258695201
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(36182090432085908)
,p_name=>'Microsoft Entra ID'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(36181510204998626)
,p_attribute_02=>'OPENID_CONNECT'
,p_attribute_03=>'https://login.microsoftonline.com/[tenant_id]/v2.0/.well-known/openid-configuration'
,p_attribute_07=>'profile,email'
,p_attribute_09=>'#email# '
,p_attribute_11=>'N'
,p_attribute_13=>'Y'
,p_invalid_session_type=>'LOGIN'
,p_post_auth_process=>'post_auth'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>2292110
);
wwv_flow_imp.component_end;
end;
/
