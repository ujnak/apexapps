prompt --application/shared_components/logic/application_items/g_user_info
begin
--   Manifest
--     APPLICATION ITEM: G_USER_INFO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>6839750546516074
,p_default_application_id=>100
,p_default_id_offset=>7248850033305255
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(50553917667917264)
,p_name=>'G_USER_INFO'
,p_protection_level=>'I'
,p_version_scn=>40536979089201
);
wwv_flow_imp.component_end;
end;
/
