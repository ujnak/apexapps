prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>6839750546516074
,p_default_application_id=>100
,p_default_id_offset=>6841123258695201
,p_default_owner=>'WKSP_APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
