prompt --application/deployment/install/install_dump_signon_response_sql
begin
--   Manifest
--     INSTALL: INSTALL-dump_signon_response.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>6839750546516074
,p_default_application_id=>100
,p_default_id_offset=>7242787260119611
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14448490176861744)
,p_install_id=>wwv_flow_imp.id(14448083270852744)
,p_name=>'dump_signon_response.sql'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace function dump_signon_response',
'return clob',
'as',
'    k varchar2(32767);',
'    v apex_json.t_value;',
'    t apex_json.t_kind;',
'    res clob := '''';',
'begin',
'    k := apex_json.g_values.first;',
'    while k is not null loop',
'        v := apex_json.get_value(k);',
'        res := res || k || '' = '';',
'        /* decoce access_token and id_token */',
'        if k = ''access_token'' then',
'            res := res || parse_jwt( v.varchar2_value);',
'            res := res || apex_application.LF;',
'        elsif k = ''id_token'' then',
'            res := res || parse_jwt( v.varchar2_value);',
'            res := res || apex_application.LF;',
'        end if;',
'        /* end */',
'        case v.kind',
'        when apex_json.c_null then',
'            res := res || ''(NULL)'';',
'        when apex_json.c_true then',
'            res := res || ''(TRUE)'';',
'        when apex_json.c_false then',
'            res := res || ''(FALSE)'';',
'        when apex_json.c_number then',
'            res := res || to_char(v.number_value);',
'        when apex_json.c_varchar2 then',
'            res := res || v.varchar2_value;',
'        when apex_json.c_object then',
'            res := res || ''(OBJECT['' || apex_string.join(v.object_members, '':'') || ''])'';',
'        when apex_json.c_array then',
'            res := res || ''(ARRAY['' || to_number(v.number_value) || ''])'';',
'        when apex_json.c_clob then',
'            res := res || v.clob_value;',
'        else',
'            res := res || ''(OTHER)'';',
'        end case;',
'        res := res || apex_application.LF;',
'        k := apex_json.g_values.next(k);',
'    end loop;',
'    return res;',
'end dump_signon_response;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
