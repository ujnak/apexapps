prompt --application/shared_components/workflow/task_definitions/reimbursement_request
begin
--   Manifest
--     TASK_DEF: Reimbursement Request
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>320
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(53251067800924537)
,p_name=>'Reimbursement Request'
,p_static_id=>'REIMBURSEMENT_REQUEST'
,p_subject=>'Expense Approval of Amount &AMOUNT. for &EMP_NAME. - Level &LEVEL_NO.'
,p_task_type=>'APPROVAL'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP,2:P2_TASK_ID:&TASK_ID.'
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(53758101727412301)
,p_task_def_id=>wwv_flow_imp.id(53251067800924537)
,p_label=>'Amount'
,p_static_id=>'AMOUNT'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(53758553743412302)
,p_task_def_id=>wwv_flow_imp.id(53251067800924537)
,p_label=>'Emp Name'
,p_static_id=>'EMP_NAME'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(53758968967412302)
,p_task_def_id=>wwv_flow_imp.id(53251067800924537)
,p_label=>'Level No'
,p_static_id=>'LEVEL_NO'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(53757439346412297)
,p_task_def_id=>wwv_flow_imp.id(53251067800924537)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>'select mgr_name from approval_levels where level_code = :LEVEL_NO'
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(53757774243412300)
,p_task_def_id=>wwv_flow_imp.id(53251067800924537)
,p_participant_type=>'BUSINESS_ADMIN'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'PAT'
);
wwv_flow_imp.component_end;
end;
/
