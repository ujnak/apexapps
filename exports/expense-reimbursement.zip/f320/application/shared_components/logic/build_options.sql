prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 320
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>320
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(53453962818379895)
,p_build_option_name=>unistr('\30B3\30E1\30F3\30C8\30FB\30A2\30A6\30C8')
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>40541897244641
);
wwv_flow_imp.component_end;
end;
/
