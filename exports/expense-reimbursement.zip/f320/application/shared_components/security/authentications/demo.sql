prompt --application/shared_components/security/authentications/demo
begin
--   Manifest
--     AUTHENTICATION: Demo
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>320
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(53410838706798888)
,p_name=>'Demo'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'demo_authentication'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function demo_authentication (',
'    p_username in varchar2,',
'    p_password in varchar2 )',
'    return boolean',
'is',
'begin',
'    if upper(p_username) in (',
'        ''STEVE'',''JANE'',''BO'',''SUSIE'',''CLARA''',
'    ) then',
'        return true;',
'    end if;',
'    return false;',
'end;'))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
