prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Policy Violations'
,p_alias=>'HOME'
,p_step_title=>'CSP Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>\30C7\30FC\30BF\3092\898B\3064\3051\308B\306B\306F\3001\691C\7D22\30C0\30A4\30A2\30ED\30B0\306B\691C\7D22\6587\5B57\5217\3092\5165\529B\3059\308B\304B\3001\5217\30D8\30C3\30C0\30FC\3092\30AF\30EA\30C3\30AF\3057\3066\623B\3055\308C\308B\30EC\30B3\30FC\30C9\3092\5236\9650\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30A2\30AF\30B7\30E7\30F3\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\591A\304F\306E\6A5F\80FD\3092\5B9F\884C\3067\304D\307E\3059\3002\3053\308C\306B\306F\3001\8868\793A\5217\307E\305F\306F\975E\8868\793A\5217\306E\9078\629E\3068\305D\306E\8868\793A\9806\5E8F\306B\52A0\3048\3001\591A\304F\306E\30C7\30FC\30BF\304A\3088\3073\66F8\5F0F\8A2D\5B9A\6A5F\80FD\304C\542B\307E\308C\307E\3059\3002\30C1\30E3\30FC\30C8\3001\30B0\30EB\30FC\30D7\5316\304A\3088\3073\30D4\30DC\30C3\30C8\30FB\30AA\30D7\30B7\30E7\30F3\3092\4F7F\7528\3057\3066\3001\30C7\30FC\30BF\306E\8FFD\52A0\30D3\30E5\30FC\3092\5B9A\7FA9\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\72EC\81EA\306E\30AB\30B9\30BF\30DE\30A4\30BA\5185\5BB9\3092\4FDD\5B58\3059\308B\5834\5408\3001\30EC\30DD\30FC\30C8\3092\9078\629E\3059\308B\304B\3001\300C\30C0\30A6\30F3\30ED\30FC\30C9\300D\3092\30AF\30EA\30C3\30AF\3057\3066\30C7\30FC\30BF\3092\30A2\30F3\30ED\30FC\30C9\3057\307E\3059\3002\5B9A\671F\7684\306B\30C7\30FC\30BF\3092\9001\4FE1\3059\308B\30B5\30D6\30B9\30AF\30EA\30D7\30B7\30E7\30F3\3067\96FB\5B50\30E1\30FC\30EB\30FB\30A2\30C9\30EC\30B9\3068\6642\9593\67A0\3092\5165\529B\3057\307E\3059\3002<p>'),
'',
unistr('<p>\8FFD\52A0\60C5\5831\3092\5165\624B\3059\308B\306B\306F\3001\300C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\306E\4E00\756A\4E0B\306E\300C\30D8\30EB\30D7\300D\3092\30AF\30EA\30C3\30AF\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30EA\30BB\30C3\30C8\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\5BFE\8A71\30E2\30FC\30C9\30FB\30EC\30DD\30FC\30C8\3092\30C7\30D5\30A9\30EB\30C8\8A2D\5B9A\306B\623B\3059\3053\3068\304C\3067\304D\307E\3059\3002</p>')))
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14510340075099650)
,p_plug_name=>'Policy Violations'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'  jd.id,',
'  jt.document_uri,',
'  jt.referrer,',
'  jt.violated_directive,',
'  jt.effective_directive,',
'  jt.original_policy,',
'  jt.disposition,',
'  jt.blocked_uri,',
'  jt.line_number,',
'  jt.column_number,',
'  jt.source_file,',
'  jt.status_code,',
'  jt.script_sample,',
'  jd.created',
'FROM ebaj_csp_reports jd,',
'     JSON_TABLE(',
'       jd.report,',
'       ''$."csp-report"''',
'       COLUMNS (',
'         document_uri VARCHAR2(200) PATH ''$."document-uri"'',',
'         referrer VARCHAR2(200) PATH ''$."referrer"'',',
'         violated_directive VARCHAR2(200) PATH ''$."violated-directive"'',',
'         effective_directive VARCHAR2(200) PATH ''$."effective-directive"'',',
'         original_policy VARCHAR2(500) PATH ''$."original-policy"'',',
'         disposition VARCHAR2(50) PATH ''$."disposition"'',',
'         blocked_uri VARCHAR2(200) PATH ''$."blocked-uri"'',',
'         line_number NUMBER PATH ''$."line-number"'',',
'         column_number NUMBER PATH ''$."column-number"'',',
'         source_file VARCHAR2(200) PATH ''$."source-file"'',',
'         status_code NUMBER PATH ''$."status-code"'',',
'         script_sample VARCHAR2(500) PATH ''$."script-sample"''',
'       )',
'     ) jt;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Policy Violations'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(14510450929099650)
,p_name=>'Policy Violations'
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>14510450929099650
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14511178240099652)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14511535067099652)
,p_db_column_name=>'DOCUMENT_URI'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Document Uri'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14511900173099652)
,p_db_column_name=>'REFERRER'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Referrer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14512345004099652)
,p_db_column_name=>'VIOLATED_DIRECTIVE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Violated Directive'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14512783998099652)
,p_db_column_name=>'EFFECTIVE_DIRECTIVE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Effective Directive'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14513124952099653)
,p_db_column_name=>'ORIGINAL_POLICY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Original Policy'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14513504108099653)
,p_db_column_name=>'DISPOSITION'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Disposition'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14513919196099653)
,p_db_column_name=>'BLOCKED_URI'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Blocked Uri'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14514383132099653)
,p_db_column_name=>'LINE_NUMBER'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Line Number'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14514778829099653)
,p_db_column_name=>'COLUMN_NUMBER'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Column Number'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14515158767099653)
,p_db_column_name=>'SOURCE_FILE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Source File'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14515552694099653)
,p_db_column_name=>'STATUS_CODE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Status Code'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14515985792099653)
,p_db_column_name=>'SCRIPT_SAMPLE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Script Sample'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14516311632099653)
,p_db_column_name=>'CREATED'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(14520013073103986)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'145201'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:DOCUMENT_URI:REFERRER:VIOLATED_DIRECTIVE:EFFECTIVE_DIRECTIVE:ORIGINAL_POLICY:DISPOSITION:BLOCKED_URI:LINE_NUMBER:COLUMN_NUMBER:SOURCE_FILE:STATUS_CODE:SCRIPT_SAMPLE:CREATED'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14517681596099654)
,p_plug_name=>'CSP Report'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12287416910271215)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14517681596099654)
,p_button_name=>'RESET'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14516745481099653)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14510340075099650)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>unistr('\30EA\30BB\30C3\30C8')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12287539912271216)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RESET'
,p_process_sql_clob=>'delete from ebaj_csp_reports;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(12287416910271215)
,p_internal_uid=>12287539912271216
);
wwv_flow_imp.component_end;
end;
/
