prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 193
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>193
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(112218457922940633)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'24.1'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(111978131517935113)
,p_default_dialog_template=>wwv_flow_imp.id(111981595269935121)
,p_error_template=>wwv_flow_imp.id(111968140399935086)
,p_printer_friendly_template=>wwv_flow_imp.id(111978131517935113)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(111968140399935086)
,p_default_button_template=>wwv_flow_imp.id(112128426510935952)
,p_default_region_template=>wwv_flow_imp.id(112054893178935670)
,p_default_chart_template=>wwv_flow_imp.id(112054893178935670)
,p_default_form_template=>wwv_flow_imp.id(112054893178935670)
,p_default_reportr_template=>wwv_flow_imp.id(112054893178935670)
,p_default_tabform_template=>wwv_flow_imp.id(112054893178935670)
,p_default_wizard_template=>wwv_flow_imp.id(112054893178935670)
,p_default_menur_template=>wwv_flow_imp.id(112067247974935721)
,p_default_listr_template=>wwv_flow_imp.id(112054893178935670)
,p_default_irr_template=>wwv_flow_imp.id(112045048543935646)
,p_default_report_template=>wwv_flow_imp.id(112091055831935829)
,p_default_label_template=>wwv_flow_imp.id(112125988350935940)
,p_default_menu_template=>wwv_flow_imp.id(112130025344935957)
,p_default_calendar_template=>wwv_flow_imp.id(112130102394935960)
,p_default_list_template=>wwv_flow_imp.id(112115828141935907)
,p_default_nav_list_template=>wwv_flow_imp.id(112124687586935933)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(112124687586935933)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(112122881616935928)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(112011183039935545)
,p_default_dialogr_template=>wwv_flow_imp.id(111988217344935438)
,p_default_option_label=>wwv_flow_imp.id(112125988350935940)
,p_default_required_label=>wwv_flow_imp.id(112127255968935945)
,p_default_navbar_list_template=>wwv_flow_imp.id(112122454156935926)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/24.1/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
