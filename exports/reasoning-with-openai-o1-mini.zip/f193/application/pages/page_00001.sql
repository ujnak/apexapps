prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>193
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Reasoning with OpenAI o1'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(112252363047941498)
,p_plug_name=>'Reasoning with OpenAI o1'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(112031562931935613)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(111397278515930521)
,p_button_sequence=>30
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(112128426510935952)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111397170000930520)
,p_name=>'P1_QUESTION'
,p_item_sequence=>20
,p_prompt=>'Question'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(112125988350935940)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111397346245930522)
,p_name=>'P1_ANSWER'
,p_item_sequence=>40
,p_prompt=>'Answer'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>wwv_flow_imp.id(112125988350935940)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'MARKDOWN'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
,p_attribute_25=>'CKEDITOR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111397617985930525)
,p_name=>'P1_MODEL'
,p_item_sequence=>60
,p_prompt=>'Model'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(112125988350935940)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111397752006930526)
,p_name=>'P1_USAGE'
,p_item_sequence=>70
,p_prompt=>'Usage'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(112125988350935940)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111397866235930527)
,p_name=>'P1_FINISH_REASON'
,p_item_sequence=>50
,p_prompt=>'Finish Reason'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(112125988350935940)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(111397432867930523)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Call OpenAI API'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request clob;',
'    l_request_json json_object_t;',
'    l_messages json_array_t;',
'    l_message  json_object_t;',
'    l_response clob;',
'    l_response_json json_object_t;',
'    e_openai_api_failed exception;',
'    l_model_name varchar2(80);',
'    l_response_content clob;',
'    l_usage_json json_object_t;',
'    l_usage      clob;',
'    l_choices json_array_t;',
'    l_choice  json_object_t;',
'    l_finish_reason varchar2(80);',
'    l_count integer;',
'begin',
'    l_request_json := json_object_t();',
'    l_request_json.put(''model'',''o1-mini'');',
'    l_message := json_object_t(''{ "role": "user" }'');',
'    l_message.put(''content'', :P1_QUESTION);',
'    l_messages := json_array_t();',
'    l_messages.append(l_message);',
'    l_request_json.put(''messages'', l_messages);',
'    -- max_completion_tokens can be applied here.',
'    -- o1-preview: Up to 32,768 tokens, o1-mini: Up to 65,536 tokens',
'    -- l_request_json.put(''max_completion_tokens'', 65536);',
'    l_request := l_request_json.to_clob();',
'    /*',
'     * Call OpenAI o1-mini for reasonong.',
'     */',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'');',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => ''https://api.openai.com/v1/chat/completions''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''OPENAI_API_KEY''',
'        ,p_transfer_timeout => 360',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_openai_api_failed;',
'    end if;',
'    /*',
unistr('     * \30EC\30B9\30DD\30F3\30B9\306E\30D1\30FC\30B9'),
'     */',
'    l_response_json := json_object_t(l_response);',
unistr('    -- \5B9F\969B\306E\30E2\30C7\30EB\540D'),
'    :P1_MODEL := l_response_json.get_string(''model'');',
'    l_usage_json := l_response_json.get_object(''usage'');',
'    l_usage := l_usage_json.to_clob();',
unistr('    -- usage - JSON\305D\306E\307E\307E\3067\5370\5237\3059\308B\3002'),
'    select json_serialize(l_usage pretty) into :P1_USAGE from dual;',
unistr('    -- \30EC\30B9\30DD\30F3\30B9\30FB\30E1\30C3\30BB\30FC\30B8\306E\53D6\5F97'),
'    l_choices := l_response_json.get_array(''choices'');',
'    l_count   := l_choices.get_size();',
'    l_response_content := '''';',
'    l_finish_reason := '''';',
unistr('    -- choices\306B\542B\307E\308C\308B\30E1\30C3\30BB\30FC\30B8\306F\FF11\3064\3060\3051\3060\3068\601D\3046\304C\3001\5FF5\306E\70BA\914D\5217\3092\51E6\7406\3059\308B\3002'),
'    for i in 1 .. l_count',
'    loop',
'        l_choice := treat(l_choices.get(i-1) as json_object_t);',
'        l_message := l_choice.get_object(''message'');',
'        l_response_content := l_response_content || l_message.get_string(''content'') || apex_application.LF;',
'        l_finish_reason := l_finish_reason || l_choice.get_string(''finish_reason'') || '','';',
'    end loop;',
unistr('    -- \30DA\30FC\30B8\30FB\30A2\30A4\30C6\30E0\306B\51FA\529B\3059\308B\3002'),
'    :P1_ANSWER        := l_response_content;',
'    :P1_FINISH_REASON := l_finish_reason;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(111397278515930521)
,p_internal_uid=>111397432867930523
);
wwv_flow_imp.component_end;
end;
/
