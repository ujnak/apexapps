prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>103
,p_default_id_offset=>26567742131370767
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>unistr('\90E8\9580\9577')
,p_alias=>unistr('\90E8\9580\9577')
,p_step_title=>unistr('\90E8\9580\9577')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(52512561937546053)
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221221074058'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(52467926583050727)
,p_plug_name=>unistr('\90E8\9580\9577')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(52161550698222821)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    expe.expe_id',
'    ,expe.expe_justification',
'    ,expe.expe_amount',
'    ,expe.expe_status',
'    ,expe.expe_submitted_by',
'    ,expe.expe_submitted_on',
'    ,expe.expe_invoice_dd',
'    ,expe.expe_purpose',
'    ,tibx.link_text',
'    ,tibx.sbfl_prcs_id',
'    ,tibx.sbfl_step_key',
'from tuto_expenses expe ',
'    join flow_task_inbox_vw tibx on expe.expe_id = tibx.sbfl_business_ref',
'    join apex_appl_acl_user_roles aclr on tibx.sbfl_current_lane = aclr.role_static_id',
'where tibx.sbfl_dgrm_name = :APP_NAME',
unistr('    and expe.expe_status = ''approved_by_mgr'' -- \72B6\614B\306FF4A\3067\7BA1\7406\3057\3066\3044\308B\306E\3067\3001\5FC5\9808\3067\306F\306A\3044\3002'),
'    and tibx.sbfl_current = ''review_expense_vp''',
'    and aclr.application_id = :APP_ID',
'    and aclr.user_name = :APP_USER'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>unistr('\90E8\9580\9577')
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(52467988263050727)
,p_name=>unistr('\90E8\9580\9577')
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'#LINK_TEXT#'
,p_detail_link_text=>'<span aria-label="&#x7DE8;&#x96C6;"><span class="fa fa-edit" aria-hidden="true" title="&#x7DE8;&#x96C6;"></span></span>'
,p_owner=>'APEXDEV'
,p_internal_uid=>25900246131679960
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52468436086050727)
,p_db_column_name=>'EXPE_ID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'Expe Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52468812185050728)
,p_db_column_name=>'EXPE_JUSTIFICATION'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Expe Justification'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52469180205050728)
,p_db_column_name=>'EXPE_AMOUNT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Expe Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52469626372050729)
,p_db_column_name=>'EXPE_STATUS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Expe Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52469995584050729)
,p_db_column_name=>'EXPE_SUBMITTED_BY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Expe Submitted By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52470437824050730)
,p_db_column_name=>'EXPE_SUBMITTED_ON'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Expe Submitted On'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52470832283050730)
,p_db_column_name=>'EXPE_INVOICE_DD'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Expe Invoice Dd'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52471153085050731)
,p_db_column_name=>'EXPE_PURPOSE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Expe Purpose'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52471568736050731)
,p_db_column_name=>'LINK_TEXT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Link Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52472010753050732)
,p_db_column_name=>'SBFL_PRCS_ID'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Sbfl Prcs Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(52472393763050732)
,p_db_column_name=>'SBFL_STEP_KEY'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Sbfl Step Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(52483606964270491)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'259159'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EXPE_ID:EXPE_JUSTIFICATION:EXPE_AMOUNT:EXPE_STATUS:EXPE_SUBMITTED_BY:EXPE_SUBMITTED_ON:EXPE_INVOICE_DD:EXPE_PURPOSE:LINK_TEXT:SBFL_PRCS_ID:SBFL_STEP_KEY'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(52474625540050735)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(52183777597222832)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(52068668584222773)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(52245860390222865)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(52473192983050733)
,p_name=>unistr('\30EC\30DD\30FC\30C8\306E\7DE8\96C6 - \30C0\30A4\30A2\30ED\30B0\306E\30AF\30ED\30FC\30BA')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(52467926583050727)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52473660259050734)
,p_event_id=>wwv_flow_imp.id(52473192983050733)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(52467926583050727)
);
wwv_flow_imp.component_end;
end;
/
