prompt --application/shared_components/user_interface/lovs/unified_task_list_lov_initiated
begin
--   Manifest
--     UNIFIED_TASK_LIST.LOV.INITIATED
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>103
,p_default_id_offset=>26567742131370767
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(26629828052657919)
,p_lov_name=>'UNIFIED_TASK_LIST.LOV.INITIATED'
,p_lov_query=>'.'||wwv_flow_imp.id(26629828052657919)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26630113484657919)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('\904E\53BB1\6642\9593')
,p_lov_return_value=>'|1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26630507664657919)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('\904E\53BB24\6642\9593')
,p_lov_return_value=>'1|24'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26630966918657920)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('\904E\53BB7\65E5\9593')
,p_lov_return_value=>'24|168'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26631330061657920)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('\904E\53BB30\65E5\9593')
,p_lov_return_value=>'168|720'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(26631777869657920)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>unistr('30\65E5\3088\308A\53E4\3044')
,p_lov_return_value=>'720|'
);
wwv_flow_imp.component_end;
end;
/
