prompt --application/shared_components/logic/application_items/step_key
begin
--   Manifest
--     APPLICATION ITEM: STEP_KEY
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>103
,p_default_id_offset=>26567742131370767
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(52327881771229651)
,p_name=>'STEP_KEY'
,p_protection_level=>'N'
);
wwv_flow_imp.component_end;
end;
/
