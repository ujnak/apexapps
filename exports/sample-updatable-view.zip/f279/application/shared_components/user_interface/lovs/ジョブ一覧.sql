prompt --application/shared_components/user_interface/lovs/ジョブ一覧
begin
--   Manifest
--     ジョブ一覧
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>279
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(97325394771013651)
,p_lov_name=>unistr('\30B8\30E7\30D6\4E00\89A7')
,p_lov_query=>'.'||wwv_flow_imp.id(97325394771013651)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(97325657463013654)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('\793E\9577')
,p_lov_return_value=>'PRESIDENT'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(97326025229013654)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('\30DE\30CD\30FC\30B8\30E3\30FC')
,p_lov_return_value=>'MANAGER'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(97326478675013655)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('\30A2\30CA\30EA\30B9\30C8')
,p_lov_return_value=>'ANALYST'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(97326804258013655)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('\5E97\54E1')
,p_lov_return_value=>'CLERK'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(97327227591013655)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>unistr('\55B6\696D\54E1')
,p_lov_return_value=>'SALESMAN'
);
wwv_flow_imp.component_end;
end;
/
