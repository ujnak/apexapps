prompt --application/shared_components/user_interface/lovs/openai_functions_function_name
begin
--   Manifest
--     OPENAI_FUNCTIONS.FUNCTION_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>312
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(15744752141250134)
,p_lov_name=>'OPENAI_FUNCTIONS.FUNCTION_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'OPENAI_FUNCTIONS'
,p_return_column_name=>'ID'
,p_display_column_name=>'FUNCTION_NAME'
,p_default_sort_column_name=>'FUNCTION_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
