prompt --application/shared_components/web_sources/list_files
begin
--   Manifest
--     WEB SOURCE: List files
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>300
,p_default_id_offset=>15833696375620490
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(30853050263668153)
,p_name=>'List files'
,p_static_id=>'List_files'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(30850448575668150)
,p_remote_server_id=>wwv_flow_imp.id(128679627188677162)
,p_url_path_prefix=>'v1/files'
,p_credential_id=>wwv_flow_imp.id(59103911961121450)
,p_pass_ecid=>true
,p_catalog_internal_name=>'OPENAI_FILES_API'
,p_catalog_service_name=>'List files'
,p_catalog_service_version=>20231108
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(30853217210668153)
,p_web_src_module_id=>wwv_flow_imp.id(30853050263668153)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
