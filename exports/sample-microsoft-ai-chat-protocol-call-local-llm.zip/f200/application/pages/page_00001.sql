prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>200
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample MS AI Chat Protocol'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/@microsoft/ai-chat-protocol/dist/iife/index.min.js',
''))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('var client;      /* Microsoft AI Chat Protocol\306E\30AF\30E9\30A4\30A2\30F3\30C8 */'),
unistr('var messages;    /* \9001\4FE1\3059\308B\30E1\30C3\30BB\30FC\30B8\306E\914D\5217 */'),
unistr('const contentDiv = document.getElementById("content"); /* \30C1\30E3\30C3\30C8\5C65\6B74\3092\8868\793A\3059\308B\8981\7D20 */'),
'',
unistr('/* \8868\793A\3055\308C\305F\30C1\30E3\30C3\30C8\5C65\6B74\3092\521D\671F\5316 */'),
'function removeAllChildren(element) {',
'    while (element.firstChild) {',
'        element.removeChild(element.firstChild);',
'    }',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.bubble-left {',
unistr('  max-width: 70%;              /* \5439\304D\51FA\3057\306E\5E45 */'),
unistr('  padding: 10px 15px;          /* \5185\5074\306E\4F59\767D */'),
unistr('  margin: 10px 0;              /* \5439\304D\51FA\3057\306E\4E0A\4E0B\306E\9593\9694 */'),
unistr('  background-color: #e1f5fe; /* \5439\304D\51FA\3057\306E\80CC\666F\8272 */'),
unistr('  text-align: left;            /* \6587\5B57\3092\5DE6\5BC4\305B */'),
unistr('  position: relative;          /* \5439\304D\51FA\3057\306E\4F4D\7F6E\3092\76F8\5BFE\7684\306B */'),
unistr('  border-radius: 15px 15px 15px 15px; /* \89D2\3092\4E38\3081\308B */'),
'}',
'',
'.bubble-right {',
unistr('  max-width: 70%;               /* \5439\304D\51FA\3057\306E\5E45 */'),
unistr('  padding: 10px 15px;           /* \5185\5074\306E\4F59\767D */'),
unistr('  margin: 10px 0;               /* \5439\304D\51FA\3057\306E\4E0A\4E0B\9593\9694 */'),
unistr('  background-color: #c8e6c9;  /* \5439\304D\51FA\3057\306E\80CC\666F\8272\FF08\8584\3044\7DD1\8272\FF09 */'),
unistr('  text-align: left;             /* \6587\5B57\306F\5DE6\5BC4\305B */'),
unistr('  position: relative;           /* \5439\304D\51FA\3057\306E\4F4D\7F6E\3092\76F8\5BFE\7684\306B */'),
unistr('  margin-left: auto;            /* \5439\304D\51FA\3057\3092\53F3\5BC4\305B */'),
unistr('  border-radius: 15px 15px 15px 15px; /* \89D2\3092\4E38\3081\308B */'),
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94341163995295144)
,p_plug_name=>'Chat'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(99166197796441976)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94341278130295145)
,p_plug_name=>'Content'
,p_parent_plug_id=>wwv_flow_imp.id(94341163995295144)
,p_region_css_classes=>'h400'
,p_region_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="overflow-y: scroll;"'
,p_plug_template=>wwv_flow_imp.id(99147802788441935)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>'<div id="content"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99412283117442807)
,p_plug_name=>'Sample MS AI Chat Protocol'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(99191124530442030)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94341670412295149)
,p_button_sequence=>10
,p_button_name=>'OPEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(99288029206442259)
,p_button_image_alt=>'Open'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94341482451295147)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(94341163995295144)
,p_button_name=>'SUBMIT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(99288029206442259)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94341584904295148)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(94341163995295144)
,p_button_name=>'CLOSE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(99288029206442259)
,p_button_image_alt=>'Close'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94341317107295146)
,p_name=>'P1_MESSAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(94341163995295144)
,p_prompt=>'Message'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(99285504358442250)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94341720902295150)
,p_name=>'onClick OPEN'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94341670412295149)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99417736885462506)
,p_event_id=>wwv_flow_imp.id(94341720902295150)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('/* AI Chat Protocol\306E\30AF\30E9\30A4\30A2\30F3\30C8\3092\4F5C\6210\3059\308B */'),
'client = new ChatProtocol.AIChatProtocolClient(',
'    "http://localhost:8080/v1/chat/completions",',
'    {',
'        "allowInsecureConnection": true',
'    }',
');',
'',
unistr('/* \30E1\30C3\30BB\30FC\30B8\3068\30C1\30E3\30C3\30C8\5C65\6B74\3092\8868\793A\3059\308BDIV\8981\7D20\3082\521D\671F\5316\3002 */'),
'messages = [];',
'removeAllChildren(contentDiv);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99417214170462501)
,p_event_id=>wwv_flow_imp.id(94341720902295150)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(94341163995295144)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99417390825462502)
,p_name=>'onClick CLOSE'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94341584904295148)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99417445199462503)
,p_event_id=>wwv_flow_imp.id(99417390825462502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(94341163995295144)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99417517472462504)
,p_name=>'onClick SUBMIT'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94341482451295147)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99417650744462505)
,p_event_id=>wwv_flow_imp.id(99417517472462504)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \9001\4FE1\30E1\30C3\30BB\30FC\30B8\3092\8FFD\52A0'),
' */',
'messages.push({',
'    "role": "user",',
'    "content": apex.items.P1_MESSAGE.value',
'});',
'',
'/*',
unistr(' * \9001\4FE1\3059\308B\30E1\30C3\30BB\30FC\30B8\3092\5DE6\306B\5370\5237\3059\308B'),
' */',
'const messageDiv = document.createElement(''div'');',
'messageDiv.classList.add("bubble-left");',
'messageDiv.textContent = apex.items.P1_MESSAGE.value;',
'contentDiv.appendChild(messageDiv);',
unistr('messageDiv.scrollIntoView({ behavior: ''smooth'' }); /* \4E0B\306B\30B9\30AF\30ED\30FC\30EB */'),
unistr('apex.items.P1_MESSAGE.setValue("");   /* \5165\529B\3057\305F\30E1\30C3\30BB\30FC\30B8\3092\6D88\3059 */'),
'',
'/*',
unistr(' * AI\306B\554F\5408\305B'),
' */',
'const result = client.getCompletion(messages);',
'',
'/*',
unistr(' * \5FDC\7B54\3092\53F3\306B\5370\5237\3059\308B\3002'),
' */',
'result.then( (response ) => {',
'    const replyDiv = document.createElement(''div'');',
'    replyDiv.classList.add("bubble-right");',
'    console.log(response.choices[0]);',
'    replyDiv.textContent = response.choices[0].message.content;',
'    contentDiv.appendChild(replyDiv);',
'    replyDiv.scrollIntoView({ behavior: ''smooth'' });',
'});'))
);
wwv_flow_imp.component_end;
end;
/
