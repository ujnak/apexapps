prompt --application/shared_components/user_interface/lovs/red_pandas
begin
--   Manifest
--     RED PANDAS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(11732276118393786)
,p_lov_name=>'RED PANDAS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    panda_id,',
'    coalesce(panda_ja_name, panda_en_name) as panda_name,',
'    panda_gender,',
'    panda_birthday,',
'    panda_death,',
'    coalesce(zoo_ja_name, zoo_en_name) as zoo_name,',
'    coalesce(zoo_ja_address, zoo_en_address) as zoo_address,',
'    zoo_country_flag as zoo_country',
'from graph_table (',
'    red_panda_graph',
'    match (panda is red_panda where panda.id > 0) -[e is relationship WHERE e.relationship = ''zoo'']-> (zoo is red_panda where zoo.id < 0)',
'    columns (',
'        panda.id         as panda_id,',
'        panda.ja_name    as panda_ja_name,',
'        panda.en_name    as panda_en_name,',
'        panda.gender     as panda_gender,',
'        panda.birthday   as panda_birthday,',
'        panda.death      as panda_death,',
'        zoo.ja_name      as zoo_ja_name,',
'        zoo.en_name      as zoo_en_name,',
'        zoo.ja_address   as zoo_ja_address,',
'        zoo.en_address   as zoo_en_address,',
'        zoo.country_flag as zoo_country_flag',
'    )',
')',
'order by panda_id;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'PANDA_ID'
,p_display_column_name=>'PANDA_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>4229868
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(11732805990402831)
,p_query_column_name=>'PANDA_ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(11733206706402831)
,p_query_column_name=>'PANDA_NAME'
,p_heading=>unistr('\540D\524D')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(11733685742402831)
,p_query_column_name=>'PANDA_GENDER'
,p_heading=>unistr('\6027\5225')
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(11734031639402831)
,p_query_column_name=>'PANDA_BIRTHDAY'
,p_heading=>unistr('\8A95\751F\65E5')
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(12928888428935550)
,p_query_column_name=>'PANDA_DEATH'
,p_heading=>unistr('\547D\65E5')
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(11734810001402831)
,p_query_column_name=>'ZOO_NAME'
,p_heading=>unistr('\98FC\80B2\5712\9928')
,p_display_sequence=>60
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(11735214527402831)
,p_query_column_name=>'ZOO_ADDRESS'
,p_heading=>unistr('\4F4F\6240')
,p_display_sequence=>70
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(11735675426402832)
,p_query_column_name=>'ZOO_COUNTRY'
,p_heading=>unistr('\56FD')
,p_display_sequence=>80
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
