prompt --application/shared_components/user_interface/lovs/red_pandas
begin
--   Manifest
--     RED PANDAS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(11732276118393786)
,p_lov_name=>'RED PANDAS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    panda_id,',
'    coalesce(panda_name_ja, panda_name_en) as panda_name,',
'    gender,',
'    birthday,',
'    death,',
'    coalesce(zoo_name_ja, zoo_name_en) as zoo_name,',
'    coalesce(location_ja, location_en) as location,',
'    country_flag as country',
'from graph_table (',
'    red_panda_graph',
'    match',
unistr('        /* \52D5\7269\5712\306B\98FC\80B2\3055\308C\3066\3044\308B\3001\307E\305F\306F\3001\3055\308C\3066\3044\305F\500B\4F53\3092\30EA\30B9\30C8\3059\308B\3002 */'),
'        (p is red_panda) -[is currentzoo]-> (z is zoo)',
'    columns (',
'        p.panda_id, p.panda_name_en, p.panda_name_ja, p.gender, p.birthday, p.death,',
'        z.zoo_id, z.zoo_name_en, z.zoo_name_ja, z.location_en, z.location_ja, z.country_flag',
'    )',
')',
'order by panda_id;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'PANDA_ID'
,p_display_column_name=>'PANDA_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>4913131
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(14314893491907939)
,p_query_column_name=>'PANDA_ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(14313650355907939)
,p_query_column_name=>'PANDA_NAME'
,p_heading=>unistr('\540D\524D')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(14314004116907939)
,p_query_column_name=>'GENDER'
,p_heading=>unistr('\6027\5225')
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(14312867088907939)
,p_query_column_name=>'BIRTHDAY'
,p_heading=>unistr('\51FA\751F\65E5')
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(14315252990907939)
,p_query_column_name=>'DEATH'
,p_heading=>unistr('\547D\65E5')
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(14314467820907939)
,p_query_column_name=>'ZOO_NAME'
,p_heading=>unistr('\98FC\80B2\5712\9928')
,p_display_sequence=>60
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(14313261855907939)
,p_query_column_name=>'LOCATION'
,p_heading=>unistr('\5834\6240')
,p_display_sequence=>70
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(14312522259907939)
,p_query_column_name=>'COUNTRY'
,p_heading=>unistr('\56FD')
,p_display_sequence=>80
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
