prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Red Panda Lineage'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8122668366654043)
,p_plug_name=>unistr('\8840\7D71')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('/* \5B50\4F9B\3068\89AA \518D\5E30\7684\306B\691C\7D22\3059\308B\3068Graph Visualization Plugin\304C\5FC5\8981\3068\3059\308B e \304C\53D6\308C\306A\3044\3002 */'),
'select',
'    red_panda_s, e, red_panda_d',
'from graph_table ( red_panda_graph',
'match',
'    (m is red_panda where m.id = :P1_RED_PANDA)',
'    -[e is relationship where e.relationship = ''family'' ]-',
'    (n is red_panda)',
'    columns (',
'        vertex_id(m) AS red_panda_s, edge_id(e) as e, vertex_id(n) AS red_panda_d',
'    )',
')',
'union',
unistr('/* \5B6B\3068\7956\7236\6BCD\3068\914D\5076\8005\3068\5144\5F1F */'),
'select',
'    red_panda_s, e, red_panda_d',
'from graph_table ( red_panda_graph',
'match',
'    (m0  is red_panda where m0.id = :P1_RED_PANDA)',
'    -[e0 is relationship where e0.relationship = ''family'' ]-',
'    (m is red_panda)',
'    -[e is relationship where e.relationship = ''family'' ]-',
'    (n is red_panda)',
'    columns (',
'        vertex_id(m) AS red_panda_s, edge_id(e) as e, vertex_id(n) AS red_panda_d',
'    )',
')'))
,p_plug_source_type=>'PLUGIN_GRAPHVIZ'
,p_ajax_items_to_submit=>'P1_RED_PANDA'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_05', 'N',
  'attribute_06', '500',
  'attribute_10', 'modes:exploration',
  'attribute_14', 'Y',
  'attribute_16', '640',
  'basestyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "vertex": {',
    '        "label": {',
    '            "text": "${properties.JA_NAME} - ${properties.EN_NAME}"',
    '        }',
    '    }',
    '}')),
  'bind_variable_pgql', 'N',
  'custom_theme', 'N',
  'darktheme', 'N',
  'defaults_for_modes', 'interactionActive:fitToScreenActive:stickyActive:evolutionActive',
  'enable_evolution', 'N',
  'escapehtml', 'N',
  'exploration_options', 'expand:focus:group:ungroup:drop:undo:redo:reset',
  'livesearch', 'Y',
  'modes_options', 'interaction:fitToScreen:sticky:evolution',
  'rulebasedstyles', wwv_flow_string.join(wwv_flow_t_varchar2(
    '[',
    '  {',
    '    "_id": 1,',
    '    "component": "vertex",',
    '    "stylingEnabled": true,',
    '    "target": "vertex",',
    '    "visibilityEnabled": true,',
    '    "conditions": {',
    '      "operator": "and",',
    '      "conditions": [',
    '        {',
    '          "property": "DEATH",',
    '          "operator": "*",',
    '          "value": ""',
    '        }',
    '      ]',
    '    },',
    '    "legendTitle": "DEAD",',
    '    "style": {',
    '        "icon": {',
    '            "class": "fa-heart"',
    '        }',
    '    }',
    '  }',
    ']')),
  'schema_visualization', 'N',
  'show_legend', 'Y',
  'showtitle', 'Y')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12817704592311802)
,p_name=>'E'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12818633470311811)
,p_name=>'RED_PANDA_S'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12818785908311812)
,p_name=>'RED_PANDA_D'
,p_data_type=>'CLOB'
,p_is_visible=>true
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11727440320136132)
,p_plug_name=>'Red Panda Lineage'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12818847250311813)
,p_plug_name=>unistr('\5834\6240')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with report_wv as (',
'/*',
unistr(' * \30EC\30DD\30FC\30C8\3068\306F\5909\3048\3066\3001\5730\56F3\4E0A\306B\8868\793A\3059\308B\306E\306F\751F\5B58\3057\3066\3044\308B\500B\4F53\306B\9650\5B9A\3059\308B\3002'),
unistr(' * SELECT\6587\306B\672B\5C3E\306Bwhere death is null\3092\8FFD\52A0\3057\3066\3044\308B\3002'),
' */',
'select',
'    distinct',
unistr('    -- id,  -- \52D5\7269\5712\3067\307E\3068\3081\308B\306E\3067ID\306F\9664\304F'),
'    zoo_id,',
'    coalesce(ja_name, en_name) as name,',
'    gender,',
'    birthday,',
'    death,',
'    coalesce(ja_location, en_location) as location,',
'    coalesce(ja_zoo_name, en_zoo_name) as zoo_name,',
'    country,',
'    longitude,',
'    latitude',
'from graph_table ( red_panda_graph',
'match',
'    (m is red_panda  where m.id = :P1_RED_PANDA)',
'    -[e  is relationship where e.relationship = ''family'' ]-{0,2}',
'    (n   is red_panda)',
'    -[r  is relationship where r.relationship = ''zoo'' ]->',
'    (l   is red_panda)',
'    columns (',
'       n.id, n.ja_name, n.en_name, n.gender, n.birthday, n.death,',
'       l.id as zoo_id, l.ja_location, l.en_location,',
'       l.ja_name as ja_zoo_name, l.en_name as en_zoo_name, l.country_flag as country,',
'       l.longitude, l.latitude',
'    )',
')',
'where death is null',
')',
'select',
'    zoo_id,',
'    listagg(name,'','') as names,',
'    location,',
'    zoo_name,',
'    country,',
'    longitude,',
'    latitude',
'from report_wv',
'group by zoo_id, zoo_name, location, country, longitude, latitude'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_ajax_items_to_submit=>'P1_RED_PANDA'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(12818962694311814)
,p_region_id=>wwv_flow_imp.id(12818847250311813)
,p_height=>640
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_legend_position=>'END'
,p_features=>'SCALE_BAR:INFINITE_MAP:RECTANGLE_ZOOM'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(12819021511311815)
,p_map_region_id=>wwv_flow_imp.id(12818962694311814)
,p_name=>unistr('\98FC\80B2\5834\6240')
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'REGION_SOURCE'
,p_has_spatial_index=>false
,p_pk_column=>'ZOO_ID'
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_tooltip_column=>'LOCATION'
,p_info_window_adv_formatting=>false
,p_info_window_title_column=>'ZOO_NAME'
,p_info_window_body_column=>'NAMES'
,p_display_in_legend=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12819217062311817)
,p_plug_name=>unistr('\30EA\30B9\30C8')
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
unistr('    /* :P1_RED_PANDA\306E\8840\7D71 */'),
'    distinct',
'    id,',
'    zoo_id,',
'    coalesce(ja_name, en_name) as name,',
'    gender,',
'    birthday,',
'    death,',
'    coalesce(ja_location, en_location) as location,',
'    coalesce(ja_zoo_name, en_zoo_name) as zoo_name,',
'    country,',
'    -- edge_ids,',
'    longitude,',
'    latitude',
'from graph_table ( red_panda_graph',
'match',
'    (m   is red_panda     where m.id = :P1_RED_PANDA)',
'    /*',
unistr('     * \8840\7D71\306E\691C\7D22'),
'     */',
'    -[e  is relationship  where e.relationship = ''family'' ]-{0,2}',
'    (n   is red_panda)',
'    -[r  is relationship where r.relationship = ''zoo'' ]->',
unistr('    (l   is red_panda) -- \52D5\7269\5712\3060\3051\3069\30E9\30D9\30EB\306Fred_panda'),
'    columns (',
'       n.id, n.ja_name, n.en_name, n.gender, n.birthday, n.death,',
unistr('       /* \8907\6570\306E\30D1\30B9\304C\898B\3064\304B\308B\3053\3068\3067\3001\7D50\679C\304C\91CD\8907\3059\308B\3002\305D\306E\305F\3081distinct\3092\3064\3051\3066\3044\308B\3002 */'),
'       -- listagg(e.id, '','') as edge_ids,',
'       l.id as zoo_id, l.ja_location, l.en_location,',
'       l.ja_name as ja_zoo_name, l.en_name as en_zoo_name, l.country_flag as country,',
'       l.longitude, l.latitude',
'    )',
')'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1_RED_PANDA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(12820985058311834)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>12820985058311834
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12821075948311835)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12821114171311836)
,p_db_column_name=>'NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12821211433311837)
,p_db_column_name=>'GENDER'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Gender'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12821322523311838)
,p_db_column_name=>'BIRTHDAY'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Birthday'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12821414525311839)
,p_db_column_name=>'DEATH'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Death'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12821566127311840)
,p_db_column_name=>'LOCATION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Location'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12821636770311841)
,p_db_column_name=>'ZOO_NAME'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Zoo Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12821762694311842)
,p_db_column_name=>'COUNTRY'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Country'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12821984640311844)
,p_db_column_name=>'LONGITUDE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Longitude'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12822018059311845)
,p_db_column_name=>'LATITUDE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Latitude'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12822463984311849)
,p_db_column_name=>'ZOO_ID'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Zoo Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(13138548982483563)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'131386'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>10
,p_report_columns=>'ID:NAME:GENDER:BIRTHDAY:DEATH:LOCATION:ZOO_NAME:COUNTRY:LONGITUDE:LATITUDE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8121792439654034)
,p_name=>'P1_RED_PANDA'
,p_item_sequence=>10
,p_prompt=>unistr('\30EC\30C3\30B5\30FC\30FB\30D1\30F3\30C0')
,p_display_as=>'NATIVE_SELECT_ONE'
,p_named_lov=>'RED PANDAS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    panda_id,',
'    coalesce(panda_ja_name, panda_en_name) as panda_name,',
'    panda_gender,',
'    panda_birthday,',
'    panda_death,',
'    coalesce(zoo_ja_name, zoo_en_name) as zoo_name,',
'    coalesce(zoo_ja_address, zoo_en_address) as zoo_address,',
'    zoo_country_flag as zoo_country',
'from graph_table (',
'    red_panda_graph',
'    match (panda is red_panda where panda.id > 0) -[e is relationship WHERE e.relationship = ''zoo'']-> (zoo is red_panda where zoo.id < 0)',
'    columns (',
'        panda.id         as panda_id,',
'        panda.ja_name    as panda_ja_name,',
'        panda.en_name    as panda_en_name,',
'        panda.gender     as panda_gender,',
'        panda.birthday   as panda_birthday,',
'        panda.death      as panda_death,',
'        zoo.ja_name      as zoo_ja_name,',
'        zoo.en_name      as zoo_en_name,',
'        zoo.ja_address   as zoo_ja_address,',
'        zoo.en_address   as zoo_en_address,',
'        zoo.country_flag as zoo_country_flag',
'    )',
')',
'order by panda_id;'))
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12818062533311805)
,p_name=>'onChange P1_RED_PANDA'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_RED_PANDA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12818152984311806)
,p_event_id=>wwv_flow_imp.id(12818062533311805)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8122668366654043)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12819182084311816)
,p_event_id=>wwv_flow_imp.id(12818062533311805)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12818847250311813)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12822186273311846)
,p_event_id=>wwv_flow_imp.id(12818062533311805)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12819217062311817)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12822221676311847)
,p_name=>'onSelect Vertex'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(8122668366654043)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_GRAPHVIZ|REGION TYPE|selection'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12822317532311848)
,p_event_id=>wwv_flow_imp.id(12822221676311847)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (this.data.vertices && this.data.vertices.length > 0) {',
'    const vertex = this.data.vertices[0].id;',
'    /* ',
unistr('     * id\306F RED_PANDA_VERTICES{"ID":26} \3068\3057\3066\6E21\3055\308C\308B\306E\3067\3001'),
unistr('     * \6B63\898F\8868\73FE\3067\6570\5024\90E8\5206\3092\53D6\308A\51FA\3059\3002'),
unistr('     * \6B63\5E38\306B\53D6\308A\51FA\305B\305F\3089\3001P1_RED_PANDA\306B\8A2D\5B9A\3059\308B\3002'),
'     */',
'    const match = vertex.match(/"ID":(\d+)/);',
'    if (match) {',
'        // console.log(match[1]);',
'        apex.items.P1_RED_PANDA.setValue(match[1]);',
'    }    ',
'}'))
);
wwv_flow_imp.component_end;
end;
/
