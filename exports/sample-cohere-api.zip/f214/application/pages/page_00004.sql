prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>214
,p_default_id_offset=>29033660045324779
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Embed'
,p_alias=>'EMBED'
,p_step_title=>'Embed'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230626084335'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29018205438893910)
,p_plug_name=>'Texts'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55984709691819499)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'select seq_id, c001 from apex_collections where collection_name = ''EMBED_TEXTS'''
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Texts'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29018411795893912)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29018580374893913)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'text'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29018641702893914)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29018779639893915)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(29018369731893911)
,p_internal_uid=>29018369731893911
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(29038154664651744)
,p_interactive_grid_id=>wwv_flow_imp.id(29018369731893911)
,p_static_id=>'290382'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(29038354643651745)
,p_report_id=>wwv_flow_imp.id(29038154664651744)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29038864418651746)
,p_view_id=>wwv_flow_imp.id(29038354643651745)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(29018411795893912)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29039705725651749)
,p_view_id=>wwv_flow_imp.id(29038354643651745)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(29018580374893913)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29040687465651752)
,p_view_id=>wwv_flow_imp.id(29038354643651745)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(29018641702893914)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29019444327893922)
,p_plug_name=>'Response'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(55994477213819504)
,p_plug_display_sequence=>50
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request clob;',
'    l_response clob;',
'    l_count number;',
'begin',
'    select count(*) into l_count from apex_collections where collection_name = ''EMBED_TEXTS'';',
'    if l_count = 0 then',
'        l_response := ''no input exists.'';',
'        return l_response;',
'    end if;',
unistr('    -- Co.Embed\3078\306E\30EA\30AF\30A8\30B9\30C8\3092\751F\6210\3059\308B\3002'),
'    select json_object(',
'        key ''texts'' value',
'        (',
'            select json_arrayagg(c001 order by seq_id) from apex_collections',
'            where collection_name = ''EMBED_TEXTS''',
'        )',
unistr('        -- \30E2\30C7\30EB\3092\6307\5B9A\3059\308B\3002'),
'        ,key ''model''    value :P4_MODEL',
unistr('        -- \30C8\30E9\30F3\30B1\30FC\30C8\3092\6307\5B9A\3059\308B\3002'),
'        ,key ''truncate'' value :P4_TRUNCATE',
'    returning clob)',
'    into l_request',
'    from dual;',
unistr('    -- Cohere Co.Embed\3092\547C\3073\51FA\3059\3002'),
'    -- https://docs.cohere.com/reference/embed',
'    apex_debug.info(l_request);',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'', p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => ''https://api.cohere.ai/v1/embed''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request',
'        ,p_credential_static_id => ''COHERE_API''',
'    );',
'    return l_response;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P4_MODEL,P4_TRUNCATE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29036171421558947)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(56006920639819511)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(55891217683819450)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(56069306825819546)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29019311821893921)
,p_button_sequence=>40
,p_button_name=>'SUBMIT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(56067663051819545)
,p_button_image_alt=>'Submit'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29019185630893919)
,p_name=>'P4_MODEL'
,p_item_sequence=>20
,p_item_default=>'embed-multilingual-v2.0'
,p_prompt=>'Model'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(56065201463819542)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29019273457893920)
,p_name=>'P4_TRUNCATE'
,p_item_sequence=>30
,p_item_default=>'NONE'
,p_prompt=>'Truncate'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(56065201463819542)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29019525965893923)
,p_name=>'onClick Refresh'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(29019311821893921)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29019674986893924)
,p_event_id=>wwv_flow_imp.id(29019525965893923)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(29019444327893922)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29018838231893916)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(29018205438893910)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Texts - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_COLLECTION_NAME constant varchar2(20) := ''EMBED_TEXTS'';',
'begin',
'  case :APEX$ROW_STATUS',
'  when ''C'' then',
'      :SEQ_ID := apex_collection.add_member(',
'          p_collection_name => C_COLLECTION_NAME',
'          ,p_c001 => :C001',
'      );',
'  when ''U'' then',
'    apex_collection.update_member(',
'        p_collection_name => C_COLLECTION_NAME',
'        ,p_c001 => :C001',
'        ,p_seq  => :SEQ_ID',
'    );',
'  when ''D'' then',
'    apex_collection.delete_member(',
'        p_collection_name => C_COLLECTION_NAME',
'        ,p_seq => :SEQ_ID',
'    );',
'  end case;',
'end;'))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>29018838231893916
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29018121628893909)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('APEX\30B3\30EC\30AF\30B7\30E7\30F3\306E\521D\671F\5316')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_collection.create_or_truncate_collection(''EMBED_TEXTS'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>29018121628893909
);
wwv_flow_imp.component_end;
end;
/
