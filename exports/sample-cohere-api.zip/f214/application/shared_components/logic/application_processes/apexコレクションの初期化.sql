prompt --application/shared_components/logic/application_processes/apexコレクションの初期化
begin
--   Manifest
--     APPLICATION PROCESS: APEXコレクションの初期化
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>214
,p_default_id_offset=>29033660045324779
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(56190405807838921)
,p_process_sequence=>1
,p_process_point=>'ON_NEW_INSTANCE'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('APEX\30B3\30EC\30AF\30B7\30E7\30F3\306E\521D\671F\5316')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_collection.create_or_truncate_collection(''CLASSIFY_INPUTS'');',
'    apex_collection.create_or_truncate_collection(''CLASSIFY_EXAMPLES'');',
'end;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
