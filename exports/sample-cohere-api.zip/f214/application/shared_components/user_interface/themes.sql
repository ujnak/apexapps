prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 214
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>214
,p_default_id_offset=>29033660045324779
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(56152714263819605)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(55917851838819464)
,p_default_dialog_template=>wwv_flow_imp.id(55912606515819461)
,p_error_template=>wwv_flow_imp.id(55902642175819456)
,p_printer_friendly_template=>wwv_flow_imp.id(55917851838819464)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(55902642175819456)
,p_default_button_template=>wwv_flow_imp.id(56067663051819545)
,p_default_region_template=>wwv_flow_imp.id(55994477213819504)
,p_default_chart_template=>wwv_flow_imp.id(55994477213819504)
,p_default_form_template=>wwv_flow_imp.id(55994477213819504)
,p_default_reportr_template=>wwv_flow_imp.id(55994477213819504)
,p_default_tabform_template=>wwv_flow_imp.id(55994477213819504)
,p_default_wizard_template=>wwv_flow_imp.id(55994477213819504)
,p_default_menur_template=>wwv_flow_imp.id(56006920639819511)
,p_default_listr_template=>wwv_flow_imp.id(55994477213819504)
,p_default_irr_template=>wwv_flow_imp.id(55984709691819499)
,p_default_report_template=>wwv_flow_imp.id(56032728229819524)
,p_default_label_template=>wwv_flow_imp.id(56065201463819542)
,p_default_menu_template=>wwv_flow_imp.id(56069306825819546)
,p_default_calendar_template=>wwv_flow_imp.id(56069428285819546)
,p_default_list_template=>wwv_flow_imp.id(56049068248819533)
,p_default_nav_list_template=>wwv_flow_imp.id(56060891683819539)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(56060891683819539)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(56055557108819536)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(55930674225819471)
,p_default_dialogr_template=>wwv_flow_imp.id(55927874458819470)
,p_default_option_label=>wwv_flow_imp.id(56065201463819542)
,p_default_required_label=>wwv_flow_imp.id(56066494608819544)
,p_default_navbar_list_template=>wwv_flow_imp.id(56055084669819536)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/23.1/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
