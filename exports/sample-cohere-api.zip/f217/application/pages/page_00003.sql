prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>217
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Generate'
,p_alias=>'GENERATE'
,p_step_title=>'Generate'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230626044333'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28131501777402523)
,p_plug_name=>'Generate'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26951049646494720)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>'select clob001 from apex_collections where collection_name = ''GENERATE'''
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Generate'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(28131659382402524)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>28131659382402524
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(28131771280402525)
,p_db_column_name=>'CLOB001'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Text'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_display_text_as=>'RICH_TEXT'
,p_heading_alignment=>'LEFT'
,p_rich_text_format=>'MARKDOWN'
,p_rpt_show_filter_lov=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(28992823003028306)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'289929'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CLOB001'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28975408499003409)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26973260594494732)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(26857557638494671)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(27035646780494767)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28976094326003409)
,p_plug_name=>'Generate'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(26960817168494725)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    0 as "ID"',
'    ,''this column is for prompt string that should be long enough to reserve max string size'' as "PROMPT"',
'    ,''command'' as "MODEL"',
'    ,1 as "NUM_GENERATIONS"',
'    ,20 as "MAX_TOKENS"',
'    ,'''' as "PRESET"',
'    ,0.75 as "TEMPERATURE"',
'    ,0 as "K"',
'    ,0.75 as "P"',
'    ,0.0 as "FREQUENCY_PENALTY"',
'    ,0.0 as "PRESENCE_PENALTY"',
'    ,''[]'' as "END_SEQUENCES"',
'    ,''[]'' as "STOP_SEQUENCES"',
'    ,''NONE'' as "RETURN_LIKELIHOODS"',
'    ,''{}'' as "LOGIT_BIAS"',
'    ,''END'' as "TRUNCATE"',
'    ,''N'' as "STREAM"',
'from dual;'))
,p_is_editable=>true
,p_edit_operations=>'i'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28989309223003418)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27034003006494766)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_position=>'CHANGE'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
,p_required_patch=>wwv_flow_imp.id(26856996535494669)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28988316788003418)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27034003006494766)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28989769714003419)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27034003006494766)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'CREATE'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(28988907477003418)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(27034003006494766)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
,p_required_patch=>wwv_flow_imp.id(26856996535494669)
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(28990048978003419)
,p_branch_action=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28131411526402522)
,p_name=>'P3_RESPONSE'
,p_item_sequence=>20
,p_prompt=>'Response'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28976445070003410)
,p_name=>'P3_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28976872833003410)
,p_name=>'P3_PROMPT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'Prompt'
,p_source=>'PROMPT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>32
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28977206768003410)
,p_name=>'P3_MODEL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Model'
,p_source=>'MODEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>7
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28977611077003411)
,p_name=>'P3_NUM_GENERATIONS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'Num Generations'
,p_source=>'NUM_GENERATIONS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>7
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28978099406003411)
,p_name=>'P3_MAX_TOKENS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'Max Tokens'
,p_source=>'MAX_TOKENS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>7
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28978409954003411)
,p_name=>'P3_PRESET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'Preset'
,p_source=>'PRESET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28978859488003411)
,p_name=>'P3_TEMPERATURE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Temperature'
,p_source=>'TEMPERATURE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28979288738003412)
,p_name=>'P3_K'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'K'
,p_source=>'K'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28979634165003412)
,p_name=>'P3_P'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'P'
,p_source=>'P'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28980059115003412)
,p_name=>'P3_FREQUENCY_PENALTY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'Frequency Penalty'
,p_source=>'FREQUENCY_PENALTY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28980445426003413)
,p_name=>'P3_PRESENCE_PENALTY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'Presence Penalty'
,p_source=>'PRESENCE_PENALTY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28980804410003413)
,p_name=>'P3_END_SEQUENCES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_use_cache_before_default=>'NO'
,p_prompt=>'End Sequences'
,p_source=>'END_SEQUENCES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>2
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28981246278003413)
,p_name=>'P3_STOP_SEQUENCES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'Stop Sequences'
,p_source=>'STOP_SEQUENCES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>2
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28981665087003413)
,p_name=>'P3_RETURN_LIKELIHOODS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Return Likelihoods'
,p_source=>'RETURN_LIKELIHOODS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28982006379003414)
,p_name=>'P3_LOGIT_BIAS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'Logit Bias'
,p_source=>'LOGIT_BIAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>2
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28982402817003414)
,p_name=>'P3_TRUNCATE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'Truncate'
,p_source=>'TRUNCATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>3
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28982870428003414)
,p_name=>'P3_STREAM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_item_source_plug_id=>wwv_flow_imp.id(28976094326003409)
,p_prompt=>'Stream'
,p_source=>'STREAM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(27031541418494763)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28990961671003420)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(28976094326003409)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0Generate')
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request       json_object_t;',
'    l_request_clob  clob;',
'    l_response      clob;',
'    l_response_blob blob;',
'begin',
'    l_request := json_object_t();',
'    l_request.put(''prompt'', :P3_PROMPT);',
'    if :P3_MODEL is not null then',
'        l_request.put(''model'', :P3_MODEL);',
'    end if;',
'    if :P3_NUM_GENERATIONS is not null then',
'        l_request.put(''num_generations'', to_number(:P3_NUM_GENERATIONS));',
'    end if; ',
'    if :P3_MAX_TOKENS is not null then',
'        l_request.put(''max_tokens'', to_number(:P3_MAX_TOKENS));',
'    end if;',
'    if :P3_PRESET is not null then',
'        l_request.put(''preset'', :P3_PRESET);',
'    end if;',
'    if :P3_TEMPERATURE is not null then',
'        l_request.put(''temperature'', to_number(:P3_TEMPERATURE));',
'    end if;',
'    if :P3_K is not null then',
'        l_request.put(''k'', to_number(:P3_K));',
'    end if;',
'    if :P3_P is not null then',
'        l_request.put(''p'', to_number(:P3_P));',
'    end if;',
'    if :P3_FREQUENCY_PENALTY is not null then',
'        l_request.put(''frequency_penalty'', to_number(:P3_FREQUENCY_PENALTY));',
'    end if;',
'    if :P3_PRESENCE_PENALTY is not null then',
'        l_request.put(''presence_penalty'', to_number(:P3_PRESENCE_PENALTY));',
'    end if;',
'    if :P3_END_SEQUENCES is not null then',
'        l_request.put(''end_sequences'', json_array_t.parse(:P3_END_SEQUENCES));',
'    end if;',
'    if :P3_STOP_SEQUENCES is not null then',
'        l_request.put(''stop_sequences'', json_array_t.parse(:P3_STOP_SEQUENCES));',
'    end if;',
'    if :P3_RETURN_LIKELIHOODS is not null then',
'        l_request.put(''return_likelihoods'', :P3_RETURN_LIKELIHOODS);',
'    end if;',
'    if :P3_LOGIT_BIAS is not null then',
'        l_request.put(''logit_bias'', json_object_t.parse(:P3_LOGIT_BIAS));',
'    end if;',
'    if :P3_TRUNCATE is not null then',
'        l_request.put(''truncate'', :P3_TRUNCATE);',
'    end if;',
'    if :P3_STREAM is not null then',
'        if :P3_STREAM = ''Y'' then',
'            l_request.put(''stream'', true);',
'        else',
'            l_request.put(''stream'', false);',
'        end if;',
'    end if;',
'    l_request_clob := l_request.to_clob();',
'    apex_debug.info(''Co.Generate Request: %s'', l_request_clob);',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Accept'',''application/json'', p_reset => false);',
'    apex_web_service.set_request_headers(''Content-Type'',''application/json'', p_reset => false);',
'    l_response_blob := apex_web_service.make_rest_request_b(',
'        p_url => ''https://api.cohere.ai/v1/generate''',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'        ,p_credential_static_id => ''COHERE_API''',
'    );',
unistr('    -- \5FDC\7B54\306F\6574\5F62\3057\3066\8868\793A\3059\308B\3002'),
'    select json_serialize(l_response_blob returning clob pretty) into l_response from dual;',
'    :P3_RESPONSE := l_response;',
unistr('    -- \751F\6210\3055\308C\305F\30C6\30AD\30B9\30C8\3092APEX\30B3\30EC\30AF\30B7\30E7\30F3\306B\6295\5165\3059\308B\3002'),
'    apex_collection.create_or_truncate_collection(''GENERATE'');',
'    for r in (',
'        select id, text from json_table(l_response, ''$.generations[*]''',
'            columns',
'            (',
'                id varchar2(80) path ''$.id''',
'                ,text clob path ''$.text''',
'            )',
'        )',
'    )',
'    loop',
'        apex_collection.add_member(',
'            p_collection_name => ''GENERATE''',
'            ,p_c001 => r.id',
'            ,p_clob001 => r.text',
'        );',
'    end loop;',
'end;'))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>28990961671003420
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(28990541754003419)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(28976094326003409)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0Generate')
,p_required_patch=>wwv_flow_imp.id(26856996535494669)
,p_internal_uid=>28990541754003419
);
wwv_flow_imp.component_end;
end;
/
