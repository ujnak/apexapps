prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 111
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7335198607042437
,p_default_application_id=>111
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(79434214026341796)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(79287834874341724)
,p_default_dialog_template=>wwv_flow_imp.id(79282671669341721)
,p_error_template=>wwv_flow_imp.id(79272615616341716)
,p_printer_friendly_template=>wwv_flow_imp.id(79287834874341724)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(79272615616341716)
,p_default_button_template=>wwv_flow_imp.id(79431258805341794)
,p_default_region_template=>wwv_flow_imp.id(79358312603341757)
,p_default_chart_template=>wwv_flow_imp.id(79358312603341757)
,p_default_form_template=>wwv_flow_imp.id(79358312603341757)
,p_default_reportr_template=>wwv_flow_imp.id(79358312603341757)
,p_default_tabform_template=>wwv_flow_imp.id(79358312603341757)
,p_default_wizard_template=>wwv_flow_imp.id(79358312603341757)
,p_default_menur_template=>wwv_flow_imp.id(79370792517341764)
,p_default_listr_template=>wwv_flow_imp.id(79358312603341757)
,p_default_irr_template=>wwv_flow_imp.id(79353718394341755)
,p_default_report_template=>wwv_flow_imp.id(79396202872341776)
,p_default_label_template=>wwv_flow_imp.id(79428771771341793)
,p_default_menu_template=>wwv_flow_imp.id(79432828752341795)
,p_default_calendar_template=>wwv_flow_imp.id(79432957984341795)
,p_default_list_template=>wwv_flow_imp.id(79412611147341784)
,p_default_nav_list_template=>wwv_flow_imp.id(79424431243341790)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(79424431243341790)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(79419087477341788)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(79300795297341730)
,p_default_dialogr_template=>wwv_flow_imp.id(79297913587341729)
,p_default_option_label=>wwv_flow_imp.id(79428771771341793)
,p_default_required_label=>wwv_flow_imp.id(79430072758341793)
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_default_navbar_list_template=>wwv_flow_imp.id(79418613470341787)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/22.1/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
