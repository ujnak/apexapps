prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.7'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>255
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>unistr('\5C0F\8AAC\3092\8AAD\3080')
,p_alias=>'READ-STORY'
,p_step_title=>unistr('\5C0F\8AAC\3092\8AAD\3080')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134765263239363945)
,p_plug_name=>'Item Container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(139041266724676612)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(139256033210748829)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(139061384110676656)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(138945681820676315)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(139124134516676828)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(139258314396772201)
,p_plug_name=>unistr('\5C0F\8AAC')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(139048939346676629)
,p_plug_display_sequence=>20
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_story clob;',
'begin',
'    if :P2_STORY is not null then',
'        select story into l_story from ebaj_stories where id = :P2_STORY;',
'        return apex_markdown.to_html(l_story);',
'    end if;',
'    return '''';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(134765440125363947)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(134765263239363945)
,p_button_name=>'READ'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(139122589615676823)
,p_button_image_alt=>unistr('\8AAD\3080')
,p_button_position=>'BUTTON_END'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(134765507224363948)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(134765263239363945)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(139122589615676823)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'BUTTON_END'
,p_confirm_message=>unistr('\672C\5F53\306B\524A\9664\3057\307E\3059\304B\FF1F')
,p_confirm_style=>'danger'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134765352611363946)
,p_name=>'P2_STORY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(134765263239363945)
,p_prompt=>unistr('\5C0F\8AAC')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select title d, id r from ebaj_stories',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- \8AAD\307F\305F\3044\5C0F\8AAC\3092\9078\3093\3067 -')
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(139120006114676813)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134765637670363949)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE'
,p_process_sql_clob=>'delete from ebaj_stories where id = :P2_STORY;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(134765507224363948)
,p_internal_uid=>134765637670363949
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134765769081363950)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>unistr('P2_STORY\306E\30AF\30EA\30A2')
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P2_STORY'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(134765507224363948)
,p_internal_uid=>134765769081363950
);
wwv_flow_imp.component_end;
end;
/
