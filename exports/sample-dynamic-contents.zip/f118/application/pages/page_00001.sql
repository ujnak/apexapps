prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7216617235130697
,p_default_application_id=>118
,p_default_id_offset=>10157363975434874
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Dynamic Contents'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'img {',
'  max-width:100%;',
'  max-height: 100%;',
'  width: auto;',
'  height: auto;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18445801354524988)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(28677024880211919)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28581003702334040)
,p_plug_name=>'Image'
,p_region_css_classes=>'w800 h800 margin-auto'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(28675609369211915)
,p_plug_display_sequence=>30
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response  clob;',
'    l_clob      clob;',
'    l_offset    integer;',
'    l_length    integer;',
'    l_image  ebmj_images%rowtype;',
'    l_output varchar2(80);',
'begin',
'    select * into l_image from ebmj_images where title = :P1_ANIMAL;',
'    dbms_lob.createTemporary(l_response, false, dbms_lob.SESSION);',
'    /* open img tag */',
'    l_output := q''~<img src="data:~'';',
'    dbms_lob.writeAppend(l_response, length(l_output), l_output);',
'    l_output := l_image.content_mimetype;',
'    dbms_lob.writeAppend(l_response, length(l_output), l_output);',
'    l_output := q''~;base64,~'';',
'    dbms_lob.writeAppend(l_response, length(l_output), l_output);',
'    /* base64 encoded image */',
'    l_clob := apex_web_service.blob2clobbase64(l_image.content, ''N'');',
'    l_length := dbms_lob.getlength(l_clob);',
'    l_offset := dbms_lob.getlength(l_response) + 1;',
'    dbms_lob.copy(',
'        dest_lob => l_response',
'        ,src_lob => l_clob',
'        ,amount =>  l_length',
'        ,dest_offset => l_offset',
'        ,src_offset => 1',
'    );',
'    /* close img tag */',
'    l_output := q''~">~'';',
'    dbms_lob.writeAppend(l_response, length(l_output), l_output);',
'    /* return img tag */',
'    return l_response;',
'    -- dbms_lob.freeTemporary(l_response);',
'exception',
'    when no_data_found then',
'        return ''<div>no data found</div>'';',
'end;'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_ANIMAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28939613903212841)
,p_plug_name=>'Sample Dynamic Contents'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(28707546682211983)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8288556577090115)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18445801354524988)
,p_button_name=>'BUTTON1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(28814398446212233)
,p_button_image_alt=>unistr('\305F\306C\304D')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8288623056090116)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(18445801354524988)
,p_button_name=>'BUTTON2'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(28814398446212233)
,p_button_image_alt=>unistr('\30B7\30DE\30A6\30DE')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8288707962090117)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(18445801354524988)
,p_button_name=>'BUTTON3'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(28814398446212233)
,p_button_image_alt=>unistr('\30EC\30C3\30B5\30FC\30D1\30F3\30C0')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8289490470090124)
,p_name=>'P1_ANIMAL'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8288888263090118)
,p_name=>'onClick BUTTON1'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8288556577090115)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8289559655090125)
,p_event_id=>wwv_flow_imp.id(8288888263090118)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_ANIMAL'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>unistr('\305F\306C\304D')
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8289671889090126)
,p_event_id=>wwv_flow_imp.id(8288888263090118)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(28581003702334040)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8289027661090120)
,p_name=>'onClick BUTTON2'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8288623056090116)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8289768905090127)
,p_event_id=>wwv_flow_imp.id(8289027661090120)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_ANIMAL'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>unistr('\30B7\30DE\30A6\30DE')
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8290074041090130)
,p_event_id=>wwv_flow_imp.id(8289027661090120)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(28581003702334040)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8289254560090122)
,p_name=>'onClick  BUTTON3'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8288707962090117)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8289871689090128)
,p_event_id=>wwv_flow_imp.id(8289254560090122)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_ANIMAL'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>unistr('\30EC\30C3\30B5\30FC\30D1\30F3\30C0')
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8289947164090129)
,p_event_id=>wwv_flow_imp.id(8289254560090122)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(28581003702334040)
);
wwv_flow_imp.component_end;
end;
/
