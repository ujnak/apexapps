prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>212
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Danfo.js'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/danfojs/lib/bundle.min.js',
'https://cdn.jsdelivr.net/npm/gridjs/dist/gridjs.production.min.js'))
,p_javascript_code=>'var elem;'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'elem = document.getElementById("grid");',
unistr('// Grid.js\3067\30DA\30FC\30B8\30F3\30B0\3059\308B\969B\306B\30DA\30FC\30B8\306E\9001\4FE1\3092\884C\308F\306A\3044\3002'),
'elem.addEventListener(''click'', function(event) {',
'    event.preventDefault();',
'});'))
,p_css_file_urls=>'https://cdn.jsdelivr.net/npm/gridjs/dist/theme/mermaid.min.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(111399020790930539)
,p_plug_name=>'Grid'
,p_region_name=>'grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112638800732417640)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(112901871755418723)
,p_plug_name=>'Sample Danfo.js'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(112670741992417717)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(111398281621930531)
,p_button_sequence=>20
,p_button_name=>'PREVIEW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(112777601148418073)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Preview'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111397917800930528)
,p_name=>'P1_EXCEL'
,p_item_sequence=>10
,p_prompt=>'Excel'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(112775108560418066)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(111398342648930532)
,p_name=>'onClick READ'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(111398281621930531)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(111398408413930533)
,p_event_id=>wwv_flow_imp.id(111398342648930532)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const file = document.getElementById("P1_EXCEL").files[0];',
'',
'dfd.readExcel(file).then((df) => {',
'    // remove if preview element is exist.',
'    if (elem.firstChild) {',
'        elem.removeChild(elem.firstChild);',
'    };',
'    // create new preview element.',
'    const preview = document.createElement("div");',
'    const grid = new gridjs.Grid({',
'        columns: df.$columns,',
'        data: df.$data,',
'        pagination: {',
'            enabled: true,',
'            limit: 4',
'        }',
'    }).render(preview);',
'    elem.appendChild(preview);',
'});'))
);
wwv_flow_imp.component_end;
end;
/
