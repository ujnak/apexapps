prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>232
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample PCL.js'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "pcl.js": "https://cdn.jsdelivr.net/npm/pcl.js@1.16.0/dist/pcl.esm.js",',
'            "pcl.js/PointCloudViewer": "https://cdn.jsdelivr.net/npm/pcl.js@1.16.0/dist/visualization/PointCloudViewer.esm.js",',
'            "three": "https://cdn.jsdelivr.net/npm/three@0.171.0/build/three.module.js",',
'            "three/examples/jsm/controls/OrbitControls": "https://cdn.jsdelivr.net/npm/three@0.171.0/examples/jsm/controls/OrbitControls.js",',
'            "three/examples/jsm/loaders/PCDLoader": "https://cdn.jsdelivr.net/npm/three@0.171.0/examples/jsm/loaders/PCDLoader.js"',
'        }',
'    }',
'</script>'))
,p_javascript_file_urls=>'[module,defer]#APP_FILES#app#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(126288621591997508)
,p_plug_name=>'keypoints - ISSKeypoint3D'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(127726840949423041)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1 id="progress" style="position: absolute; z-index: 9; right: 50%; top: 50%;">',
'    Loading...',
'</h1>',
'',
'<div id="container" class="h600">',
'    <canvas id="canvas"></canvas>',
'    <div style="',
'            position: absolute;',
'            z-index: 1;',
'            top: 10px;',
'            right: 10px;',
'            background: rgba(0, 0, 0, 0.5);',
'            color: #fff;',
'          ">',
'        <fieldset>',
'            <legend>Select display mode</legend>',
'            <div>',
'                <input type="radio" id="mix" name="display" value="mix" checked />',
'                <label for="mix">Mix</label>',
'            </div>',
'            <div>',
'                <input',
'                type="radio"',
'                id="original"',
'                name="display"',
'                value="original"',
'              />',
'                <label for="original">Original</label>',
'            </div>',
'            <div>',
'                <input',
'                type="radio"',
'                id="keypoints"',
'                name="display"',
'                value="keypoints"',
'              />',
'                <label for="keypoints">Keypoints</label>',
'            </div>',
'        </fieldset>',
'    </div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127924797209423712)
,p_plug_name=>'Sample PCL.js'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(127693553160422968)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126289159733997513)
,p_name=>'P1_PCD'
,p_item_sequence=>10
,p_prompt=>'PCD'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:bun0.pcd;bun0.pcd,ism_test_wolf.pcd;ism_test_wolf.pcd,ism_train_horse.pcd;ism_train_horse.pcd'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(127797907398423216)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'REDIRECT_SET_VALUE'
);
wwv_flow_imp.component_end;
end;
/
