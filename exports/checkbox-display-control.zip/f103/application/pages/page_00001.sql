prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>8495801124689411
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\30C1\30A7\30C3\30AF\30DC\30C3\30AF\30B9\306E\8868\793A\5236\5FA1')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'const TOP_N = 3;'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add([',
'{',
'    // show all checkboxs in the page item "cbid"',
'    name: "show-all",',
'    action: function( event, element, args ) {',
'        $x_Show("B_HIDE");',
'        $x_Hide("B_SHOW");',
'        let allCheckboxes = document.getElementsByName(args.cb);',
'        allCheckboxes.forEach( (e) => {',
'            // console.log(e);',
'            $x_Show(e);',
'        });',
'    }',
'},',
'{',
'    // hide all checkboxes except top 2.',
'    name: "hide-except",',
'    action: function( event, element, args ) {',
'        $x_Hide("B_HIDE");',
'        $x_Show("B_SHOW");',
'        let i = 0;',
'        let allCheckboxes = document.getElementsByName(args.cb);',
'        allCheckboxes.forEach( (e) => {',
'            if ( ++i > TOP_N ) {',
'                // console.log(e);',
'                $x_Hide(e);',
'            }',
'        });',
'    }',
'}',
']);',
unistr('// \6700\521D\306F\975E\8868\793A\3002'),
'apex.actions.invoke("hide-except", null, null, {cb:"P1_CB"});'))
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221116060650'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9216392629646458)
,p_plug_name=>unistr('\30C1\30A7\30C3\30AF\30DC\30C3\30AF\30B9\306E\8868\793A\5236\5FA1')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(9074332167646342)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85451640419237032)
,p_plug_name=>unistr('\30C6\30B9\30C8')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(9107342086646359)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85452226871237038)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(85451640419237032)
,p_button_name=>'B_SHOW'
,p_button_static_id=>'B_SHOW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(9180225112646401)
,p_button_image_alt=>unistr('\3059\3079\3066\8868\793A')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$show-all?cb=P1_CB"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85452313729237039)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(85451640419237032)
,p_button_name=>'B_HIDE'
,p_button_static_id=>'B_HIDE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(9180225112646401)
,p_button_image_alt=>unistr('\5C11\306A\304F\8868\793A')
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$hide-except?cb=P1_CB"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85451547523237031)
,p_name=>'P1_CB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(85451640419237032)
,p_prompt=>unistr('\30C1\30A7\30C3\30AF\30DC\30C3\30AF\30B9')
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:D1;R1,D2;R2,D3;R3,D4;R4,D5;D5'
,p_colspan=>2
,p_field_template=>wwv_flow_imp.id(9177769072646398)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_imp.component_end;
end;
/
