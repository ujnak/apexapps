prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Blob handling'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11398683095153039)
,p_name=>'Collection'
,p_template=>4072358936313175081
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    seq_id,',
'    c001,',
'    substr(clob001,1,60) clob001,',
'    dbms_lob.getlength(blob001) blob001',
'from apex_collections',
'where collection_name = :P1_COLLECTION_NAME'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11398757473153040)
,p_query_column_id=>1
,p_column_alias=>'SEQ_ID'
,p_column_display_sequence=>10
,p_column_heading=>'Seq Id'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11398857546153041)
,p_query_column_id=>2
,p_column_alias=>'C001'
,p_column_display_sequence=>20
,p_column_heading=>'C001'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11398908550153042)
,p_query_column_id=>3
,p_column_alias=>'CLOB001'
,p_column_display_sequence=>30
,p_column_heading=>'Clob001'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11399050382153043)
,p_query_column_id=>4
,p_column_alias=>'BLOB001'
,p_column_display_sequence=>40
,p_column_heading=>'Blob001'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11614624771748692)
,p_plug_name=>'Blob handling'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11396924438153022)
,p_button_sequence=>30
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11396831746153021)
,p_name=>'P1_FILE'
,p_item_sequence=>20
,p_prompt=>'File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'display_as', 'INLINE',
  'purge_file_at', 'REQUEST',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11398437324153037)
,p_name=>'P1_COLLECTION_NAME'
,p_item_sequence=>10
,p_item_default=>'BASE64'
,p_prompt=>'Collection Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11397906413153032)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Initialize'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_COLLECTION'
,p_attribute_04=>'CREATE_OR_TRUNCATE_COLLECTION'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(11396924438153022)
,p_internal_uid=>11397906413153032
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(11398029487153033)
,p_page_process_id=>wwv_flow_imp.id(11397906413153032)
,p_page_id=>1
,p_name=>'p_collection_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'STATIC'
,p_value=>'BASE64'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11398100337153034)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BLOB2BASE64_PLSQL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_THIS_PROCESS_NAME constant varchar2(80) := ''BLOB2BASE64_PLSQL'';',
'    l_blob   blob;',
'    l_base64 clob;',
'begin',
'    /*',
unistr('     * \30A2\30C3\30D7\30ED\30FC\30C9\3055\308C\305F\30D5\30A1\30A4\30EB\3092BLOB\3068\3057\3066\53D6\308A\51FA\3059\3002'),
'     */',
'    select blob_content into l_blob from apex_application_temp_files',
'    where name = :P1_FILE;',
'    /*',
unistr('     * PL/SQL\306B\3088\308BBLOB\304B\3089BASE64\3067\30A8\30F3\30B3\30FC\30C9\3057\305FCLOB\3078\306E\5909\63DB\306B\306F'),
unistr('     * APEX_WEB_SERVICE.BLOB2CLOBBASE64\3092\547C\3073\51FA\3059\3002'),
'     */',
'    l_base64 := apex_web_service.blob2clobbase64(l_blob,''N'',''N'');',
'    /*',
unistr('     * \7D50\679C\3092APEX\30B3\30EC\30AF\30B7\30E7\30F3\306BCLOB\3068\3057\3066\4FDD\5B58\3059\308B\3002'),
'     */',
'    apex_collection.add_member(',
'        p_collection_name => :P1_COLLECTION_NAME',
'        ,p_c001           => C_THIS_PROCESS_NAME',
'        ,p_clob001        => l_base64',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(11396924438153022)
,p_internal_uid=>11398100337153034
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11398204182153035)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BLOB2BASE64_JS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const {encode: base64encode, decode: base64decode} = await import(''mle-encode-base64'');',
'const C_THIS_PROCESS_NAME = ''BLOB2BASE64_JS'';',
'const collection_name = apex.env.P1_COLLECTION_NAME;',
'',
'/*',
unistr(' * \30A2\30C3\30D7\30ED\30FC\30C9\3055\308C\305F\30D5\30A1\30A4\30EB\3092BLOB\3068\3057\3066\53D6\308A\51FA\3059\3002'),
' */',
'const name = apex.env.P1_FILE;',
'const result = apex.conn.execute(',
'    `select blob_content from apex_application_temp_files where name = :name`,',
'    {',
'        name: {',
'            type: oracledb.DB_TYPE_VARCHAR,',
'            dir: oracledb.BIND_IN,',
'            val: name',
'        }',
'    },',
'    {',
'        fetchInfo: {',
'            "BLOB_CONTENT": {',
'                type: oracledb.ORACLE_BLOB',
'            }',
'        }',
'    }',
');',
'if (result.rows.length === 0) {',
'    throw new Error(`No data found for name ${name}`);',
'}',
'else',
'{',
unistr('    // \691C\7D22\7D50\679C\306F\5FC5\305A\FF11\884C\306E\307F\3002'),
'    for (let row of result.rows) {',
'        /*',
unistr('         * JavaScript\306B\3088\308BBLOB\304B\3089BASE64\3067\30A8\30F3\30B3\30FC\30C9\3057\305FCLOB\3078\306E\5909\63DB\306F'),
unistr('         * \30E2\30B8\30E5\30FC\30EBmle-encode-base64\306B\542B\307E\308C\3066\3044\308Bencode\3092\547C\3073\51FA\3059\3002'),
'         */',
'        const blob = row.BLOB_CONTENT;        ',
'        const base64string = base64encode(blob.getData());',
'        /*',
unistr('         * \7D50\679C\3092APEX\30B3\30EC\30AF\30B7\30E7\30F3\306BCLOB\3068\3057\3066\4FDD\5B58\3059\308B\3002'),
'         */',
'        apex.conn.execute(',
'            `begin apex_collection.add_member(p_collection_name => :col, p_c001 => :c001, p_clob001 => :clob001 ); end;`,',
'            {',
'                col: {',
'                    type: oracledb.DB_TYPE_VARCHAR,',
'                    dir: oracledb.BIND_IN,',
'                    val: collection_name',
'                },',
'                c001: {',
'                    type: oracledb.DB_TYPE_VARCHAR,',
'                    dir: oracledb.BIND_IN,',
'                    val: C_THIS_PROCESS_NAME',
'                },',
'                clob001: {',
'                    type: oracledb.DB_TYPE_CLOB,',
'                    dir: oracledb.BIND_IN,',
'                    val: base64string',
'                }',
'            }',
'        );',
'    };',
'};'))
,p_process_clob_language=>'JAVASCRIPT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(11396924438153022)
,p_internal_uid=>11398204182153035
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11398399057153036)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BASE642BLOB_PLSQL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_THIS_PROCESS_NAME   constant varchar2(80) := ''BASE642BLOB_PLSQL'';',
'    C_SOURCE_PROCESS_NAME constant varchar2(80) := ''BLOB2BASE64_JS'';',
'    l_blob    blob;',
'    l_base64  clob;',
'begin',
'    /*',
unistr('     * JavaScript\3067Base64\306B\5909\63DB\3057\305FCLOB\3092\53D6\308A\51FA\3059\3002'),
'     */',
'    select clob001 into l_base64 from apex_collections ',
'    where collection_name = :P1_COLLECTION_NAME and C001 = C_SOURCE_PROCESS_NAME;',
'    /*',
unistr('     * PL/SQL\306B\3088\308BBASE64\3067\30A8\30F3\30B3\30FC\30C9\3057\305FCLOB\304B\3089BLOB\3078\306E\5909\63DB\306B\306F'),
unistr('     * APEX_WEB_SERVICE.CLOBBASE642BLOB\3092\547C\3073\51FA\3059\3002'),
'     */',
'    l_blob := apex_web_service.clobbase642blob(l_base64);',
'    /*',
unistr('     * \7D50\679C\3092APEX\30B3\30EC\30AF\30B7\30E7\30F3\306BBLOB\3068\3057\3066\4FDD\5B58\3059\308B\3002'),
'     */    ',
'    apex_collection.add_member(',
'        p_collection_name => :P1_COLLECTION_NAME',
'        ,p_c001           => C_THIS_PROCESS_NAME',
'        ,p_blob001        => l_blob',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(11396924438153022)
,p_internal_uid=>11398399057153036
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11398513607153038)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BASE642BLOB_JS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const {encode: base64encode, decode: base64decode} = await import(''mle-encode-base64'');',
'const C_THIS_PROCESS_NAME   = ''BLOB2BASE64_JS'';',
'const C_SOURCE_PROCESS_NAME = ''BLOB2BASE64_PLSQL'';',
'const collection_name = apex.env.P1_COLLECTION_NAME;',
'',
'/*',
unistr(' * PL/SQL\3067Base64\306B\5909\63DB\3057\305FCLOB\3092\53D6\308A\51FA\3059\3002'),
' */',
'const name = apex.env.P1_FILE;',
'const result = apex.conn.execute(',
'    `select clob001 from apex_collections where collection_name = :collection_name and c001 = :c001`,',
'    {',
'        collection_name: {',
'            type: oracledb.DB_TYPE_VARCHAR,',
'            dir: oracledb.BIND_IN,',
'            val: collection_name',
'        },',
'        c001: {',
'            type: oracledb.DB_TYPE_VARCHAR,',
'            dir: oracledb.BIND_IN,',
'            val: C_SOURCE_PROCESS_NAME',
'        }',
'    },',
'    {',
'        fetchInfo: {',
'            "CLOB001": {',
'                type: oracledb.ORACLE_CLOB',
'            }',
'        }',
'    }',
');',
'if (result.rows.length === 0) {',
'    throw new Error(`No data found for c001 ${c001}`);',
'}',
'else',
'{',
unistr('    // \691C\7D22\7D50\679C\306F\5FC5\305A\FF11\884C\306E\307F\3002'),
'    for (let row of result.rows) {',
'        /*',
unistr('         * JavaScript\306B\3088\308BBASE64\3067\30A8\30F3\30B3\30FC\30C9\3057\305FCLOB\304B\3089BLOB\3078\306E\5909\63DB\306F'),
unistr('         * \30E2\30B8\30E5\30FC\30EBmle-encode-base64\306B\542B\307E\308C\3066\3044\308Bdecode\3092\547C\3073\51FA\3059\3002'),
'         */',
'        const base64 = row.CLOB001;',
'        const bytes = base64decode(base64.getData());',
'        const blob = OracleBlob.createTemporary(false);',
'        blob.open(OracleBlob.LOB_READWRITE);',
'        blob.write(1, bytes);',
'        /*',
unistr('         * \7D50\679C\3092APEX\30B3\30EC\30AF\30B7\30E7\30F3\306BBLOB\3068\3057\3066\4FDD\5B58\3059\308B\3002'),
'         */',
'        apex.conn.execute(',
'            `begin apex_collection.add_member(p_collection_name => :col, p_c001 => :c001, p_blob001 => :blob001 ); end;`,',
'            {',
'                col: {',
'                    type: oracledb.DB_TYPE_VARCHAR,',
'                    dir: oracledb.BIND_IN,',
'                    val: collection_name',
'                },',
'                c001: {',
'                    type: oracledb.DB_TYPE_VARCHAR,',
'                    dir: oracledb.BIND_IN,',
'                    val: C_THIS_PROCESS_NAME',
'                },',
'                blob001: {',
'                    type: oracledb.DB_TYPE_BLOB,',
'                    dir: oracledb.BIND_IN,',
'                    val: blob',
'                }',
'            }',
'        );',
'        blob.close();',
'        blob.freeTemporary();',
'    };',
'};'))
,p_process_clob_language=>'JAVASCRIPT'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(11396924438153022)
,p_internal_uid=>11398513607153038
);
wwv_flow_imp.component_end;
end;
/
