prompt --application/plugin_settings
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>315
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(28908408867133728)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'Y'
,p_version_scn=>40536963572837
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(28908770634133731)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attribute_01=>'fa-star'
,p_attribute_04=>'#VALUE#'
,p_version_scn=>40536963572878
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(28909051015133732)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_version_scn=>40536963572888
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(28909332972133732)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_APEX'
,p_attribute_01=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_02=>'VISIBLE'
,p_attribute_03=>'15'
,p_attribute_04=>'FOCUS'
,p_version_scn=>40536963572892
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(28909692245133732)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attribute_01=>'Y'
,p_attribute_03=>'N'
,p_attribute_05=>'SWITCH_CB'
,p_version_scn=>40536963572892
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(28909997235133733)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attribute_01=>'IG'
,p_version_scn=>40536963572892
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(28910250506133733)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_ADFBC'
,p_version_scn=>40536963572897
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(28910519616133733)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_MAP_REGION'
,p_attribute_01=>'Y'
,p_version_scn=>40536963572903
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(28910857077133733)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attribute_01=>'FULL'
,p_attribute_02=>'POPUP'
,p_version_scn=>40536963572911
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(28911119152133734)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_GEOCODED_ADDRESS'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_attribute_02=>'N'
,p_attribute_03=>'POPUP:ITEM'
,p_attribute_04=>'default'
,p_attribute_06=>'LIST'
,p_version_scn=>40536963572916
);
wwv_flow_imp.component_end;
end;
/
