prompt --application/shared_components/security/authentications/oracle_iam
begin
--   Manifest
--     AUTHENTICATION: Oracle IAM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19591634751348691
,p_default_application_id=>102
,p_default_id_offset=>25756861992616856
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(100010089810480975)
,p_name=>'Oracle IAM'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(99184356078075113)
,p_attribute_02=>'OPENID_CONNECT'
,p_attribute_03=>'https://*****/.well-known/openid-configuration'
,p_attribute_07=>'profile,email,api://ords/myordsapp'
,p_attribute_09=>'#email# '
,p_attribute_11=>'N'
,p_attribute_13=>'Y'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure post_auth is',
'begin',
'  :G_USER_INFO := dump_signon_response;',
'end post_auth;'))
,p_invalid_session_type=>'LOGIN'
,p_logout_url=>'f?p=ORDS-JWT-TEST:LOGOUT:0::NO:::'
,p_post_auth_process=>'post_auth'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>45899068976273
);
wwv_flow_imp.component_end;
end;
/
