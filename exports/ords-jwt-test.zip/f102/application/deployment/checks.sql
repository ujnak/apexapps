prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19591634751348691
,p_default_application_id=>102
,p_default_id_offset=>24552872637583426
,p_default_owner=>'WKSP_APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
