prompt --application/deployment/install/install_import_jwt_decode_to_mle_sql
begin
--   Manifest
--     INSTALL: INSTALL-import_jwt_decode_to_mle.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19591634751348691
,p_default_application_id=>102
,p_default_id_offset=>24765285286625372
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(221659669882666634)
,p_install_id=>wwv_flow_imp.id(246122223788635843)
,p_name=>'import_jwt_decode_to_mle.sql'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_condition_type=>'EXPRESSION'
,p_condition=>'DBMS_DB_VERSION.VERSION >= 23'
,p_condition2=>'PLSQL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' * Create the MLE module MOD_JWT_DECODE from jwt-decode.',
' */',
'create or replace mle module mod_jwt_decode',
'language javascript using clob (',
'    select apex_web_service.make_rest_request(',
'        p_url => ''https://cdn.jsdelivr.net/npm/jwt-decode@latest/+esm''',
'        ,p_http_method => ''GET''',
'    )',
')',
'/',
'',
'/*',
' * Create the MLE module MOD_CORE_JS from core-js.',
' */',
'create or replace mle module mod_core_js',
'language javascript using clob (',
'    select apex_web_service.make_rest_request(',
'        p_url => ''https://cdn.jsdelivr.net/npm/core-js@latest/+esm''',
'        ,p_http_method => ''GET''',
'    )',
')',
'/',
'',
'/*',
' * Create the MLE module MOD_PARSE_JWT, which exports the function parseJWT.',
' */',
'create or replace mle module mod_parse_jwt',
'language javascript using clob (',
'    select q''~',
'import * as decode from "mod_core_js";',
'import * as e from "mod_jwt_decode";',
'',
'export function parseJWT(jwt) {',
'    const decoded = e.jwtDecode(jwt);',
'    return JSON.stringify(decoded, null, 2);',
'}',
'~''',
')',
'/',
'',
'/*',
' * Create MLE environment JWTENV to import all created modules.',
' */',
'create or replace mle env jwtenv',
'imports (',
'    ''mod_core_js''    module MOD_CORE_JS,',
'    ''mod_jwt_decode'' module MOD_JWT_DECODE,',
'    ''mod_parse_jwt''  module MOD_PARSE_JWT',
')',
'/',
'',
'/*',
' * Create parseJWT as the PL/SQL function PARSE_JWT.',
' */',
'create or replace function parse_jwt(',
'    p_jwt in varchar2',
')',
'return varchar2',
'as mle module MOD_PARSE_JWT env JWTENV',
'signature ''parseJWT(string)'';',
'/',
'',
'/*',
unistr('\3000\3000Sample code for retry.'),
'drop function parse_jwt;',
'drop mle env jwtenv;',
'drop mle module mod_parse_jwt;',
'drop mle module mod_jwt_decode;',
'drop mle module mod_core_js;',
'*/'))
);
wwv_flow_imp.component_end;
end;
/
