prompt --application/deployment/buildoptions
begin
--   Manifest
--     INSTALL BUILD OPTIONS: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.12'
,p_default_workspace_id=>5472329228451884
,p_default_application_id=>102
,p_default_id_offset=>9238217402757035
,p_default_owner=>'WKSP_APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
