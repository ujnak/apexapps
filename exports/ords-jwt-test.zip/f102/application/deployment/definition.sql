prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19591634751348691
,p_default_application_id=>102
,p_default_id_offset=>24735934799685923
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(196610846496166493)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    execute immediate ''drop function parse_jwt'';',
'exception',
'    when others then',
'        null;',
'end;',
'/',
'begin',
'    execute immediate ''drop mle env jwtenv'';',
'exception',
'    when others then',
'        null;',
'end;',
'/',
'begin',
'    execute immediate ''drop mle module mod_parse_jwt'';',
'exception',
'    when others then',
'        null;',
'end;',
'/',
'begin',
'    execute immediate ''drop mle module mod_jwt_decode'';',
'exception',
'    when others then',
'        null;',
'end;',
'/',
'begin',
'    execute immediate ''drop mle module mod_core_js'';',
'exception',
'    when others then',
'        null;',
'end;',
'/',
'begin',
'    execute immediate ''drop function dump_signon_response'';',
'exception',
'    when others then',
'        null;',
'end;',
'/',
'begin',
'    execute immediate ''drop function dump_signon_response'';',
'exception',
'    when others then',
'        null;',
'end;',
'/',
'begin',
'    ords.delete_privilege(',
'        p_name => ''myordsapp''',
'    );',
'    ords.delete_module(',
'        p_module_name => ''print''',
'    );',
'exception',
'    when others then',
'        null;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
