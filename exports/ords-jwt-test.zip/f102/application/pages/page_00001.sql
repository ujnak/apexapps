prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19591634751348691
,p_default_application_id=>102
,p_default_id_offset=>25756861992616856
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'ORDS JWT Test'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(298830354491877183)
,p_plug_name=>'REST API Response'
,p_region_template_options=>'#DEFAULT#:i-h320:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_static_id   varchar2(80);',
'    l_alias       varchar2(128);',
'    l_rest_url    varchar2(32767);',
'    l_wallet_path varchar2(128);',
'    l_response    clob;',
'begin',
'    /*',
'     * Get credential static id of web credentials of current authentication scheme',
'     * into l_static_id.',
'     */',
'    select c.static_id into l_static_id',
'    from APEX_APPLICATION_AUTH a join APEX_WORKSPACE_CREDENTIALS c on a.attribute_01 = c.credential_id',
'    where a.application_id = :APP_ID and a.is_current_authentication = ''Y'';',
'    apex_debug.info(''Web Credential Selected: %s'', l_static_id);',
'    /*',
'     * Construct complete URL of REST service print/env.',
'     */',
'    select pattern into l_alias from user_ords_schemas ',
'    where parsing_schema = sys_context(''USERENV'',''CURRENT_USER'');',
'    l_rest_url := apex_util.host_url(''APEX_PATH'') || l_alias || ''/print/env'';',
'    apex_debug.info(''ORDS REST API URL: %s'', l_rest_url);',
'    /*',
'     * Wallet Path: Should be set as a value of Substitution String G_WALLET_PATH',
'     * in Application Definitions.',
'     */',
'    l_wallet_path := :G_WALLET_PATH;',
'    apex_debug.info(''Wallet Path: %s'', l_wallet_path);',
'    /*',
'     * Call ORDS REST API .../print/env',
'     */',
'    apex_web_service.clear_request_headers();',
'    l_response := apex_web_service.make_rest_request(',
'        p_url                   => l_rest_url',
'        ,p_http_method          => ''GET''',
'        ,p_credential_static_id => l_static_id',
'        ,p_wallet_path          => l_wallet_path',
'    );',
'    return l_response;',
'exception',
'    when others then',
'        l_response := SQLERRM;',
'        return l_response;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(300730264515373040)
,p_plug_name=>'ORDS JWT Test'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(298830540255877185)
,p_name=>'P1_USER_INFO'
,p_data_type=>'CLOB'
,p_item_sequence=>10
,p_prompt=>'User Info'
,p_source=>'G_USER_INFO'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>20
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
