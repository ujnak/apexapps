prompt --workspace/credentials/oracle_iam_jwt_test
begin
--   Manifest
--     CREDENTIAL: Oracle IAM JWT Test
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19591634751348691
,p_default_application_id=>102
,p_default_id_offset=>24746092005843978
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(49487806043235886)
,p_name=>'Oracle IAM JWT Test'
,p_static_id=>'ORACLE_IAM_JWT_TEST'
,p_authentication_type=>'OAUTH2_CLIENT_CREDENTIALS'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
