prompt --application/shared_components/files/observale_json
begin
--   Manifest
--     APP STATIC FILES: 139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>139
,p_default_id_offset=>35133620179025240
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '7B0A2020202022696D706F727473223A207B0A20202020202020202240406F627365727661626C6568712F706C6F74223A202268747470733A2F2F63646E2E6A7364656C6976722E6E65742F6E706D2F406F627365727661626C6568712F706C6F742F2B';
wwv_flow_imp.g_varchar2_table(2) := '65736D220A202020207D0A7D0A';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(36802260566588533)
,p_file_name=>'observale.json'
,p_mime_type=>'application/json'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
