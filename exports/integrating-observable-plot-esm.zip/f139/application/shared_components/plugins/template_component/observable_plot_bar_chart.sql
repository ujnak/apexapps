prompt --application/shared_components/plugins/template_component/observable_plot_bar_chart
begin
--   Manifest
--     PLUGIN: OBSERVABLE_PLOT_BAR_CHART
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>139
,p_default_id_offset=>35133620179025240
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(35263644597409408)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '')
,p_name=>'OBSERVABLE_PLOT_BAR_CHART'
,p_display_name=>'Observable Plot Bar Chart'
,p_supported_component_types=>'PARTIAL'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','OBSERVABLE_PLOT_BAR_CHART'),'')
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if ?VALUE/}',
'<div id="#APEX$DOM_ID#"><div>',
'<script type="module">',
'    import * as observablehq from ''observablehq'';',
'',
'    /* plot chart */',
'    let config = {',
'        label: null,',
'        marks: []',
'    };',
'',
'    // define plot area.',
'    config.width = Number("#WIDTH#");',
'    const height = "#HEIGHT#";',
'    if ( height ) {',
'        config.height = Number(height);',
'    };',
'    const marginTop = "#MARGIN_TOP#";',
'    if ( marginTop ) {',
'        config.marginTop = Number(marginTop);',
'    };',
'    const marginRight = "#MARGIN_RIGHT#";',
'    if ( marginRight ) {',
'        config.marginRight = Number(marginRight);',
'    };',
'    const marginLeft = "#MARGIN_LEFT#";',
'    if ( marginLeft ) {',
'        config.marginLeft = Number(marginLeft);',
'    };',
'    const marginBottom = "#MARGIN_BOTTOM#";',
'    if ( marginBottom ) {',
'        config.marginBottom = Number(marginBottom);',
'    };',
'',
'    // define bar.',
'    const groups = "#GROUPS#";',
'    apex.debug.info(groups);',
'    const xy = groups.split(",");',
'    let bar = {',
'        x: xy[0].trim(),',
'        y: xy[1].trim()',
'    };',
'    const color = "#COLOR#";',
'    if ( color ) {',
'        bar.fill = color;',
'    };',
'',
'    // data',
'    const data = JSON.parse(''#VALUE#'');',
'',
'    const orientation = "#ORIENTATION#";',
'    if ( orientation === null || orientation === "horizontal" ) {',
'        config.marks.push(',
'            observablehq.barX(data, bar)',
'        );',
'    }',
'    else',
'    {',
'        config.marks.push(',
'            observablehq.barY(data, bar)',
'        );',
'    };',
'',
'    /* draw chart */',
'    apex.debug.info(config);',
'    const plot = observablehq.plot(config);',
'    document.getElementById("#APEX$DOM_ID#").appendChild(plot);',
'</script>',
'{endif/}'))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>1
,p_standard_attributes=>'REGION_TEMPLATE'
,p_substitute_attributes=>true
,p_version_scn=>41128892159548
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_files_version=>55
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35263947300409422)
,p_plugin_id=>wwv_flow_imp.id(35263644597409408)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>30
,p_static_id=>'COLOR'
,p_prompt=>'Color'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_escape_mode=>'RAW'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35264749305409424)
,p_plugin_id=>wwv_flow_imp.id(35263644597409408)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>110
,p_static_id=>'HEIGHT'
,p_prompt=>'Height'
,p_attribute_type=>'INTEGER'
,p_is_required=>false
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35265105969409425)
,p_plugin_id=>wwv_flow_imp.id(35263644597409408)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>150
,p_static_id=>'MARGIN_BOTTOM'
,p_prompt=>'Margin Bottom'
,p_attribute_type=>'INTEGER'
,p_is_required=>false
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35265591075409426)
,p_plugin_id=>wwv_flow_imp.id(35263644597409408)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>140
,p_static_id=>'MARGIN_LEFT'
,p_prompt=>'Margin Left'
,p_attribute_type=>'INTEGER'
,p_is_required=>false
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35265906304409427)
,p_plugin_id=>wwv_flow_imp.id(35263644597409408)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>6
,p_display_sequence=>130
,p_static_id=>'MARGIN_RIGHT'
,p_prompt=>'Margin Right'
,p_attribute_type=>'INTEGER'
,p_is_required=>false
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35266316575409427)
,p_plugin_id=>wwv_flow_imp.id(35263644597409408)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>7
,p_display_sequence=>120
,p_static_id=>'MARGIN_TOP'
,p_prompt=>'Margin Top'
,p_attribute_type=>'INTEGER'
,p_is_required=>false
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35266764235409428)
,p_plugin_id=>wwv_flow_imp.id(35263644597409408)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>8
,p_display_sequence=>40
,p_static_id=>'ORIENTATION'
,p_prompt=>'Orientation'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>false
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35270332751436483)
,p_plugin_attribute_id=>wwv_flow_imp.id(35266764235409428)
,p_display_sequence=>10
,p_display_value=>'horizontal'
,p_return_value=>'horizontal'
);
wwv_flow_imp_shared.create_plugin_attr_value(
 p_id=>wwv_flow_imp.id(35270726625437283)
,p_plugin_attribute_id=>wwv_flow_imp.id(35266764235409428)
,p_display_sequence=>20
,p_display_value=>'vertical'
,p_return_value=>'vertical'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35267185940409429)
,p_plugin_id=>wwv_flow_imp.id(35263644597409408)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>9
,p_display_sequence=>20
,p_static_id=>'VALUE'
,p_prompt=>'Value'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>true
,p_escape_mode=>'RAW'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35267558132409430)
,p_plugin_id=>wwv_flow_imp.id(35263644597409408)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>10
,p_display_sequence=>100
,p_static_id=>'WIDTH'
,p_prompt=>'Width'
,p_attribute_type=>'INTEGER'
,p_is_required=>true
,p_escape_mode=>'ATTR'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(35302022980807819)
,p_plugin_id=>wwv_flow_imp.id(35263644597409408)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>11
,p_display_sequence=>10
,p_static_id=>'GROUPS'
,p_prompt=>'Groups'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_escape_mode=>'RAW'
,p_is_translatable=>false
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
