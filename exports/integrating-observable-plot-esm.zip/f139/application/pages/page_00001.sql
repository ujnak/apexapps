prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>139
,p_default_id_offset=>35133620179025240
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Integrating Observable Plot'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="importmap">',
'    {',
'        "imports": {',
'            "observablehq": "https://cdn.jsdelivr.net/npm/@observablehq/plot/+esm"',
'        }',
'    }',
'</script>'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134690038528206586)
,p_plug_name=>'Observable Plot'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(135403404416335929)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="myChart""></div>',
'<script type="module">',
'    import * as observablehq from ''observablehq'';',
'',
'    // "apex.items.ITEM_NAME.value" is not available inside module.',
'    // const value = apex.items.P1_VALUE.value; ',
'    const value = apex.item("P1_VALUE").getValue();',
'    var data = JSON.parse(value);',
'',
'    const plot = observablehq.plot({',
'        label: null,',
'        width: 400,',
'        marginLeft: 60,',
'        marks: [',
'            observablehq.barX(data, {  x: "sal", y: "ename", fill: "#309fdb" } )',
'        ]',
'    });',
'',
'    const div = document.getElementById("myChart");',
'    div.append(plot);',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(135601422840336630)
,p_plug_name=>'Integrating Observable Plot'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(135380137275335880)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134689714908206583)
,p_name=>'P1_VALUE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(134689898468206585)
,p_computation_sequence=>20
,p_computation_item=>'P1_VALUE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    json_arrayagg(',
'        json_object(',
'            ''ename'' value ename,',
'            ''sal'' value sal',
'        )',
'        order by empno asc',
'    )',
'from emp where deptno = 10'))
);
wwv_flow_imp.component_end;
end;
/
