prompt --workspace/credentials/google_custom_search_api_key
begin
--   Manifest
--     CREDENTIAL: Google Custom Search API Key
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>133
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(42210102265031920)
,p_name=>'Google Custom Search API Key'
,p_static_id=>'GOOGLE_SEARCH_API_KEY'
,p_authentication_type=>'HTTP_QUERY_STRING'
,p_valid_for_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://customsearch.googleapis.com/customsearch/v1',
''))
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
