prompt --workspace/remote_servers/customsearch_googleapis_com
begin
--   Manifest
--     REMOTE SERVER: customsearch-googleapis-com
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>133
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(42429761900220628)
,p_name=>'customsearch-googleapis-com'
,p_static_id=>'customsearch_googleapis_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('customsearch_googleapis_com'),'https://customsearch.googleapis.com/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('customsearch_googleapis_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('customsearch_googleapis_com'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('customsearch_googleapis_com'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('customsearch_googleapis_com'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
