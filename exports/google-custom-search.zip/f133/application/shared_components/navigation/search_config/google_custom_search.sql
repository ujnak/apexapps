prompt --application/shared_components/navigation/search_config/google_custom_search
begin
--   Manifest
--     SEARCH CONFIG: Google Custom Search
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>133
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(42441944346549740)
,p_label=>'Google Custom Search'
,p_static_id=>'google_custom_search'
,p_search_type=>'SIMPLE'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(42433168366220638)
,p_function_body_language=>'PLSQL'
,p_return_max_results=>100
,p_pk_column_name=>'LINK'
,p_title_column_name=>'TITLE'
,p_description_column_name=>'SNIPPET'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-file-search'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(42442213438549743)
,p_web_src_param_id=>wwv_flow_imp.id(42434111962220642)
,p_search_config_id=>wwv_flow_imp.id(42441944346549740)
,p_value_type=>'ITEM'
,p_value=>'G_ENGINE_ID'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(42442415087549743)
,p_web_src_param_id=>wwv_flow_imp.id(42433751754220642)
,p_search_config_id=>wwv_flow_imp.id(42441944346549740)
,p_value_type=>'STATIC'
);
wwv_flow_imp.component_end;
end;
/
