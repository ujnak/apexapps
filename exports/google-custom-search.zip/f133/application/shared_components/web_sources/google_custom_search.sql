prompt --application/shared_components/web_sources/google_custom_search
begin
--   Manifest
--     WEB SOURCE: Google Custom Search
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>133
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(42433168366220638)
,p_name=>'Google Custom Search'
,p_static_id=>'Google_Custom_Search'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(42429935436220630)
,p_remote_server_id=>wwv_flow_imp.id(42429761900220628)
,p_url_path_prefix=>'/customsearch/v1'
,p_credential_id=>wwv_flow_imp.id(42210102265031920)
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(42433751754220642)
,p_web_src_module_id=>wwv_flow_imp.id(42433168366220638)
,p_name=>'q'
,p_param_type=>'QUERY_STRING'
,p_is_query_param=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(42434111962220642)
,p_web_src_module_id=>wwv_flow_imp.id(42433168366220638)
,p_name=>'cx'
,p_param_type=>'QUERY_STRING'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(42433391215220639)
,p_web_src_module_id=>wwv_flow_imp.id(42433168366220638)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
