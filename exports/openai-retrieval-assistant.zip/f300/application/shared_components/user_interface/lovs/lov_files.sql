prompt --application/shared_components/user_interface/lovs/lov_files
begin
--   Manifest
--     LOV_FILES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>300
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13548153858551703)
,p_lov_name=>'LOV_FILES'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(13439782037323062)
,p_return_column_name=>'ID'
,p_display_column_name=>'FILENAME'
,p_default_sort_column_name=>'FILENAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
