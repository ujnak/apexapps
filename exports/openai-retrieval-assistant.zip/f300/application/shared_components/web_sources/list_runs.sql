prompt --application/shared_components/web_sources/list_runs
begin
--   Manifest
--     WEB SOURCE: List runs
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>300
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(13444746612327926)
,p_name=>'List runs'
,p_static_id=>'List_runs'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(13440371048327923)
,p_remote_server_id=>wwv_flow_imp.id(128679627188677162)
,p_url_path_prefix=>'v1/threads/:thread_id/runs'
,p_credential_id=>wwv_flow_imp.id(59103911961121450)
,p_pass_ecid=>true
,p_catalog_internal_name=>'OPENAI_ASSISTANTS_API'
,p_catalog_service_name=>'List runs'
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(13445389419327926)
,p_web_src_module_id=>wwv_flow_imp.id(13444746612327926)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(13445713464327926)
,p_web_src_module_id=>wwv_flow_imp.id(13444746612327926)
,p_name=>'OpenAI-Beta'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'assistants=v1'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(13446160507327927)
,p_web_src_module_id=>wwv_flow_imp.id(13444746612327926)
,p_name=>'thread_id'
,p_param_type=>'URL_PATTERN'
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(13444966484327926)
,p_web_src_module_id=>wwv_flow_imp.id(13444746612327926)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
