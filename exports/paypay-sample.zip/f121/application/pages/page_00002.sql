prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>121
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Checkout'
,p_alias=>'CHECKOUT'
,p_step_title=>'Checkout'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230301025356'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(57739973980572633)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(57639386892534083)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(57524282114533991)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(57701432181534122)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54894349385513337)
,p_button_sequence=>30
,p_button_name=>'CHECKOUT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(57699801355534121)
,p_button_image_alt=>'Checkout'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54894154586513335)
,p_name=>'P2_AMOUNT'
,p_item_sequence=>10
,p_prompt=>'Amount'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(57697385575534119)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'100'
,p_attribute_02=>'10000'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54894254903513336)
,p_name=>'P2_ORDER_DESCRIPTION'
,p_item_sequence=>20
,p_prompt=>'Order Description'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(57697385575534119)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54894431021513338)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PayPay Checkout'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request json_object_t;',
'    l_request_string varchar2(32767); ',
'    l_apikey        varchar2(64);',
'    l_apikey_secret varchar2(128);',
'    l_content_type  varchar2(20)  := ''application/json'';',
'    l_merchant_payment_id varchar2(64);',
'    -- Sandbox Server',
'    l_server varchar2(64) := ''https://stg-api.sandbox.paypay.ne.jp'';',
'    l_request_url varchar2(32) := ''/v2/codes'';',
'    l_header varchar2(200);',
'    l_amount json_object_t;',
'    l_redirect_url varchar2(400);',
'    l_user_agent   varchar2(400);',
'    --',
'    l_response_clob clob;',
'    l_response json_object_t;',
'    l_data     json_object_t;',
'    l_paypay_url varchar2(400);',
'begin',
unistr('    /* API\30AD\30FC\3068API\30AD\30FC\30FB\30B7\30FC\30AF\30EC\30C3\30C8\3092\53D6\5F97\3059\308B\3002 */'),
'    l_apikey := v(''G_PAYPAY_APIKEY'');',
'    l_apikey_secret := v(''G_PAYPAY_APIKEY_SECRET'');',
'    /*',
unistr('     * PayPay\306B\9001\4FE1\3059\308B\30EA\30AF\30A8\30B9\30C8\3092\4F5C\6210\3059\308B\3002'),
'     */',
'    l_request := json_object_t();',
unistr('    /* merchantPaymentId - \52A0\76DF\5E97\304B\3089\63D0\4F9B\3055\308C\305F\4E00\610F\306E\652F\6255\3044\53D6\5F15ID */'),
'    l_merchant_payment_id := sys_guid();',
'    l_request.put(''merchantPaymentId'', l_merchant_payment_id);',
unistr('    /* amount - \652F\6255\91D1\984D */'),
'    l_amount := json_object_t();',
'    l_amount.put(''amount'', to_number(:P2_AMOUNT));',
'    l_amount.put(''currency'',''JPY'');',
'    l_request.put(''amount'',l_amount);',
unistr('    /* orderDescription - \6CE8\6587\5185\5BB9\306E\8AAC\660E\3002 */'),
'    l_request.put(''orderDescription'', :P2_ORDER_DESCRIPTION);',
unistr('    /* codeType - \5E38\306BORDER_QR */'),
'    l_request.put(''codeType'',''ORDER_QR'');',
unistr('    /* redirectUrl - \652F\6255\3044\5B8C\4E86\5F8C\306B\958B\304F\30DA\30FC\30B8/\30A2\30D7\30EA\306EURL */'),
'    l_redirect_url := apex_util.host_url || apex_page.get_url(',
'        p_page => 1',
'    );',
'    l_request.put(''redirectUrl'', l_redirect_url);',
unistr('    /* redirectType - \3064\306D\306BWEB_LINK */'),
'    l_request.put(''redirectType'',''WEB_LINK'');',
unistr('    /* userAgent  - \30C8\30E9\30F3\30B6\30AF\30B7\30E7\30F3\306E\767A\751F\5143\3067\3042\308BWeb\30D6\30E9\30A6\30B6\30FC\306EUser Agent */'),
'    l_user_agent := owa_util.get_cgi_env(''HTTP_USER_AGENT'');',
'    l_request.put(''userAgent'', l_user_agent);',
'    l_request_string := l_request.to_string();',
'    -- apex_debug.info(l_request_string);',
'',
'    /*',
unistr('     * Create QR Code\306EREST API\3092\767A\884C\3059\308B\3002'),
'     *',
unistr('     * \53C2\7167: https://www.paypay.ne.jp/opa/doc/jp/v1.0/webcashier#tag/%E6%B1%BA%E6%B8%88/operation/createQRCode'),
'     */',
'    l_header := util_paypay_api.generate_hmac_auth_header(',
'        p_request_body => l_request_string',
'        ,p_content_type => l_content_type',
'        ,p_request_url => l_request_url',
'        ,p_http_method => ''POST''',
'        ,p_apikey      => l_apikey',
'        ,p_apikey_secret => l_apikey_secret',
'    );',
'    apex_web_service.set_request_headers(',
'        p_name_01 => ''Content-Type''',
'        ,p_value_01 => l_content_type',
'        ,p_name_02 => ''Authorization''',
'        ,p_value_02 => l_header',
'    );',
'    l_response_clob := apex_web_service.make_rest_request(',
'        p_url => l_server || l_request_url',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_string',
'        ,p_credential_static_id => ''PAYPAY_MERCHANT_ID''',
'    );',
'    -- apex_debug.info(l_response_clob);',
'    if apex_web_service.g_status_code <> 201 then',
'        raise_application_error(-20001, ''ORDER_QR Error = '' || apex_web_service.g_status_code);',
'    end if;',
'',
'    /*',
unistr('     * \30EC\30B9\30DD\30F3\30B9\304B\3089url\3092\53D6\308A\51FA\3057\3001PayPay\306E\6C7A\6E08\753B\9762\306B\9077\79FB\3059\308B\3002'),
'     */',
'    l_response := json_object_t(l_response_clob);',
'    l_data := treat(l_response.get(''data'') as json_object_t);',
'    l_paypay_url := l_data.get_string(''url'');',
'    apex_util.redirect_url(',
'        p_url => l_paypay_url',
'    );',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(54894349385513337)
);
wwv_flow_imp.component_end;
end;
/
