prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>134
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'PayPay Sample'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230301061516'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54895004852513344)
,p_plug_name=>'Get payment details'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(58082207628137237)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \5B8C\4E86\3057\305F\53D6\5F15\306E\72B6\614B\3092\78BA\8A8D\3059\308B\3002'),
' *',
' */',
'declare',
'    l_apikey        varchar2(64);',
'    l_apikey_secret varchar2(128);',
'    l_merchant_payment_id varchar2(64);',
'    -- Sandbox Server',
'    l_server varchar2(64) := ''https://stg-api.sandbox.paypay.ne.jp'';',
'    l_request_url varchar2(80);',
'    l_header varchar2(200);',
'    l_response_clob clob;',
'begin',
unistr('    /* API\30AD\30FC\3068API\30AD\30FC\30FB\30B7\30FC\30AF\30EC\30C3\30C8\3092\53D6\5F97\3059\308B\3002 */'),
'    l_apikey := v(''G_PAYPAY_APIKEY'');',
'    l_apikey_secret := v(''G_PAYPAY_APIKEY_SECRET'');',
'',
'    /*',
unistr('     * Get payment details\306EREST API\3092\767A\884C\3059\308B\3002'),
'     *',
unistr('     * \53C2\7167: https://www.paypay.ne.jp/opa/doc/jp/v1.0/webcashier#tag/%E6%B1%BA%E6%B8%88/operation/getPaymentDetails'),
'     */',
'    l_request_url := ''/v2/codes/payments/'' || :P1_MERCHANT_PAYMENT_ID;',
'    l_header := util_paypay_api.generate_hmac_auth_header(',
'        p_request_url => l_request_url',
'        ,p_http_method => ''GET''',
'        ,p_apikey      => l_apikey',
'        ,p_apikey_secret => l_apikey_secret',
'    );',
'    apex_web_service.clear_request_headers;',
'    apex_web_service.set_request_headers(''Authorization'', l_header, p_reset => false);',
'    l_response_clob := apex_web_service.make_rest_request(',
'        p_url => l_server || l_request_url',
'        ,p_http_method => ''GET''',
'        ,p_credential_static_id => ''PAYPAY_MERCHANT_ID''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise_application_error(-20001, ''GET_PAYMENT_DETAILS Error = '' || apex_web_service.g_status_code);',
'    end if;',
'',
'    /*',
unistr('     * \5FDC\7B54\306EJSON\3092\305D\306E\307E\307E\51FA\529B\3059\308B\3002'),
'     */',
'    return l_response_clob;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P1_MERCHANT_PAYMENT_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(58191149430137310)
,p_plug_name=>'PayPay Sample'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(58049208692137218)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54894982092513343)
,p_name=>'P1_MERCHANT_PAYMENT_ID'
,p_item_sequence=>10
,p_prompt=>'Merchant Payment ID'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(58152610534137278)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
