prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>159
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'APEX_UTIL.HOST_URL'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230310055817'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61410308421313126)
,p_plug_name=>unistr('APEX_UTIL.HOST_URL\306E\7D50\679C\3092\78BA\8A8D')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(63377299034102345)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob clob;',
'    l_result varchar2(4000);',
'    procedure append(',
'        p_clob    in out clob',
'        ,p_string in varchar2',
'        ,p_bold   in boolean default false)',
'    as',
'    begin',
'        if p_bold then',
'            p_clob := p_clob || ''<p><b>'' || p_string || ''</b></p>'';',
'        else',
'            p_clob := p_clob || ''<p>'' || p_string || ''</p>'';',
'        end if;',
'    end append;        ',
'begin',
unistr('    l_clob := ''<p><b>APEX\306E\5834\5408\306Fapex_page.get_url\304C\3042\308B\305F\3081\3001apex_util.host_url\304C\5FC5\8981\306A\30B1\30FC\30B9\306F\5C11\306A\3044\3002</b></p>'';'),
'    l_result := apex_util.host_url();',
'    append(l_clob, q''~apex_util.host_url()~'', true);',
'    append(l_clob, l_result);',
'    l_result := apex_util.host_url(''SCRIPT'');',
'    append(l_clob, q''~apex_util.host_url(''SCRIPT'')~'', true);',
'    append(l_clob, l_result);',
'    l_result := apex_util.host_url(''APEX_PATH'');',
'    append(l_clob, q''~apex_util.host_url(''APEX_PATH'')~'', true);',
'    append(l_clob, l_result);',
'    l_result := apex_util.host_url(''IMGPRE'');',
'    append(l_clob, q''~apex_util.host_url(''IMGPRE'')~'', true);',
'    append(l_clob, l_result);',
unistr('    /* \30EF\30FC\30AF\30B9\30DA\30FC\30B9\540D */'),
'    select workspace into l_result from apex_workspaces where workspace_id = :WORKSPACE_ID;',
unistr('    append(l_clob, q''~\30EF\30FC\30AF\30B9\30DA\30FC\30B9\540D~'', true);'),
'    append(l_clob, q''~select workspace into l_result from apex_workspaces where workspace_id = :WORKSPACE_ID~'', true);',
'    append(l_clob, l_result);',
unistr('    /* ORDS\5225\540D */'),
'    select pattern into l_result from user_ords_schemas where parsing_schema = sys_context(''USERENV'',''CURRENT_USER'');',
unistr('    append(l_clob, q''~ORDS\5225\540D~'', true);'),
'    append(l_clob, q''~select pattern into l_result from user_ords_schemas where parsing_schema = sys_context(''USERENV'',''CURRENT_USER'')~'', true);',
'    append(l_clob, l_result);',
unistr('    /* \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\5225\540D  */'),
'    l_result := utl_url.escape(lower(:APP_ALIAS), false, ''AL32UTF8'');',
unistr('    append(l_clob, q''~\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\5225\540D - \305F\3060\3057\65E5\672C\8A9E\306A\3069\3092\8A2D\5B9A\3057\306A\3051\308C\3070 lower(:APP_ALIAS)\3067\5341\5206~'', true);'),
'    append(l_clob, q''~utl_url.escape(lower(:APP_ALIAS), false, ''AL32UTF8'')~'', true);',
'    append(l_clob, l_result);',
unistr('    /* \305D\308C\4EE5\5916\306E\78BA\8A8D\65B9\6CD5 */'),
'    l_result := owa_util.get_cgi_env(''X-APEX-BASE'');',
'    append(l_clob, q''~owa_util.get_cgi_env(''X-APEX-BASE'')~'', true);',
'    append(l_clob, l_result);',
'    l_result := owa_util.get_cgi_env(''SCRIPT_NAME'');',
'    append(l_clob, q''~owa_util.get_cgi_env(''SCRIPT_NAME'')~'', true);',
'    append(l_clob, l_result);',
'    l_result := owa_util.get_cgi_env(''SCRIPT_PREFIX'');',
'    append(l_clob, q''~owa_util.get_cgi_env(''SCRIPT_PREFIX'')~'', true);',
'    append(l_clob, l_result);',
'    l_result := owa_util.get_cgi_env(''PATH_INFO'');',
'    append(l_clob, q''~owa_util.get_cgi_env(''PATH_INFO'')~'', true);',
'    append(l_clob, l_result);',
'    l_result := owa_util.get_cgi_env(''PATH_PREFIX'');',
'    append(l_clob, q''~owa_util.get_cgi_env(''PATH_PREFIX'')~'', true);',
'    append(l_clob, l_result);',
'    return l_clob;',
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp.component_end;
end;
/
