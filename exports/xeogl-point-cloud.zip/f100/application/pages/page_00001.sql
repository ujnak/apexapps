prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.10'
,p_default_workspace_id=>7601775501100353
,p_default_application_id=>100
,p_default_id_offset=>20765999211925465
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'xeogl point cloud'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdn.jsdelivr.net/npm/xeogl@0.9.0/build/xeogl.min.js',
'#APP_FILES#app#MIN#.js'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#myCanvas {',
'    width: 100%;',
'    height: 100vh;',
'    background: linear-gradient(to bottom, #1a1a2e, #0f0f1e);',
'}',
'input[type="range"] {',
'    width: 100%;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37149611212535668)
,p_plug_name=>'xeogl point cloud'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44712624455877910)
,p_plug_name=>'xeogl'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>'    <canvas id="myCanvas" style="width:100%; height:800px"></canvas>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44712717949877911)
,p_plug_name=>'Controls'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37532209268966269)
,p_plug_name=>'Tile Selection'
,p_parent_plug_id=>wwv_flow_imp.id(44712717949877911)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>2
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37532354758966270)
,p_plug_name=>'Zoom'
,p_parent_plug_id=>wwv_flow_imp.id(44712717949877911)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<label>\30BA\30FC\30E0: <span id="zoomValue">400</span></label>'),
'<input type="range" id="zoom" min="-600" max="0" value="0" step="5">',
unistr('<label>\6C34\5E73\56DE\56DE\8EE2: <span id="yawValue">0</span>\00B0</label>'),
'<input type="range" id="yaw" min="-180" max="180" value="0" step="5">     ',
unistr('<label>\5782\76F4\56DE\8EE2: <span id="pitchValue">0</span>\00B0</label>'),
'<input type="range" id="pitch" min="-89" max="89" value="0" step="5">',
unistr('<label>\4E2D\5FC3\5EA7\6A19 X: <span id="centerXValue">81308.9</span></label>'),
'<input type="range" id="centerX" min="-800000" max="800000" value="0" step="5">',
unistr('<label>\4E2D\5FC3\5EA7\6A19 Y: <span id="centerYValue">-35609.3</span></label>'),
'<input type="range" id="centerY" min="-800000" max="800000" value="0" step="5">',
unistr('<label>\4E2D\5FC3\5EA7\6A19 Z: <span id="centerZValue">10</span></label>'),
'<input type="range" id="centerZ" min="-100" max="800" value="0" step="5">'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44713035909877914)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(37532209268966269)
,p_button_name=>'DRAW'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Draw'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44712966970877913)
,p_name=>'P1_TILE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(37532209268966269)
,p_prompt=>'Tile ID'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select tile_id d, tile_id r from tokyo_point_cloud_tiles '
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44713135387877915)
,p_name=>'onClick Draw'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(44713035909877914)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37531917191966266)
,p_event_id=>wwv_flow_imp.id(44713135387877915)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'createPointCloud();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37532033353966267)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_POINT_CLOUDS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_tile_id   varchar2(8)  := :P1_TILE_ID;',
'    l_response json_object_t := json_object_t();',
'    l_blob     blob;',
'    l_compressed_blob blob;',
'    l_points   json_object_t := json_object_t();',
'    l_positions clob;',
'    l_colors    clob;',
'    l_indices   clob;',
'    l_extent    clob;',
'begin',
unistr('    -- \5358\4E00\306ESELECT\6587\3067\5168\3066\306E\914D\5217\3068extent\60C5\5831\3092\53D6\5F97'),
'    select',
'        json_arrayagg(rownum - 1 order by rownum returning clob),',
'        json_arrayagg(json_array(x_coord, y_coord, z_coord) order by rownum returning clob),',
'        json_arrayagg(json_array(',
'            r_color / 65535, ',
'            g_color / 65535, ',
'            b_color / 65535, ',
'            1.0',
'        ) order by rownum returning clob),',
'        json_object(',
'            ''minX'' value min(x_coord),',
'            ''minY'' value min(y_coord),',
'            ''minZ'' value min(z_coord),',
'            ''maxX'' value max(x_coord),',
'            ''maxY'' value max(y_coord),',
'            ''maxZ'' value max(z_coord)',
'            returning clob',
'        )',
'    into l_indices, l_positions, l_colors, l_extent',
unistr('    from tokyo_point_clouds sample(10) -- \70B9\7FA4\306E\6570\30921/10\306B\524A\6E1B\3059\308B'),
'    where tile_id = l_tile_id;',
'    ',
unistr('    -- JSON\30AA\30D6\30B8\30A7\30AF\30C8\69CB\7BC9\FF08\7A7A\30C7\30FC\30BF\306E\30CF\30F3\30C9\30EA\30F3\30B0\4ED8\304D\FF09'),
'    l_response.put(''extent'', json_object_t(l_extent));',
'    ',
unistr('    -- positions, colors\306F\FF12\6B21\5143\306E\914D\5217\3067\8FD4\3059\3002xeogl\5411\3051\306E\30D5\30E9\30C3\30C8\5316\306F\30AF\30E9\30A4\30A2\30F3\30C8\3067\5B9F\65BD\3059\308B\3002'),
'    if l_positions is null or length(l_positions) = 0 then',
'        l_points.put(''positions'', json_array_t());',
'    else',
'        l_points.put(''positions'', json_array_t(l_positions));',
'    end if;',
'    ',
'    if l_colors is null or length(l_colors) = 0 then',
'        l_points.put(''colors'', json_array_t());',
'    else',
'        l_points.put(''colors'', json_array_t(l_colors));',
'    end if;',
'    ',
'    if l_indices is null or length(l_indices) = 0 then',
'        l_points.put(''indices'', json_array_t());',
'    else',
'        l_points.put(''indices'', json_array_t(l_indices));',
'    end if;',
'    ',
'    l_response.put(''points'', l_points);',
'    ',
unistr('    -- JSON\3092BLOB\306B\5909\63DB'),
'    l_blob := l_response.to_blob();',
'    ',
unistr('    -- GZIP\5727\7E2E'),
'    l_compressed_blob := utl_compress.lz_compress(l_blob);',
'    ',
unistr('    -- HTTP\30D8\30C3\30C0\30FC\3068GZIP\5727\7E2E\30C7\30FC\30BF\3092\9001\4FE1'),
'    sys.htp.init;',
'    sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_compressed_blob));',
'    sys.htp.p(''Content-Type: application/json'');',
unistr('    sys.htp.p(''Content-Encoding: gzip'');  -- GZIP\5727\7E2E\3092\901A\77E5'),
'    sys.htp.p(''Content-Disposition: attachment; filename=PointCloud.json.gz'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_compressed_blob);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>16766034142040802
);
wwv_flow_imp.component_end;
end;
/
