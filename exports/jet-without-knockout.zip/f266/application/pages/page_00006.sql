prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>266
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>unistr('\30AB\30FC\30C9')
,p_alias=>unistr('\30AB\30FC\30C9')
,p_step_title=>unistr('\30AB\30FC\30C9')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>'require(["ojs/ojpictochart"], function() {});'
,p_css_file_urls=>'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oj-dvt-datatip-value {',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230908012249'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85968335570096234)
,p_plug_name=>unistr('\30AB\30FC\30C9')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(85651810964653289)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    c.city_name',
'    ,t.month',
'    ,hmt_util.generate_temperatures_by_month(c.id, t.month) temperatures',
'from hmt_cities c join ',
'(',
'    select city_id, to_char(date_rec,''YYYY-MM'') month',
'    from hmt_city_temperatures',
'    group by city_id, to_char(date_rec,''YYYY-MM'')',
') t',
'on c.id = t.city_id'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{"orderBys":[{"key":"CITY_NAME","expr":"\"CITY_NAME\" asc"},{"key":"MONTH_ASC","expr":"\"MONTH\" asc"},{"key":"MONTH_DESC","expr":"\"MONTH\" desc"}],"itemName":"P6_ORDER_BY"}'
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows=>5
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(85968873943096236)
,p_region_id=>wwv_flow_imp.id(85968335570096234)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CITY_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'MONTH'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<oj-picto-chart',
'    items="&TEMPERATURES."',
'    layout="horizontal"',
'    row-height="20"',
'    column-count="7">',
'    <template slot="itemTemplate" data-oj-as="item">',
'        <oj-picto-chart-item',
'            color="[[item.data.color]]"',
'            name="[[item.data.name]]"',
'            shape="[[item.data.shape]]">',
'        </oj-picto-chart-item>',
'    </template>',
'</oj-picto-chart>'))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85969343029096239)
,p_name=>'P6_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(85968335570096234)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_item_default=>'CITY_NAME'
,p_prompt=>unistr('\4E26\66FF\3048\57FA\6E96')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:City Name;CITY_NAME,Month asc;MONTH_ASC,Month desc;MONTH_DESC'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(85786342653653382)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp.component_end;
end;
/
