prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>266
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>unistr('\5BFE\8A71\30E2\30FC\30C9\30FB\30EC\30DD\30FC\30C8')
,p_alias=>unistr('\5BFE\8A71\30E2\30FC\30C9-\30EC\30DD\30FC\30C8')
,p_step_title=>unistr('\5BFE\8A71\30E2\30FC\30C9\30FB\30EC\30DD\30FC\30C8')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>'require(["ojs/ojpictochart"], function() {});'
,p_css_file_urls=>'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oj-dvt-datatip-value {',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230907221028'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85954857733999099)
,p_plug_name=>unistr('\5BFE\8A71\30E2\30FC\30C9\30FB\30EC\30DD\30FC\30C8')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(85705654295653323)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    c.city_name',
'    ,t.month',
'    ,hmt_util.generate_temperatures_by_month(c.id, t.month) temperatures',
'from hmt_cities c join ',
'(',
'    select city_id, to_char(date_rec,''YYYY-MM'') month',
'    from hmt_city_temperatures',
'    group by city_id, to_char(date_rec,''YYYY-MM'')',
') t',
'on c.id = t.city_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>unistr('\5BFE\8A71\30E2\30FC\30C9\30FB\30EC\30DD\30FC\30C8')
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(85954938305999099)
,p_name=>unistr('\5BFE\8A71\30E2\30FC\30C9\30FB\30EC\30DD\30FC\30C8')
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>85954938305999099
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85955339072999101)
,p_db_column_name=>'CITY_NAME'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'City Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85955762394999102)
,p_db_column_name=>'MONTH'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Month'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85956189793999102)
,p_db_column_name=>'TEMPERATURES'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Temperatures'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<oj-picto-chart',
'    items="#TEMPERATURES#"',
'    layout="horizontal"',
'    row-height="20"',
'    column-count="7">',
'    <template slot="itemTemplate" data-oj-as="item">',
'        <oj-picto-chart-item',
'            color="[[item.data.color]]"',
'            name="[[item.data.name]]"',
'            shape="[[item.data.shape]]">',
'        </oj-picto-chart-item>',
'    </template>',
'</oj-picto-chart>'))
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(85957185700018021)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'859572'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CITY_NAME:MONTH:TEMPERATURES'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85567267904163221)
,p_name=>'afterRefresh REPORT'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(85954857733999099)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85567346274163222)
,p_event_id=>wwv_flow_imp.id(85567267904163221)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload(false);'
);
wwv_flow_imp.component_end;
end;
/
