prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>266
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>unistr('\5BFE\8A71\30B0\30EA\30C3\30C9')
,p_alias=>unistr('\5BFE\8A71\30B0\30EA\30C3\30C9')
,p_step_title=>unistr('\5BFE\8A71\30B0\30EA\30C3\30C9')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>'require(["ojs/ojpictochart"], function() {});'
,p_css_file_urls=>'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oj-dvt-datatip-value {',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230908005141'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85958918970033416)
,p_plug_name=>unistr('\5BFE\8A71\30B0\30EA\30C3\30C9')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(85705654295653323)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    c.city_name',
'    ,t.month',
'    ,hmt_util.generate_temperatures_by_month(c.id, t.month) temperatures',
'    ,null as chart',
'from hmt_cities c join ',
'(',
'    select city_id, to_char(date_rec,''YYYY-MM'') month',
'    from hmt_city_temperatures',
'    group by city_id, to_char(date_rec,''YYYY-MM'')',
') t',
'on c.id = t.city_id'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>unistr('\5BFE\8A71\30B0\30EA\30C3\30C9')
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(85567412029163223)
,p_name=>'CHART'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CHART'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HTML_EXPRESSION'
,p_heading=>'Temperatures'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<oj-picto-chart',
'    items="&TEMPERATURES."',
'    layout="horizontal"',
'    row-height="20"',
'    column-count="7">',
'    <template slot="itemTemplate" data-oj-as="item">',
'        <oj-picto-chart-item',
'            color="[[item.data.color]]"',
'            name="[[item.data.name]]"',
'            shape="[[item.data.shape]]">',
'        </oj-picto-chart-item>',
'    </template>',
'</oj-picto-chart>'))
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(85960236761033421)
,p_name=>'CITY_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CITY_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'City Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>true
,p_max_length=>320
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(85961208267033423)
,p_name=>'MONTH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTH'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Month'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>7
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(85962262331033424)
,p_name=>'TEMPERATURES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TEMPERATURES'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(85959494529033417)
,p_internal_uid=>85959494529033417
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(85959819174033418)
,p_interactive_grid_id=>wwv_flow_imp.id(85959494529033417)
,p_static_id=>'859599'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>5
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(85960043907033418)
,p_report_id=>wwv_flow_imp.id(85959819174033418)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(85960608752033422)
,p_view_id=>wwv_flow_imp.id(85960043907033418)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(85960236761033421)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(85961625131033423)
,p_view_id=>wwv_flow_imp.id(85960043907033418)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(85961208267033423)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(85962602610033424)
,p_view_id=>wwv_flow_imp.id(85960043907033418)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(85962262331033424)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(85965514274064369)
,p_view_id=>wwv_flow_imp.id(85960043907033418)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(85567412029163223)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp.component_end;
end;
/
