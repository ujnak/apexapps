prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>266
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'JET without Knockout'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>'require(["ojs/ojcore", "ojs/ojpictochart"], function(oj) {});'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#JET_CSS_DIRECTORY#alta/oj-alta-notag-min.css',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oj-dvt-datatip-value {',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230907085721'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85566670876163215)
,p_plug_name=>'Picto Chart'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(85715604576653329)
,p_plug_display_sequence=>40
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<oj-picto-chart',
'    id="pictochart1"',
'    items="[]"',
'    layout="horizontal"',
'    row-height="20"',
'    column-count="7">',
'    <template slot="itemTemplate" data-oj-as="item">',
'        <oj-picto-chart-item',
'            color="[[item.data.color]]"',
'            name="[[item.data.name]]"',
'            shape="[[item.data.shape]]">',
'        </oj-picto-chart-item>',
'    </template>',
'</oj-picto-chart>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85566343506163212)
,p_name=>'P1_CITY'
,p_item_sequence=>10
,p_prompt=>'City'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select city_name d, id r from hmt_cities order by city_name asc'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- \90FD\5E02\3092\9078\629E -')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(85786342653653382)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85566466070163213)
,p_name=>'P1_YEAR'
,p_item_sequence=>20
,p_prompt=>'Year'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(date_rec,''YYYY'') d, to_char(date_rec,''YYYY'') r',
'from hmt_city_temperatures where city_id = :P1_CITY',
'group by to_char(date_rec,''YYYY'') order by to_char(date_rec,''YYYY'') desc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- \5E74\3092\9078\629E -')
,p_lov_cascade_parent_items=>'P1_CITY'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(85786342653653382)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85566587273163214)
,p_name=>'P1_MONTH'
,p_item_sequence=>30
,p_prompt=>'Month'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(date_rec,''MM'') d, to_char(date_rec,''MM'') r',
'from hmt_city_temperatures ',
'where city_id = :P1_CITY and to_char(date_rec,''YYYY'') = :P1_YEAR',
'group by to_char(date_rec,''MM'') order by to_char(date_rec,''MM'') asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- \6708\3092\9078\629E -')
,p_lov_cascade_parent_items=>'P1_CITY,P1_YEAR'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(85786342653653382)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85566861892163217)
,p_name=>unistr('Picto Chart\306E\66F4\65B0')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_MONTH'
,p_condition_element=>'P1_MONTH'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85566976132163218)
,p_event_id=>wwv_flow_imp.id(85566861892163217)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process( "GET_DATA",',
'    {',
'        pageItems: ["P1_CITY","P1_YEAR","P1_MONTH"]',
'    },',
'    {',
'        success: (data) => {    ',
'            let pictoChart1 = document.getElementById("pictochart1");',
'            let busyContext = oj.Context.getContext(pictoChart1).getBusyContext();',
'            busyContext.whenReady().then(function() {',
'                pictoChart1.items = data;',
'            });',
'        }',
'    }',
')'))
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P1_MONTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85566733360163216)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_month varchar2(7);',
'    l_data clob;',
'begin',
'    l_month := :P1_YEAR || ''-'' || :P1_MONTH;',
'    l_data := hmt_util.generate_temperatures_by_month(',
'        p_city_id => :P1_CITY',
'        ,p_month => l_month',
'        ,p_shape => ''circle''',
'    );',
'    -- apex_debug.info(l_data);',
'    htp.p(l_data);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>85566733360163216
);
wwv_flow_imp.component_end;
end;
/
