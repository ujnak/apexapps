prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>266
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>unistr('\30AF\30E9\30B7\30C3\30AF\30FB\30EC\30DD\30FC\30C8')
,p_alias=>unistr('\30AF\30E9\30B7\30C3\30AF-\30EC\30DD\30FC\30C8')
,p_step_title=>unistr('\30AF\30E9\30B7\30C3\30AF\30FB\30EC\30DD\30FC\30C8')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'[require jet]'
,p_javascript_code_onload=>'require(["ojs/ojpictochart"], function() {});'
,p_css_file_urls=>'#JET_CSS_DIRECTORY#redwood/oj-redwood-notag-min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oj-dvt-datatip-value {',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230907224446'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(85949179025880094)
,p_name=>unistr('\30AF\30E9\30B7\30C3\30AF\30FB\30EC\30DD\30FC\30C8')
,p_template=>wwv_flow_imp.id(85715604576653329)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    c.city_name',
'    ,t.month',
'    ,hmt_util.generate_temperatures_by_month(c.id, t.month) temperatures',
'from hmt_cities c join ',
'(',
'    select city_id, to_char(date_rec,''YYYY-MM'') month',
'    from hmt_city_temperatures',
'    group by city_id, to_char(date_rec,''YYYY-MM'')',
') t',
'on c.id = t.city_id'))
,p_query_row_template=>wwv_flow_imp.id(85742232992653346)
,p_query_num_rows=>5
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85949544102880099)
,p_query_column_id=>1
,p_column_alias=>'CITY_NAME'
,p_column_display_sequence=>1
,p_column_heading=>'City Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85949944658880101)
,p_query_column_id=>2
,p_column_alias=>'MONTH'
,p_column_display_sequence=>2
,p_column_heading=>'Month'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85950379505880101)
,p_query_column_id=>3
,p_column_alias=>'TEMPERATURES'
,p_column_display_sequence=>3
,p_column_heading=>'Temperatures'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<oj-picto-chart',
'    items="#TEMPERATURES#"',
'    layout="horizontal"',
'    row-height="20"',
'    column-count="7">',
'    <template slot="itemTemplate" data-oj-as="item">',
'        <oj-picto-chart-item',
'            color="[[item.data.color]]"',
'            name="[[item.data.name]]"',
'            shape="[[item.data.shape]]">',
'        </oj-picto-chart-item>',
'    </template>',
'</oj-picto-chart>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
