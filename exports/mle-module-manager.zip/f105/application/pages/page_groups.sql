prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 105
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>7739405930131605
,p_default_application_id=>105
,p_default_id_offset=>15540053757464423
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(29918427615344199)
,p_group_name=>unistr('\7BA1\7406')
);
wwv_flow_imp.component_end;
end;
/
