prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>112
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'download'
,p_alias=>'DOWNLOAD'
,p_step_title=>'download'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_deep_linking=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20221207044737'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12447221651680428)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\30C0\30A6\30F3\30ED\30FC\30C9')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response dbms_cloud_oci_obs_object_storage_get_object_response_t;',
'    l_status_code number;',
'    l_filename sfm_contents.content_filename%type;',
'    l_mime_type sfm_contents.content_mimetype%type;',
'    l_version sfm_contents.version%type;',
'    l_object_name varchar2(4000);',
'    file_download_error exception;',
'    l_download apex_data_export.t_export;',
'begin',
unistr('    -- \30AA\30D6\30B8\30A7\30AF\30C8\30FB\30B9\30C8\30EC\30FC\30B8\4E0A\306E\540D\524D\3092l_object_name\3068\3057\3066\53D6\308A\51FA\3059\3002'),
'    select version, content_filename, content_mimetype',
'    into l_version, l_filename, l_mime_type',
'    from sfm_contents',
'    where id = :ID;',
'    l_object_name := :ID || ''/'' || l_version || ''/'' || utl_url.escape(l_filename, false, ''AL32UTF8'');',
'',
unistr('    -- \30AA\30D6\30B8\30A7\30AF\30C8\30FB\30B9\30C8\30EC\30FC\30B8\304B\3089\5BFE\8C61\30D5\30A1\30A4\30EB\3092\53D6\308A\51FA\3059\3002'),
'    l_response := dbms_cloud_oci_obs_object_storage.get_object(',
'        namespace_name => :G_NAMESPACE',
'        ,bucket_name => :G_BUCKET',
'        ,object_name => l_object_name',
'        ,region => :G_REGION',
'        ,credential_name => :G_CREDENTIAL',
'    );',
'    l_status_code := l_response.status_code;',
'    if l_status_code != 200 then',
'        raise file_download_error;',
'    end if;',
'',
unistr('    -- \53D6\308A\51FA\3057\305F\30D5\30A1\30A4\30EB\3092\3001\30D6\30E9\30A6\30B6\306B\30C0\30A6\30F3\30ED\30FC\30C9\3059\308B\3002'),
'    l_download.file_name := l_filename;',
'    l_download.mime_type := l_mime_type;',
'    l_download.as_clob := false;',
'    l_download.content_blob := l_response.response_body;',
'    apex_data_export.download( p_export => l_download );',
'    apex_application.stop_apex_engine;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp.component_end;
end;
/
