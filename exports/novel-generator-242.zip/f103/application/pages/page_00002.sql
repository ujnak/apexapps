prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>103
,p_default_id_offset=>12229795983249102
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>unistr('\5C0F\8AAC\3092\8AAD\3080')
,p_alias=>'READ-STORY'
,p_step_title=>unistr('\5C0F\8AAC\3092\8AAD\3080')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40859484523012917)
,p_plug_name=>'Item Container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1569994581593435632
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(40859939734012922)
,p_plug_name=>unistr('\5C0F\8AAC')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_story clob;',
'begin',
'    if :P2_STORY is not null then',
'        select story into l_story from ebaj_stories where id = :P2_STORY;',
'        return apex_markdown.to_html(l_story);',
'    end if;',
'    return '''';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42564838990427411)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(42541548670704426)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(40859684797012919)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(40859484523012917)
,p_button_name=>'READ'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\8AAD\3080')
,p_button_position=>'BUTTON_END'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(40859781023012920)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(40859484523012917)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'BUTTON_END'
,p_confirm_message=>unistr('\672C\5F53\306B\524A\9664\3057\307E\3059\304B\FF1F')
,p_confirm_style=>'danger'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40859577057012918)
,p_name=>'P2_STORY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(40859484523012917)
,p_prompt=>unistr('\5C0F\8AAC')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select title d, id r from ebaj_stories'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- \8AAD\307F\305F\3044\5C0F\8AAC\3092\9078\3093\3067 -')
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(40859834282012921)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DELETE'
,p_process_sql_clob=>'delete from ebaj_stories where id = :P2_STORY;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(40859781023012920)
,p_internal_uid=>28630038298763819
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(40860079021012923)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>unistr('P2_STORY\306E\30AF\30EA\30A2')
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P2_STORY'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(40859781023012920)
,p_internal_uid=>28630283037763821
);
wwv_flow_imp.component_end;
end;
/
