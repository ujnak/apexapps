prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Update Chart Title'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10750524178374639)
,p_plug_name=>unistr('\7D66\4E0E')
,p_title=>'&P1_JOB.'
,p_region_name=>'myChart'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'EMP'
,p_query_where=>':P1_JOB is null or JOB = :P1_JOB'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P1_JOB'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(10750660702374640)
,p_region_id=>wwv_flow_imp.id(10750524178374639)
,p_chart_type=>'bar'
,p_title=>'&P1_JOB.'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ) {',
'    apex.debug.info(options);',
unistr('    const job = apex.items.P1_JOB.value ? apex.items.P1_JOB.value : "\3059\3079\3066\306EJOB";'),
'    // const job = apex.items.P1_JOB.value;',
'    if ( options.title ) {',
unistr('        // title\304C\521D\671F\5316\6E08\307F\3067\3042\308C\3070\3001text\306E\307F\3092\66F4\65B0\3059\308B\3002'),
'        options.title.text = job;',
'        apex.debug.info("INIT: title.text is replaced, ", job);',
'    }',
'    else',
'    {',
unistr('        // \305D\3046\3067\306A\3044\5834\5408\306F\4E2D\592E\63C3\3048\3082\542B\3081\3066title\3092\521D\671F\5316\3059\308B'),
'        options.title = {',
'            "halign": "center",',
'            "text": job',
'        };',
'        apex.debug.info("INIT: title.text is created, ", job);',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(10750787550374641)
,p_chart_id=>wwv_flow_imp.id(10750660702374640)
,p_seq=>10
,p_name=>unistr('\7D66\4E0E')
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'SAL'
,p_items_label_column_name=>'ENAME'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10750869248374642)
,p_chart_id=>wwv_flow_imp.id(10750660702374640)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(10750944058374643)
,p_chart_id=>wwv_flow_imp.id(10750660702374640)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15137531545973768)
,p_plug_name=>'Update Chart Title'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10751041973374644)
,p_name=>'P1_JOB'
,p_item_sequence=>10
,p_prompt=>unistr('\30B8\30E7\30D6')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select job d, job r from emp group by job'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('\6761\4EF6\306A\3057')
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10751102782374645)
,p_name=>'onChange JOB'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_JOB'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10751211320374646)
,p_event_id=>wwv_flow_imp.id(10751102782374645)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10750524178374639)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10751382299374647)
,p_event_id=>wwv_flow_imp.id(10751102782374645)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>unistr('option\3092\6307\5B9A\3057\306A\3044')
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('const job = this.triggeringElement.value ? this.triggeringElement.value : "\3059\3079\3066\306EJOB";'),
'// const job = this.triggeringElement.value;',
'apex.region("myChart").widget().ojChart(',
'    { ',
'        "title": {',
'            "halign": "center",',
'            "text": job',
'        }',
'    }',
');'))
,p_build_option_id=>wwv_flow_imp.id(15123763013973745)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10751497376374648)
,p_event_id=>wwv_flow_imp.id(10751102782374645)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>unistr('option\3068title\3092\6307\5B9A')
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('const job = this.triggeringElement.value ? this.triggeringElement.value : "\3059\3079\3066\306EJOB";'),
'// const job = this.triggeringElement.value;',
'apex.region("myChart").widget().ojChart(',
'    "option",',
'    "title",',
'    {',
'        "halign": "center",',
'        "text": job',
'    }',
');'))
,p_build_option_id=>wwv_flow_imp.id(15123763013973745)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10751596837374649)
,p_event_id=>wwv_flow_imp.id(10751102782374645)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>unistr('option\3068title.text\3092\6307\5B9A')
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('const job = this.triggeringElement.value ? this.triggeringElement.value : "\3059\3079\3066\306EJOB";'),
'// const job = this.triggeringElement.value;',
'apex.region("myChart").widget().ojChart(',
'    "option",',
'    "title.text",',
'    job',
');'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10751668536374650)
,p_event_id=>wwv_flow_imp.id(10751102782374645)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_name=>unistr('\30EA\30FC\30B8\30E7\30F3\306E\30BF\30A4\30C8\30EB\3092\66F4\65B0')
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr('* \30EA\30FC\30B8\30E7\30F3\306B\30BF\30A4\30C8\30EB\304C\3055\308C\3066\3044\308B\5834\5408\3001\305D\308C\3082\66F4\65B0\3059\308B\3002'),
'*/',
unistr('const job = this.triggeringElement.value ? this.triggeringElement.value : "\3059\3079\3066\306EJOB";'),
'// const job = this.triggeringElement.value;',
'const regionTitle = document.getElementById("myChart_heading");',
'if ( regionTitle ) {',
'    regionTitle.textContent = job;',
'};'))
);
wwv_flow_imp.component_end;
end;
/
