prompt --application/shared_components/logic/application_computations/create_index_ivf
begin
--   Manifest
--     APPLICATION COMPUTATION: CREATE_INDEX_IVF
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>100
,p_default_id_offset=>16251806941449740
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(48487592108154756)
,p_computation_sequence=>10
,p_computation_item=>'CREATE_INDEX_IVF'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE VECTOR INDEX genvec_vector_idx ON genvec(v) ',
'ORGANIZATION NEIGHBOR PARTITIONS',
'DISTANCE EUCLIDEAN',
'WITH TARGET ACCURACY 95'))
,p_version_scn=>7656805
);
wwv_flow_imp.component_end;
end;
/
