prompt --application/shared_components/logic/application_computations/select_default
begin
--   Manifest
--     APPLICATION COMPUTATION: SELECT_DEFAULT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>100
,p_default_id_offset=>16211890502110820
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(32235130839674439)
,p_computation_sequence=>10
,p_computation_item=>'SELECT_DEFAULT'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select /* my_vector_query */ json(v) jv, name from genvec ',
'order by name asc fetch first 100 rows only'))
,p_version_scn=>7655948
);
wwv_flow_imp.component_end;
end;
/
