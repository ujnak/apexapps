prompt --application/shared_components/user_interface/lovs/lov_vector
begin
--   Manifest
--     LOV_VECTOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>100
,p_default_id_offset=>16211890502110820
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(30817877638822354)
,p_lov_name=>'LOV_VECTOR'
,p_lov_query=>'select name d, json(v) r from genvec order by 1 asc'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_query_owner=>'VECSYS'
,p_return_column_name=>'D'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>6405599
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(30818431061824513)
,p_query_column_name=>'R'
,p_heading=>'Value'
,p_display_sequence=>10
,p_data_type=>'CLOB'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(30818836359824514)
,p_query_column_name=>'D'
,p_heading=>'Name'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
