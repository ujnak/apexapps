prompt --application/deployment/install/install_table
begin
--   Manifest
--     INSTALL: INSTALL-table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>100
,p_default_id_offset=>16211890502110820
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(31832027366707206)
,p_install_id=>wwv_flow_imp.id(31831641585703336)
,p_name=>'table'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE genvec (',
'  id number,           -- id of the generated vector',
'  v VECTOR,            -- generated vector',
'  name VARCHAR2(500),  -- name for the generated vector: C1 to Cn are centroids, Cx_y is vector number y in cluster number x',
'  nv VECTOR,           -- normalized version of the generated vector',
'  ly number            -- random number you can use to filter out rows in addition to similarity search on vectors',
');'))
);
wwv_flow_imp.component_end;
end;
/
