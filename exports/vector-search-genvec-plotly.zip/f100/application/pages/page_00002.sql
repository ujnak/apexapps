prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>100
,p_default_id_offset=>16251806941449740
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Index'
,p_alias=>'INDEX'
,p_step_title=>'Index'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46073646345067785)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(45674345442297869)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46269764302120665)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(46272304793120691)
,p_name=>'Index Info'
,p_template=>3371237801798025892
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'select * from v$vector_index where index_name = ''GENVEC_VECTOR_IDX'''
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46273920718120707)
,p_query_column_id=>1
,p_column_alias=>'OWNER'
,p_column_display_sequence=>10
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46274060209120708)
,p_query_column_id=>2
,p_column_alias=>'INDEX_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Index Name'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46274135862120709)
,p_query_column_id=>3
,p_column_alias=>'PARTITION_NAME'
,p_column_display_sequence=>30
,p_column_heading=>'Partition Name'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46274289262120710)
,p_query_column_id=>4
,p_column_alias=>'INDEX_ORGANIZATION'
,p_column_display_sequence=>40
,p_column_heading=>'Index Organization'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48091496701316661)
,p_query_column_id=>5
,p_column_alias=>'INDEX_OBJN'
,p_column_display_sequence=>50
,p_column_heading=>'Index Objn'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48091541844316662)
,p_query_column_id=>6
,p_column_alias=>'ALLOCATED_BYTES'
,p_column_display_sequence=>60
,p_column_heading=>'Allocated Bytes'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48091691482316663)
,p_query_column_id=>7
,p_column_alias=>'USED_BYTES'
,p_column_display_sequence=>70
,p_column_heading=>'Used Bytes'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48091793767316664)
,p_query_column_id=>8
,p_column_alias=>'NUM_VECTORS'
,p_column_display_sequence=>80
,p_column_heading=>'Num Vectors'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48091853519316665)
,p_query_column_id=>9
,p_column_alias=>'NUM_REPOP'
,p_column_display_sequence=>90
,p_column_heading=>'Num Repop'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48091989731316666)
,p_query_column_id=>10
,p_column_alias=>'INDEX_USED_COUNT'
,p_column_display_sequence=>100
,p_column_heading=>'Index Used Count'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48092077574316667)
,p_query_column_id=>11
,p_column_alias=>'DISTANCE_TYPE'
,p_column_display_sequence=>110
,p_column_heading=>'Distance Type'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48092141318316668)
,p_query_column_id=>12
,p_column_alias=>'INDEX_DIMENSIONS'
,p_column_display_sequence=>120
,p_column_heading=>'Index Dimensions'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48092198739316669)
,p_query_column_id=>13
,p_column_alias=>'INDEX_DIM_TYPE'
,p_column_display_sequence=>130
,p_column_heading=>'Index Dim Type'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48092351648316670)
,p_query_column_id=>14
,p_column_alias=>'DEFAULT_ACCURACY'
,p_column_display_sequence=>140
,p_column_heading=>'Default Accuracy'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48092469349316671)
,p_query_column_id=>15
,p_column_alias=>'CON_ID'
,p_column_display_sequence=>150
,p_column_heading=>'Con Id'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49479728412090207)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(46269764302120665)
,p_button_name=>'DROP_INDEX'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Drop Index'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49479382503090203)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(46269764302120665)
,p_button_name=>'CREATE_HNSW_IDX'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Create Hnsw Idx'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49479632648090206)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(46269764302120665)
,p_button_name=>'CREATE_IVF_IDX'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Create Ivf Idx'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49479822019090208)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Drop Index'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_DROP_INDEX   constant varchar2(400) := q''~DROP INDEX if exists genvec_vector_idx~'';',
'begin',
'    execute immediate C_DROP_INDEX;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>17016124575529648
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49479492932090204)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Hnsw Index'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    execute immediate :CREATE_INDEX_HNSW;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(49479382503090203)
,p_internal_uid=>17015795488529644
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49479587847090205)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Ivf Index'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    execute immediate :CREATE_INDEX_IVF;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(49479632648090206)
,p_internal_uid=>17015890403529645
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46269665850120664)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Gather Table Stats'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    DBMS_STATS.GATHER_TABLE_STATS(',
'        ownname => null,',
'        tabname          => ''GENVEC'',',
'        estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,',
'        cascade          => TRUE',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>13805968406560104
);
wwv_flow_imp.component_end;
end;
/
