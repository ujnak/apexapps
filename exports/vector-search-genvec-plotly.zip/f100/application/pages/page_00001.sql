prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>100
,p_default_id_offset=>16211890502110820
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Genvec and Plotly'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.plot.ly/plotly-3.0.1.min.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * \30EC\30A4\30A2\30A6\30C8\8A2D\5B9A\3002'),
' */',
'const layout = {',
'    autosize: true,',
'    height: 480,',
'    scene: {',
'        aspectratio: {',
'            x: 1,',
'            y: 1,',
'            z: 1',
'        },',
'        camera: {',
'            center: {',
'                x: 0,',
'                y: 0,',
'                z: 0',
'            },',
'            eye: {',
'                x: 1.25,',
'                y: 1.25,',
'                z: 1.25',
'            },',
'            up: {',
'                x: 0,',
'                y: 0,',
'                z: 1',
'            }',
'        },',
'        xaxis: {',
'            type: ''linear'',',
'            range: null,',
'            zeroline: false',
'        },',
'        yaxis: {',
'            type: ''linear'',',
'            range: null,',
'            zeroline: false',
'        },',
'        zaxis: {',
'            type: ''linear'',',
'            range: null,',
'            zeroline: false',
'        }',
'    },',
'    title: {',
'        text: ''3d point clustering''',
'    },',
'    width: 477',
'};'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29435653109848153)
,p_plug_name=>'Genvec and Plotly'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33226075368640448)
,p_plug_name=>'Genvec'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>'<div id="myDiv" class="w500 h500"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15631074458756134)
,p_plug_name=>'Range'
,p_parent_plug_id=>wwv_flow_imp.id(33226075368640448)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33226660077640454)
,p_plug_name=>'Selection'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33227262633640460)
,p_plug_name=>'PLAN'
,p_region_name=>'PLAN'
,p_parent_plug_id=>wwv_flow_imp.id(33226660077640454)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>80
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_plan clob;',
'begin',
'    l_plan := ''<pre><code>'';',
'    for r in (',
'        select * from table(dbms_xplan.display_cursor(:P1_SQL_ID, :P1_CHILD_NUMBER))',
'    )',
'    loop',
'        l_plan := l_plan || r.plan_table_output || apex_application.LF;',
'    end loop;',
'    l_plan := l_plan || ''</code></pre>'';',
'    return l_plan;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_SQL_ID,P1_CHILD_NUMBER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33226966955640457)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(33226660077640454)
,p_button_name=>'SEARCH'
,p_button_static_id=>'SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Search'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33228143009640469)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(33226660077640454)
,p_button_name=>'APPROX_SEARCH'
,p_button_static_id=>'APPROX_SEARCH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Approx Search'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15630635823756130)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(33226660077640454)
,p_button_name=>'RESET'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Reset'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15630890884756132)
,p_name=>'P1_MIN_VALUE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(15631074458756134)
,p_prompt=>'Min Value'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15630911482756133)
,p_name=>'P1_MAX_VALUE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(15631074458756134)
,p_prompt=>'Max Value'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30018026463670926)
,p_name=>'P1_VECTOR_VALUE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(33226660077640454)
,p_prompt=>'Vector Value'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33226777432640455)
,p_name=>'P1_VECTOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(33226660077640454)
,p_prompt=>'Vector Name'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VECTOR'
,p_lov=>'select name d, json(v) r from genvec order by 1 asc'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_outputs', 'R:P1_VECTOR_VALUE',
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33226884445640456)
,p_name=>'P1_ROWS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(33226660077640454)
,p_prompt=>'Rows'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33227047663640458)
,p_name=>'P1_SQL_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33227152732640459)
,p_name=>'P1_CHILD_NUMBER'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31842093160866946)
,p_name=>'onClick APPROX_SEARCH'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(33228143009640469)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31842202980866947)
,p_event_id=>wwv_flow_imp.id(31842093160866946)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * GET_DATA\3092\547C\3073\51FA\3057\3066\3001\6210\529F\3057\305F\5F8C\306BmyDiv\306B\63CF\753B\3059\308B\3002'),
' */',
'apex.server.process( "GET_DATA", {',
'    x01: this.triggeringElement.id,',
'    pageItems: "#P1_VECTOR_VALUE,#P1_ROWS,#P1_MIN_VALUE,#P1_MAX_VALUE"',
'},{',
'    success: function( response )  {',
'        apex.item("P1_SQL_ID").setValue(response.sql_id);',
'        apex.item("P1_CHILD_NUMBER").setValue(response.child_number);',
'        apex.item("P1_MIN_VALUE").setValue(response.range[0]);',
'        apex.item("P1_MAX_VALUE").setValue(response.range[1]);',
'        layout.scene.xaxis.range = response.range;',
'        layout.scene.yaxis.range = response.range;',
'        layout.scene.zaxis.range = response.range;',
'        apex.debug.info(response.sql_id);',
'        apex.debug.info(response.data);',
'        apex.debug.info(response.range);',
'        // Plotly.newPlot(''myDiv'', response.data, layout);',
'        Plotly.react(''myDiv'', response.data, layout);',
'        apex.region("PLAN").refresh();',
'    },',
'    loadingIndicator: "#myDiv"',
'}',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15630416818756128)
,p_name=>'onClick SEARCH'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(33226966955640457)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15630539391756129)
,p_event_id=>wwv_flow_imp.id(15630416818756128)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr(' * GET_DATA\3092\547C\3073\51FA\3057\3066\3001\6210\529F\3057\305F\5F8C\306BmyDiv\306B\63CF\753B\3059\308B\3002'),
' */',
'apex.server.process( "GET_DATA", {',
'    x01: this.triggeringElement.id,',
'    pageItems: "#P1_VECTOR_VALUE,#P1_ROWS,#P1_MIN_VALUE,#P1_MAX_VALUE"',
'},{',
'    success: function( response )  {',
'        apex.item("P1_SQL_ID").setValue(response.sql_id);',
'        apex.item("P1_CHILD_NUMBER").setValue(response.child_number);',
'        apex.item("P1_MIN_VALUE").setValue(response.range[0]);',
'        apex.item("P1_MAX_VALUE").setValue(response.range[1]);',
'        layout.scene.xaxis.range = response.range;',
'        layout.scene.yaxis.range = response.range;',
'        layout.scene.zaxis.range = response.range;',
'        apex.debug.info(response.sql_id);',
'        apex.debug.info(response.data);',
'        apex.debug.info(response.range);',
'        // Plotly.newPlot(''myDiv'', response.data, layout);',
'        Plotly.react(''myDiv'', response.data, layout);',
'        apex.region("PLAN").refresh();',
'    },',
'    loadingIndicator: "#myDiv",',
'    loadingIndicatorPosition: "centered"',
'}',
');'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31841682338866941)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_BULK_LIMIT    constant pls_integer := 1000;',
'    C_COLOR_COUNT   constant pls_integer := 30;',
unistr('    C_RANGE_BUFFER  constant number := 0.1;  -- 10%\306E\30D0\30C3\30D5\30A1'),
'    C_MARKER_SIZE   constant number := 2;',
unistr('    /* \30AF\30E9\30B9\30BF\3054\3068\306B\8272\4ED8\3051\3059\308B\30AB\30E9\30FC\30D1\30EC\30C3\30C8 */'),
'    type t_color_array is varray(C_COLOR_COUNT) of varchar2(7);',
'    C_COLOR_PALETTE t_color_array := t_color_array(',
'        ''#e6194b'', ''#3cb44b'', ''#ffe119'', ''#0082c8'', ''#f58231'',',
'        ''#911eb4'', ''#46f0f0'', ''#f032e6'', ''#d2f53c'', ''#fabebe'',',
'        ''#008080'', ''#e6beff'', ''#aa6e28'', ''#fffac8'', ''#800000'',',
'        ''#aaffc3'', ''#808000'', ''#ffd8b1'', ''#000080'', ''#808080'',',
'        ''#FFFFFF'', ''#000000'', ''#FF69B4'', ''#7FFFD4'', ''#6495ED'',',
'        ''#DC143C'', ''#00CED1'', ''#FFD700'', ''#ADFF2F'', ''#20B2AA''        ',
'    );',
unistr('    /* \30D0\30AF\30EB\30D5\30A7\30C3\30C1\306B\4F7F\7528\3059\308B */'),
'    type t_vector_array is table of vector;',
'    type t_name_array   is table of genvec.name%type;',
'    l_vectors t_vector_array;',
'    l_names   t_name_array;',
unistr('    /* scatter3d\30C1\30E3\30FC\30C8\5411\3051\306E\30C7\30FC\30BF\3001\30AF\30E9\30B9\30BF\6BCE\306E\9023\60F3\914D\5217 */'),
'    type t_data_array is table of clob index by pls_integer;',
unistr('    l_data_id_str varchar2(8); /* Cnn-xx\306Enn\306E\6587\5B57\5217\3092\4FDD\6301\3059\308B */'),
unistr('    l_data_id  pls_integer;   /* \6DFB\5B57 */'),
unistr('    l_data     json_object_t; /* \8981\7D20 */'),
unistr('    l_data_arr t_data_array;    /* \9023\60F3\914D\5217 */'),
'    l_index    pls_integer;',
unistr('    l_plotly_data json_array_t; /* l_data_arr\306EPlotly\5411\3051JSON\8868\73FE */'),
unistr('    /* Oracle Vector\30C7\30FC\30BF */'),
'    l_vector vector;',
'    l_v json_array_t;',
'    l_name genvec.name%type;',
'    l_name_arr json_array_t;',
unistr('    /* \5B9F\884C\3059\308BSELECT\6587\3068\30D7\30E9\30F3\306E\8868\793A */'),
'    l_cursor        sys_refcursor;',
'    l_select        varchar2(32767);',
'    l_sql_id        v$sql.sql_id%type;',
'    l_child_number  number;',
'    l_vector_value  vector;',
'    l_rows          number;',
unistr('    /* \30EC\30B9\30DD\30F3\30B9 */'),
'    l_response      clob;',
'    l_response_blob blob;',
'    l_response_json json_object_t;',
unistr('    /* \30C1\30E3\30FC\30C8\8868\793A\306E\7BC4\56F2 */'),
'    l_value       number;',
'    l_min_value   number := 0;',
'    l_max_value   number := 0;',
'    l_max_value_item number;',
'    l_min_value_item number;',
'    l_buffer_size number;',
'    l_range      json_array_t;',
unistr('    /* \4F8B\5916 */'),
unistr('    /* Cnn, Cnn-xx\3068\3044\3063\305F\30D5\30A9\30FC\30DE\30C3\30C8\306Enn\304C\898B\3064\304B\3089\306A\3044\3002 */'),
'    e_no_cluster_id exception;',
unistr('    /* Cnn, Cnn-xx\3068\3044\3063\305F\30D5\30A9\30FC\30DE\30C3\30C8\306Enn\3092\6570\5024\306B\3067\304D\306A\3044\3002 */'),
'    e_invalid_cluster_id exception;',
unistr('    /* \30AF\30E9\30B9\30BF\306E\521D\671F\5316\306B\5931\6557 */'),
'    e_initialize_cluster_data_failed exception;',
unistr('    /* \30AF\30E9\30B9\30BF\30FC\30FB\30C7\30FC\30BF\304C\4E0D\6B63 CLOB\3092JSON\306B\623B\305B\306A\3044\3002 */'),
'    e_invalid_cluster_data exception;',
unistr('    /* \5EA7\6A19\5024\304Cnull */'),
'    e_null_coordinate_value exception;',
unistr('    /* \30D9\30AF\30C8\30EB\304C\FF13\6B21\5143\3088\308A\5C0F\3055\3044 */'),
'    e_insufficient_vector exception;',
'',
unistr('    /* \305D\308C\305E\308C\306E\5EA7\6A19\306B\6570\5024\3092\8FFD\52A0\3059\308B\3002 */'),
'    procedure append_coordinate(',
'        p_data in out json_object_t',
'        ,p_axis in varchar2 -- x,y,z',
'        ,p_vector in json_array_t',
'        ,p_index  in pls_integer',
'        ,p_min_value in out number',
'        ,p_max_value in out number',
'    )',
'    as',
'        l_coordinate json_array_t;',
'        l_value      number;',
unistr('        /* \5EA7\6A19\8EF8\304Cx, y, z\4EE5\5916 */'),
'        e_invalid_axis exception;',
'    begin',
unistr('        /* \5EA7\6A19\8EF8\306B\5BFE\5FDC\3057\305F\8981\7D20\3092\53D6\308A\51FA\3059\3002 */'),
'        l_value := p_vector.get_number(p_index);',
'        if l_value is null then',
'            apex_debug.error(''Null coordinate value for axis %s'', p_axis);',
'            raise e_null_coordinate_value;',
'        end if;',
unistr('        /* \53D6\308A\51FA\3057\305F\6570\5024\306E\6700\5C0F\5024\3068\6700\5927\5024\3092\8A18\61B6\3059\308B\3002 */'),
'        if l_value > p_max_value then',
'            p_max_value := l_value;',
'        end if;',
'        if l_value < p_min_value then',
'            p_min_value := l_value;',
'        end if;',
unistr('        /* \305D\308C\305E\308C\306E\5EA7\6A19\306B\6570\5024\3092\8FFD\52A0\3059\308B\3002 */'),
'        l_coordinate := p_data.get_array(p_axis);',
'        if l_coordinate is null then',
'            apex_debug.error(''Invalid axis %s'', p_axis);',
'            raise e_invalid_axis;',
'        end if;',
'        l_coordinate.append(l_value);',
'        p_data.put(p_axis, l_coordinate);',
'    end append_coordinate;',
unistr('    /* \30AF\30E9\30B9\30BF\306E\30C7\30FC\30BF\3092\521D\671F\5316\3059\308B\3002 */'),
'    function init_cluster_data(',
'        p_data_id in number',
'    )',
'    return json_object_t',
'    as',
'        l_data        json_object_t;',
'        l_color_index pls_integer;',
'    begin',
unistr('        /* \914D\8272\306E\4F4D\7F6E\3092\8A08\7B97 */'),
'        l_color_index := case',
'            when p_data_id is null or p_data_id <=0 then 1',
'            else mod(p_data_id - 1, C_COLOR_COUNT) + 1',
'        end;',
'        l_data := json_object_t();',
'        l_data.put(''x'',    json_array_t());',
'        l_data.put(''y'',    json_array_t());',
'        l_data.put(''z'',    json_array_t());',
'        l_data.put(''text'', json_array_t());',
'        l_data.put(''mode'', ''markers'');',
'        l_data.put(''type'', ''scatter3d'');',
'        l_data.put(''name'', ''C'' || p_data_id);',
unistr('        /* 30\500B\3042\308B\30AB\30E9\30FC\30FB\30D1\30EC\30C3\30C8\304B\3089\8272\3092\9078\629E\3059\308B */'),
'        l_data.put(''marker'', json_object_t(json_object(',
'            key ''color'' value C_COLOR_PALETTE(l_color_index),',
'            key ''size''  value C_MARKER_SIZE',
'        )));',
'        return l_data;',
'    exception',
'        when others then',
'            apex_debug.info(''Cluster data initialization failed for id %s'', p_data_id);',
'            raise e_initialize_cluster_data_failed;',
'    end init_cluster_data;',
'begin',
'    /*',
unistr('     * \5B9F\884C\3059\308BSELECT\6587\3092\6C7A\3081\308B\3002'),
unistr('     * \691C\7D22\6761\4EF6\306E\6307\5B9A\304C\7121\3051\308C\3070\30AF\30EA\30C3\30AF\3057\305F\30DC\30BF\30F3\306B\95A2\308F\3089\305A\30C7\30D5\30A9\30EB\30C8\306E\691C\7D22\3002'),
'     */',
unistr('    /* P1_VECTOR_VALUE\3068P1_ROWS\306E\30D5\30A9\30FC\30DE\30C3\30C8\30C1\30A7\30C3\30AF\3002\5931\6557\6642\306Fnull\306B\623B\3059\3002 */'),
'    begin',
'        l_vector_value := to_vector(:P1_VECTOR_VALUE);',
'    exception',
'        when others then',
'            apex_debug.warn(''Failed to convert vector %s'', :P1_VECTOR_VALUE);',
'            apex_session_state.set_value(''P1_VECTOR_VALUE'', '''');',
'            apex_session_state.set_value(''P1_VECTOR'', '''');',
'    end;',
'    l_rows := to_number(:P1_ROWS default null on conversion error);',
unistr('    /* \30D9\30AF\30C8\30EB\985E\4F3C\691C\7D22\3092\884C\3046 */'),
'    if l_vector_value is not null and l_rows is not null then',
unistr('        /* \30AF\30EA\30C3\30AF\3057\305F\30DC\30BF\30F3\306E\9759\7684ID\3067\3001EXACT\3068APPROX\3092\5207\308A\66FF\3048\308B\3002 */'),
'        if apex_application.g_x01 = ''SEARCH'' then',
'            l_select := :SELECT_EXACT;',
'        else',
'            l_select := :SELECT_APPROX;',
'        end if;',
'        open l_cursor for l_select using l_vector_value, l_rows;',
'    else',
unistr('        /* \691C\7D22\6761\4EF6\304C\306A\3044\6642\306F\6271\3046\30D9\30AF\30C8\30EB\3092100\4EF6\306B\9650\5B9A */'),
'        l_select := :SELECT_DEFAULT;',
'        open l_cursor for l_select;',
'    end if;',
'    /*',
unistr('     * \691C\7D22\3057\305F\30D9\30AF\30C8\30EB\3068\540D\524D\3092\30AF\30E9\30B9\30BF\6BCE\306B\307E\3068\3081\3001Plotly\306Edata\306B\6E21\3059'),
unistr('     * JSON\30AA\30D6\30B8\30A7\30AF\30C8\3092\751F\6210\3059\308B\3002'),
'     */',
'    begin',
'        loop',
'            fetch l_cursor bulk collect into l_vectors, l_names limit C_BULK_LIMIT;',
'            for i in 1..l_vectors.count loop',
'                l_vector := l_vectors(i);',
'                l_name   := l_names(i);',
'                /*',
unistr('                 * \4F4D\7F6E\6307\5B9A\3067\8981\7D20\3092\53D6\5F97\3059\308B\305F\3081vector\304B\3089json_array\3078\5909\63DB\3002'),
unistr('                 * Oracle\306EVECTOR\578B\3067\4F4D\7F6E\6307\5B9A\3067\8981\7D20\3092\53D6\308A\51FA\3059\65B9\6CD5\3092\898B\3064\3051\3089\308C\306A\304B\3063\305F\3002'),
'                 */',
'                l_v := json_array_t(json(l_vector));',
unistr('                /* C1-11\3068\3044\3063\305F\540D\524D\3088\308A\30AF\30E9\30B9\30BF\306E\756A\53F7\3092\53D6\308A\51FA\3059\3002 */'),
'                begin',
'                    l_data_id_str := regexp_substr(l_name, ''\d+'');',
'                    if l_data_id_str is null then',
'                        apex_debug.error(''no cluster id found in %s'', l_name);',
'                        raise e_no_cluster_id;',
'                    end if;',
'                    l_data_id     := to_number(l_data_id_str);',
'                    apex_debug.info(''cluster id %s found in name %s'', l_data_id, l_name);',
'                exception',
'                    when value_error then',
'                        apex_debug.error(''invalid cluster id in %s'', l_name);',
'                        raise e_invalid_cluster_id;',
'                end;',
unistr('                /* \6240\5C5E\3059\308B\30AF\30E9\30B9\30BF\306E\30C7\30FC\30BF\3092\53D6\308A\51FA\3059\3002 */'),
'                if l_data_arr.exists(l_data_id) then',
'                    apex_debug.info(''cluster exists for id %s'', l_data_id);',
unistr('                    /* l_data_arr\306B\306Fclob\3067\4FDD\5B58\3057\3066\3044\308B\306E\3067\3001json_object_t\306B\5909\63DB\3059\308B */'),
'                    begin',
'                        l_data := json_object_t(l_data_arr(l_data_id));',
'                    exception',
'                        when others then',
'                            apex_debug.error(''Failed to convert from CLOB to JSON for id %s'', l_data_id);',
'                            raise e_invalid_cluster_data;',
'                    end;',
'                else',
unistr('                    /* \30AF\30E9\30B9\30BF\306E\521D\671F\5316 */'),
'                    apex_debug.info(''no cluster found for id %s, initialize'', l_data_id);',
'                    l_data := init_cluster_data(l_data_id);',
'                end if;',
unistr('                /* \6B21\5143\6570\3092\78BA\8A8D\3059\308B\3002 */'),
'                if l_v.get_size() > 3 then',
'                    apex_debug.warn(''too many dimenstions, ignore %s'', l_v.to_string());',
'                end if;',
'                if l_v.get_size() < 3 then',
'                    apex_debug.error(''insufficient dimensions, stop %s'', l_v.to_string());',
'                    raise e_insufficient_vector;',
'                end if;',
'                /* append x, y, z */',
'                append_coordinate(l_data,''x'',l_v,0,l_min_value,l_max_value);       ',
'                append_coordinate(l_data,''y'',l_v,1,l_min_value,l_max_value);       ',
'                append_coordinate(l_data,''z'',l_v,2,l_min_value,l_max_value);       ',
'                /* append name */',
'                l_name_arr := l_data.get_array(''text'');',
'                l_name_arr.append(l_name);',
'                l_data.put(''text'', l_name_arr);',
unistr('                /* \30D9\30AF\30C8\30EB\3092\8FFD\52A0\3057\305F\30C7\30FC\30BF\306B\66F4\65B0\3059\308B */'),
'                l_data_arr(l_data_id) := l_data.to_clob();',
'            end loop;',
'            exit when l_vectors.count < C_BULK_LIMIT;',
'        end loop;',
'    exception',
'        when others then',
'            if l_cursor%ISOPEN then',
'                close l_cursor;',
'            end if;',
'            raise;',
'    end;',
unistr('    /* Plotly\5411\3051\306E\63CF\753B\30C7\30FC\30BF\3092\4F5C\6210\3059\308B */'),
'    l_plotly_data := json_array_t();',
'    l_index := l_data_arr.FIRST;',
'    while l_index is not null',
'    loop',
'        begin',
'            l_plotly_data.append(json_object_t(l_data_arr(l_index)));',
'        exception',
'            when others then',
'                apex_debug.error(''Failed to convert from CLOB to JSON for id %s'', l_index);',
'                raise e_invalid_cluster_data;',
'        end;',
'        l_index := l_data_arr.NEXT(l_index);',
'    end loop;',
'    /*',
unistr('     * Plotly\306Escatter3d\30B0\30E9\30D5\306E\30EC\30F3\30B8\3092'),
unistr('     * \30D9\30AF\30C8\30EB\306B\542B\307E\308C\308B\6570\5024\306E\6700\5C0F\5024\3001\6700\5927\5024\304B\3089\6C7A\3081\308B\3002'),
'     */',
'    l_range := json_array_t();',
'    if :P1_MAX_VALUE is not null then',
unistr('        /* \8A2D\5B9A\6E08\307F\306E\5024\3092\512A\5148 */'),
'        l_max_value_item := to_number(:P1_MAX_VALUE default null on conversion error);',
'    end if;',
'    if l_max_value_item is not null then',
'        l_max_value := l_max_value_item;',
'    else',
unistr('        /* \30D9\30AF\30C8\30EB\306E\8981\7D20\306E\6700\5927\5024\306B\3001\6700\5C0F\5024\3068\306E\5DEE\306E1/10\3092\52A0\3048\308B\3002 */'),
'        l_buffer_size := (l_max_value - l_min_value) * C_RANGE_BUFFER;',
'        l_max_value := trunc(l_max_value + l_buffer_size);',
'    end if;',
'    if :P1_MIN_VALUE is not null then',
unistr('        /* \8A2D\5B9A\6E08\307F\306E\5024\3092\512A\5148 */'),
'        l_min_value_item := to_number(:P1_MIN_VALUE default null on conversion error);',
'    end if;',
'    if l_min_value_item is not null then',
'        l_min_value := l_min_value_item;',
'    else',
unistr('        /* \30D9\30AF\30C8\30EB\306E\8981\7D20\306E\6700\5C0F\5024\306B\3001\6700\5927\5024\3068\306E\5DEE\306E1/10\3092\5DEE\3057\5F15\304F\3002 */'),
'        if l_max_value_item is not null then',
'            l_buffer_size := (l_max_value - l_min_value) * C_RANGE_BUFFER;',
'        end if;',
'        l_min_value := trunc(l_min_value - l_buffer_size);',
'    end if;',
'    l_range.append(l_min_value);',
'    l_range.append(l_max_value);',
'    /*',
unistr('     * \5B9F\884C\8A08\753B\3092\8868\793A\3059\308B\305F\3081\3001\5B9F\884C\3057\305FSELECT\6587\306ESQL_ID\3068CHILD_NUMBER\3092\898B\3064\3051\308B\3002'),
'     */',
'    begin',
'        select sql_id, child_number into l_sql_id, l_child_number',
unistr('        -- \5148\982D30\6587\5B57\307E\3067\4E00\81F4\3059\308BSELECT\6587\3092\63A2\3059\3002'),
'        from v$sql where sql_text like substr(l_select,1,30) || ''%''',
'        order by last_active_time desc fetch first 1 rows only;',
'    exception',
'        when no_data_found then',
'            l_sql_id := null;',
'            l_child_number := null;',
'            apex_debug.info(''SQL_ID not found for query.'');',
'    end;',
'    /*',
unistr('     * response\3068\306A\308BJSON\3092\3064\304F\308B'),
'     */',
'    l_response_json := json_object_t();',
'    l_response_json.put(''data'', l_plotly_data);',
'    l_response_json.put(''sql_id'', l_sql_id);',
'    l_response_json.put(''child_number'', l_child_number);',
'    l_response_json.put(''range'', l_range);',
'    l_response := l_response_json.to_clob();',
'    l_response_blob := apex_util.clob_to_blob(',
'        p_clob => l_response',
'        , p_charset => ''AL32UTF8''',
'    );',
'    /*',
unistr('     * \547C\3073\51FA\3057\5143\306BJSON\3092\8FD4\3059\3002'),
'     */',
'    sys.htp.init;',
'    sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_response_blob));',
'    sys.htp.p(''Content-Type: application/json'');',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(l_response_blob);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>15629791836756121
);
wwv_flow_imp.component_end;
end;
/
