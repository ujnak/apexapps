prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.7'
,p_default_workspace_id=>7236383262984313
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Genvec and Plotly'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.plot.ly/plotly-3.0.1.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var data = JSON.parse(apex.item("P1_DATA").value);',
'var range = JSON.parse(apex.item("P1_RANGE").value);',
'',
'var layout = {',
'    autosize: true,',
'    height: 480,',
'    scene: {',
'        aspectratio: {',
'            x: 1,',
'            y: 1,',
'            z: 1',
'        },',
'        camera: {',
'            center: {',
'                x: 0,',
'                y: 0,',
'                z: 0',
'            },',
'            eye: {',
'                x: 1.25,',
'                y: 1.25,',
'                z: 1.25',
'            },',
'            up: {',
'                x: 0,',
'                y: 0,',
'                z: 1',
'            }',
'        },',
'        xaxis: {',
'            type: ''linear'',',
'            range: range,',
'            zeroline: false',
'        },',
'        yaxis: {',
'            type: ''linear'',',
'            range: range,',
'            zeroline: false',
'        },',
'        zaxis: {',
'            type: ''linear'',',
'            range: range,',
'            zeroline: false',
'        }',
'    },',
'    title: {',
'        text: ''3d point clustering''',
'    },',
'    width: 477',
'};',
'',
'console.log(data);',
'',
'Plotly.newPlot(''myDiv'', data, layout);'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13223762607737333)
,p_plug_name=>'Genvec and Plotly'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17014184866529628)
,p_plug_name=>'Genvec'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>'<div id="myDiv" class="w500 h500"></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17014769575529634)
,p_plug_name=>'Selection'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17015372131529640)
,p_plug_name=>'PLAN'
,p_parent_plug_id=>wwv_flow_imp.id(17014769575529634)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>70
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_plan clob;',
'begin',
'    l_plan := ''<pre><code>'';',
'    for r in (',
'        select * from table(dbms_xplan.display_cursor(:P1_SQL_ID, :P1_CHILD_NUMBER))',
'    )',
'    loop',
'        l_plan := l_plan || r.plan_table_output || apex_application.LF;',
'    end loop;',
'    l_plan := l_plan || ''</code></pre>'';',
'    return l_plan;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17015076453529637)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(17014769575529634)
,p_button_name=>'SEARCH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Search'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17016252507529649)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(17014769575529634)
,p_button_name=>'APPROX_SEARCH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Approx Search'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13806135961560106)
,p_name=>'P1_VECTOR_VALUE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(17014769575529634)
,p_prompt=>'Vector Value'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15628885943756112)
,p_name=>'P1_RANGE'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15628905243756113)
,p_name=>'P1_DATA'
,p_data_type=>'CLOB'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17014886930529635)
,p_name=>'P1_VECTOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(17014769575529634)
,p_prompt=>'Vector Name'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_VECTOR'
,p_lov=>'select name d, json(v) r from genvec order by 1 asc'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_outputs', 'R:P1_VECTOR_VALUE',
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17014993943529636)
,p_name=>'P1_ROWS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(17014769575529634)
,p_prompt=>'Rows'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17015157161529638)
,p_name=>'P1_SQL_ID'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17015262230529639)
,p_name=>'P1_CHILD_NUMBER'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17016354025529650)
,p_name=>'P1_APPROX'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(17014769575529634)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13805641377560101)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Approx Search'
,p_process_sql_clob=>':P1_APPROX := ''Y'';'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(17016252507529649)
,p_internal_uid=>13805641377560101
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13805718090560102)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Exace Search'
,p_process_sql_clob=>':P1_APPROX := ''N'';'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(17015076453529637)
,p_internal_uid=>13805718090560102
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17014637094529633)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Prepare for Plotly'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
unistr('    /* \30AF\30E9\30B9\30BF\3054\3068\306B\8272\4ED8\3051\3059\308B\305F\3081\306E\30AB\30E9\30FC\30D1\30EC\30C3\30C8 */'),
'    type t_color_array is varray(30) of varchar2(7);',
'    C_COLOR_PALETTE t_color_array := t_color_array(',
'        ''#e6194b'', ''#3cb44b'', ''#ffe119'', ''#0082c8'', ''#f58231'',',
'        ''#911eb4'', ''#46f0f0'', ''#f032e6'', ''#d2f53c'', ''#fabebe'',',
'        ''#008080'', ''#e6beff'', ''#aa6e28'', ''#fffac8'', ''#800000'',',
'        ''#aaffc3'', ''#808000'', ''#ffd8b1'', ''#000080'', ''#808080'',',
'        ''#FFFFFF'', ''#000000'', ''#FF69B4'', ''#7FFFD4'', ''#6495ED'',',
'        ''#DC143C'', ''#00CED1'', ''#FFD700'', ''#ADFF2F'', ''#20B2AA''        ',
'    );',
unistr('    /* scatter3d\30C1\30E3\30FC\30C8\5411\3051\306E\30C7\30FC\30BF\3001\30AF\30E9\30B9\30BF\6BCE\306E\9023\60F3\914D\5217 */'),
'    type t_data_arr is table of clob index by pls_integer;',
unistr('    l_data_id  pls_integer;   /* \6DFB\5B57 */'),
unistr('    l_data     json_object_t; /* \8981\7D20 */'),
unistr('    l_data_arr t_data_arr;    /* \9023\60F3\914D\5217 */'),
'    l_index    pls_integer;',
unistr('    l_plotly_data json_array_t; /* l_data_arr\306EJSON\8868\73FE */'),
unistr('    /* Oracle Vector\30C7\30FC\30BF */'),
'    l_vector vector;',
'    l_v json_array_t;',
'    l_x json_array_t;',
'    l_y json_array_t;',
'    l_z json_array_t;',
'    l_name genvec.name%type;',
'    l_name_arr json_array_t;',
'    l_cursor sys_refcursor;',
unistr('    /* \30C1\30E3\30FC\30C8\306E\30EC\30F3\30B8 */'),
'    l_min_value number;',
'    l_max_value number;',
'    /* select statements */',
'    l_select varchar2(32767);',
'begin',
'    /*',
unistr('     * Plotly\306Escatter3d\30B0\30E9\30D5\306E\30EC\30F3\30B8\3092\3001VECTOR_GEN_PKG.generate_vectors\306B'),
unistr('     * \4E0E\3048\305Fmin_vlue\3068max_value\304B\3089\6C7A\3081\308B\3002'),
'     */',
'    if :P3_MIN_VALUE is not null then',
'        l_min_value := to_number(:P3_MIN_VALUE);',
'    else',
'        l_min_value := 0;',
'    end if;',
'    if :P3_MAX_VALUE is not null then',
'        l_max_value := to_number(:P3_MAX_VALUE);',
'    else',
'        l_max_value := 100;',
'    end if;',
'    :P1_RANGE := apex_string.format(''[%s,%s]'', l_min_value, l_max_value);',
'    /*',
unistr('     * \5B9F\884C\3059\308BSELECT\6587\3092\6C7A\3081\308B\3002'),
'     */',
'    if :P1_VECTOR is not null and :P1_ROWS is not null then',
'        if :P1_APPROX = ''N'' then',
'            l_select := :SELECT_EXACT;',
'        else',
'            l_select := :SELECT_APPROX;',
'        end if;',
'        open l_cursor for l_select using :P1_VECTOR_VALUE, :P1_ROWS;',
'    else',
unistr('        /* \691C\7D22\6761\4EF6\304C\306A\3044\6642\306F\6271\3046\30D9\30AF\30C8\30EB\3092100\4EF6\306B\9650\5B9A */'),
'        l_select := :SELECT_DEFAULT;',
'        open l_cursor for l_select;',
'    end if;',
'    /*',
unistr('     * \691C\7D22\3057\305F\30D9\30AF\30C8\30EB\3068\540D\524D\3092\30AF\30E9\30B9\30BF\6BCE\306B\307E\3068\3081\3001Plotly\306Edata\306B\6E21\3059'),
unistr('     * JSON\30AA\30D6\30B8\30A7\30AF\30C8\3092\751F\6210\3059\308B\3002'),
'     */',
'    loop',
'        fetch l_cursor into l_vector, l_name;',
'        exit when l_cursor%NOTFOUND;',
unistr('        /* \4F4D\7F6E\6307\5B9A\3067\8981\7D20\3092\53D6\5F97\3059\308B\305F\3081vector\304B\3089json_array\3078\5909\63DB */'),
'        l_v := json_array_t(json(l_vector));',
'        apex_debug.info(l_v.to_string());',
unistr('        /* C1-11\3068\3044\3063\305F\540D\524D\3088\308A\30AF\30E9\30B9\30BF\306E\756A\53F7\3092\53D6\308A\51FA\3059\3002 */'),
'        l_data_id := to_number(regexp_substr(l_name, ''\d+''));',
'        apex_debug.info(''name %s, id %s'', l_name, l_data_id);',
unistr('        /* \6240\5C5E\3059\308B\30AF\30E9\30B9\30BF\306E\30C7\30FC\30BF\3092\53D6\308A\51FA\3059\3002 */'),
'        begin',
'            apex_debug.info(''data found for id %s'', l_data_id);',
'            l_data := json_object_t(l_data_arr(l_data_id));',
'        exception',
'            when no_data_found then',
unistr('                /* \898B\3064\304B\3089\306A\3044\5834\5408\306F\521D\671F\5316 */'),
'                apex_debug.info(''no data found for id %s, initialize'', l_data_id);',
'                l_data := json_object_t();',
'                l_data.put(''x'',     json_array_t());',
'                l_data.put(''y'',     json_array_t());',
'                l_data.put(''z'',     json_array_t());',
'                l_data.put(''text'', json_array_t());',
'                l_data.put(''mode'', ''markers'');',
'                l_data.put(''type'', ''scatter3d'');',
'                l_data.put(''name'', ''C'' || l_data_id);',
unistr('                /* 30\500B\3042\308B\30AB\30E9\30FC\30FB\30D1\30EC\30C3\30C8\304B\3089\8272\3092\9078\629E\3059\308B */'),
'                l_data.put(''marker'', json_object_t(json_object(',
'                    key ''color'' value C_COLOR_PALETTE(mod(l_data_id, 30) + 1),',
'                    key ''size''  value 2',
'                )));',
'        end;',
'        /* append x */',
'        l_x := l_data.get_array(''x'');',
'        l_x.append(l_v.get_number(0));',
'        l_data.put(''x'', l_x);',
'        /* append y */',
'        l_y := l_data.get_array(''y'');',
'        l_y.append(l_v.get_number(1));',
'        l_data.put(''y'', l_y);',
'        /* append z */',
'        l_z := l_data.get_array(''z'');',
'        l_z.append(l_v.get_number(2));',
'        l_data.put(''z'', l_z);',
'        /* append name */',
'        l_name_arr := l_data.get_array(''text'');',
'        l_name_arr.append(l_name);',
'        l_data.put(''text'', l_name_arr);',
unistr('        /* \30D9\30AF\30C8\30EB\3092\8FFD\52A0\3057\305F\30C7\30FC\30BF\306B\66F4\65B0\3059\308B */'),
'        l_data_arr(l_data_id) := l_data.to_clob();',
'    end loop;',
unistr('    /* Plotly\5411\3051\306E\63CF\753B\30C7\30FC\30BF\3092\4F5C\6210\3059\308B */'),
'    l_plotly_data := json_array_t();',
'    l_index := l_data_arr.FIRST;',
'    while l_index is not null',
'    loop',
'        l_plotly_data.append(json_object_t(l_data_arr(l_index)));',
'        l_index := l_data_arr.NEXT(l_index);',
'    end loop;',
'    :P1_DATA := l_plotly_data.to_clob();',
'    /* save SQL_ID */',
'    select sql_id, child_number into :P1_SQL_ID, :P1_CHILD_NUMBER',
'    -- from v$sql where sql_text like ''select /* my_vector_query */%''',
unistr('    -- \5148\982D30\6587\5B57\307E\3067\306F\540C\3058\3067\3042\308C\3070\3001'),
'    from v$sql where sql_text like substr(l_select,1,30) || ''%''',
'    order by last_active_time desc fetch first 1 rows only;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>17014637094529633
);
wwv_flow_imp.component_end;
end;
/
