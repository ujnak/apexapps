prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>301
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'QR Code'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#P1_QR_C {',
'  --a-qrcode-size: 4rem;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231130003746'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11433562935359945)
,p_plug_name=>'Page Item'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11555901078009784)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11433637078359946)
,p_plug_name=>'APEX_BARCODE.GET_QRCODE_'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11555901078009784)
,p_plug_display_sequence=>40
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11431664216359926)
,p_plug_name=>'SVG'
,p_parent_plug_id=>wwv_flow_imp.id(11433637078359946)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11555901078009784)
,p_plug_display_sequence=>80
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P1_URL2 is null then',
'    return '''';',
'end if;',
'return apex_barcode.get_qrcode_svg(',
'    p_value => :P1_URL2',
'    ,p_size => :P1_SIZE',
');'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_URL2,P1_SIZE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11431745532359927)
,p_plug_name=>'PNG'
,p_parent_plug_id=>wwv_flow_imp.id(11433637078359946)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11555901078009784)
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P1_URL2 is null then',
'    return '''';',
'end if;',
'return ''<img src="data:image/png;base64,'' ||',
'    apex_web_service.blob2clobbase64(',
'        p_blob => apex_barcode.get_qrcode_png(',
'            p_value => :P1_URL2',
'            ,p_scale => :P1_SCALE',
'        )',
'        ,p_newlines => ''N''',
'        ,p_padding => ''N''',
'    )',
'|| ''">'';'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_URL2,P1_SCALE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11433891429359948)
,p_plug_name=>'APEX_BARCODE.GET_CODE128_'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11555901078009784)
,p_plug_display_sequence=>50
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11431988082359929)
,p_plug_name=>'SVG'
,p_parent_plug_id=>wwv_flow_imp.id(11433891429359948)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11555901078009784)
,p_plug_display_sequence=>100
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P1_TEXT is null then',
'    return '''';',
'end if;',
'return apex_barcode.get_code128_svg(',
'    p_value => :P1_TEXT',
'    ,p_size => :P1_SIZE',
');'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_TEXT,P1_SIZE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11432385453359933)
,p_plug_name=>'PNG'
,p_parent_plug_id=>wwv_flow_imp.id(11433891429359948)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11555901078009784)
,p_plug_display_sequence=>110
,p_plug_new_grid_row=>false
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P1_TEXT is null then',
'    return '''';',
'end if;',
'return ''<img src="data:image/png;base64,'' ||',
'    apex_web_service.blob2clobbase64(',
'        p_blob => apex_barcode.get_code128_png(',
'            p_value => :P1_TEXT',
'            ,p_scale => :P1_SCALE',
'        )',
'        ,p_newlines => ''N''',
'        ,p_padding => ''N''',
'    )',
'|| ''">'';'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_TEXT,P1_SCALE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11433973035359949)
,p_plug_name=>'APEX_BARCODE.GET_EAN8_'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11555901078009784)
,p_plug_display_sequence=>60
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11433062488359940)
,p_plug_name=>'SVG'
,p_parent_plug_id=>wwv_flow_imp.id(11433973035359949)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11555901078009784)
,p_plug_display_sequence=>130
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P1_NUMBER is null then',
'    return '''';',
'end if;',
'return apex_barcode.get_ean8_svg(',
'    p_value => :P1_NUMBER',
');'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_NUMBER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11433127911359941)
,p_plug_name=>'PNG'
,p_parent_plug_id=>wwv_flow_imp.id(11433973035359949)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11555901078009784)
,p_plug_display_sequence=>140
,p_plug_new_grid_row=>false
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P1_NUMBER is null then',
'    return '''';',
'end if;',
'return ''<img src="data:image/png;base64,'' ||',
'    apex_web_service.blob2clobbase64(',
'        p_blob => apex_barcode.get_ean8_png(',
'            p_value => :P1_NUMBER',
'            ,p_scale => :P1_SCALE',
'        )',
'        ,p_newlines => ''N''',
'        ,p_padding => ''N''',
'    )',
'|| ''">'';'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P1_NUMBER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11753397726010120)
,p_plug_name=>'QR Code'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(11532610834009772)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11430833858359918)
,p_name=>'P1_QR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11433562935359945)
,p_prompt=>'Default'
,p_display_as=>'NATIVE_QRCODE'
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11430937416359919)
,p_name=>'P1_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11433562935359945)
,p_prompt=>'URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'URL'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11431267321359922)
,p_name=>'P1_QR_S'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(11433562935359945)
,p_prompt=>'Small'
,p_display_as=>'NATIVE_QRCODE'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
,p_attribute_02=>'a-QRCode--sm'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11431329936359923)
,p_name=>'P1_QR_M'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(11433562935359945)
,p_prompt=>'Medium'
,p_display_as=>'NATIVE_QRCODE'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
,p_attribute_02=>'a-QRCode--md'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11431488449359924)
,p_name=>'P1_QR_L'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(11433562935359945)
,p_prompt=>'Large'
,p_display_as=>'NATIVE_QRCODE'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
,p_attribute_02=>'a-QRCode--lg'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11431534022359925)
,p_name=>'P1_QR_C'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(11433562935359945)
,p_prompt=>'Custom'
,p_display_as=>'NATIVE_QRCODE'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11432084555359930)
,p_name=>'P1_TEXT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11433891429359948)
,p_prompt=>'Text'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11432564640359935)
,p_name=>'P1_NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(11433973035359949)
,p_prompt=>'Number'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11433793514359947)
,p_name=>'P1_URL2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11433637078359946)
,p_prompt=>'URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11786385207984704)
,p_name=>'P1_SIZE'
,p_item_sequence=>20
,p_item_default=>'256'
,p_prompt=>'Size (px) for SVG'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11786411773984705)
,p_name=>'P1_SCALE'
,p_item_sequence=>30
,p_item_default=>'1'
,p_prompt=>'Scale for PNG (1-10)'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(11626646789009827)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'1'
,p_attribute_02=>'10'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11431063036359920)
,p_name=>'Update Page Items'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_URL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11431148604359921)
,p_event_id=>wwv_flow_imp.id(11431063036359920)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_QR,P1_QR_S,P1_QR_M,P1_QR_L,P1_QR_C'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$v(this.triggeringElement)'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11433391964359943)
,p_event_id=>wwv_flow_imp.id(11431063036359920)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11431664216359926)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11433494993359944)
,p_event_id=>wwv_flow_imp.id(11431063036359920)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11431745532359927)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11432163441359931)
,p_name=>'Update CODE128'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_TEXT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11432256165359932)
,p_event_id=>wwv_flow_imp.id(11432163441359931)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11431988082359929)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11432410855359934)
,p_event_id=>wwv_flow_imp.id(11432163441359931)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11432385453359933)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11432625573359936)
,p_name=>'Update EAN8'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_NUMBER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11432738369359937)
,p_event_id=>wwv_flow_imp.id(11432625573359936)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11433062488359940)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11433231747359942)
,p_event_id=>wwv_flow_imp.id(11432625573359936)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11433127911359941)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11786047001984701)
,p_name=>'Update QR Code'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_URL2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11786151922984702)
,p_event_id=>wwv_flow_imp.id(11786047001984701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11431664216359926)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11786251577984703)
,p_event_id=>wwv_flow_imp.id(11786047001984701)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11431745532359927)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11786555043984706)
,p_name=>'Change Scale'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_SCALE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11786696054984707)
,p_event_id=>wwv_flow_imp.id(11786555043984706)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11431745532359927)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11786704833984708)
,p_event_id=>wwv_flow_imp.id(11786555043984706)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11432385453359933)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11786844847984709)
,p_event_id=>wwv_flow_imp.id(11786555043984706)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11433127911359941)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11786979456984710)
,p_name=>'Change Size'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_SIZE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11787052790984711)
,p_event_id=>wwv_flow_imp.id(11786979456984710)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11431664216359926)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11787166898984712)
,p_event_id=>wwv_flow_imp.id(11786979456984710)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11431988082359929)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11787294989984713)
,p_event_id=>wwv_flow_imp.id(11786979456984710)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11433062488359940)
);
wwv_flow_imp.component_end;
end;
/
