prompt --application/deployment/install/install_ctx_consumer_group_pkg
begin
--   Manifest
--     INSTALL: INSTALL-ctx_consumer_group_pkg
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>6209720412671547
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7855978636029201)
,p_install_id=>wwv_flow_imp.id(7656473496025547)
,p_name=>'ctx_consumer_group_pkg'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package ctx_consumer_group_pkg',
'as',
'/**',
' * Switch to the new consumer group and remember the old group.',
' */',
'procedure set',
'(',
'   p_group in varchar2',
');',
'',
'/**',
' * Revert to the old consumer group.',
' */',
'procedure clear;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
