prompt --application/deployment/install/install_ctx_consumer_group_pkg_pkb
begin
--   Manifest
--     INSTALL: INSTALL-ctx_consumer_group_pkg.pkb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>6209720412671547
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7856043358032085)
,p_install_id=>wwv_flow_imp.id(7656473496025547)
,p_name=>'ctx_consumer_group_pkg.pkb'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package body ctx_consumer_group_pkg',
'as',
'',
'/**',
' * Switch to the new consumer group and remember the old group.',
' */',
'procedure set(',
'  p_group in varchar2',
')',
'is',
'  l_old_group varchar2(30);',
'begin',
'  apex_debug.info(''consumer group is set to '' || p_group);',
'  dbms_session.switch_current_consumer_group(p_group, l_old_group, FALSE);',
'  apex_debug.info(''preserve old consumer group '' || l_old_group);',
'  dbms_session.set_context(''ctx_consumer_group'',''name'',l_old_group);',
'end set;',
'',
'/**',
' * Revert to the old consumer group.',
' */',
'procedure clear',
'is',
'    l_group varchar2(30);',
'    l_old_group varchar2(30);',
'begin',
'  l_group := sys_context(''ctx_consumer_group'',''name'');',
'  apex_debug.info(''recover old consumer group '' || l_group);',
'  dbms_session.switch_current_consumer_group(l_group, l_old_group, FALSE);',
'  apex_debug.info(''previous consumer group '' || l_old_group);',
'  dbms_session.clear_context(''ctx_consumer_group'');',
'end clear;',
'',
'end ctx_consumer_group_pkg;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
