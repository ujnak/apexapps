prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>6209720412671547
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'APEXDEV'
);
null;
wwv_flow_imp.component_end;
end;
/
