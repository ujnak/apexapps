prompt --application/shared_components/security/authentications/oracle_apexアカウント
begin
--   Manifest
--     AUTHENTICATION: Oracle APEXアカウント
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>6209720412671547
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'APEXDEV'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(7461338540830226)
,p_name=>unistr('Oracle APEX\30A2\30AB\30A6\30F3\30C8')
,p_scheme_type=>'NATIVE_APEX_ACCOUNTS'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>3335820
);
wwv_flow_imp.component_end;
end;
/
