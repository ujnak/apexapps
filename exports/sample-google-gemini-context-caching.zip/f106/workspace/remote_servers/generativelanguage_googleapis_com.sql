prompt --workspace/remote_servers/generativelanguage_googleapis_com
begin
--   Manifest
--     REMOTE SERVER: generativelanguage-googleapis-com
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(24603187718951626)
,p_name=>'generativelanguage-googleapis-com'
,p_static_id=>'generativelanguage_googleapis_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('generativelanguage_googleapis_com'),'https://generativelanguage.googleapis.com/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('generativelanguage_googleapis_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('generativelanguage_googleapis_com'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('generativelanguage_googleapis_com'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('generativelanguage_googleapis_com'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('generativelanguage_googleapis_com'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('generativelanguage_googleapis_com'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('generativelanguage_googleapis_com'),'')
);
wwv_flow_imp.component_end;
end;
/
