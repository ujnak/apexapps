prompt --application/shared_components/user_interface/lovs/cached_contents_lov
begin
--   Manifest
--     CACHED_CONTENTS_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(26625396051793967)
,p_lov_name=>'CACHED_CONTENTS_LOV'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(26443402865641620)
,p_return_column_name=>'NAME'
,p_display_column_name=>'DISPLAY_NAME'
,p_default_sort_column_name=>'DISPLAY_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41127790235514
);
wwv_flow_imp.component_end;
end;
/
