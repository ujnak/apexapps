prompt --application/shared_components/web_sources/google_gemini_files
begin
--   Manifest
--     WEB SOURCE: Google Gemini Files
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(26448097283641634)
,p_name=>'Google Gemini Files'
,p_static_id=>'GOOGLE_GEMINI_FILES'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(26444827971641627)
,p_remote_server_id=>wwv_flow_imp.id(24603187718951626)
,p_url_path_prefix=>'/v1beta/files'
,p_credential_id=>wwv_flow_imp.id(23969360392615230)
,p_pass_ecid=>true
,p_version_scn=>41127790584950
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(26449512825641638)
,p_web_src_module_id=>wwv_flow_imp.id(26448097283641634)
,p_name=>'pageSize'
,p_param_type=>'QUERY_STRING'
,p_data_type=>'NUMBER'
,p_is_required=>false
,p_value=>'100'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(26448315192641635)
,p_web_src_module_id=>wwv_flow_imp.id(26448097283641634)
,p_operation=>'POST'
,p_database_operation=>'INSERT'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(26448766352641636)
,p_web_src_module_id=>wwv_flow_imp.id(26448097283641634)
,p_operation=>'DELETE'
,p_database_operation=>'DELETE'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(26449182613641636)
,p_web_src_module_id=>wwv_flow_imp.id(26448097283641634)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
