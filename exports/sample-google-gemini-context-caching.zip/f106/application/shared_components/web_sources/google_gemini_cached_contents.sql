prompt --application/shared_components/web_sources/google_gemini_cached_contents
begin
--   Manifest
--     WEB SOURCE: Google Gemini Cached Contents
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(26443402865641620)
,p_name=>'Google Gemini Cached Contents'
,p_static_id=>'GOOGLE_GEMINI_CACHED_CONTENTS'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(26441104458641613)
,p_remote_server_id=>wwv_flow_imp.id(24603187718951626)
,p_url_path_prefix=>'v1beta/cachedContents'
,p_credential_id=>wwv_flow_imp.id(23969360392615230)
,p_pass_ecid=>true
,p_version_scn=>41127790584950
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(26443639888641622)
,p_web_src_module_id=>wwv_flow_imp.id(26443402865641620)
,p_operation=>'DELETE'
,p_database_operation=>'DELETE'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(26444020689641624)
,p_web_src_module_id=>wwv_flow_imp.id(26443402865641620)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(26444466492641625)
,p_web_src_module_id=>wwv_flow_imp.id(26443402865641620)
,p_operation=>'POST'
,p_database_operation=>'INSERT'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
);
wwv_flow_imp.component_end;
end;
/
