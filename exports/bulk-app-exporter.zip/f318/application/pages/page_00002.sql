prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>318
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Export'
,p_alias=>'EXPORT'
,p_step_title=>'Export'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.actions.add(',
'    [',
'        {',
'            name: "set-column-value-all",',
'            action: (event, element, args) => {',
'                const grid  = apex.region(args.grid).call("getViews","grid");  ',
'                const model = grid.model; ',
'                let rec;',
unistr('                /* **\8868\793A\3055\308C\3066\3044\308B** \3059\3079\3066\306E\884C\3067\7E70\308A\8FD4\3059 */'),
'                model.forEach( (row) => {',
unistr('                    /* \5148\982D\5217\306F\4E3B\30AD\30FC\3001\3064\307E\308AAPPLICATION_ID */'),
'                    rec = model.getRecord(row[0]);',
'                    model.setValue(rec, args.column, args.value);',
'                });',
'            }',
'        }',
'    ]',
');'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240201023610'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37775761417266121)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38792830615313821)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39074552926387788)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38848902862313855)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38733249014313753)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38911339243313916)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39075252438387792)
,p_plug_name=>'Export'
,p_region_name=>'export-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38826715109313843)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    application_id',
'    ,''N'' as export',
'    ,''N'' as overwrite',
'    ,application_name',
'    ,alias',
'    ,owner',
'    ,application_group',
'    ,version',
'    ,created_by',
'    ,created_on',
'    ,last_updated_by',
'    ,last_updated_on',
'    ,application_comment',
'    ,is_working_copy',
'from apex_applications ',
'where workspace_id = :workspace_id'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Export'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39076551934387798)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
,p_required_patch=>wwv_flow_imp.id(38732684148313749)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39077078463387798)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_required_patch=>wwv_flow_imp.id(38732684148313749)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39078043965387814)
,p_name=>'APPLICATION_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APPLICATION_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39079041041387816)
,p_name=>'EXPORT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EXPORT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Export'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39080063180387817)
,p_name=>'OVERWRITE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OVERWRITE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Overwrite'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39081092667387818)
,p_name=>'APPLICATION_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APPLICATION_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Application Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>true
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39082070069387819)
,p_name=>'ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ALIAS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Alias'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>true
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39083011203387820)
,p_name=>'OWNER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OWNER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>true
,p_max_length=>128
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39084072903387820)
,p_name=>'APPLICATION_GROUP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APPLICATION_GROUP'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Application Group'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39085059328387821)
,p_name=>'VERSION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VERSION'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Version'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39086058089387823)
,p_name=>'CREATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_BY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Created By'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39087095011387825)
,p_name=>'CREATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_ON'
,p_data_type=>'DATE'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Created On'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39088018513387826)
,p_name=>'LAST_UPDATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED_BY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Last Updated By'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39089097485387828)
,p_name=>'LAST_UPDATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED_ON'
,p_data_type=>'DATE'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Last Updated On'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39090026775387829)
,p_name=>'APPLICATION_COMMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APPLICATION_COMMENT'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'CLOB'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Application Comment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39091077862387831)
,p_name=>'IS_WORKING_COPY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IS_WORKING_COPY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Is Working Copy'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_max_length=>3
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(39075754844387793)
,p_internal_uid=>39075754844387793
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(39076184169387795)
,p_interactive_grid_id=>wwv_flow_imp.id(39075754844387793)
,p_static_id=>'390762'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(39076379770387796)
,p_report_id=>wwv_flow_imp.id(39076184169387795)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39077476096387800)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(39077078463387798)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39078487538387814)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(39078043965387814)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39079475343387816)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(39079041041387816)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39080492672387817)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(39080063180387817)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39081477500387818)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(39081092667387818)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39082424698387819)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(39082070069387819)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39083402329387820)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(39083011203387820)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39084484702387821)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(39084072903387820)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39085444207387822)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(39085059328387821)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39086485805387823)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(39086058089387823)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39087417348387825)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(39087095011387825)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39088421110387826)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(39088018513387826)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39089453165387828)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(39089097485387828)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39090443158387830)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(39090026775387829)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39091492428387831)
,p_view_id=>wwv_flow_imp.id(39076379770387796)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(39091077862387831)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37775812913266122)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(37775761417266121)
,p_button_name=>'EXPORT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38909714254313915)
,p_button_image_alt=>'Export'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37776074461266124)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(37775761417266121)
,p_button_name=>'CHECK_ALL_EXPORT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38909714254313915)
,p_button_image_alt=>'Check All Export'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$set-column-value-all?grid=export-grid&column=EXPORT&value=Y"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37776169387266125)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(37775761417266121)
,p_button_name=>'UNCHECK_ALL_EXPORT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38909714254313915)
,p_button_image_alt=>'Unheck All Export'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$set-column-value-all?grid=export-grid&column=EXPORT&value=N"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37776226301266126)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(37775761417266121)
,p_button_name=>'CHECK_ALL_OVERWRITE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38909714254313915)
,p_button_image_alt=>'Check All Overwrite'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$set-column-value-all?grid=export-grid&column=OVERWRITE&value=Y"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37776350824266127)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(37775761417266121)
,p_button_name=>'UNCHECK_ALL_OVERWRITE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38909714254313915)
,p_button_image_alt=>'Unheck All Overwrite'
,p_warn_on_unsaved_changes=>null
,p_button_cattributes=>'data-action="#action$set-column-value-all?grid=export-grid&column=OVERWRITE&value=N"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(37775927063266123)
,p_branch_name=>unistr('\30DA\30FC\30B8\306E\30EA\30ED\30FC\30C9')
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(37775812913266122)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39092042451387832)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(39075252438387792)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Export - \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\30A2\30C3\30D7\30ED\30FC\30C9')
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_app_export apex_t_export_files;',
'    l_zip_export blob;',
'    l_request_url varchar2(4000);',
'    l_response    clob;',
'    e_upload_failed exception;',
'begin',
'    if :APEX$ROW_STATUS <> ''U'' then',
unistr('        /* \66F4\65B0\884C\306E\307F\306E\306F\305A\3060\304C\5FF5\306E\305F\3081\4ED6\306E\72B6\614B\306F\9664\5916\3059\308B\3002 */'),
'        return;',
'    end if;',
'    if :EXPORT <> ''Y'' then',
unistr('        /* EXPORT\304C\30C1\30A7\30C3\30AF\3055\308C\3066\3044\306A\3044\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306F\30A8\30AF\30B9\30DD\30FC\30C8\3057\306A\3044\3002 */'),
'        return;',
'    end if;',
unistr('    /* \30A2\30C3\30D7\30ED\30FC\30C9\5148\3068\306A\308BURL\3092\4F5C\6210\3059\308B\3002 */'),
'    l_request_url := apex_string.format(''https://objectstorage.%s.oraclecloud.com/n/%s/b/%s/o/%s.zip'',',
'        :G_REGION, :G_NAMESPACE, :G_BUCKET, utl_url.escape(lower(:ALIAS), false, ''AL32UTF8'')',
'    );',
unistr('    /* OVERWRITE\304C\30C1\30A7\30C3\30AF\3055\308C\3066\3044\306A\3044\5834\5408\3001\4E0A\66F8\304D\3092\56DE\907F\3059\308B\3002 */'),
'    if :OVERWRITE <> ''Y'' then',
'        apex_web_service.clear_request_headers();',
'        l_response := apex_web_service.make_rest_request(',
'            p_url          => l_request_url',
'            ,p_http_method => ''HEAD''',
'            ,p_credential_static_id => :G_CREDENTIAL',
'        );',
'        if apex_web_service.g_status_code = 200 then',
'            apex_debug.info(''Export exists, %s, id %s'', :ALIAS, :APPLICATION_ID);',
unistr('            /* \3059\3067\306B\5B58\5728\3059\308B\306E\3067\30A2\30C3\30D7\30ED\30FC\30C9\305B\305A\306B\51E6\7406\3092\7D42\4E86\3059\308B\3002 */'),
'            return;',
'        end if;',
'    end if;',
'    /*',
unistr('    \3000\3000* ZIP\5F62\5F0F\3067\30A8\30AF\30B9\30DD\30FC\30C8\3059\308B\3002'),
'     * Ref: https://docs.oracle.com/en/database/oracle/apex/23.2/aeapi/GET_APPLICATION_Function.html',
'     *',
unistr('     * \5F15\6570\306E\6307\5B9A\306B\3088\308A\30A8\30AF\30B9\30DD\30FC\30C8\306B\542B\307E\308C\308B\5185\5BB9\304C\5909\308F\308B\305F\3081\3001\8981\4EF6\306B\5408\308F\305B\3066\5909\66F4\3059\308B\3002'),
'     */',
'    apex_debug.info(''Start export application %s, id %s'', :ALIAS, :APPLICATION_ID);',
'    l_app_export := apex_export.get_application(',
'        p_application_id => :APPLICATION_ID',
'        ,p_split                   => TRUE',
unistr('        ,p_with_date               => FALSE /* \30A8\30AF\30B9\30DD\30FC\30C8\65E5\3092\9664\5916 */'),
unistr('        ,p_with_ir_public_reports  => FALSE /* \30E6\30FC\30B6\30FC\304C\4FDD\5B58\3057\305F\30D1\30D6\30EA\30C3\30AF\30FB\30EC\30DD\30FC\30C8\3092\9664\5916 */'),
unistr('        ,p_with_ir_private_reports => FALSE /* \30E6\30FC\30B6\30FC\306E\30D7\30E9\30A4\30D9\30FC\30C8\30FB\30EC\30DD\30FC\30C8\3082\9664\5916 */'),
'        ,p_with_ir_notifications   => FALSE',
unistr('        ,p_with_translations       => TRUE  /* \7FFB\8A33\306F\542B\3081\308B */'),
'        ,p_with_original_ids       => TRUE',
unistr('        ,p_with_no_subscriptions   => TRUE /* \30B5\30D6\30B9\30AF\30EA\30D7\30B7\30E7\30F3\306F\9664\5916\3059\308B */'),
'        ,p_with_comments           => TRUE',
'        ,p_with_supporting_objects => ''Y''',
'        ,p_with_acl_assignments    => TRUE',
'    );',
'    /*',
unistr('     * \5206\5272\3055\308C\3066\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\305F\30D5\30A1\30A4\30EB\3092ZIP\FF08BLOB)\306B\56FA\3081\308B\3002'),
'     */',
'    l_zip_export := apex_export.zip(',
'        p_source_files => l_app_export',
'    );',
'    /*',
unistr('     * \30AA\30D6\30B8\30A7\30AF\30C8\30FB\30B9\30C8\30EC\30FC\30B8\306B\30A2\30C3\30D7\30ED\30FC\30C9\3059\308B\3002'),
'     */',
'    apex_debug.info(''Upload export to %s, bytes %s'', l_request_url, dbms_lob.getlength(l_zip_export));   ',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/zip'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url          => l_request_url',
'        ,p_http_method => ''PUT''',
'        ,p_body_blob   => l_zip_export',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_upload_failed;',
'    end if;',
'    apex_debug.info(''End export application %s'', :ALIAS);',
'end;'))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37775812913266122)
,p_internal_uid=>39092042451387832
);
wwv_flow_imp.component_end;
end;
/
