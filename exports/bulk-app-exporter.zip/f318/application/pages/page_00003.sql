prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>318
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Import'
,p_alias=>'IMPORT'
,p_step_title=>'Import'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240201043559'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37776912509266133)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38792830615313821)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39135900090412637)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38848902862313855)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38733249014313753)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38911339243313916)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39136681359412638)
,p_plug_name=>'Import'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38826715109313843)
,p_plug_display_sequence=>20
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(39111811298146252)
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select MD5,',
'       ''N'' as IMPORT,',
'       ''N'' as OVERWRITE,',
'       ETAG,',
'       NAME,',
'       SIZE_,',
'       TIMECREATED,',
'       TIMEMODIFIED',
'  from #APEX$SOURCE_DATA#'))
,p_source_post_processing=>'SQL'
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Import'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37776741095266131)
,p_name=>'IMPORT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMPORT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Import'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37776832627266132)
,p_name=>'OVERWRITE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OVERWRITE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Overwrite'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39137983298412640)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
,p_required_patch=>wwv_flow_imp.id(38732684148313749)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39138415148412640)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_required_patch=>wwv_flow_imp.id(38732684148313749)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39139401544412642)
,p_name=>'MD5'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MD5'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39140499959412642)
,p_name=>'ETAG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ETAG'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Etag'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39141438901412643)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39142400653412644)
,p_name=>'SIZE_'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SIZE_'
,p_data_type=>'NUMBER'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Size '
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39143440223412645)
,p_name=>'TIMECREATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIMECREATED'
,p_data_type=>'TIMESTAMP_TZ'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Timecreated'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39144425103412646)
,p_name=>'TIMEMODIFIED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIMEMODIFIED'
,p_data_type=>'TIMESTAMP_TZ'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Timemodified'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_item_attributes=>'readonly'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(39137126912412639)
,p_internal_uid=>39137126912412639
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(39137560371412639)
,p_interactive_grid_id=>wwv_flow_imp.id(39137126912412639)
,p_static_id=>'391376'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(39137726911412640)
,p_report_id=>wwv_flow_imp.id(39137560371412639)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39138833298412641)
,p_view_id=>wwv_flow_imp.id(39137726911412640)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(39138415148412640)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39139848560412642)
,p_view_id=>wwv_flow_imp.id(39137726911412640)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(39139401544412642)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39140807039412643)
,p_view_id=>wwv_flow_imp.id(39137726911412640)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(39140499959412642)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39141882864412644)
,p_view_id=>wwv_flow_imp.id(39137726911412640)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(39141438901412643)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39142823888412644)
,p_view_id=>wwv_flow_imp.id(39137726911412640)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(39142400653412644)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39143857735412645)
,p_view_id=>wwv_flow_imp.id(39137726911412640)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(39143440223412645)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39144847209412646)
,p_view_id=>wwv_flow_imp.id(39137726911412640)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(39144425103412646)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39148178581469969)
,p_view_id=>wwv_flow_imp.id(39137726911412640)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(37776741095266131)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39149018687469973)
,p_view_id=>wwv_flow_imp.id(39137726911412640)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(37776832627266132)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(39145837238412647)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(39112813308146257)
,p_page_plug_id=>wwv_flow_imp.id(39136681359412638)
,p_value_type=>'STATIC'
,p_value=>'&G_BUCKET.'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(39146368748412647)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(39113288746146258)
,p_page_plug_id=>wwv_flow_imp.id(39136681359412638)
,p_value_type=>'DEFAULT'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(39146899669412648)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(39112454074146257)
,p_page_plug_id=>wwv_flow_imp.id(39136681359412638)
,p_value_type=>'STATIC'
,p_value=>'&G_NAMESPACE.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37777015972266134)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(37776912509266133)
,p_button_name=>'IMPORT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38909714254313915)
,p_button_image_alt=>'Import'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39145430783412646)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(39136681359412638)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('Import - \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306E\30A4\30F3\30DD\30FC\30C8')
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
' * Ref: Building a REST API to Deploy APEX Apps',
' * https://blogs.oracle.com/apex/post/building-a-rest-api-to-deploy-apex-apps',
' */',
'declare',
'    l_request_url varchar2(400);',
'    l_zip_file    blob;',
'    l_app_files   apex_zip.t_files;',
'    l_files       apex_t_export_files := apex_t_export_files();',
'    l_new_app_id  number;',
'    e_download_object_failed exception;',
'begin',
'    if :APEX$ROW_STATUS <> ''U'' then',
unistr('        /* \66F4\65B0\884C\306E\307F\306E\306F\305A\3060\304C\5FF5\306E\305F\3081\4ED6\306E\72B6\614B\306F\9664\5916\3059\308B\3002 */'),
'        return;',
'    end if;',
'    if :IMPORT <> ''Y'' then',
unistr('        /* IMPORT\304C\30C1\30A7\30C3\30AF\3055\308C\3066\3044\306A\3044\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306F\9664\5916\3059\308B\3002 */'),
'        return;',
'    end if;',
'    /*',
unistr('     * Object Storage\304B\3089ZIP\30D5\30A1\30A4\30EB\3092\53D6\5F97\3059\308B\3002'),
'     */',
'    l_request_url := apex_string.format(''https://objectstorage.%s.oraclecloud.com/n/%s/b/%s/o/%s'',',
'        :G_REGION, :G_NAMESPACE, :G_BUCKET, utl_url.escape(lower(:NAME), false, ''AL32UTF8'')',
'    );',
'    apex_debug.info(''Download application export from %s'', l_request_url);',
'    apex_web_service.clear_request_headers();',
'    l_zip_file := apex_web_service.make_rest_request_b(',
'        p_url => l_request_url',
'        ,p_http_method => ''GET''',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_download_object_failed;',
'    end if;',
'    apex_debug.info(''Download success: %s, size %s'', :NAME, dbms_lob.getlength(l_zip_file));',
'    /*',
unistr('     * ZIP\30D5\30A1\30A4\30EB\3092\5C55\958B\3059\308B\3002'),
'     */',
'    l_app_files := apex_zip.get_files( ',
'        p_zipped_blob => l_zip_file,',
'        p_only_files  => true',
'    );',
'    l_files.extend( l_app_files.count );',
'    for i in 1 .. l_app_files.count',
'    loop',
'        l_files(i) := apex_t_export_file( ',
'                            l_app_files(i),',
'                            apex_util.blob_to_clob( ',
'                                apex_zip.get_file_content( ',
'                                    p_zipped_blob => l_zip_file,',
'                                    p_file_name   => l_app_files(i)',
'                                )',
'                            )',
'                        );',
'    end loop;',
'    /*',
unistr('     * \672A\4F7F\7528\306E\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3ID\3092\53D6\5F97\3059\308B\3002'),
'     */',
'    select max(application_id) + 1 into l_new_app_id',
'    from apex_applications;',
'    /*',
unistr('     * \4E88\7D04\3055\308C\3066\3044\308B\756A\53F7\3067\3042\308C\3070\30019000\306B\3059\308B\3002'),
'     */',
'    if l_new_app_id between 3000 and 8999 then',
'        l_new_app_id := 9000;',
'    end if;',
'    /*',
unistr('     * \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\3092\30A4\30F3\30DD\30FC\30C8\3059\308B\3002'),
'     *',
unistr('     * SET_APPLICATION_ALIAS, SET_APPLICATION_NAME\306E\547C\3073\51FA\3057\3082\8981\691C\8A0E\3002'),
'     */',
'    apex_application_install.set_application_id( ',
'        p_application_id => l_new_app_id);',
'    apex_application_install.install( ',
'        p_source             => l_files,',
'        /* ',
unistr('         * \30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306B\306F\5FC5\305A\7A7A\3044\3066\3044\308B\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3ID\304C\5272\308A\5F53\305F\308B'),
unistr('         * \305F\3081\3001\4E0A\66F8\304D\3092Y\306B\3059\308B\5FC5\8981\304C\306A\3044\3002'),
'         */',
'        p_overwrite_existing => (:OVERWRITE = ''Y'') );',
'end;'))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(37777015972266134)
,p_internal_uid=>39145430783412646
);
wwv_flow_imp.component_end;
end;
/
