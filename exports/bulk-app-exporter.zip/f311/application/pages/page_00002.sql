prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>311
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Export'
,p_alias=>'EXPORT'
,p_step_title=>'Export'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240131065214'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37422552071492946)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37234790872486624)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37119035104486557)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37297191334486661)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37423244636492951)
,p_plug_name=>'Export'
,p_region_name=>'export-grid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37212555279486612)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    application_id',
'    ,''N'' as export',
'    ,''N'' as overwrite',
'    ,application_name',
'    ,alias',
'    ,owner',
'    ,application_group',
'    ,version',
'    ,created_by',
'    ,created_on',
'    ,last_updated_by',
'    ,last_updated_on',
'    ,application_comment',
'    ,is_working_copy',
'from apex_applications ',
'where workspace_id = :workspace_id'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Export'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(34802252346281436)
,p_name=>'EXPORT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EXPORT'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Export'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>1730
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(34802901958281443)
,p_name=>'OVERWRITE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OVERWRITE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'Overwrite'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>1740
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37424579262492957)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
,p_required_patch=>wwv_flow_imp.id(37118471770486556)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37425011350492958)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_required_patch=>wwv_flow_imp.id(37118471770486556)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37427914058492964)
,p_name=>'APPLICATION_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APPLICATION_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37428918331492965)
,p_name=>'APPLICATION_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APPLICATION_NAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Application Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37429960181492966)
,p_name=>'ALIAS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ALIAS'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Alias'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37430912686492967)
,p_name=>'OWNER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OWNER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>128
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37431994810492968)
,p_name=>'APPLICATION_GROUP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APPLICATION_GROUP'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Application Group'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37462945142492997)
,p_name=>'VERSION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VERSION'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Version'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>400
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37480910533493014)
,p_name=>'CREATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_BY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Created By'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>580
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37481971461493015)
,p_name=>'CREATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_ON'
,p_data_type=>'DATE'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Created On'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>590
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37482930797493016)
,p_name=>'LAST_UPDATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED_BY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Last Updated By'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>600
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37483960758493017)
,p_name=>'LAST_UPDATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED_ON'
,p_data_type=>'DATE'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Last Updated On'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>610
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37590997725493116)
,p_name=>'APPLICATION_COMMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'APPLICATION_COMMENT'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'CLOB'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Application Comment'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>1680
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37594952516493119)
,p_name=>'IS_WORKING_COPY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IS_WORKING_COPY'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Is Working Copy'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>1720
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>3
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(37423733526492952)
,p_internal_uid=>37423733526492952
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(37424146757492954)
,p_interactive_grid_id=>wwv_flow_imp.id(37423733526492952)
,p_static_id=>'374242'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(37424376125492955)
,p_report_id=>wwv_flow_imp.id(37424146757492954)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37425412172492959)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(37425011350492958)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37428346304492964)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(37427914058492964)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37429331235492966)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(37428918331492965)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37430332664492967)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(37429960181492966)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37431325593492967)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(37430912686492967)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37432348052492968)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(37431994810492968)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37463376837492998)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>38
,p_column_id=>wwv_flow_imp.id(37462945142492997)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37481358165493014)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>56
,p_column_id=>wwv_flow_imp.id(37480910533493014)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37482326663493016)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>57
,p_column_id=>wwv_flow_imp.id(37481971461493015)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37483342312493017)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>58
,p_column_id=>wwv_flow_imp.id(37482930797493016)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37484302138493018)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>59
,p_column_id=>wwv_flow_imp.id(37483960758493017)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37591360947493116)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>166
,p_column_id=>wwv_flow_imp.id(37590997725493116)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37595321422493120)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>170
,p_column_id=>wwv_flow_imp.id(37594952516493119)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37754827936678726)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>172
,p_column_id=>wwv_flow_imp.id(34802252346281436)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(37767379195182430)
,p_view_id=>wwv_flow_imp.id(37424376125492955)
,p_display_seq=>173
,p_column_id=>wwv_flow_imp.id(34802901958281443)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37773886577266102)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37158570295486581)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(34802021959281434)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(37773886577266102)
,p_button_name=>'EXPORT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37295552359486660)
,p_button_image_alt=>'Export'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(34803623125281450)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(37773886577266102)
,p_button_name=>'CHECK_ALL_EXPORT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37295552359486660)
,p_button_image_alt=>'Check All Export'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37774332029266107)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(37773886577266102)
,p_button_name=>'UNCHECK_ALL_EXPORT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37295552359486660)
,p_button_image_alt=>'Uncheck All Export'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37773771932266101)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(37773886577266102)
,p_button_name=>'CHECK_ALL_OVERWRITE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37295552359486660)
,p_button_image_alt=>'Check All Overwrite'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37774844343266112)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(37773886577266102)
,p_button_name=>'UNCHECK_ALL_OVERWRITE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37295552359486660)
,p_button_image_alt=>'Unheck All Overwrite'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(34802874230281442)
,p_branch_name=>'Force Reload'
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(34802021959281434)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34803279826281446)
,p_name=>'onChage Export'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_EXPORT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34803329356281447)
,p_event_id=>wwv_flow_imp.id(34803279826281446)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(37423244636492951)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37774147754266105)
,p_name=>'onClick Check All Export'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(34803623125281450)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37774223955266106)
,p_event_id=>wwv_flow_imp.id(37774147754266105)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let grid        = apex.region(''export-grid'').call(''getViews'',''grid'');  ',
'var model       = grid.model; ',
'model.forEach( (row) => {',
'    let rec = model.getRecord(row[0]);',
'    model.setValue(rec, "EXPORT", "Y");',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34803440798281448)
,p_name=>'onChange Overwite'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_OVERWRITE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34803513696281449)
,p_event_id=>wwv_flow_imp.id(34803440798281448)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(37423244636492951)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37774438144266108)
,p_name=>'onClick Uncheck All Export'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(37774332029266107)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37774511847266109)
,p_event_id=>wwv_flow_imp.id(37774438144266108)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let grid        = apex.region(''export-grid'').call(''getViews'',''grid'');  ',
'var model       = grid.model; ',
'model.forEach( (row) => {',
'    let rec = model.getRecord(row[0]);',
'    model.setValue(rec, "EXPORT", "N");',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37774623541266110)
,p_name=>'onClick Check All Overwrite'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(37773771932266101)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37774754137266111)
,p_event_id=>wwv_flow_imp.id(37774623541266110)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let grid        = apex.region(''export-grid'').call(''getViews'',''grid'');  ',
'var model       = grid.model; ',
'model.forEach( (row) => {',
'    let rec = model.getRecord(row[0]);',
'    model.setValue(rec, "OVERWRITE", "Y");',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37774982264266113)
,p_name=>'onClick Uncheck All Overwrite'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(37774844343266112)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37775009030266114)
,p_event_id=>wwv_flow_imp.id(37774982264266113)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let grid        = apex.region(''export-grid'').call(''getViews'',''grid'');  ',
'var model       = grid.model; ',
'model.forEach( (row) => {',
'    let rec = model.getRecord(row[0]);',
'    model.setValue(rec, "OVERWRITE", "N");',
'});'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(34801925628281433)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(37423244636492951)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'App Export'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_app_export apex_t_export_files;',
'    l_zip_export blob;',
'    l_request_url varchar2(4000);',
'    l_file_name   varchar2(400);',
'    l_response    clob;',
'    e_upload_failed exception;',
'begin',
'    if :EXPORT <> ''Y'' then',
unistr('        -- EXPORT\304C\9078\629E\3055\308C\3066\3044\306A\3044\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\306F\30A8\30AF\30B9\30DD\30FC\30C8\3057\306A\3044\3002'),
'        return;',
'    end if;',
'    /*',
unistr('     * \30A2\30C3\30D7\30ED\30FC\30C9\5148\3092\78BA\8A8D\3059\308B\3002'),
'     */',
'    l_file_name := utl_url.escape(lower(:ALIAS), false, ''AL32UTF8'') || ''.zip'';',
'    l_request_url := :G_BUCKET_URL || ''o/'' || l_file_name;',
'    /*',
unistr('     * \4E0A\66F8\304D\3092\56DE\907F\3059\308B\3002'),
'     */',
'    if :OVERWRITE <> ''Y'' then',
'        apex_web_service.clear_request_headers();',
'        l_response := apex_web_service.make_rest_request(',
'            p_url          => l_request_url',
'            ,p_http_method => ''HEAD''',
'            ,p_credential_static_id => :G_CREDENTIAL',
'        );',
'        if apex_web_service.g_status_code = 200 then',
'            apex_debug.info(''Export already exist, %s, id %s'', :ALIAS, :APPLICATION_ID);',
unistr('            /* \3059\3067\306B\5B58\5728\3059\308B\306E\3067\30A2\30C3\30D7\30ED\30FC\30C9\3057\306A\3044\3002 */'),
'            return;',
'        end if;',
'    end if;',
'    /*',
unistr('    \3000\3000* ZIP\5F62\5F0F\3067\30A8\30AF\30B9\30DD\30FC\30C8\3059\308B\3002'),
'     * Ref: https://docs.oracle.com/en/database/oracle/apex/23.2/aeapi/GET_APPLICATION_Function.html',
'     *',
unistr('     * \5F15\6570\306E\6307\5B9A\306B\3088\308A\30A8\30AF\30B9\30DD\30FC\30C8\306B\542B\307E\308C\308B\5185\5BB9\304C\5909\308F\308B\305F\3081\3001\8981\4EF6\306B\5408\308F\305B\3066\5909\66F4\3059\308B\3002'),
'     */',
'    apex_debug.info(''Start exporting application %s, id %s'', :ALIAS, :APPLICATION_ID);',
'    l_app_export := apex_export.get_application(',
'        p_application_id => :APPLICATION_ID',
'        ,p_split                   => TRUE',
unistr('        ,p_with_date               => FALSE /* \30A8\30AF\30B9\30DD\30FC\30C8\65E5\3092\9664\5916 */'),
unistr('        ,p_with_ir_public_reports  => FALSE /* \30E6\30FC\30B6\30FC\304C\4FDD\5B58\3057\305F\30D1\30D6\30EA\30C3\30AF\30FB\30EC\30DD\30FC\30C8\3092\9664\5916 */'),
unistr('        ,p_with_ir_private_reports => FALSE /* \30E6\30FC\30B6\30FC\306E\30D7\30E9\30A4\30D9\30FC\30C8\30FB\30EC\30DD\30FC\30C8\3082\9664\5916 */'),
'        ,p_with_ir_notifications   => FALSE',
unistr('        ,p_with_translations       => TRUE  /* \7FFB\8A33\306F\542B\3081\308B */'),
'        ,p_with_original_ids       => TRUE',
unistr('        ,p_with_no_subscriptions   => TRUE /* \30B5\30D6\30B9\30AF\30EA\30D7\30B7\30E7\30F3\306F\9664\5916\3059\308B */'),
'        ,p_with_comments           => TRUE',
'        ,p_with_supporting_objects => ''Y''',
'        ,p_with_acl_assignments    => TRUE',
'    );',
'    /*',
unistr('     * \5206\5272\3055\308C\3066\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\305F\30D5\30A1\30A4\30EB\3092ZIP\FF08BLOB)\306B\56FA\3081\308B\3002'),
'     */',
'    l_zip_export := apex_export.zip(',
'        p_source_files => l_app_export',
'    );',
'    /*',
unistr('     * \30AA\30D6\30B8\30A7\30AF\30C8\30FB\30B9\30C8\30EC\30FC\30B8\306B\30A2\30C3\30D7\30ED\30FC\30C9\3059\308B\3002'),
'     */',
'    apex_debug.info(''Upload export file to %s, bytes %s'', l_request_url, dbms_lob.getlength(l_zip_export));   ',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/zip'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url          => l_request_url',
'        ,p_http_method => ''PUT''',
'        ,p_body_blob   => l_zip_export',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_upload_failed;',
'    end if;',
'    apex_debug.info(''End exporting application %s'', :ALIAS);',
'end;'))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(34802021959281434)
,p_internal_uid=>34801925628281433
);
wwv_flow_imp.component_end;
end;
/
