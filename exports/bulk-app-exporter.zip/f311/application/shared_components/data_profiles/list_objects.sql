prompt --application/shared_components/data_profiles/list_objects
begin
--   Manifest
--     DATA PROFILE: List Objects
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>311
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(37831993290499174)
,p_name=>'List Objects'
,p_format=>'JSON'
,p_row_selector=>'objects'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(37832167470499175)
,p_data_profile_id=>wwv_flow_imp.id(37831993290499174)
,p_name=>'MD5'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'md5'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(37832445430499175)
,p_data_profile_id=>wwv_flow_imp.id(37831993290499174)
,p_name=>'ETAG'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'etag'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(37832793987499175)
,p_data_profile_id=>wwv_flow_imp.id(37831993290499174)
,p_name=>'NAME'
,p_sequence=>3
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'name'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(37833065758499175)
,p_data_profile_id=>wwv_flow_imp.id(37831993290499174)
,p_name=>'SIZE_'
,p_sequence=>4
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_has_time_zone=>false
,p_selector=>'size'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(37833335966499176)
,p_data_profile_id=>wwv_flow_imp.id(37831993290499174)
,p_name=>'TIMECREATED'
,p_sequence=>5
,p_column_type=>'DATA'
,p_data_type=>'TIMESTAMP WITH TIME ZONE'
,p_format_mask=>'YYYY"-"MM"-"DD"T"HH24":"MI:SS.FF9TZR'
,p_has_time_zone=>true
,p_selector=>'timeCreated'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(37833620340499176)
,p_data_profile_id=>wwv_flow_imp.id(37831993290499174)
,p_name=>'TIMEMODIFIED'
,p_sequence=>6
,p_column_type=>'DATA'
,p_data_type=>'TIMESTAMP WITH TIME ZONE'
,p_format_mask=>'YYYY"-"MM"-"DD"T"HH24":"MI:SS.FF9TZR'
,p_has_time_zone=>true
,p_selector=>'timeModified'
);
wwv_flow_imp.component_end;
end;
/
