prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.3'
,p_default_workspace_id=>9659628319127220
,p_default_application_id=>150
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\6CD5\4EE4')
,p_alias=>'HOME'
,p_step_title=>unistr('e-Gov\6CD5\4EE4')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>\30C7\30FC\30BF\3092\898B\3064\3051\308B\306B\306F\3001\691C\7D22\30C0\30A4\30A2\30ED\30B0\306B\691C\7D22\6587\5B57\5217\3092\5165\529B\3059\308B\304B\3001\5217\30D8\30C3\30C0\30FC\3092\30AF\30EA\30C3\30AF\3057\3066\623B\3055\308C\308B\30EC\30B3\30FC\30C9\3092\5236\9650\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30A2\30AF\30B7\30E7\30F3\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\591A\304F\306E\6A5F\80FD\3092\5B9F\884C\3067\304D\307E\3059\3002\3053\308C\306B\306F\3001\8868\793A\5217\307E\305F\306F\975E\8868\793A\5217\306E\9078\629E\3068\305D\306E\8868\793A\9806\5E8F\306B\52A0\3048\3001\591A\304F\306E\30C7\30FC\30BF\304A\3088\3073\66F8\5F0F\8A2D\5B9A\6A5F\80FD\304C\542B\307E\308C\307E\3059\3002\30C1\30E3\30FC\30C8\3001\30B0\30EB\30FC\30D7\5316\304A\3088\3073\30D4\30DC\30C3\30C8\30FB\30AA\30D7\30B7\30E7\30F3\3092\4F7F\7528\3057\3066\3001\30C7\30FC\30BF\306E\8FFD\52A0\30D3\30E5\30FC\3092\5B9A\7FA9\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\72EC\81EA\306E\30AB\30B9\30BF\30DE\30A4\30BA\5185\5BB9\3092\4FDD\5B58\3059\308B\5834\5408\3001\30EC\30DD\30FC\30C8\3092\9078\629E\3059\308B\304B\3001\300C\30C0\30A6\30F3\30ED\30FC\30C9\300D\3092\30AF\30EA\30C3\30AF\3057\3066\30C7\30FC\30BF\3092\30A2\30F3\30ED\30FC\30C9\3057\307E\3059\3002\5B9A\671F\7684\306B\30C7\30FC\30BF\3092\9001\4FE1\3059\308B\30B5\30D6\30B9\30AF\30EA\30D7\30B7\30E7\30F3\3067\96FB\5B50\30E1\30FC\30EB\30FB\30A2\30C9\30EC\30B9\3068\6642\9593\67A0\3092\5165\529B\3057\307E\3059\3002<p>'),
'',
unistr('<p>\8FFD\52A0\60C5\5831\3092\5165\624B\3059\308B\306B\306F\3001\300C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\306E\4E00\756A\4E0B\306E\300C\30D8\30EB\30D7\300D\3092\30AF\30EA\30C3\30AF\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30EA\30BB\30C3\30C8\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\5BFE\8A71\30E2\30FC\30C9\30FB\30EC\30DD\30FC\30C8\3092\30C7\30D5\30A9\30EB\30C8\8A2D\5B9A\306B\623B\3059\3053\3068\304C\3067\304D\307E\3059\3002</p>')))
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46132680671340040)
,p_plug_name=>unistr('\9032\6357')
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from APEX_APPL_PAGE_BG_PROC_STATUS',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(46132712740340041)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>46132712740340041
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46132809686340042)
,p_db_column_name=>'WORKSPACE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Workspace'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46132927512340043)
,p_db_column_name=>'WORKSPACE_DISPLAY_NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Workspace Display Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46133008255340044)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46133188775340045)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46133237360340046)
,p_db_column_name=>'WORKING_COPY_NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Working Copy Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46133366083340047)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46133463932340048)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46133586922340049)
,p_db_column_name=>'EXECUTION_ID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Execution Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46133608277340050)
,p_db_column_name=>'PROCESS_ID'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Process Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46529872376254901)
,p_db_column_name=>'PROCESS_NAME'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Process Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46529945026254902)
,p_db_column_name=>'SERIAL_EXECUTION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Serial Execution'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46530019883254903)
,p_db_column_name=>'CURRENT_PROCESS_ID'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Current Process Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46530109185254904)
,p_db_column_name=>'CURRENT_PROCESS_NAME'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Current Process Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46530293960254905)
,p_db_column_name=>'CURRENT_PROCESS_SEQUENCE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Current Process Sequence'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46530364561254906)
,p_db_column_name=>'PROCESS_TYPE_PLUGIN_NAME'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Process Type Plugin Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46530402451254907)
,p_db_column_name=>'SESSION_ID'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Session Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46530573631254908)
,p_db_column_name=>'WORKING_SESSION_ID'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Working Session Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46530689113254909)
,p_db_column_name=>'REQUEST'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Request'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46530703015254910)
,p_db_column_name=>'ECID'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Ecid'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46530870717254911)
,p_db_column_name=>'CONTEXT_VALUE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Context Value'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46530956874254912)
,p_db_column_name=>'STATUS'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46531093167254913)
,p_db_column_name=>'STATUS_CODE'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Status Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46531195737254914)
,p_db_column_name=>'STATUS_MESSAGE'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Status Message'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46531206810254915)
,p_db_column_name=>'SOFAR'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Sofar'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46531320309254916)
,p_db_column_name=>'TOTALWORK'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Totalwork'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46531431784254917)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46531594377254918)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Last Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(46544447751266802)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'465445'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WORKSPACE:WORKSPACE_DISPLAY_NAME:APPLICATION_ID:APPLICATION_NAME:WORKING_COPY_NAME:PAGE_ID:PAGE_NAME:EXECUTION_ID:PROCESS_ID:PROCESS_NAME:SERIAL_EXECUTION:CURRENT_PROCESS_ID:CURRENT_PROCESS_NAME:CURRENT_PROCESS_SEQUENCE:PROCESS_TYPE_PLUGIN_NAME:SESSI'
||'ON_ID:WORKING_SESSION_ID:REQUEST:ECID:CONTEXT_VALUE:STATUS:STATUS_CODE:STATUS_MESSAGE:SOFAR:TOTALWORK:CREATED_ON:LAST_UPDATED_ON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46485836957150110)
,p_plug_name=>'Data'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>60
,p_query_type=>'TABLE'
,p_query_table=>'JLAW_DATA'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>unistr('\6CD5\4EE4')
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(46485983985150110)
,p_name=>unistr('\6CD5\4EE4')
,p_max_row_count_message=>unistr('\3053\306E\30EC\30DD\30FC\30C8\306E\6700\5927\884C\6570\306F#MAX_ROW_COUNT#\884C\3067\3059\3002\30D5\30A3\30EB\30BF\3092\9069\7528\3057\3066\3001\554F\5408\305B\306E\30EC\30B3\30FC\30C9\6570\3092\524A\6E1B\3057\3066\304F\3060\3055\3044\3002')
,p_no_data_found_message=>unistr('\30C7\30FC\30BF\304C\898B\3064\304B\308A\307E\305B\3093\3002')
,p_allow_save_rpt_public=>'Y'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>46485983985150110
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46486612564150115)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46487035334150116)
,p_db_column_name=>'LAW_TYPE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Law Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46487443987150116)
,p_db_column_name=>'LAW_NUMBER'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Law Number'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46487821476150116)
,p_db_column_name=>'LAW_TITLE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Law Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46488293883150116)
,p_db_column_name=>'LAW_TITLE_KANA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Law Title Kana'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46488618334150116)
,p_db_column_name=>'LAW_TITLE_FORMER'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Law Title Former'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46489075663150116)
,p_db_column_name=>'PROMULGATION_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Promulgation Date'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46489481285150116)
,p_db_column_name=>'LAW_TITLE_AMMENDED'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Law Title Ammended'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46489832225150116)
,p_db_column_name=>'LAW_NUMBER_AMMENDED'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Law Number Ammended'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46490223592150116)
,p_db_column_name=>'PROMULGATION_DATE_AMMENDED'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Promulgation Date Ammended'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46490610375150116)
,p_db_column_name=>'ENFORCEMENT_DATE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Enforcement Date'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46491024279150116)
,p_db_column_name=>'ENFORCEMENT_DATE_REMARK'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Enforcement Date Remark'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46491441049150116)
,p_db_column_name=>'LAW_ID'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Law ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46491857626150116)
,p_db_column_name=>'BODY_URL'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Body URL'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46492297159150116)
,p_db_column_name=>'NOT_IN_FORCE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Not In Force'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(46492656703150117)
,p_db_column_name=>'BODY_HASH'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Body Hash'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(46494857920150121)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'464949'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:LAW_TYPE:LAW_NUMBER:LAW_TITLE:LAW_TITLE_KANA:LAW_TITLE_FORMER:PROMULGATION_DATE:LAW_TITLE_AMMENDED:LAW_NUMBER_AMMENDED:PROMULGATION_DATE_AMMENDED:ENFORCEMENT_DATE:ENFORCEMENT_DATE_REMARK:LAW_ID:BODY_URL:NOT_IN_FORCE:BODY_HASH:'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46493915628150117)
,p_plug_name=>unistr('e-Gov\6CD5\4EE4')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46531907000254922)
,p_button_sequence=>20
,p_button_name=>'UPLOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46132595514340039)
,p_button_sequence=>40
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Load'
,p_confirm_message=>unistr('\6CD5\4EE4\30C7\30FC\30BF\3092\30ED\30FC\30C9\3057\307E\3059\304B\FF1F')
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46493075114150117)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(46485836957150110)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>unistr('\30EA\30BB\30C3\30C8')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46132437985340038)
,p_name=>'P1_URL'
,p_item_sequence=>30
,p_prompt=>'URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'URL',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46531899349254921)
,p_name=>'P1_FILE'
,p_item_sequence=>10
,p_prompt=>'File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'display_as', 'INLINE',
  'file_types', 'application/zip',
  'purge_file_at', 'REQUEST',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46531627403254919)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>unistr('\6CD5\4EE4\30C7\30FC\30BF\306E\30ED\30FC\30C9')
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'MOVE'
,p_attribute_05=>'P1_FILE'
,p_attribute_09=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'LOAD UPLOAD'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>46531627403254919
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46531736797254920)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(46531627403254919)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load e-Gov CSV and XML'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_blob_zip blob;',
'    l_blob_csv blob;',
'    l_blob_xml blob;',
'    l_clob_xml clob;',
'    l_new_hash raw(32);',
'    l_old_hash raw(32);',
'    e_web_access_failed exception;',
'    l_files apex_zip.t_files;',
'    l_load_result apex_data_loading.t_data_load_result;',
'    l_total_laws number;',
'    l_id varchar2(4000);',
'    l_xml xmltype;',
'    l_skipped number := 0;',
'    l_ignored number := 0;',
'    l_updated number := 0;',
'    l_message varchar2(100);',
'begin',
'    if :REQUEST = ''LOAD'' then',
'        /*',
unistr('        * URL\3067\6307\5B9A\3055\308C\305F\6CD5\4EE4\7A2E\5225\30C7\30FC\30BF\30BB\30C3\30C8\3092\53D6\5F97\3059\308B\3002ZIP\5F62\5F0F\306E\30D0\30A4\30CA\30EA\3002'),
'        */',
'        apex_background_process.set_status(''Start: downloading zip'');',
'        apex_web_service.set_request_headers(''Content-Type'', ''application/zip'');',
'        l_blob_zip := apex_web_service.make_rest_request_b(',
'            p_url => :P1_URL',
'            ,p_http_method => ''GET''',
'        );',
'        if apex_web_service.g_status_code <> 200 then',
'            raise e_web_access_failed;',
'        end if;',
'        apex_debug.info(''Download Completed.'');',
'        apex_background_process.set_status(''Completed: downloading zip'');',
'    elsif :REQUEST = ''UPLOAD'' then',
'        /*',
unistr('        * P1_FILE\3067\9078\629E\3057\305F\30D5\30A1\30A4\30EB\3092\53D6\308A\51FA\3059\3002'),
'        */',
'        select blob_content into l_blob_zip from apex_application_temp_files',
'        where name = :P1_FILE;',
'    end if;',
'    /*',
unistr('     * ZIP\30A2\30FC\30AB\30A4\30D6\306B\542B\307E\308C\308B\30D5\30A1\30A4\30EB\4E00\89A7\3092\53D6\5F97\3059\308B\3002'),
'     */',
'    l_files := apex_zip.get_files(',
'        p_zipped_blob => l_blob_zip',
'    );',
'    /*',
unistr('     * ZIP\30A2\30FC\30AB\30A4\30D6\306B\542B\307E\308C\308BCSV\30D5\30A1\30A4\30EB\3092\898B\3064\3051\3001\8868JLAW_DATA\306B\30ED\30FC\30C9\3059\308B\3002'),
'     */',
'    apex_background_process.set_status(''Start: load CSV in zip'');',
'    for i in 1..l_files.count',
'    loop',
'        /*',
unistr('        \3000\3000* \542B\307E\308C\3066\3044\308BCSV\30D5\30A1\30A4\30EB\306F\FF11\3064\3060\3051\306A\306F\305A\3002'),
'         */',
'        if l_files(i) like ''%.csv'' then',
'            apex_debug.info(''file %s found.'', l_files(i));',
'            l_blob_csv := apex_zip.get_file_content(',
'                p_zipped_blob => l_blob_zip',
'                ,p_file_name => l_files(i)',
'            );',
'            l_load_result := apex_data_loading.load_data(',
'                p_static_id    => ''LOAD_CSV''',
'                ,p_data_to_load => l_blob_csv',
'            );',
'            l_total_laws := l_load_result.processed_rows;',
'            apex_debug.info( ''Processed %s rows.'', l_total_laws);',
unistr('            exit; -- CSV\304C\30ED\30FC\30C9\3067\304D\308C\3070\4EE5\964D\306F\30B9\30AD\30C3\30D7\3057\3066XML\306E\30ED\30FC\30C9\306B\79FB\308B\3002'),
'        end if;',
'    end loop;',
'    apex_debug.info(''CSV Load Complated.'');',
'    apex_background_process.set_status(''Completed: load CSV in zip'');',
'    /*',
unistr('     * ZIP\306B\542B\307E\308C\3066\3044\308BXML\3092\8868JLAW_DATA\306B\66F4\65B0\3059\308B\3002'),
'     */',
'    apex_background_process.set_status(''Start: load XML files in zip'');',
'    for i in 1..l_files.count',
'    loop',
'        if l_files(i) like ''%.xml'' then',
'            l_blob_xml := apex_zip.get_file_content(',
'                p_zipped_blob => l_blob_zip',
'                ,p_file_name => l_files(i)',
'            );',
unistr('            /* \6CD5\4EE4\306EXML\30D5\30A1\30A4\30EB\306F\30C7\30A3\30EC\30AF\30C8\30EA\540D\3068\30D5\30A1\30A4\30EB\540D\304C\540C\3058\3002 */'),
'            l_id := replace(l_files(i),''.xml'');',
'            l_id := substr(l_id, instr(l_id,''/'')+1);',
unistr('            /* BLOB\3092XMLtype\306B\5909\63DB */'),
'            l_xml := xmltype(',
'                xmlData => l_blob_xml',
'                ,csid =>  NLS_CHARSET_ID(''AL32UTF8'') ',
'            );',
unistr('            /* \30CF\30C3\30B7\30E5\5024\306E\8A08\7B97 */'),
'            l_clob_xml := l_xml.getClobVal();',
'            l_new_hash := sys.dbms_crypto.hash(l_clob_xml, dbms_crypto.HASH_SH256);',
'            begin',
'                select body_hash into l_old_hash from jlaw_data where id = l_id;',
unistr('                /* \30CF\30C3\30B7\30E5\5024\304C\4E00\81F4\3057\3066\3044\308C\3070\66F4\65B0\3057\306A\3044\3002 */'),
'                if l_old_hash = l_new_hash then',
'                    l_skipped := l_skipped + 1;',
'                else    ',
'                    l_updated := l_updated + 1;',
'                    update jlaw_data set body = l_xml, body_hash = l_new_hash where id = l_id;',
'                    if mod(l_updated, 200) = 0 then',
unistr('                        commit; -- 200\884C\30A2\30C3\30D7\30C7\30FC\30C8\3054\3068\306B\30B3\30DF\30C3\30C8\3059\308B\3002'),
'                        apex_debug.info(''XML Load Commited.'');',
'                    end if;',
'                end if;',
'            exception',
'                when no_data_found then',
unistr('                    /* CSV\306B\30A8\30F3\30C8\30EA\304C\306A\3044\306E\306BXML\306F\3042\308B\306E\306F\7570\5E38\3002 */'),
'                    l_ignored := l_ignored + 1;',
'                    apex_debug.info(''id %s not in CSV.'', l_id);',
'            end;',
'            apex_background_process.set_progress(p_sofar => i ,p_totalwork => l_total_laws);',
'        end if;',
'    end loop;',
'    commit;',
'    l_message := apex_string.format(''Completed: updated %s, skipped %s, ignored %s'', l_updated, l_skipped, l_ignored);',
'    apex_background_process.set_status(l_message);',
'    apex_debug.info(l_message);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>46531736797254920
);
wwv_flow_imp.component_end;
end;
/
