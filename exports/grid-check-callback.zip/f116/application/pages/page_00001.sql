prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.4'
,p_default_workspace_id=>7329869927659841
,p_default_application_id=>116
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(22867992522604505)
,p_name=>'EMP'
,p_alias=>'HOME'
,p_step_title=>'Grid Check Callback'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>\3053\306E\5BFE\8A71\30B0\30EA\30C3\30C9\5185\3067\30C7\30FC\30BF\3092\76F4\63A5\633F\5165\3001\66F4\65B0\304A\3088\3073\524A\9664\3067\304D\307E\3059\3002<br>'),
unistr('  \300C\884C\306E\8FFD\52A0\300D\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\65B0\3057\3044\884C\3092\633F\5165\3067\304D\307E\3059\3002<br>'),
unistr('  \30BB\30EB\5185\3092\30C0\30D6\30EB\30AF\30EA\30C3\30AF\3059\308B\304B\3001<strong>\300C\7DE8\96C6\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\30B9\30D7\30EC\30C3\30C9\30B7\30FC\30C8\3067\30C7\30FC\30BF\3092\7DE8\96C6\3059\308B\5834\5408\3068\540C\3058\3088\3046\306B\30C7\30FC\30BF\5024\3092\66F4\65B0\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30EC\30DD\30FC\30C8\306E\4E00\756A\4E0A\306B\3042\308B\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC(<span class="fa fa-bars" aria-hidden="true"></span>)\3092\4F7F\7528\3057\3066\3001\9078\629E\3057\305F\884C\3092\8907\88FD\3001\524A\9664\3001\30EA\30D5\30EC\30C3\30B7\30E5\307E\305F\306F\56DE\5FA9\3057\307E\3059\3002<br>'),
unistr('  \500B\3005\306E\884C\306E\300C\884C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\3092\4F7F\7528\3057\3066\3001\5358\4E00\884C\30D3\30E5\30FC\306B\30A2\30AF\30BB\30B9\3057\305F\308A\3001\65B0\3057\3044\884C\3092\8FFD\52A0\3057\305F\308A\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\30C7\30FC\30BF\3092\898B\3064\3051\308B\306B\306F\3001\691C\7D22\30C0\30A4\30A2\30ED\30B0\306B\691C\7D22\6587\5B57\5217\3092\5165\529B\3059\308B\304B\3001\5217\30D8\30C3\30C0\30FC\3092\30AF\30EA\30C3\30AF\3057\3066\623B\3055\308C\308B\30EC\30B3\30FC\30C9\3092\5236\9650\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30A2\30AF\30B7\30E7\30F3\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\591A\304F\306E\6A5F\80FD\3092\5B9F\884C\3067\304D\307E\3059\3002\3053\308C\306B\306F\3001\8868\793A\5217\307E\305F\306F\975E\8868\793A\5217\306E\9078\629E\3068\305D\306E\8868\793A\9806\5E8F\306B\52A0\3048\3001\591A\304F\306E\30C7\30FC\30BF\304A\3088\3073\66F8\5F0F\8A2D\5B9A\6A5F\80FD\304C\542B\307E\308C\307E\3059\3002\30C1\30E3\30FC\30C8\30FB\30AA\30D7\30B7\30E7\30F3\3092\4F7F\7528\3057\3066\3001\30C7\30FC\30BF\306E\8FFD\52A0\30D3\30E5\30FC\3092\5B9A\7FA9\3059\308B\3053\3068\3082\3067\304D\307E\3059\3002</p>'),
'',
unistr('<p>\72EC\81EA\306E\30AB\30B9\30BF\30DE\30A4\30BA\5185\5BB9\3092\4FDD\5B58\3059\308B\5834\5408\3001\30EC\30DD\30FC\30C8\3092\9078\629E\3059\308B\304B\3001\300C\30C0\30A6\30F3\30ED\30FC\30C9\300D\3092\30AF\30EA\30C3\30AF\3057\3066\30C7\30FC\30BF\3092\30A2\30F3\30ED\30FC\30C9\3057\307E\3059\3002<p>'),
'',
unistr('<p>\8FFD\52A0\60C5\5831\3092\5165\624B\3059\308B\306B\306F\3001\300C\30A2\30AF\30B7\30E7\30F3\300D\30E1\30CB\30E5\30FC\306E\4E00\756A\4E0B\306E\300C\30D8\30EB\30D7\300D\3092\30AF\30EA\30C3\30AF\3057\307E\3059\3002</p>'),
'',
unistr('<p><strong>\300C\30EA\30BB\30C3\30C8\300D</strong>\30DC\30BF\30F3\3092\30AF\30EA\30C3\30AF\3059\308B\3068\3001\5BFE\8A71\30B0\30EA\30C3\30C9\3092\30C7\30D5\30A9\30EB\30C8\8A2D\5B9A\306B\623B\3059\3053\3068\304C\3067\304D\307E\3059\3002</p>')))
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20220901081349'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22877787973604560)
,p_plug_name=>'Employees'
,p_region_name=>'emp'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(22765582720604418)
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'EMP'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'EMP'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22879048362604567)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22879586069604568)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>unistr('\30A2\30AF\30B7\30E7\30F3')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22880507611604571)
,p_name=>'EMPNO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMPNO'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_heading=>'Empno'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22881501761604573)
,p_name=>'ENAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ENAME'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Employee Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22882580348604574)
,p_name=>'JOB'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JOB'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Job'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22883582901604574)
,p_name=>'MGR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MGR'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Manager'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(22889151798604582)
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22884551125604575)
,p_name=>'HIREDATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HIREDATE'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_JET'
,p_heading=>'Hired'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22885513404604576)
,p_name=>'SAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SAL'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Salary'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_format_mask=>'999G999G999G999G999G999G999G999G999G990'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22886586146604576)
,p_name=>'COMM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMM'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Commission'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>90
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_format_mask=>'9990'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22887528207604577)
,p_name=>'DEPTNO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DEPTNO'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Department'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(22888495054604579)
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(22878270985604561)
,p_internal_uid=>22878270985604561
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
'  options.defaultModelOptions = {',
'    check: (result, operation, record, addAction, recordsToAdd) => {',
unistr('      // \7DE8\96C6\53EF\80FD\306A\3068\304D\306E\307Fcheck\3092\884C\3046\3002'),
'      if (!result) {',
'        return result;',
'      }',
unistr('      // \7DE8\96C6\30E2\30FC\30C9\FF08\524A\9664\3067\306F\306A\3044)\306E\3068\304D\306E\307Fcheck\3092\884C\3046\3002'),
'      if (operation !== "canEdit") {',
'        return result;',
'      }',
unistr('      // \7DE8\96C6\5BFE\8C61\306E\30EC\30B3\30FC\30C9\304C\5B58\5728\3059\308B\3068\304D\306E\307Fcheck\3092\884C\3046\3002'),
'      if (record === undefined || record === null) {',
'        return result;',
'      };',
unistr('      // model\3001id\3001meta, fields\3092\6E96\5099\3059\308B\3002'),
'      let grid = apex.region("emp").call("getViews","grid");',
'      let model = grid.model;',
'      let id = model.getRecordId(record),',
'          meta = model.getRecordMetadata(id); ',
'      let fields = meta.fields;',
'',
unistr('      // RecordFieldMetadata\3092\521D\671F\5316\3059\308B\3002'),
'      // https://docs.oracle.com/en/database/oracle/apex/22.1/aexjs/model.html#.RecordFieldMetadata',
'      if (!fields) {',
'        fields = meta.fields = {};',
'      }',
unistr('      // \7DE8\96C6\53EF/\4E0D\53EF\3092\8A2D\5B9A\3059\308B\5217SAL\3001COMM\306E\30E1\30BF\30C7\30FC\30BF\304C\7121\3051\308C\3070\521D\671F\5316\3059\308B\3002'),
'      if (!fields["SAL"]) {',
'        fields["SAL"] = {};',
'      }',
'      if (!fields["COMM"]) {',
'        fields["COMM"] = {};',
'      }',
'',
unistr('      // \4E0A\53F8\306E\5024\3092\53D6\5F97\3057\3001\4E0A\53F8\304C\8A2D\5B9A\3055\308C\3066\3044\306A\3051\308C\3070\5217SAL\3001COMM\3068\3082\306B\7DE8\96C6\4E0D\53EF\306B\3059\308B\3002'),
'      let mgr = record[model.getFieldKey("MGR")];',
'      if (mgr.d == "") {',
'        fields["SAL"].ck = 1;',
'        fields["COMM"].ck = 1;',
'      }',
'      else',
'      {',
'        fields["SAL"].ck = "";',
'        fields["COMM"].ck = "";',
'      }',
unistr('      // \305D\308C\4EE5\5916\306F\7DE8\96C6\53EF\80FD\306A\306E\3067true\3092\8FD4\3059\3002'),
'      return true;',
'    }',
'  }',
'  return options;',
'}'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(22878601867604563)
,p_interactive_grid_id=>wwv_flow_imp.id(22878270985604561)
,p_static_id=>'228787'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(22878887005604565)
,p_report_id=>wwv_flow_imp.id(22878601867604563)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(22879992378604569)
,p_view_id=>wwv_flow_imp.id(22878887005604565)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(22879586069604568)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(22880922853604572)
,p_view_id=>wwv_flow_imp.id(22878887005604565)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(22880507611604571)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(22881955791604573)
,p_view_id=>wwv_flow_imp.id(22878887005604565)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(22881501761604573)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(22882991211604574)
,p_view_id=>wwv_flow_imp.id(22878887005604565)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(22882580348604574)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(22883910989604575)
,p_view_id=>wwv_flow_imp.id(22878887005604565)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(22883582901604574)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(22884997776604575)
,p_view_id=>wwv_flow_imp.id(22878887005604565)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(22884551125604575)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(22885949628604576)
,p_view_id=>wwv_flow_imp.id(22878887005604565)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(22885513404604576)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(22886950552604576)
,p_view_id=>wwv_flow_imp.id(22878887005604565)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(22886586146604576)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(22887950540604577)
,p_view_id=>wwv_flow_imp.id(22878887005604565)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(22887528207604577)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22890431767604583)
,p_plug_name=>'Grid Check Callback'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(22742398961604407)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15861351678947340)
,p_tabular_form_region_id=>wwv_flow_imp.id(22877787973604560)
,p_validation_name=>unistr('\7D66\4E0E\306E\5909\66F4\7981\6B62')
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sal0  emp.sal%type;',
'    l_sal1  emp.sal%type;',
'begin',
'    if :APEX$ROW_STATUS = ''U'' and :MGR is null then',
unistr('        -- \5909\66F4\524D\306E\30C7\30FC\30BF\306E\53D6\5F97'),
'        select sal into l_sal0 from emp where empno = :EMPNO;',
unistr('        -- \5909\66F4\5F8C\306E\30C7\30FC\30BF\306E\53D6\5F97'),
'        select to_number(:SAL, format_mask)  into l_sal1  from APEX_APPL_PAGE_IG_COLUMNS',
'        where application_id = :APP_ID and page_id = :APP_PAGE_ID and name = ''SAL'';',
unistr('        -- \524D\5F8C\3092\6BD4\8F03\3057\3066\5909\66F4\304C\306A\3044\3068\304D\306Btrue\3092\8FD4\3059\3002'),
'        if',
'        (l_sal0 is not null and l_sal1 is not null and l_sal0 = l_sal1) or (l_sal0 is null and l_sal1 is null) ',
'        then',
'            return true;',
'        end if;',
'        return false;',
'    end if;',
'    return true;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('\4E0A\53F8\306E\3044\306A\3044\5F93\696D\54E1\306E\7D66\4E0E\306F\5909\66F4\3067\304D\307E\305B\3093\3002')
,p_associated_column=>'SAL'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15861441248947341)
,p_tabular_form_region_id=>wwv_flow_imp.id(22877787973604560)
,p_validation_name=>unistr('\624B\5F53\306E\5909\66F4\7981\6B62')
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_comm0  emp.sal%type;',
'    l_comm1  emp.sal%type;',
'begin',
'    if :APEX$ROW_STATUS = ''U'' and :MGR is null then',
unistr('        -- \5909\66F4\524D\306E\30C7\30FC\30BF\306E\53D6\5F97'),
'        select comm into l_comm0 from emp where empno = :EMPNO;',
unistr('        -- \5909\66F4\5F8C\306E\30C7\30FC\30BF\306E\53D6\5F97'),
'        select to_number(:COMM, format_mask)  into l_comm1  from APEX_APPL_PAGE_IG_COLUMNS',
'        where application_id = :APP_ID and page_id = :APP_PAGE_ID and name = ''COMM'';',
unistr('        -- \524D\5F8C\3092\6BD4\8F03\3057\3066\5909\66F4\304C\306A\3044\3068\304D\306Btrue\3092\8FD4\3059\3002'),
'        if',
'        (l_comm0 is not null and l_comm1 is not null and l_comm0 = l_comm1) or (l_comm0 is null and l_comm1 is null) ',
'        then',
'            return true;',
'        end if;',
'        return false;',
'    end if;',
'    return true;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('\4E0A\53F8\306E\3044\306A\3044\5F93\696D\54E1\306E\624B\5F53\306F\5909\66F4\3067\304D\307E\305B\3093\3002')
,p_associated_column=>'COMM'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22889958574604582)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(22877787973604560)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('EMP - \5BFE\8A71\30B0\30EA\30C3\30C9\30FB\30C7\30FC\30BF\306E\4FDD\5B58')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
