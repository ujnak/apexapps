prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 136
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>136
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000B7494441545847637CDB68F79F610001E3A8034643603404464360D087C08BDF1C0C1CC2920CDFFF33330829E9629499EFEE5D';
wwv_flow_imp.g_varchar2_table(2) := '66E064FC8BB52CFDFDFE058328F377BCE52CC192F0E16F6E067E6131880394F5301D70F7124E077C7CFB8A419EF52B650EF8C0A7C820A6A4C5F099819D41C4361CC3B037875732F032FCC46AC9AB7BD718043EDD1FE20E40890212D3C0F08882D14438E0';
wwv_flow_imp.g_varchar2_table(3) := 'B9603411A214C524968454298A69DD602658178C3A6034044643603404681D020033BADF8146D7D5C30000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(40535792722604651)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
