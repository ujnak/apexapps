prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>308
,p_default_id_offset=>23779389793247009
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Chat'
,p_alias=>'CHAT'
,p_step_title=>'Chat'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20231224052316'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(20641551859011948)
,p_name=>'Chat History'
,p_template=>wwv_flow_imp.id(47173434618024471)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'select c001, c002, clob001 from apex_collections where collection_name = ''GEMINI'' order by seq_id'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(47207468919024495)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(20641696545011949)
,p_query_column_id=>1
,p_column_alias=>'C001'
,p_column_display_sequence=>10
,p_column_heading=>'role'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(20641753990011950)
,p_query_column_id=>2
,p_column_alias=>'C002'
,p_column_display_sequence=>20
,p_column_heading=>'type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23798352433634501)
,p_query_column_id=>3
,p_column_alias=>'CLOB001'
,p_column_display_sequence=>30
,p_column_heading=>'text'
,p_heading_alignment=>'LEFT'
,p_display_as=>'RICH_TEXT'
,p_attribute_01=>'MARKDOWN'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23796633309393930)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(47185873239024479)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(47070093660024348)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(47248254569024542)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20640971207011942)
,p_button_sequence=>10
,p_button_name=>'INIT_CONVERSATION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(47246675192024540)
,p_button_image_alt=>'Initialize Conversation'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(20641335969011946)
,p_button_sequence=>40
,p_button_name=>'RUN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(47246675192024540)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Run'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20641114737011944)
,p_name=>'P6_TEXT'
,p_data_type=>'CLOB'
,p_item_sequence=>20
,p_prompt=>'Text'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20641289876011945)
,p_name=>'P6_FUNCTION_SET'
,p_item_sequence=>30
,p_prompt=>'Function Set'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select function_set_name d, function_set_name r from gemini_functions group by function_set_name order by 1 asc'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('- \30D5\30A1\30F3\30AF\30B7\30E7\30F3\30FB\30BB\30C3\30C8\3092\9078\629E -')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(47244114613024533)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(20641036411011943)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Initialize Conversation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.create_or_truncate_collection(',
'    p_collection_name => ''GEMINI''',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(20640971207011942)
,p_internal_uid=>20641036411011943
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(20641449699011947)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Run Conversation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_user_text clob := :P6_TEXT;',
'    l_functioin_set_name varchar2(40) := :P6_FUNCTION_SET;',
'    -- ',
'    l_contents json_array_t := json_array_t();',
'    l_contents_clob clob;',
'    l_content  json_object_t;',
'    l_parts    json_array_t;',
'    l_part     json_object_t;',
'    -- function calling',
'    l_functions  json_array_t;',
'    l_function   json_object_t;',
'    l_parameters json_object_t;',
'    l_tools      json_array_t;',
'    l_tools_clob clob;',
'    l_tool       json_object_t;',
'    -- response',
'    l_candidates json_array_t;',
'    l_prompt_feedback json_object_t;',
'    l_response clob;',
'    l_reply    clob;',
'    l_role     varchar2(8);',
'begin',
'    /*',
unistr('    \3000\3000* add user input first.'),
'     */',
'    if l_user_text is not null then',
'        apex_collection.add_member(',
'            p_collection_name => ''GEMINI''',
'            ,p_c001 => ''user''',
'            ,p_c002 => ''text''',
'            ,p_clob001 => l_user_text',
'        );',
'    end if;',
'    /*',
unistr('    \3000\3000* reconstruct chat history from apex collection.'),
'     */',
'    for r in (select c001, c002, clob001 from apex_collections where collection_name = ''GEMINI'' order by seq_id)',
'    loop',
'        l_content := json_object_t();',
'        l_content.put(''role'',r.c001);',
'        l_part := json_object_t();',
'        case r.c002',
'        when ''text'' then',
'            l_part.put(''text'', r.clob001);',
'        else',
'            l_part.put(r.c002, json_object_t(r.clob001));',
'        end case;',
'        l_parts := json_array_t();',
'        l_parts.append(l_part);',
'        l_content.put(''parts'', l_parts);',
'        l_contents.append(l_content);',
'    end loop;',
'    l_contents_clob := l_contents.to_clob();',
'    -- prepare tools',
'    if l_functioin_set_name is not null then',
'        l_functions := json_array_t();',
'        for r in (',
'            select * from gemini_functions where function_set_name = l_functioin_set_name',
'        )',
'        loop',
'            l_function := json_object_t();',
'            l_function.put(''name'', r.function_name);',
'            l_function.put(''description'', r.description);',
'            l_parameters := json_object_t(r.parameters);',
'            l_function.put(''parameters'', l_parameters);',
'            l_functions.append(l_function);',
'        end loop;',
'        l_tool := json_object_t();',
'        l_tool.put(''function_declarations'', l_functions);',
'        l_tools := json_array_t();',
'        l_tools.append(l_tool);',
'        l_tools_clob := l_tools.to_clob();',
'    else',
'        l_tools_clob := null;',
'    end if;  ',
'    -- apex_debug.info(l_contents_clob);',
'    utl_google_gemini_api.generate_content(',
'        p_contents         => l_contents_clob',
'        ,p_tools           => l_tools_clob',
'        ,p_candidates      => l_candidates',
'        ,p_prompt_feedback => l_prompt_feedback',
'        ,p_response        => l_response',
'        ,p_credential_static_id => :G_CREDENTIAL',
'    );',
'    apex_debug.info(l_response);',
'    l_part := utl_google_gemini_api.get_first_part(',
'        p_candidates => l_candidates',
'        ,p_role => l_role',
'    );',
'    l_reply := l_part.get_string(''text'');',
'    if l_reply is null then',
'        /* append functionCall to chat history. */',
'        apex_collection.add_member(',
'            p_collection_name => ''GEMINI''',
'            ,p_c001 => l_role',
'            ,p_c002 => ''functionCall''',
'            ,p_clob001 => l_part.get_object(''functionCall'').to_clob()',
'        );',
'        /* call external function */',
'        l_reply := utl_google_gemini_api.call_function(',
'            p_part => l_part',
'        );',
'        /* append functionResponse to chat history */',
'        apex_collection.add_member(',
'            p_collection_name => ''GEMINI''',
'            ,p_c001 => ''function''',
'            ,p_c002 => ''functionResponse''',
'            ,p_clob001 => l_reply',
'        );',
'    else',
'        apex_collection.add_member(',
'            p_collection_name => ''GEMINI''',
'            ,p_c001 => l_role',
'            ,p_c002 => ''text''',
'            ,p_clob001 => l_reply',
'        );',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(20641335969011946)
,p_internal_uid=>20641449699011947
);
wwv_flow_imp.component_end;
end;
/
