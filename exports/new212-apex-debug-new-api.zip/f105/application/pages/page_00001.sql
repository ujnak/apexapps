prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>2600578355011914
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'APEXDEV'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(32448614973006576)
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('APEX_DEBUG\78BA\8A8D')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20211122125436'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3412973926248440)
,p_plug_name=>unistr('APEX_DEBUG\78BA\8A8D')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(32347086249006486)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from apex_debug_messages',
'where workspace_id = :WORKSPACE_ID',
'  and application_id = :APP_ID',
'  and page_id = :APP_PAGE_ID',
'  and session_id = :APP_SESSION'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('APEX_DEBUG\78BA\8A8D')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(3413054227248441)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>true
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'APEXDEV'
,p_internal_uid=>3413054227248441
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413189310248442)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413207447248443)
,p_db_column_name=>'PAGE_VIEW_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Page View Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413350759248444)
,p_db_column_name=>'MESSAGE_TIMESTAMP'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Message Timestamp'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413408297248445)
,p_db_column_name=>'ELAPSED_TIME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Elapsed Time'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413518263248446)
,p_db_column_name=>'EXECUTION_TIME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Execution Time'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413655083248447)
,p_db_column_name=>'MESSAGE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Message'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413725023248448)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413845561248449)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3413914726248450)
,p_db_column_name=>'SESSION_ID'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Session Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32460251051023501)
,p_db_column_name=>'APEX_USER'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Apex User'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32460371379023502)
,p_db_column_name=>'MESSAGE_LEVEL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Message Level'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32460424075023503)
,p_db_column_name=>'WORKSPACE_ID'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Workspace Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(32460509856023504)
,p_db_column_name=>'CALL_STACK'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Call Stack'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(32470478464026968)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'324705'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:PAGE_VIEW_ID:MESSAGE_TIMESTAMP:ELAPSED_TIME:EXECUTION_TIME:MESSAGE:APPLICATION_ID:PAGE_ID:SESSION_ID:APEX_USER:MESSAGE_LEVEL:WORKSPACE_ID:CALL_STACK'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32458057151006630)
,p_plug_name=>unistr('APEX_DEBUG\78BA\8A8D')
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(32329273365006478)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32460834198023507)
,p_name=>'P1_MESSAGE'
,p_item_sequence=>10
,p_prompt=>unistr('\30E1\30C3\30BB\30FC\30B8')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(32421447012006538)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(3412803207248439)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('\30E1\30C3\30BB\30FC\30B8\51FA\529B')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_region_id apex_application_page_ir.region_id%type;',
'begin',
'    apex_debug.enable;',
unistr('    apex_debug.error(''\3053\306E\4F4D\7F6E\3067\30A8\30E9\30FC\304C\767A\751F\3057\307E\3057\305F\3002'');'),
unistr('    :P1_MESSAGE := ''\3053\306E\4F4D\7F6E\3067\30A8\30E9\30FC\304C\767A\751F\3057\307E\3057\305F\3002 Id = '' || apex_debug.get_last_message_id || '),
'        '', Page View Id = '' || apex_debug.get_page_view_id;',
'    apex_debug.disable;',
'    /*',
unistr('    -- \5BFE\8A71\30E2\30FC\30C9\30FB\30EC\30DD\30FC\30C8\306B\30D5\30A3\30EB\30BF\3092\8A2D\5B9A\3059\308B\3002'),
'    select region_id into l_region_id from apex_application_page_ir',
'    where application_id = :APP_ID and page_id = :APP_PAGE_ID;',
unistr('    -- and region_name = ''APEX_DEBUG\78BA\8A8D'';'),
unistr('    -- \5BFE\8A71\30E2\30FC\30C9\30FB\30EC\30DD\30FC\30C8\306E\30EA\30BB\30C3\30C8'),
'    apex_ir.reset_report(',
'        p_page_id => :APP_PAGE_ID',
'        , p_region_id => l_region_id',
'        , p_report_id => null',
'    );',
'    apex_ir.add_filter(',
'        p_page_id => :APP_PAGE_ID',
'        , p_region_id => l_region_id',
'        , p_report_column => ''PAGE_VIEW_ID''',
'        , p_filter_value => apex_debug.get_page_view_id',
'        , p_operator_abbr => ''EQ''',
'        , p_report_id => null',
'    );',
'    apex_ir.add_filter(',
'        p_page_id => :APP_PAGE_ID',
'        , p_region_id => l_region_id',
'        , p_report_column => ''ID''',
'        , p_filter_value => apex_debug.get_last_message_id',
'        , p_operator_abbr => ''EQ''',
'        , p_report_id => null',
'    );',
'    */',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
