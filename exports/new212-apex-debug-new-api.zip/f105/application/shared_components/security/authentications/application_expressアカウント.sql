prompt --application/shared_components/security/authentications/application_expressアカウント
begin
--   Manifest
--     AUTHENTICATION: Application Expressアカウント
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>2600578355011914
,p_default_application_id=>105
,p_default_id_offset=>0
,p_default_owner=>'APEXDEV'
);
wwv_flow_api.create_authentication(
 p_id=>wwv_flow_api.id(32260214913006413)
,p_name=>unistr('Application Express\30A2\30AB\30A6\30F3\30C8')
,p_scheme_type=>'NATIVE_APEX_ACCOUNTS'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_api.component_end;
end;
/
