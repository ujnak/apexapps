prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2138965587838225
,p_default_application_id=>100
,p_default_id_offset=>3314860552955130
,p_default_owner=>'APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Chat with GenAI'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20240419091719'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64071328990898492)
,p_plug_name=>'System Message'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(64429679680495931)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>'select * from apex_collections where collection_name = :G_CHAT_HISTORY'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64071771871898497)
,p_plug_name=>'Chat History'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(64370817536495902)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select seq_id, c001, clob001, n001, n002, n003',
'from apex_collections',
'where collection_name = :G_CHAT_HISTORY order by seq_id desc'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(64071888242898498)
,p_region_id=>wwv_flow_imp.id(64071771871898497)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'C001'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'CLOB001'
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if N001/}',
'prompt_tokens: &N001. completion_tokens: &N002. total_tokens: &N003.',
'{endif/}'))
,p_media_adv_formatting=>false
,p_pk1_column_name=>'SEQ_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64071945551898499)
,p_plug_name=>'User Message'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(64429679680495931)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select * from apex_collections where collection_name = :G_CHAT_HISTORY'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64538615797496016)
,p_plug_name=>'Chat with Generative AI'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(64396724592495915)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64071462123898494)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(64071328990898492)
,p_button_name=>'SET_SYSTEM_MESSAGE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(64502595670495973)
,p_button_image_alt=>'Set System Message'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64072219275898501)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(64071945551898499)
,p_button_name=>'SEND_USER_MESSAGE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(64502595670495973)
,p_button_image_alt=>'Send User Message'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64072546372898505)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(64538615797496016)
,p_button_name=>'INIT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(64502595670495973)
,p_button_image_alt=>'Start New Conversation'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.:INIT_CONVERSATION:&DEBUG.:::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3624139264973805)
,p_name=>'P1_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>50
,p_prompt=>'Response'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(64500141221495972)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3624304582973807)
,p_name=>'P1_FUNCTION_SET'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(64071945551898499)
,p_prompt=>'Function Set'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select function_set_name d, function_set_name r',
'from genai_functions group by function_set_name'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Function Set -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(64500141221495972)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64071416237898493)
,p_name=>'P1_SYSTEM_MESSAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(64071328990898492)
,p_item_default=>'You are a helpful assistant.'
,p_prompt=>'System Message'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(64500141221495972)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64072124054898500)
,p_name=>'P1_USER_MESSAGE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(64071945551898499)
,p_prompt=>'User Message'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(64500141221495972)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64073208706898511)
,p_name=>'P1_REQUEST'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_prompt=>'Request'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(64500141221495972)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(64071628849898495)
,p_name=>'onClick Set System Message'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(64071462123898494)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64071731270898496)
,p_event_id=>wwv_flow_imp.id(64071628849898495)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_collection.add_member(',
'        p_collection_name => :G_CHAT_HISTORY',
'        ,p_c001 => ''system''',
'        ,p_clob001 => :P1_SYSTEM_MESSAGE',
'    );',
'end;'))
,p_attribute_02=>'P1_SYSTEM_MESSAGE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64072666289898506)
,p_event_id=>wwv_flow_imp.id(64071628849898495)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(64072303188898502)
,p_name=>'onClick Send User Message'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(64072219275898501)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64072379491898503)
,p_event_id=>wwv_flow_imp.id(64072303188898502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    utl_genai_api.chat(',
'        p_content          => :P1_USER_MESSAGE',
'        ,p_collection_name => :G_CHAT_HISTORY',
'        ,p_api_endpoint    => :G_API_ENDPOINT',
'        ,p_model_name      => :G_MODEL_NAME',
'        ,p_credential_static_id => :G_CREDENTIAL',
'        ,p_response_format => ''text''',
'        ,p_function_set    => :P1_FUNCTION_SET',
'        ,p_request_out     => :P1_REQUEST',
'        ,p_response_out    => :P1_RESPONSE',
'    );',
'end;'))
,p_attribute_02=>'P1_USER_MESSAGE,P1_FUNCTION_SET'
,p_attribute_03=>'P1_REQUEST,P1_RESPONSE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64072506517898504)
,p_event_id=>wwv_flow_imp.id(64072303188898502)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(64071771871898497)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3624242631973806)
,p_event_id=>wwv_flow_imp.id(64072303188898502)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_USER_MESSAGE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(64071159228898491)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init Conversation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if not apex_collection.collection_exists(:G_CHAT_HISTORY) then',
'        apex_collection.create_collection(:G_CHAT_HISTORY);',
'    end if;',
'    if :REQUEST = ''INIT_CONVERSATION'' then',
'        apex_collection.create_or_truncate_collection(:G_CHAT_HISTORY);',
'        :P1_REQUEST := '''';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>60756298675943361
);
wwv_flow_imp.component_end;
end;
/
