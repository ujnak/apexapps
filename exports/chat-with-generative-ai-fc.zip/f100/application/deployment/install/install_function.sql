prompt --application/deployment/install/install_function
begin
--   Manifest
--     INSTALL: INSTALL-function
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2138965587838225
,p_default_application_id=>100
,p_default_id_offset=>3314860552955130
,p_default_owner=>'APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3670514712258659)
,p_install_id=>wwv_flow_imp.id(3667417564210927)
,p_name=>'function'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace function get_current_weather(',
'    p_args in clob',
')',
'return clob',
'as',
'    l_args json_object_t;',
'    l_location varchar2(400);',
'    l_location_tokens apex_t_varchar2;',
'    l_lat number;',
'    l_lon number;',
'    l_url varchar2(4000);',
'    l_response clob;',
'    l_response_json json_object_t;',
'    l_weathercode number;',
'    l_weather varchar2(4000);',
'begin',
'    l_args := json_object_t(p_args);',
'    l_location := l_args.get_string(''location'');',
'    /* get first part (city name) from the location */',
'    l_location_tokens := apex_string.split(l_location, ''[ ,]'');',
'    l_location := l_location_tokens(1);',
'    /*',
unistr('     * \90FD\5E02\540D\304B\3089\7DEF\5EA6\7D4C\5EA6\306E\60C5\5831\3092\53D6\308A\51FA\3059\3002'),
unistr('     * \30A2\30DE\30CE\6280\7814\3055\3093\3088\308A\63D0\4F9B\3055\308C\3066\3044\308B\300C\4E16\754C\306E\767E\4E07\90FD\5E02\306E\4F4D\7F6E\30C7\30FC\30BF Location Data of Megacities\300D\306E'),
unistr('     * CSV\30D5\30A1\30A4\30EB\3092\8868AMANO_CITY_LOCATIONS\306B\30ED\30FC\30C9\3057\3066\3044\307E\3059\3002'),
unistr('     * \53C2\7167: https://amano-tec.com/data/megacities.html'),
'     */',
'    select lat, lon into l_lat, l_lon ',
'    from amano_city_locations',
'    where upper(capital_en) = upper(l_location) or capital_jp = l_location;',
'    /*',
unistr('     * Open-Meteo.com\306EAPI\3092\547C\3073\51FA\3057\3001\6307\5B9A\3057\305F\5EA7\6A19\306E\73FE\5728\306E\5929\6C17\3092\53D6\5F97\3057\3066\3044\307E\3059\3002'),
unistr('     * \53C2\7167: https://open-meteo.com'),
'     */',
'    l_url := ''https://api.open-meteo.com/v1/forecast?latitude='' || l_lat || ''&longitude='' || l_lon || ''&current=weathercode'';',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_url',
'        ,p_http_method => ''GET''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        return ''{ "error": "open-meteo.com api call failed, response = '' || l_response || ''" }'';',
'    end if;',
'    l_response_json := json_object_t(l_response);',
'    /*',
unistr('     * Weather Code (WMO 4501)\306E\30B3\30FC\30C9\306E\8AAC\660E\306F\4EE5\4E0B\306E\6C17\8C61\95A2\4FC2\30B3\30FC\30C9\8868\306EWMO 4501\306E\90E8\5206\3092'),
unistr('     * \8868WMO4501\3068\3057\3066\8AAD\307F\8FBC\3093\3067\3044\307E\3059\3002'),
unistr('     * \53C2\7167: https://www.jodc.go.jp/data_format/weather-code_j.html'),
'     */',
'    l_weathercode := l_response_json.get_object(''current'').get_number(''weathercode'');',
'    select description into l_weather from wmo4501 where code = l_weathercode;',
'    return ''{ "weather" : "'' || l_weather || ''" }'';',
'exception',
'    when no_data_found then',
'        return ''{ "error": "no data found" }'';',
'end get_current_weather;',
'/ '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(3670601417258669)
,p_script_id=>wwv_flow_imp.id(3670514712258659)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'GET_CURRENT_WEATHER'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20240419093444','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20240419093444','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
