prompt --application/deployment/install/install_seeddata
begin
--   Manifest
--     INSTALL: INSTALL-seeddata
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2138965587838225
,p_default_application_id=>100
,p_default_id_offset=>3314860552955130
,p_default_owner=>'APEXDEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3669708462249585)
,p_install_id=>wwv_flow_imp.id(3667417564210927)
,p_name=>'seeddata'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
unistr('    --AMANO_CITY_LOCATIONS: 521/10000 \884C\304C\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\307E\3057\305F, APEX$DATA$PKG/AMANO_CITY_LOCATIONS$245909'),
'    apex_data_install.load_supporting_object_data(p_table_name => ''AMANO_CITY_LOCATIONS'', p_delete_after_install => true );',
unistr('    --GENAI_FUNCTIONS: 1/10000 \884C\304C\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\307E\3057\305F, APEX$DATA$PKG/GENAI_FUNCTIONS$177887'),
'    apex_data_install.load_supporting_object_data(p_table_name => ''GENAI_FUNCTIONS'', p_delete_after_install => true );',
unistr('    --WMO4501: 10/10000 \884C\304C\30A8\30AF\30B9\30DD\30FC\30C8\3055\308C\307E\3057\305F, APEX$DATA$PKG/WMO4501$10033'),
'    apex_data_install.load_supporting_object_data(p_table_name => ''WMO4501'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
