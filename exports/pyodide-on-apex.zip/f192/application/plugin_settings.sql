prompt --application/plugin_settings
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>192
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105385261963780095)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'include_slider', 'Y')).to_clob
,p_version_scn=>41793554446206
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105385542458780099)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attribute_01=>'FULL'
,p_attribute_02=>'POPUP'
,p_version_scn=>41793554446361
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105385805181780100)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SELECT_MANY'
,p_attribute_01=>'separated'
,p_version_scn=>41793554446385
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105386122374780101)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_MAP_REGION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_vector_tile_layers', 'Y')).to_clob
,p_version_scn=>41793554446388
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105386426013780101)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attribute_01=>'fa-star'
,p_attribute_04=>'#VALUE#'
,p_version_scn=>41793554446388
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105386783444780102)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_ADFBC'
,p_version_scn=>41793554446394
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105387058076780103)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'actions_menu_structure', 'IG')).to_clob
,p_version_scn=>41793554446400
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105387343832780104)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attribute_01=>'Y'
,p_attribute_03=>'N'
,p_attribute_05=>'SWITCH_CB'
,p_version_scn=>41793554446410
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105387622299780105)
,p_plugin_type=>'DYNAMIC ACTION'
,p_plugin=>'NATIVE_OPEN_AI_ASSISTANT'
,p_version_scn=>41793554446420
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105387973946780106)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_APEX'
,p_attribute_01=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_02=>'VISIBLE'
,p_attribute_03=>'15'
,p_attribute_04=>'FOCUS'
,p_version_scn=>41793554446426
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105388114355780107)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_GEOCODED_ADDRESS'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_attribute_02=>'N'
,p_attribute_03=>'POPUP:ITEM'
,p_attribute_04=>'default'
,p_attribute_06=>'LIST'
,p_version_scn=>41793554446432
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105388402938780107)
,p_plugin_type=>'PROCESS TYPE'
,p_plugin=>'NATIVE_GEOCODING'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_version_scn=>41793554446444
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(105388790930780108)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_version_scn=>41793554446447
);
wwv_flow_imp.component_end;
end;
/
