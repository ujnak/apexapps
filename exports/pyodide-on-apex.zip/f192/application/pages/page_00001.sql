prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>7582124972789269
,p_default_application_id=>192
,p_default_id_offset=>105710141672843150
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Pyodide'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/pyodide/v0.26.3/full/pyodide.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var pyodide;',
'',
'async function main() {',
'  pyodide = await loadPyodide();',
'',
'  /*',
unistr('   * \8FFD\52A0\306E\30E9\30A4\30D6\30E9\30EA\306E\8AAD\307F\8FBC\307F\306E\4F8B'),
'   * Ref:',
'   * https://pyodide.org/en/stable/usage/packages-in-pyodide.html',
'   */',
'  await pyodide.loadPackage(''scikit-learn'');',
'',
'  pyodide.setStdout({',
'    batched: (msg) => {',
'        let smsg = apex.item("P1_OUTPUT").getValue();',
'        apex.item("P1_OUTPUT").setValue(`${smsg}\n${msg}`);',
'    }',
'  });',
'',
'  // Pyodide is now ready to use...',
'  console.log(pyodide.runPython(`',
'    import sys',
'    sys.version',
'  `));',
'};'))
,p_javascript_code_onload=>'main();'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(207288793881185500)
,p_button_sequence=>20
,p_button_name=>'RUN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(211276697154623827)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Run'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(211404150340646854)
,p_button_sequence=>30
,p_button_name=>'CLEAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(211276697154623827)
,p_button_image_alt=>'Clear'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105694598547803709)
,p_name=>'P1_OUTPUT'
,p_item_sequence=>50
,p_prompt=>'Output'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>15
,p_field_template=>wwv_flow_imp.id(211274156200623817)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(207288697449185499)
,p_name=>'P1_CODE'
,p_item_sequence=>10
,p_prompt=>'Code'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>15
,p_field_template=>wwv_flow_imp.id(211274156200623817)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(211403995215646852)
,p_name=>'onClick runPython'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(207288793881185500)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211404087044646853)
,p_event_id=>wwv_flow_imp.id(211403995215646852)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'pyodide.runPython(apex.items.P1_CODE.value);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(211404262777646855)
,p_name=>'onClick CLEAR'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(211404150340646854)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211404393985646856)
,p_event_id=>wwv_flow_imp.id(211404262777646855)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_CODE,P1_OUTPUT'
);
wwv_flow_imp.component_end;
end;
/
