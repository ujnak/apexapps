prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2543608252682513
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Ebmj File'
,p_alias=>'EBMJ-FILE'
,p_page_mode=>'MODAL'
,p_step_title=>'Ebmj File'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(5524390477777139)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20240527064312'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5826960132780772)
,p_plug_name=>'Ebmj File'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5560213855777497)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'EBMJ_FILES'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5832783537780886)
,p_plug_name=>unistr('\30DC\30BF\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5563074679777510)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5833124873780889)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5832783537780886)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5700046370778394)
,p_button_image_alt=>unistr('\53D6\6D88')
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5834581916780914)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5832783537780886)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(5700046370778394)
,p_button_image_alt=>unistr('\524A\9664')
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5834906750780916)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(5832783537780886)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5700046370778394)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\5909\66F4\306E\9069\7528')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5835371461780918)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(5832783537780886)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5700046370778394)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\4F5C\6210')
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5827298523780776)
,p_name=>'P3_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_item_source_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_use_cache_before_default=>'NO'
,p_prompt=>'ID'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(5698896116778359)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5827600595780831)
,p_name=>'P3_TITLE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_item_source_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Title'
,p_source=>'TITLE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(5698896116778359)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5828056187780837)
,p_name=>'P3_CONTENT'
,p_source_data_type=>'BLOB'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_item_source_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Content'
,p_source=>'CONTENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(5697564013778341)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_06=>'Y'
,p_attribute_08=>'attachment'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5828454870780840)
,p_name=>'P3_CONTENT_FILENAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_item_source_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Content Filename'
,p_source=>'CONTENT_FILENAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_cSize=>32
,p_cMaxlength=>255
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(5697564013778341)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5828888542780843)
,p_name=>'P3_CONTENT_MIMETYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_item_source_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Content Mimetype'
,p_source=>'CONTENT_MIMETYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_cSize=>32
,p_cMaxlength=>255
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(5697564013778341)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5829231312780846)
,p_name=>'P3_CONTENT_CHARSET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_item_source_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Content Charset'
,p_source=>'CONTENT_CHARSET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_cSize=>32
,p_cMaxlength=>255
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(5697564013778341)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5829630724780849)
,p_name=>'P3_CONTENT_LASTUPD'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_item_source_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Content Lastupd'
,p_source=>'CONTENT_LASTUPD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(5697564013778341)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5830033917780858)
,p_name=>'P3_TEXT'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_item_source_plug_id=>wwv_flow_imp.id(5826960132780772)
,p_prompt=>'Text'
,p_source=>'TEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(5697564013778341)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(5523037150777063)
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5833222553780889)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(5833124873780889)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5834076154780908)
,p_event_id=>wwv_flow_imp.id(5833222553780889)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5836192454780924)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(5826960132780772)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('\30D7\30ED\30BB\30B9\30FB\30D5\30A9\30FC\30E0Ebmj File')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>5836192454780924
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5588243249702129)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Extract, Chunking and Embedding'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>5588243249702129
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5836539695780926)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>unistr('\30C0\30A4\30A2\30ED\30B0\3092\9589\3058\308B')
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>5836539695780926
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5835786393780921)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(5826960132780772)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('\521D\671F\5316\30D5\30A9\30FC\30E0Ebmj File')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>5835786393780921
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5588339907702130)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(5588243249702129)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Extract'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_PARAMS constant json := json(',
'            json_object(',
'                key ''plaintext'' value true',
'                ,key ''charset''  value ''UTF8''',
'            )',
'        );',
'    C_FILE_ID constant number := :P3_ID;',
'    l_content blob;',
'    l_text    clob;',
'begin',
'    select content into l_content from ebmj_files where id = C_FILE_ID;',
'    l_text := dbms_vector_chain.utl_to_text(',
'        data => l_content',
'        ,params => C_PARAMS',
'    );',
'    update ebmj_files set text = l_text where id = C_FILE_ID;',
' end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>5588339907702130
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5588460787702131)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(5588243249702129)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Chunking'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_FILE_ID constant number := :P3_ID;',
'    l_text clob;',
'begin',
'    select text into l_text from ebmj_files where id = C_FILE_ID;',
'    delete from ebmj_chunks where id = C_FILE_ID;',
'    insert into ebmj_chunks(file_id, chunk_id, chunk_offset, chunk_length, chunk_data)',
'    select C_FILE_ID file_id, rownum chunk_id, t.chunk_offset, t.chunk_length, t.chunk_text chunk_data',
'    from vector_chunks(',
'        l_text',
'        by words',
'        max 300',
'        overlap 0',
'        split by recursively',
'        language japanese',
'        normalize all',
'    ) t;',
' end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>5588460787702131
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5588553057702132)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(5588243249702129)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Embedding'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    C_FILE_ID constant number := :P3_ID;',
'    l_chunks vector_array_t;',
'    l_chunk json_object_t;',
'    l_vectors vector_array_t;',
'    l_embedding json_array_t;',
'begin',
unistr('    -- \30C1\30E3\30F3\30AF\306E\914D\5217\3092\4F5C\6210\3059\308B'),
'    l_chunks := vector_array_t();',
'    for r in (',
'        select chunk_id, chunk_offset, chunk_length, chunk_data',
'        from ebmj_chunks where file_id = C_FILE_ID order by chunk_id asc',
'    )',
'    loop',
'        l_chunks.extend;',
'        l_chunk := json_object_t();',
'        l_chunk.put(''chunk_id'',     r.chunk_id);',
'        l_chunk.put(''chunk_offset'', r.chunk_offset);',
'        l_chunk.put(''chunk_length'', r.chunk_length);',
'        l_chunk.put(''chunk_data'',   r.chunk_data);',
'        apex_debug.info(''l_chunks(%s) = %s'', r.chunk_id, r.chunk_data);',
'        l_chunks(r.chunk_id) := l_chunk.to_clob();',
'    end loop;',
unistr('    -- \30C1\30E3\30F3\30AF\306E\914D\5217\304B\3089\30D9\30AF\30C8\30EB\FF08\30A8\30F3\3079\30C7\30A3\30F3\30B0\FF09\306E\914D\5217\3092\751F\6210\3059\308B\3002'),
'    l_vectors := dbms_vector_chain.utl_to_embeddings(',
'        data => l_chunks',
'        ,params => JSON(json_object(',
'            key ''provider'' value ''OpenAI''',
'            ,key ''credential_name'' value ''OPENAI_CRED''',
'            ,key ''url'' value ''http://host.docker.internal:8080/v1/embeddings''',
'            ,key ''model'' value ''text-embedding-3-small''',
'            ,key ''batch_size'' value 10',
'            ,key ''transfer_timeout'' value 60',
'            )',
'        )',
'    );',
unistr('    -- \30A8\30F3\3079\30C7\30A3\30F3\30B0\3092\4FDD\5B58\3059\308B'),
'    for i in l_vectors.first .. l_vectors.last',
'    loop',
'        apex_debug.info(''l_vectors(%s) = %s'', i, l_vectors(i));',
'        update ebmj_chunks set embed_vector = to_vector(l_vectors(i))',
'        where file_id = C_FILE_ID and chunk_id = i;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>5588553057702132
);
wwv_flow_imp.component_end;
end;
/
