prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2543608252682513
,p_default_application_id=>103
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Sample Vector Search'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20240527083011'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5825733027780639)
,p_plug_name=>'Sample Vector Search'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(5593530489777658)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5589287653702139)
,p_name=>'P1_QUERY'
,p_item_sequence=>10
,p_prompt=>'Query'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(5697564013778341)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5589319089702140)
,p_name=>'P1_ANSWER'
,p_data_type=>'CLOB'
,p_item_sequence=>20
,p_prompt=>'Answer'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(5697564013778341)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5589435209702141)
,p_name=>'P1_PROMPT'
,p_data_type=>'CLOB'
,p_item_sequence=>30
,p_prompt=>'Prompt'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(5697564013778341)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5589590387702142)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generate Answer'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_vector_q vector;',
'    l_prompt   clob;',
'    l_answer   clob;',
'    l_norm     clob;',
'begin',
unistr('    -- \554F\5408\305B\6587\5B57\5217\306E\30A8\30F3\3079\30C7\30A3\30F3\30B0\3092\53D6\5F97\3059\308B'),
'    l_vector_q := dbms_vector_chain.utl_to_embedding(',
'            data => :P1_QUERY',
'            ,params => JSON(json_object(',
'                key ''provider'' value ''OpenAI''',
'                ,key ''credential_name'' value ''OPENAI_CRED''',
'                ,key ''url'' value ''http://host.docker.internal:8080/v1/embeddings''',
'                ,key ''model'' value ''text-embedding-3-small''',
'                ,key ''transfer_timeout'' value 60',
'                )',
'            )',
'        );',
unistr('    -- \30D7\30ED\30F3\30D7\30C8\3092\751F\6210\3059\308B'),
unistr('    l_prompt := l_prompt || ''\4EE5\4E0B\306B\4E0E\3048\308B\60C5\5831\3092\5143\306B\3001\6700\5F8C\306E\8CEA\554F\306B\56DE\7B54\3057\3066\304F\3060\3055\3044\3002'';'),
'    l_prompt := l_prompt || apex_application.CRLF;',
unistr('    -- \30D9\30AF\30C8\30EB\691C\7D22\3092\884C\3063\3066\3001\30D7\30ED\30F3\30D7\30C8\306B\691C\7D22\3055\308C\305F\30C1\30E3\30F3\30AF\3092\57CB\3081\8FBC\3080'),
'    for r in (',
'        select chunk_data',
'        from ebmj_chunks',
'        order by vector_distance(l_vector_q, embed_vector) asc',
'        fetch first 2 partitions by file_id, 2 rows only',
'    )',
'    loop',
'        l_prompt := l_prompt || ''--------------------------'';',
'        l_prompt := l_prompt || apex_application.CRLF;',
'        l_norm := r.chunk_data;',
unistr('        -- CR\3068LF\3092\53D6\308A\9664\304F\3002'),
'        l_norm := replace(l_norm, chr(10));',
'        l_norm := replace(l_norm, chr(13));',
'        l_prompt := l_prompt || l_norm;',
'        l_prompt := l_prompt || apex_application.CRLF;',
'    end loop;',
'    l_prompt := l_prompt || ''--------------------------'';',
'    l_prompt := l_prompt || apex_application.CRLF;',
'    l_prompt := l_prompt || :P1_QUERY;',
unistr('    -- \56DE\7B54\3092\751F\6210\3059\308B'),
'    apex_debug.info(l_prompt);',
'    utl_http.set_body_charset(''utf-8'');',
'    l_answer := dbms_vector_chain.utl_to_generate_text(',
'        data => l_prompt',
'        ,params => JSON(json_object(',
'            key ''provider'' value ''OpenAI''',
'            ,key ''credential_name'' value ''OPENAI_CRED''',
'            ,key ''url'' value ''http://host.docker.internal:8080/v1/chat/completions?''',
'            ,key ''model'' value ''gpt-3.5-turbo''',
'            ,key ''transfer_timeout'' value 160',
'            ,key ''max_tokens'' value 260',
'            -- ,key ''temerature'' value 1.0',
'            )',
'        )',
'    );',
'    :P1_ANSWER := l_answer;',
unistr('    -- \30C7\30D0\30C3\30B0\7528\306B\30D7\30ED\30F3\30D7\30C8\3092\8868\793A\3059\308B'),
'    :P1_PROMPT := l_prompt;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P1_QUERY'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>5589590387702142
);
wwv_flow_imp.component_end;
end;
/
