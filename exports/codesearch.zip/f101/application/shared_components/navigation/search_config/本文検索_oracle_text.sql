prompt --application/shared_components/navigation/search_config/本文検索_oracle_text
begin
--   Manifest
--     SEARCH CONFIG: 本文検索 - Oracle Text
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>101
,p_default_id_offset=>42206722767460109
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(49090274574620907651)
,p_label=>unistr('\672C\6587\691C\7D22 - Oracle Text')
,p_static_id=>'content_text'
,p_search_prefix=>'content-text'
,p_search_type=>'TEXT_MANUAL'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'CDS_DOCUMENTS'
,p_oratext_index_column_name=>'CONTENT'
,p_pk_column_name=>'ID'
,p_title_column_name=>'TITLE'
,p_custom_01_column_name=>'URL'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-file-text-o'
);
wwv_flow_imp.component_end;
end;
/
