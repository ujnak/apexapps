prompt --application/shared_components/navigation/lists/アプリケーション管理
begin
--   Manifest
--     LIST: アプリケーション管理
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>101
,p_default_id_offset=>42206722767460109
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(49086851662388200349)
,p_name=>unistr('\30A2\30D7\30EA\30B1\30FC\30B7\30E7\30F3\7BA1\7406')
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(49086852028933200349)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Attachments'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>unistr('\30B3\30F3\30DD\30FC\30CD\30F3\30C8\306E\7BA1\7406')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(49086852451391200349)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Documents'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>unistr('\30B3\30F3\30DD\30FC\30CD\30F3\30C8\306E\7BA1\7406')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
