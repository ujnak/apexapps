prompt --application/shared_components/user_interface/lovs/cds_documents_title
begin
--   Manifest
--     CDS_DOCUMENTS.TITLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>101
,p_default_id_offset=>42206722767460109
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(49086795777000199811)
,p_lov_name=>'CDS_DOCUMENTS.TITLE'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'CDS_DOCUMENTS'
,p_return_column_name=>'ID'
,p_display_column_name=>'TITLE'
,p_default_sort_column_name=>'TITLE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
