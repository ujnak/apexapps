prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>101
,p_default_id_offset=>42206722767460109
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30B3\30FC\30C9\691C\7D22')
,p_alias=>'HOME'
,p_step_title=>unistr('\30B3\30FC\30C9\691C\7D22')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_deep_linking=>'Y'
,p_rejoin_existing_sessions=>'P'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230207050026'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49093324025574092135)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49086695913897199624)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(49086580749502199571)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(49086757961864199655)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49093324653037092136)
,p_plug_name=>unistr('\691C\7D22\7D50\679C')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(49086680755762199617)
,p_plug_display_sequence=>20
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_attribute_02=>'Y'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="a-ResultsItem &RESULT_CSS_CLASSES!ATTR.">',
'  {if ?ICON_VALUE/}',
'    {case ICON_TYPE/}',
'      {when INITIALS/}',
'        <div class="a-ResultItem-initials u-color-var">&ICON_VALUE.</div>',
'      {when URL/}',
'        <div class="a-ResultItem-image"><img src="&ICON_VALUE!ATTR." alt="&TITLE!ATTR." role="presentation" /></div>',
'      {when CLASS/}',
'        <div class="a-ResultItem-icon u-color-var"><span class="fa &ICON_VALUE!ATTR." aria-hidden="true"></span></div>',
'    {endcase/}',
'  {endif/}',
'  <div class="a-ResultsItem-content">',
'    <div class="a-ResultsItem-header">',
'      {if ?LINK/}',
'        <span class="a-ResultsItem-title"><a href="&LINK!ATTR.">&TITLE.</a></span>',
'      {else/}',
'        <span class="a-ResultsItem-title">&TITLE.</span>',
'      {endif/}',
'      {if ?BADGE/}<span class="a-ResultsItem-badge">&BADGE.</span>{endif/}',
'    </div>',
'    {if ?SUBTITLE/}<div class="a-ResultsItem-subTitle">&SUBTITLE.</div>{endif/}',
'    {if ?DESCRIPTION/}<div class="a-ResultsItem-description">&DESCRIPTION.</div>{endif/}',
'    {if ?HAS_CUSTOM_ATTRS/}',
'      <div class="a-ResultsItem-attributes">',
'        {if ?CUSTOM_01/}<a href="&CUSTOM_01." target="_blank">&CUSTOM_01.</a>{endif/}',
'        {if ?CUSTOM_02/}<a href="&CUSTOM_02." target="_blank">&CUSTOM_02.</a>{endif/}',
'        {if ?CUSTOM_03/}<span class="a-ResultsItem-attribute">&CUSTOM_03.</span>{endif/}',
'      </div>',
'    {endif/}',
'    {if ?LAST_MODIFIED/}<div class="a-ResultsItem-misc">&LAST_MODIFIED.</div>{endif/}',
'  </div>',
'</div>'))
,p_attribute_04=>'N'
,p_attribute_05=>'P1_SEARCH'
,p_attribute_06=>'N'
,p_attribute_11=>'Y'
,p_attribute_14=>'15'
,p_attribute_15=>'Y'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(49093325123135092136)
,p_region_id=>wwv_flow_imp.id(49093324653037092136)
,p_search_config_id=>wwv_flow_imp.id(49106264892954979767)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>unistr('\30B3\30FC\30C9\691C\7D22')
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(49093325625843092137)
,p_region_id=>wwv_flow_imp.id(49093324653037092136)
,p_search_config_id=>wwv_flow_imp.id(49104454930601420616)
,p_use_as_initial_result=>false
,p_display_sequence=>20
,p_name=>unistr('\672C\6587\691C\7D22 ')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49093326188334092137)
,p_name=>'P1_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(49093324025574092135)
,p_item_display_point=>'SMART_FILTERS'
,p_prompt=>unistr('\691C\7D22')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_field_template=>wwv_flow_imp.id(49086753529640199652)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'SEARCH'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
