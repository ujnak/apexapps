prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>223
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>unistr('\30A4\30E9\30B9\30C8\30EC\30FC\30B7\30E7\30F3\30FB\30AC\30A4\30C9\30E9\30A4\30F3')
,p_alias=>unistr('\30A4\30E9\30B9\30C8\30EC\30FC\30B7\30E7\30F3-\30AC\30A4\30C9\30E9\30A4\30F3')
,p_step_title=>unistr('\30A4\30E9\30B9\30C8\30EC\30FC\30B7\30E7\30F3\30FB\30AC\30A4\30C9\30E9\30A4\30F3')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'09'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230629045228'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31674897627259701)
,p_plug_name=>unistr('\30AC\30A4\30C9\30E9\30A4\30F3')
,p_region_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="height: 1000px;"'
,p_plug_template=>wwv_flow_imp.id(31340322722029856)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_URL'
,p_attribute_01=>'#WORKSPACE_FILES#/designsystem-assets/icon/icon_guideline.pdf'
,p_attribute_02=>'IFRAME'
,p_attribute_03=>'style="width: 100%; height: 100%;" type="application/pdf"'
);
wwv_flow_imp.component_end;
end;
/
