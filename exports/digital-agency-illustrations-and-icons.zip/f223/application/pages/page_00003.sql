prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>223
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>unistr('\30A2\30A4\30B3\30F3')
,p_alias=>unistr('\30A2\30A4\30B3\30F3')
,p_step_title=>unistr('\30A2\30A4\30B3\30F3')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(31313391315029836)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'24'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230629022635'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31666721067439133)
,p_plug_name=>unistr('\30D6\30EC\30C3\30C9\30AF\30E9\30E0')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(31417908971029903)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(31302226997029813)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(31480330983029959)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31667404592439136)
,p_plug_name=>unistr('\691C\7D22')
,p_parent_plug_id=>wwv_flow_imp.id(31666721067439133)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(31340322722029856)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SMART_FILTERS'
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(31667306284439136)
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31667306284439136)
,p_plug_name=>unistr('\691C\7D22\7D50\679C')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(31341788136029856)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    workspace_file_id, file_name, mime_type, file_charset, to_clob(file_content) file_content, last_updated_on',
'    , replace(file_name,''designsystem-assets/icon/svg/'','''') as file_name_short',
'    , ''#'' || ''WORKSPACE_FILES'' || ''#'' || file_name as file_name_long',
'from apex_workspace_static_files',
'where file_name like ''designsystem-assets/icon/svg/%.svg''',
'    and workspace_id = :WORKSPACE_ID'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P3_ORDER_BY", "orderBys": [{"key":"FILE_NAME_SHORT","expr":"\"FILE_NAME_SHORT\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(31668665458439137)
,p_region_id=>wwv_flow_imp.id(31667306284439136)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'FILE_NAME_SHORT'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>'&FILE_CONTENT!RAW.'
,p_second_body_adv_formatting=>false
,p_second_body_column_name=>'FILE_NAME_LONG'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'WORKSPACE_FILE_ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31667990884439136)
,p_name=>'P3_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(31667404592439136)
,p_prompt=>unistr('\691C\7D22')
,p_source=>'FILE_NAME_SHORT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31669121493439138)
,p_name=>'P3_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(31667306284439136)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_item_default=>'FILE_NAME_SHORT'
,p_prompt=>unistr('\4E26\66FF\3048\57FA\6E96')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:File Name Short;FILE_NAME_SHORT'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(31476297225029953)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
