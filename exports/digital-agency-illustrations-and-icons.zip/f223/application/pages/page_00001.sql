prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>223
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>unistr('\30C7\30B8\30BF\30EB\5E81 - \30A4\30E9\30B9\30C8\30EC\30FC\30B7\30E7\30F3\30FB\30A2\30A4\30B3\30F3\7D20\6750')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.fast-track-line {',
'    background-image: url(#WORKSPACE_FILES#designsystem-assets/icon/svg/fast_track_line.svg);',
'    background-repeat: no-repeat;',
'    display: block;',
'    background-position: center center;',
'    background-size: contain;',
'    width: 48px;',
'    height: 48px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20230629025017'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31598058061030140)
,p_plug_name=>unistr('\30C7\30B8\30BF\30EB\5E81 - \30A4\30E9\30B9\30C8\30EC\30FC\30B7\30E7\30F3\30FB\30A2\30A4\30B3\30F3\7D20\6750')
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(31389779876029884)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29021963761893947)
,p_button_sequence=>10
,p_button_name=>'FAST_TRACK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(31478822284029957)
,p_button_image_alt=>'Fast Track'
,p_icon_css_classes=>'fast-track-line'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29022014265893948)
,p_name=>'P1_IMAGE'
,p_item_sequence=>20
,p_item_default=>'#WORKSPACE_FILES#designsystem-assets/illustration/png/l_01_rectangle_white.png'
,p_prompt=>'Image'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_field_template=>wwv_flow_imp.id(31476297225029953)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp.component_end;
end;
/
