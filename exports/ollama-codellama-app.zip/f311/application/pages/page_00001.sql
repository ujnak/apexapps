prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>311
,p_default_id_offset=>56735176700902107
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'ChatGPT App'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.markdownHeight {',
'    height: 480px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'APEXDEV'
,p_last_upd_yyyymmddhh24miss=>'20240214051425'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(241873478544523472)
,p_plug_name=>'Ollama App'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(241731587339523371)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(241407082022925957)
,p_button_sequence=>30
,p_button_name=>'SEND_MESSAGE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(241837458417523429)
,p_button_image_alt=>'Send Message'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55098972356640931)
,p_name=>'P1_MODEL'
,p_item_sequence=>10
,p_item_default=>'codellama'
,p_prompt=>'Model'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(241835003968523428)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55099050835640932)
,p_name=>'P1_STATS'
,p_item_sequence=>70
,p_prompt=>'Stats'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(241835003968523428)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(181755317746008943)
,p_name=>'P1_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>60
,p_prompt=>'Response'
,p_display_as=>'NATIVE_MARKDOWN_EDITOR'
,p_tag_css_classes=>'markdownHeight'
,p_field_template=>wwv_flow_imp.id(241835003968523428)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(241406986801925956)
,p_name=>'P1_MESSAGE'
,p_is_required=>true
,p_item_sequence=>20
,p_prompt=>'Message'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(241835003968523428)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(241407165935925958)
,p_name=>'onClick Send Message'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(241407082022925957)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(241407242238925959)
,p_event_id=>wwv_flow_imp.id(241407165935925958)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_request json_object_t;',
'    l_request_clob clob;',
'    l_response clob;',
'    l_generated_message clob;',
'    e_call_api_failed exception;',
unistr('    /* \6539\884C\3054\3068\306BJSON\3092\8AAD\3080\969B\306B\4F7F\7528\3059\308B */'),
'    l_pos    integer;',
'    l_offset integer;',
'    l_amount integer;',
'    l_line   varchar2(32767);',
'    l_json   json_object_t;',
'    l_is_done boolean;',
'begin',
'    /* ',
unistr('     * Ollama\306EGenerate a completion\3092\547C\3073\51FA\3059\3002'),
'     * https://github.com/ollama/ollama/blob/main/docs/api.md',
'     */',
'    l_request := json_object_t();',
'    l_request.put(''model'', :P1_MODEL);',
'    l_request.put(''prompt'', :P1_MESSAGE);',
'    l_request_clob := l_request.to_clob();',
'    /*',
unistr('     * REST API\306E\547C\3073\51FA\3057\3002Always Free\306EAmpere A1\30A4\30F3\30B9\30BF\30F3\30B9\306F\9045\3044\306E\3067'),
unistr('     * p_transfer_timeout\306E\8A2D\5B9A\306F\5FC5\9808\3002'),
'     */',
'    apex_web_service.clear_request_headers();',
'    apex_web_service.set_request_headers(''Content-Type'', ''application/json'', p_reset => false);',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => :G_ENDPOINT',
'        ,p_http_method => ''POST''',
'        ,p_body => l_request_clob',
'        ,p_transfer_timeout => :G_TRANSFER_TIMEOUT',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_call_api_failed;',
'    end if;',
'    /* ',
unistr('     * \51FA\529B\306F\30C7\30D5\30A9\30EB\30C8\3067\30B9\30C8\30EA\30FC\30DF\30F3\30B0\3067\3001APEX\306E\5834\5408\3001Ollama\304C\5206\5272\3067\8FD4\3057\3066\3044\308B\30EC\30B9\30DD\30F3\30B9\304C'),
unistr('     * \3072\3068\3064\306E\30EC\30B9\30DD\30F3\30B9\3068\3057\3066\8FD4\3055\308C\308B\3002\305D\306E\305F\3081\3001\30EC\30B9\30DD\30F3\30B9\3092\6539\884C\3054\3068\306B\5206\5272\3057\3066\3001\305D\308C\305E\308C\3092'),
unistr('     * JSON\3068\3057\3066\89E3\91C8\3059\308B\5FC5\8981\304C\3042\308B\3002'),
'     */',
'    l_generated_message := '''';',
'    l_offset := 1;',
'    while true',
'    loop',
'        /* ',
unistr('         * LF\306E\4F4D\7F6E\3092\63A2\3059\3002 '),
unistr('         * \8FD4\3055\308C\308B\4F4D\7F6E\306Foffset\304B\3089\306E\76F8\5BFE\4F4D\7F6E\3067\306F\306A\304F\3001CLOB\306E\4E2D\3067\306E\7D76\5BFE\4F4D\7F6E\304C\8FD4\3055\308C\308B\3002'),
'        */',
'        l_pos := dbms_lob.instr(',
'            lob_loc  => l_response',
'            ,pattern => CHR(10)',
'            ,offset  => l_offset',
'        );',
unistr('        /* LF\304C\306A\3051\308C\3070\7D42\4E86 */'),
'        exit when ( l_pos = 0 );',
'        l_amount := l_pos - l_offset;',
unistr('        /* \FF11\884C\53D6\308A\51FA\3059 */'),
'        l_line := dbms_lob.substr(',
'            lob_loc => l_response',
'            ,amount => l_amount',
'            ,offset => l_offset',
'        );',
'        l_json := json_object_t(l_line);',
'        l_generated_message := l_generated_message || l_json.get_string(''response'');',
'        l_is_done := l_json.get_boolean(''done'');',
'        if l_is_done then',
unistr('            /* context\4EE5\5916\3092STATS\3068\3057\3066\5370\5237 */'),
'            l_json.remove(''context'');',
'            :P1_STATS := l_json.to_string();',
'        end if;',
unistr('        /* \6B21\306E\884C\3092\53D6\308A\51FA\3059 */'),
'        l_offset := l_pos + 1;',
'    end loop;',
'    :P1_RESPONSE := l_generated_message;',
'end;'))
,p_attribute_02=>'P1_MESSAGE,P1_MODEL'
,p_attribute_03=>'P1_RESPONSE,P1_STATS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(241406021975925947)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init Conversation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if not apex_collection.collection_exists(''CHATGPT'') then',
'        apex_collection.create_collection(''CHATGPT'');',
'    end if;',
'    if :REQUEST = ''INIT_CONVERSATION'' then',
'        apex_collection.create_or_truncate_collection(''CHATGPT'');',
'        :P1_REQUEST := '''';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>184670845275023840
);
wwv_flow_imp.component_end;
end;
/
