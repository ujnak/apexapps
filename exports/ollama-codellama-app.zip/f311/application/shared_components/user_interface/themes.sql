prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 311
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>311
,p_default_id_offset=>56735176700902107
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(241840437457523433)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(241688452655523349)
,p_default_dialog_template=>wwv_flow_imp.id(241683299347523347)
,p_error_template=>wwv_flow_imp.id(241673299085523342)
,p_printer_friendly_template=>wwv_flow_imp.id(241688452655523349)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(241673299085523342)
,p_default_button_template=>wwv_flow_imp.id(241837458417523429)
,p_default_region_template=>wwv_flow_imp.id(241764542427523387)
,p_default_chart_template=>wwv_flow_imp.id(241764542427523387)
,p_default_form_template=>wwv_flow_imp.id(241764542427523387)
,p_default_reportr_template=>wwv_flow_imp.id(241764542427523387)
,p_default_tabform_template=>wwv_flow_imp.id(241764542427523387)
,p_default_wizard_template=>wwv_flow_imp.id(241764542427523387)
,p_default_menur_template=>wwv_flow_imp.id(241776941779523392)
,p_default_listr_template=>wwv_flow_imp.id(241764542427523387)
,p_default_irr_template=>wwv_flow_imp.id(241754761458523382)
,p_default_report_template=>wwv_flow_imp.id(241802503526523408)
,p_default_label_template=>wwv_flow_imp.id(241835003968523428)
,p_default_menu_template=>wwv_flow_imp.id(241839046913523430)
,p_default_calendar_template=>wwv_flow_imp.id(241839111143523430)
,p_default_list_template=>wwv_flow_imp.id(241818862723523418)
,p_default_nav_list_template=>wwv_flow_imp.id(241830687925523425)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(241830687925523425)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(241825270871523422)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(241701370825523356)
,p_default_dialogr_template=>wwv_flow_imp.id(241698509142523355)
,p_default_option_label=>wwv_flow_imp.id(241835003968523428)
,p_default_required_label=>wwv_flow_imp.id(241836253610523429)
,p_default_navbar_list_template=>wwv_flow_imp.id(241824846943523422)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/23.2/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
