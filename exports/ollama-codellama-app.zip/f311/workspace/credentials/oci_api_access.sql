prompt --workspace/credentials/oci_api_access
begin
--   Manifest
--     CREDENTIAL: OCI API Access
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>8495821862623503
,p_default_application_id=>311
,p_default_id_offset=>56735176700902107
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(8715697685729597)
,p_name=>'OCI API Access'
,p_static_id=>'OCI_API_ACCESS'
,p_authentication_type=>'OCI'
,p_namespace=>'ocid1.tenancy.oc1..aaaaaaaakhphwqcdg4pfk2x55bg3pa5lpgbsvjeixf2y7vifeukbklctvbma'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
