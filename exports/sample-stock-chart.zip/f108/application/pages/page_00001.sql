prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>5936123940888413
,p_default_application_id=>108
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXDEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>unistr('\30DB\30FC\30E0')
,p_alias=>'HOME'
,p_step_title=>'Stock Chart'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15763503611877311)
,p_plug_name=>'Stock Chart'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    to_date(c001, ''YYYY-MM-DD'') as p_date,',
'    to_number(c002) as p_open,',
'    to_number(c003) as p_high,',
'    to_number(c004) as p_low,',
'    to_number(c005) as p_close,',
'    to_number(c006) as p_volume',
'from apex_collections where collection_name = ''STOCK_ARRAY_DATA''',
'order by p_date asc'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(15763665388877312)
,p_region_id=>wwv_flow_imp.id(15763503611877311)
,p_chart_type=>'stock'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stock_render_as=>'candlestick'
,p_zoom_and_scroll=>'live'
,p_initial_zooming=>'none'
,p_tooltip_rendered=>'Y'
,p_show_value=>true
,p_overview_rendered=>'on'
,p_time_axis_type=>'enabled'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(15763740344877313)
,p_chart_id=>wwv_flow_imp.id(15763665388877312)
,p_seq=>10
,p_name=>'Stock Price'
,p_location=>'REGION_SOURCE'
,p_items_low_column_name=>'P_LOW'
,p_items_high_column_name=>'P_HIGH'
,p_items_open_column_name=>'P_OPEN'
,p_items_close_column_name=>'P_CLOSE'
,p_items_volume_column_name=>'P_VOLUME'
,p_items_label_column_name=>'P_DATE'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(15763826624877314)
,p_chart_id=>wwv_flow_imp.id(15763665388877312)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(15763977860877315)
,p_chart_id=>wwv_flow_imp.id(15763665388877312)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16134766685847651)
,p_plug_name=>'Stock Chart'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15763260480877308)
,p_button_sequence=>20
,p_button_name=>'SHOW'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Show'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15763343232877309)
,p_name=>'P1_SYMBOL'
,p_item_sequence=>10
,p_prompt=>'Symbol'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15763428972877310)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Stock From Alpha Vantage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url varchar2(255);',
'    e_call_api_failed exception;',
'    l_information    varchar2(200);',
'    l_symbol         varchar2(10);',
'    l_last_refreshed date;',
'    l_output_size    varchar2(20);',
'    l_time_zone      varchar2(20);',
'    l_response       clob;',
'    l_response_json  json_object_t;',
'    l_meta_data      json_object_t;',
'    l_time_series_daily json_object_t;',
'    l_keys           json_key_list;',
'    l_key            varchar2(100);',
'    l_date_data      json_object_t;',
'begin',
'    l_url := ''https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol='' || :P1_SYMBOL;',
'    apex_web_service.set_request_headers(',
'        ''Content-Type'', ''application/json''',
'    );',
'    l_response := apex_web_service.make_rest_request(',
'        p_url => l_url',
'        ,p_http_method => ''GET''',
'        ,p_credential_static_id => ''ALPHAVANTAGE''',
'    );',
'    if apex_web_service.g_status_code <> 200 then',
'        raise e_call_api_failed;',
'    end if;',
'    l_response_json := json_object_t(l_response);',
'    l_meta_data      := l_response_json.get_object(''Meta Data'');',
'    l_information    := l_meta_data.get_string(''1. Information'');',
'    l_symbol         := l_meta_data.get_string(''2. Symbol'');',
'    l_last_refreshed := l_meta_data.get_date(''3. Last Refreshed'');',
'    l_output_size    := l_meta_data.get_string(''4. Output Size'');',
'    l_time_zone      := l_meta_data.get_string(''5. Time Zone'');',
'    l_time_series_daily := l_response_json.get_object(''Time Series (Daily)'');',
'    l_keys := l_time_series_daily.get_keys();',
'    apex_collection.create_or_truncate_collection(''STOCK_ARRAY_DATA'');',
'    for i in 1..l_keys.count loop',
'        l_key := l_keys(i);',
'        l_date_data := l_time_series_daily.get_object(l_key);',
'        apex_collection.add_member(',
'            p_collection_name => ''STOCK_ARRAY_DATA'',',
unistr('            p_c001 => l_key,  -- \65E5\4ED8'),
'            p_c002 => l_date_data.get_string(''1. open''),    -- open',
'            p_c003 => l_date_data.get_string(''2. high''),    -- high',
'            p_c004 => l_date_data.get_string(''3. low''),     -- low',
'            p_c005 => l_date_data.get_string(''4. close''),   -- close',
'            p_c006 => l_date_data.get_string(''5. volume'')   -- volume',
'        );',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>15763428972877310
);
wwv_flow_imp.component_end;
end;
/
